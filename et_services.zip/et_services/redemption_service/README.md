# Redemption Service
It contains user related API endpoints.

## Url Pattern
{{base-url}}/v1/
