"""
Calculate redeemability API
"""
import datetime

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from redemption_service.app.api.v1.validations.calculate_redeemability_validation import redeemability_parser
from redemption_service.common.base_resource import BaseGetResource
from redemption_service.common.models.offer_wl_active import OfferWlActive
from redemption_service.common.utils.authentication import get_current_customer, get_company
from redemption_service.modules.api_utils import calculate_redeemability, user_redemptions_lookup_hash, \
    fix_offer_valid_from_and_valid_to_dates

__author__ = 'kamalh@theentertainerasia.com'


class CalculateRedeemabilityAPI(BaseGetResource):

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/calculate_redeemability_api.log',
        ),
        'name': 'calculate_redeemability_api'
    }
    required_token = True
    strict_token = True

    request_parser = redeemability_parser

    def populate_request_arguments(self):
        self.offer_ids = self.request_args['offer_ids']

    def initialise_class_attributes(self):
        self.customer = get_current_customer()
        self.company = get_company()
        self.redemption_quantities = {}
        self.redeemability_response = {}

    def set_offer_validation_dates(self):
        self.current_date = datetime.datetime.now()
        self.date_from = self.current_date + datetime.timedelta(
            hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM
        )
        self.date_to = self.current_date + datetime.timedelta(hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)

    def get_offers_from_db(self):
        self.offers = []
        if self.customer['product_ids']:
            self.offers = OfferWlActive.get_by_offer_ids_and_product_ids(self.offer_ids, self.customer['product_ids'])

    def get_redemption_quantities(self):
        """
        Sets redemption quantities
        :return:
        """
        self.redemption_quantities = user_redemptions_lookup_hash(
            self.customer['user_id'],
            self.company,
            None
        )

    def process_offers(self):
        for offer in self.offers:
            # update offer valid from and expiration date by adding cushion
            offer = fix_offer_valid_from_and_valid_to_dates(offer)
            redeemability = calculate_redeemability(
                offer,
                self.customer['product_ids'],
                self.redemption_quantities,
                self.date_from, self.date_to
            )
            self.redeemability_response['{0}_{1}'.format(offer.id, offer.product_id)] = redeemability

    def generate_final_response(self):
        self.response = self.generate_response_dict(data=self.redeemability_response)
        self.send_response_flag = True
        self.status_code = codes.OK
        self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialise_class_attributes()
        self.set_offer_validation_dates()
        self.get_offers_from_db()
        self.get_redemption_quantities()
        self.process_offers()
        self.generate_final_response()
