"""
Insert entries in specific business tables after redemption.
    > CustomerOrder.
    > CustomerOrderHistory.
    > CustomerOrderData.
    > CustomerOrderItem.
"""
import time

from requests import codes
from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.utils.db_helpers import call_stored_procedure
from redemption_service.common.constants import ENTERTAINER_BUSINESS
from redemption_service.common.utils.authentication import get_current_customer, get_redemption_model, get_company
from redemption_service.common.models.customer_order_history import CustomerOrderHistory
from redemption_service.common.models.customer_order import CustomerOrder
from redemption_service.common.models.customer_order_data import CustomerOrderData
from redemption_service.common.models.customer_order_status import CustomerOrderStatus
from redemption_service.common.models.modules import Module
from redemption_service.common.models.customer_order_item import CustomerOrderItem
from redemption_service.app.api.v1.validations.business_db_update_validation import business_update_parser
from redemption_service.common.base_resource import BasePostResource
from redemption_service.common.models.offer import Offer
from redemption_service.common.models.outlet import Outlet
from redemption_service.common.models.product import Product
from redemption_service.modules.v1.business_module import BusinessModule
from redemption_service.common.utils.helpers import get_current_time_in_seconds


class BusinessDBUpdateAPI(BasePostResource):
    """
    @api {post} /v1/redeem/business_db_update Add entries to business tables.
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/business_db_update_api.log',
        ),
        'name': 'business_db_update'
    }
    request_parser = business_update_parser
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request args for API request.
        """
        self.redemption_id = self.request_args.get('r_i')
        self.module_name = self.request_args.get('module')
        self.locale = self.request_args.get('language')
        self.location_id = self.request_args.get('location_id')

    def initialize_modules(self):

        self.business_module = BusinessModule()

    def initialize_class_variables(self):
        """
        Initializes class variables to be used in request.
        """
        self.customer = get_current_customer()
        self.company = get_company()
        self.redemption_model = get_redemption_model()
        self.status_code = 200
        self.response_msg = 'success'

    def get_redemption_info(self):

        self.redemption = self.redemption_model.get_info(redemption_id=self.redemption_id)

    def get_customer_order_number(self):

        latest_order = CustomerOrder.get_latest_order_of_a_module(module_id=self.module.id)
        if latest_order and latest_order.order_number:
            latest_order_order_number = int(latest_order.order_number.split('-')[1]) + 1
        else:
            latest_order_order_number = 1

        order_number = '{0:09d}'.format(latest_order_order_number)
        self.order_number = '{module_prefix}-{number}-{epoch_suffix}'.format(
            module_prefix=self.module.order_prefix,
            number=order_number,
            epoch_suffix=str(get_current_time_in_seconds())[-4:]
        )

    def add_business_table_entries(self):
        """
        Updates the business tables.
        """
        customer_order_object = self.business_module.get_customer_order_object(
            customer=self.customer,
            redemption=self.redemption,
            outlet=self.outlet,
            module=self.module,
            order_number=self.order_number,
            completed_order_status_id=self.completed_order_status.id,
            location_id=self.location_id
        )
        customer_order = CustomerOrder.create_one(**customer_order_object)
        customer_order_id = customer_order.id
        customer_order_object['order_id'] = customer_order_id
        CustomerOrderHistory.add_item(**customer_order_object)
        # TODO: JSON of request and customer data not being inserted into DB?
        CustomerOrderData.add_entry(order_id=customer_order_id)

        customer_order_item_obj = self.business_module.get_customer_order_item_object(
            customer_order_id=customer_order_id,
            offer=self.offer,
            redemption=self.redemption,
            product=self.product
        )
        CustomerOrderItem.add_item(**customer_order_item_obj)
        time.sleep(5)   # TODO: Remove sleep. For testing purposes only.
        call_stored_procedure(
            schema=ENTERTAINER_BUSINESS,
            sp_name='sp_merchant_settlement',
            params=[customer_order_id, 'PPR_OFFLINE_SUCCESS'],
            is_master=True
        )

    def generates_final_response(self):
        """
        Sets final response.
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': self.status_code == codes.ok,
            'message': self.response_msg
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):

        self.initialize_class_variables()
        self.initialize_modules()
        self.get_redemption_info()
        if self.redemption:
            self.offer = Offer.get_offer_info(
                offer_id=self.redemption.offer_id,
                locale=self.locale
            )
            self.product = Product.get_product_info(product_id=self.redemption.product_id)
            self.outlet = Outlet.get_outlet_and_merchant_info(outlet_id=self.redemption.outlet_id)
            if self.offer and self.product and self.outlet:
                self.module = Module.get_module_info(name=self.module_name, company=self.company)
                if self.module:
                    self.completed_order_status = CustomerOrderStatus.get_status(
                        title=CustomerOrderStatus.COMPLETED,
                        module_id=self.module.id,
                        get_one=True
                    )
                    if self.completed_order_status:
                        self.get_customer_order_number()
                        self.add_business_table_entries()
                    else:
                        self.status_code = codes.precondition_required
                        self.response_msg = 'Missing customer order status for module.'
                else:
                    self.status_code = codes.bad_request
                    self.response_msg = 'Invalid module.'
            else:
                self.status_code = codes.bad_request
                self.response_msg = 'Incomplete information provided.'
        else:
            self.status_code = codes.bad_request
            self.response_msg = 'Invalid redemption ID.'
        self.generates_final_response()
