"""
Implementation: Validate the existence of the offers, the user, the outlet, and whether the offers are redeemable
by this user at this outlet. From the outlet, merchant information can be retrieved and the PIN can then be
verified. If all is OK, create a new record in the redemption table and calculate the redemption_code.
"""
import datetime

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.models.product import Product
from redemption_service.app.api.v1.validations.redeem_api_validation import \
    redemption_parser
from redemption_service.common.base_resource import BasePostResource
from redemption_service.common.constants import OFFER_DOES_NOT_EXIST
from redemption_service.common.models.db import with_master
from redemption_service.common.models.merchant import Merchant
from redemption_service.common.models.merchant_translation import \
    MerchantTranslation
from redemption_service.common.models.mobile_redemption import MobileRedemption
from redemption_service.common.models.offer_wl_active import OfferWlActive
from redemption_service.common.models.outlet import Outlet
from redemption_service.common.models.product_offer_wl_active import \
    ProductOfferWlActive
from redemption_service.common.models.redemption import Redemption
from redemption_service.common.models.user_saving import UserSaving
from redemption_service.common.utils.authentication import (get_company,
                                                            get_current_customer)
from redemption_service.common.utils.translation_manager import \
    TranslationManager
from redemption_service.modules.api_utils import (calculate_redeemability,
                                                  generate_redemption_code,
                                                  user_redemptions_lookup_hash)
from redemption_service.modules.constants import APP_TUTOR, INVALID_OUTLET
from requests import codes
from sqlalchemy.exc import SQLAlchemyError


class RedemptionAPI(BasePostResource):
    """
    @api {post} /v1/redemptions Post Redeem the offer
    @apiSampleRequest /v1/redemptions
    @apiVersion 1.0.0
    @apiName RedemptionProcessWL
    @apiGroup Redemptions
    @apiParam {Integer}                                     offer_id                Offer id
    @apiParam {Integer}                                     outlet_id               Outlet id
    @apiParam {Integer}                                     merchant_pin            Merchant pin
    @apiParam {Integer}                                     location_id             Id of location to filter outlets by
    @apiParam {Integer}                                     transaction_id          Transaction id
    @apiParam {Integer}                                     product_id              Product_id
    @apiParam {String="en", "ar", "cn", "el","zh"}          [language]              Response Language
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/redemption_api.log',
        ),
        'name': 'redemption_api'
    }
    request_parser = redemption_parser
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Request arguments for redemption api white label
        """
        self.offer_id = self.request_args.get('offer_id')
        self.outlet_id = self.request_args.get('outlet_id')
        self.provided_merchant_pin = self.request_args.get('merchant_pin')
        self.transaction_id = self.request_args.get('transaction_id', '')
        self.product_id = self.request_args.get('product_id')
        self.locale = self.request_args.get('language')
        self.is_reattempt = self.request_args.get('is_reattempt')

    def initialize_local_variables(self):
        """
        Sets variables for api
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer['customer_id']
        self.company = get_company()
        self.session_token = self.customer['session_token']
        self.points = 0
        self.redemption_code = None

    def verify_reattempt_code_and_transaction(self):
        """
        Verify reattempt redemption code and transactions
        """
        if self.is_reattempt and self.transaction_id:
            redemption = Redemption.get_by_transaction_id_and_customer_id(
                transaction_id=self.transaction_id,
                customer_id=self.customer_id
            )
            if redemption:
                self.message = TranslationManager.get_translation(
                    TranslationManager.SUCCESS,
                    self.locale
                )
                self.response = {
                    'data': {
                        "referenceNo": {
                            'redemption_code': redemption.code
                        }
                    },
                    'message': self.message,
                    'success': True
                }
                self.status_code = codes.CREATED
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def initialize_offers_data(self):
        """
        Checks offers against provided offer id and product id
        """
        self.offer = OfferWlActive.get_by_offer_and_product_id(self.offer_id, self.product_id)

    def is_offer_exist(self):
        """
        Checks if offer exist or not
        """
        if not self.offer:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response["message"] = TranslationManager.get_translation(
                TranslationManager.offer_does_not_exist_or_inactive,
                self.locale
            )
            self.response["message"] = self.response["message"].format(self.offer_id)
            self.response["code"] = OFFER_DOES_NOT_EXIST
            self.response["success"] = False
            self.response["data"] = []
            self.logger.info(self.response)

    def verify_app_tutorial(self):
        """
        Verifies app tutorial merchant
        """
        merchant_translation = MerchantTranslation.get_by_merchant_id(self.offer.merchant_id)
        is_app_tutorial = merchant_translation.name.__contains__(APP_TUTOR)
        if not is_app_tutorial:
            # This check is for all kind of offers, discussed with @Tahir
            redeemed_offer_count_in_last_x_hours = Redemption.get_number_of_redemptions_within_last_x_hours(
                self.customer_id,
                self.offer_id,
                self.company,
                self.offer.hours_to_consider_for_redemption_cap
            )
            if redeemed_offer_count_in_last_x_hours >= self.offer.redemptions_limit_in_x_hours:
                monthly_limit_messages = TranslationManager.get_translation(
                    TranslationManager.MONTHLY_LIMIT_MESSAGE,
                    locale=self.locale
                ).format(
                    MONTHLY_LIMIT=self.offer.redemptions_limit_in_x_hours,
                    MONTHLY_HOURS=self.offer.hours_to_consider_for_redemption_cap
                )
                self.response = self.generate_response_dict(
                    message=monthly_limit_messages,
                    custom_code=codes.UNPROCESSABLE_ENTITY,
                )
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response(self.response, codes.UNPROCESSABLE_ENTITY)

    def check_merchant(self):
        """
        Validates merchant, and it's pin
        """
        self.merchant = Merchant.get_by_id(self.offer.merchant_id)
        if not self.merchant:
            self.response = {
                "message": TranslationManager.get_translation(
                    TranslationManager.merchant_does_not_exist,
                    locale=self.locale
                ),
                "success": False,
                "code": codes.UNPROCESSABLE_ENTITY
            }
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response(self.response, self.status_code)
            return

        if int(self.merchant.pin) != self.provided_merchant_pin:
            self.response = {
                "message": TranslationManager.get_translation(
                    TranslationManager.invalid_merchant_pin,
                    locale=self.locale
                ),
                "success": False,
                "code": codes.UNPROCESSABLE_ENTITY
            }
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response(self.response, self.status_code)
        self.merchant_id = self.merchant.id
        self.merchant_sf_id = self.merchant.sf_id

    def check_redeemability(self):
        redemption_quantities = user_redemptions_lookup_hash(self.customer_id, self.company, [self.offer_id])
        current_date = datetime.datetime.now()
        date_from = current_date + datetime.timedelta(hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM)
        date_to = current_date + datetime.timedelta(hours=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)
        redeemability = calculate_redeemability(
            self.offer,
            self.customer['product_ids'],
            redemption_quantities,
            date_from,
            date_to
        )
        if not redeemability['is_redeemable']:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": TranslationManager.get_translation(
                    TranslationManager.already_redeemed,
                    locale=self.locale
                ),
                "success": False,
                "code": codes.UNPROCESSABLE_ENTITY
            }
            return self.send_response(self.response, self.status_code)

    def get_outlet_information(self):
        """
        Gets outlet information
        :return:
        """
        self.outlet = Outlet.get_by_id_and_offer_id(self.outlet_id, self.offer_id)
        if not self.outlet:
            self.response = self.generate_response_dict(
                message=INVALID_OUTLET,
            )
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response(self.response, self.status_code)

    def check_offer_is_related_to_product(self):
        """
        Checks if offer is bind with the product_id
        """
        self.product_offer = ProductOfferWlActive.get_by_product_and_offer_id(self.product_id, self.offer_id)
        self.product_offer_root_code = self.product_offer.root_code

    def redeem(self):
        """
        Redeems the offer
        """
        try:
            product = Product.get_delivery_enabled_by_id(self.product_id)
        except SQLAlchemyError as e:
            self.logger.exception("Error occurred for getting product: {}".format(e))
            Product.query.session.rollback()
            product = Product.get_delivery_enabled_by_id(self.product_id)
        if product.delivery_enabled:
            redemption_type = Redemption.TYPE_DELIVERY
        else:
            redemption_type = Redemption.TYPE_DEFAULT
        self.savings_estimates = self.offer.savings_estimate_local_currency
        self.redemption_object = Redemption(
            customer_id=self.customer_id,
            offer_id=self.offer_id,
            outlet_id=self.outlet_id,
            session_token=self.session_token,
            savings_estimate=self.savings_estimates,
            transaction_id=self.transaction_id,
            product_id=self.product_id,
            company=self.company,
            root_code=self.product_offer_root_code,
            az_sync=0
        )
        self.redemption_object.insert_record()
        self.redemption_code = generate_redemption_code(self.redemption_object.id, redemption_type)
        self.redemption_object.code = self.redemption_code
        self.redemption_object.update_record()

    def update_user_savings(self):
        """
        Updates user savings
        :return:
        """
        try:
            user_savings = UserSaving.get_by_user_id_and_company(self.customer_id, self.company)
            if user_savings:
                UserSaving.update_user_savings(user_savings.id, self.customer_id, self.savings_estimates, self.points)
            else:
                new_user_savings = UserSaving(
                    total_savings=self.savings_estimates,
                    current_year_savings=self.savings_estimates,
                    current_year_redemptions=1,
                    total_redemptions=1,
                    total_points=self.points,
                    current_year_points=self.points,
                    is_user_rank_processed=0,
                    user_id=self.customer_id,
                    company=self.company,
                )
                new_user_savings.insert_record()
        except Exception as e:
            self.logger.error("Savings {} not updated for user_id: {}, Error: {}".format(
                self.savings_estimates,
                self.customer_id,
                e
            ))

    @with_master
    def insert_informatica_db_entry(self):
        try:
            mobile_redemption = MobileRedemption(
                id=self.redemption_object.id,
                customer_id=self.customer_id,
                quantity=self.redemption_object.quantity,
                code=self.redemption_object.code,
                offer_sf_id=self.offer.sf_id,
                outlet_sf_id=self.outlet.sf_id,
                merchant_sf_id=self.merchant_sf_id,
                root_code=self.redemption_object.root_code,
                company=self.company
            )
            mobile_redemption.insert_record()
        except Exception as e:
            self.logger.error("Error occurred while inserting redemption into informatica db: {}".format(e))

    def build_redemption_response(self):
        """
        Builds redemption response
        """
        self.redemption_response = {
            'redemption_code': self.redemption_code,
            'smiles_earned': 0,
            'coupon': ''
        }

    def generates_final_response(self):
        """
        Sets final response
        :rtype: dict
        """
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': TranslationManager.get_translation(
                TranslationManager.success,
                self.locale
            ),
            'data': {"referenceNo": self.redemption_response, "id": self.redemption_object.id}
        }
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_local_variables()
        self.verify_reattempt_code_and_transaction()
        if self.send_response_flag:
            return
        self.initialize_offers_data()
        self.is_offer_exist()
        if self.send_response_flag:
            return
        self.verify_app_tutorial()
        if self.send_response_flag:
            return
        self.check_merchant()
        if self.send_response_flag:
            return
        self.check_redeemability()
        if self.send_response_flag:
            return
        self.get_outlet_information()
        if self.send_response_flag:
            return
        self.check_offer_is_related_to_product()
        if self.send_response_flag:
            return
        self.redeem()
        self.build_redemption_response()
        self.update_user_savings()
        self.insert_informatica_db_entry()
        self.generates_final_response()
