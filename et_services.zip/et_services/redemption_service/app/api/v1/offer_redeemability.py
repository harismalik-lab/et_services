"""
"""
import datetime

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.constants import SMILES_ACTION_BURN_OFFERS_TOP_UP_ID, TOP_UP_OFFER_BURN_VALUE
from common.modules.v1.merchant_module import MerchantModule
from redemption_service.common.models.merchant import Merchant
from redemption_service.common.models.product import Product
from redemption_service.common.modules.v1.offer_module import OfferModule
from redemption_service.app.api.v1.validations.offer_redeemability_validation import offer_red_parser
from redemption_service.common.models.top_up_offers import TopUpOffer
from redemption_service.common.utils.api_utils import get_formatted_date
from redemption_service.common.utils.translation_manager import TranslationManager
from redemption_service.common.utils.v_1.shared_util import SharedUtil
from redemption_service.common.base_resource import BasePostResource
from redemption_service.common.constants import ENT_COMPANY_TYPE, HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO, \
    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM
from redemption_service.common.models.api_configuration import ApiConfiguration
from redemption_service.common.utils.authentication import get_company, get_current_customer, token_decorator_v3


class OfferRedeemability(BasePostResource):
    """
    @api {post} /v1/offer_redeemability
    @apiName OfferRedeemability
    @apiGroup Redemption
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/offer_redeemability.log',
        ),
        'name': 'offer_redeemability'
    }
    request_parser = offer_red_parser
    strict_token = True
    required_token = True
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Request arguments for API request.
        """
        self.offer_id = self.request_args.get('offer_id')
        self.outlet_id = self.request_args.get('outlet_id')
        self.merchant_id = self.request_args.get('merchant_id')
        self.location_id = self.request_args.get('location_id', 1)
        self.locale = self.request_args.get('language')
        self.all_offers_active = self.request_args.get('all_offers_active')
        self.redeemability = self.request_args.get('redeemability', 'redeemable')
        self.takeaways_enabled = self.request_args.get('is_take_away', False)
        self.cashless_enabled = self.request_args.get('is_cashless', False)

    def initialize_local_variables(self):
        """
        Sets variables for API request.
        """
        self.customer = get_current_customer()
        self.company = get_company()
        self.merchant = {}
        self.category = None
        self.message_locale = self.locale

        self.offers_array = []
        self.redeemability_for_delivery = {}
        self.birthday_skus = []
        self.birthday_offers_validity = None
        self.personal_family_pinged_received = []

    def initialize_modules(self):
        """

        """
        self.shared_util = SharedUtil()
        self.offer_module = OfferModule()
        self.merchant_module = MerchantModule()

    def get_company_configs(self):
        """
        Get company specific configurations.
        """
        self.configs = self.customer.get('api_configs', {})
        self.is_ent = self.configs.get('company_type') == ENT_COMPANY_TYPE
        self.enable_cashless_delivery = self.configs.get(ApiConfiguration.ENABLE_DELIVERY_CASHLESS)
        self.enable_takeaways = self.configs.get(ApiConfiguration.ENABLE_TAKEAWAYS)
        self.enable_family_feature = self.configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE)
        self.enable_ping_feature = self.configs.get(ApiConfiguration.ENABLE_PING_FEATURE)
        self.enable_top_up_offers = self.configs.get(ApiConfiguration.ENABLE_TOP_UP_OFFERS)
        self.enable_cheers_offers = self.configs.get(ApiConfiguration.ENABLE_CHEERS)
        self.enable_birthday_feature = self.configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE)
        self.enable_live_offers = self.configs.get(ApiConfiguration.ENABLE_LIVE_OFFERS)

    def initialize_api_configs(self):

        self.takeaways_enabled = self.takeaways_enabled and self.enable_takeaways
        self.cashless_enabled = self.cashless_enabled and self.enable_cashless_delivery
        self.top_up_offers_enabled = self.enable_top_up_offers
        self.family_feature_enabled = self.enable_family_feature
        self.ping_feature_enabled = self.enable_ping_feature
        self.live_offers_enabled = self.enable_live_offers
        self.cheers_enabled = self.enable_cheers_offers and self.customer['owns_cheer_products']
        self.birthday_feature_enabled = self.enable_birthday_feature and self.customer['has_birthday_month']

    def initialize_customer(self):

        if self.ping_feature_enabled:
            if not self.customer['is_active_family_member'] and self.customer['is_member']:
                if not self.cashless_delivery_enabled:
                    self.ping_details = self.shared_util.get_ping_details(
                        self.customer['customer_id'],
                        self.customer['is_member'],
                        self.customer['product_ids'],
                        True,
                        is_family_member=self.customer['is_active_family_member'],
                    )
            else:
                product_ids_owned = self.customer['product_ids']
                if self.customer['owns_cheer_products'] and not self.cheers_enabled:
                    product_ids_owned = list(
                        map(int,
                            filter(
                                None,
                                self.customer['product_ids'] + self.customer.get('cheers_product_ids', [])
                            ))
                    )
                if not self.cashless_delivery_enabled:
                    self.ping_details = self.shared_util.get_ping_details(
                        self.customer['primary_user_id'],
                        self.customer['is_member'],
                        product_ids_owned,
                        True,
                        is_family_member=self.customer['is_active_family_member'],
                        primary_user_id=self.primary_user_id
                    )

        if self.birthday_feature_enabled:
            birthday_products = Product.get_birthday_products_with_id(self.location_id)
            self.birthday_pids = [p.id for p in birthday_products]
            self.birthday_skus = [p.sf_id for p in birthday_products]
            self.customer['product_ids'] = (
                    self.customer.get('product_ids', []) + self.birthday_pids
            )
            self.birthday_offers_validity = self.offer_module.get_birthday_offer_validity()

    def get_buy_back_offers_array(self):

        self.top_up_offers = []
        if self.top_up_offers_enabled:
            if self.family_feature_enabled and self.is_active_family_member:
                self.top_up_offers = TopUpOffer.get_top_up_offers_primary(
                    customer_id=self.customer['primary_user_id'],
                    location_id=self.location_id,
                    merchant_id=self.merchant_id,
                    offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY
                )
            else:
                self.top_up_offers = TopUpOffer.get_top_up_offers_primary(
                    customer_id=self.customer['id'],
                    location_id=self.location_id,
                    merchant_id=self.merchant_id,
                    offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY
                )

    def get_all_active_offers(self):
        """
        Get all active offers.
        """
        self.offer_ids = []
        (
            self.offers,
            self.outlet_ids_having_offers,
            self.offer_categories,
            self.offer_sub_categories,
            self.merchant_offer_ids,
            self.delivery_offers_count,
            self.has_dinner_offers,
            self.has_take_away_offers
        ) = self.offer_module.get_all_active_offers(
            outlet_ids=[self.outlet_id],
            locale=self.locale,
            customer=self.customer,
            offer_redeemability=self.redeemability,
            offer_id=self.offer_id,
            top_up_offers=self.top_up_offers,
            shared_offers_sent_family=[],
            shared_offers_received_family=[],
            offer_categories=[],
            offer_sub_categories=[],
            location_id=self.location_id,
            is_skip_mode=False,
            return_outlet_ids=True,
            selected_category=None,
            is_merlin_offers_to_show=True,
            offers_es=[],
            all_offers_active=self.all_offers_active,
            onboarding_redemption_count=self.customer['onboarding_redemptions_count'],
            primary_user_id=self.customer['primary_user_id'],
            is_active_family_member=self.customer['is_active_family_member'],
            shared_offers_received=[],
            shared_offers_sent=[],
            show_cheer_offers=self.cheers_enabled,
            ping_enabled=self.ping_feature_enabled,
            outlet_merlin_urls={},
            personal_cheer_offers=[],
            only_delivery=self.cashless_enabled,
            cashless_delivery_enabled=self.cashless_enabled,
            outlet_id=self.outlet_id,
            merchant_id=self.merchant_id,
            is_take_away=self.takeaways_enabled,
            company=self.company,
            is_ent=self.is_ent
        )

    def create_top_up_offers_hash(self):
        """
        Creates hash map for top up offers.
        """
        self.hashed_top_up_offers = {}
        self.offer_array_product_names = []

        if self.top_up_offers_enabled:
            for top_up_offer in self.top_up_offers:
                self.hashed_top_up_offers[top_up_offer.product_id] = True

    def process_offers(self):

        for offer in self.offers:
            offer.update({
                'savings_estimate_aed': round(offer['savings_estimate']),
                'offer_pay_back_app_action_id': SMILES_ACTION_BURN_OFFERS_TOP_UP_ID,
                'smiles_burn_value': TOP_UP_OFFER_BURN_VALUE,
                'top_up_offer_allowed': False,
                'is_pingable': False,
            })

            if offer['is_delivery']:
                if offer['shared_received_count'] > 0:
                    self.show_pinged_offers_delivery_section = True
                if offer.get('personal_shared_received_count', 0) > 0:
                    self.show_personal_pinged_offers_delivery_section = True
            else:
                if offer['shared_received_count'] > 0:
                    self.show_pinged_offers_non_delivery_section = True
                if offer.get('personal_shared_received_count', 0) > 0:
                    self.show_personal_pinged_offers_non_delivery_section = True

            if offer['is_freemium'] == 0:
                offer['top_up_offer_allowed'] = self.offer_module.allowed_offer_buy_back(
                    top_up_offer_against_product=offer['product_id'] in self.hashed_top_up_offers,
                    offer_type=offer['type'],
                    offer_quantity_redeemed=offer['quantity_redeemed'],
                    is_member=self.customer['is_member'],
                    is_active_family_member=self.customer['is_active_family_member'],
                    membership_sub_group=self.customer['membership_sub_group']
                )

            self.handle_deliverable_offer(offer)
            if offer['product_name'] not in self.offer_array_product_names:
                self.offers_array.append({
                    'section_name': offer['product_name'],
                    'show_pinged_offers_delivery_section': False,
                    'show_pinged_offers_non_delivery_section': False,
                    'valid_from': offer.get('valid_from_date')
                })
                self.offer_array_product_names.append(offer['product_name'])

    def handle_deliverable_offer(self, offer):

        if self.cashless_enabled:
            is_location_dc_enabled = (
                self.location_id in self.shared_util.get_delivery_enabled_location_ids_against_company(self.company)
            )
            if (
                is_location_dc_enabled and
                offer.get('cashless_delivery_enabled', False)
            ) or (
                not is_location_dc_enabled and
                offer.get('is_delivery', False)
            ):
                self.delivery_offers_count += 1
                self.redeemability_for_delivery['total_offers'] = self.redeemability_for_delivery.get('total_offers', 0)
                self.redeemability_for_delivery['total_offers'] += offer.get('quantity_redeemable', 0)
                self.redeemability_for_delivery['total_offers'] += offer.get('quantity_redeemed', 0)
                self.redeemability_for_delivery['total_offers'] += offer.get('quantity_not_redeemable', 0)
                self.redeemability_for_delivery['total_offers'] += offer.get('shared_received_count', 0)
                self.redeemability_for_delivery['total_offers'] += offer.get('personal_shared_received_count', 0)
                self.redeemability_for_delivery['total_offers'] -= offer.get('quantity_redeemed', 0)
                self.redeemability_for_delivery['total_offers'] -= offer.get('shared_redemptions_count', 0)
                self.redeemability_for_delivery['total_offers'] -= offer.get('personal_shared_redemptions_count', 0)

    def get_list_of_offers_array(self):

        self.offers_array, self.is_any_offer_pingable = self.offer_module.formulate_offer_details_array(
            offers=self.offers,
            offers_array=self.offers_array,
            message_locale=self.message_locale,
            is_user_account_frozen=self.customer['is_account_frozen'],
            is_any_offer_pingable=False,
            has_birthday_month=self.customer['has_birthday_month'],
            birthday_skus=self.birthday_skus,
            birthday_offers_validity=self.birthday_offers_validity,
            is_skip_mode=False,
            is_offer_type_attributes_to_add=True,
            replace_241_type_with_141=False,
            is_on_trial=self.customer['is_on_trial'],
            merchant_pin=self.merchant['merchant_pin'],
            family_identifier=self.customer['family_identifier'],
            personal_family_pinged_received=self.personal_family_pinged_received,
            live_offers_enabled=self.live_offers_enabled,
            ping_feature_enabled=self.ping_feature_enabled,
            cashless_delivery_enabled=self.cashless_enabled,
            birthday_feature_enabled=self.birthday_feature_enabled,
            location_id=self.location_id,
            url_update_v7=True,
            company=self.company
        )

    def format_list_of_offers_array(self):
        """

        """
        self.merchant = {}
        if self.offers_array:
            current_date = datetime.datetime.now() + datetime.timedelta(
                hours=HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM
            )
            date_to = datetime.datetime.now() + datetime.timedelta(
                hours=HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO
            )
            date_to = get_formatted_date(date_to)
            current_date = get_formatted_date(current_date)
            offers = []
            # In order to include only current year's offers, we are comparing the offer's valid_from and
            # expiration_date dates with the current_date. If the offer has valid_from less or equal to current's date
            # then add include the offers.
            for offers_array in self.offers_array:
                for offer in offers_array.get('offers_to_display', []):
                    if (
                            current_date >= offer.get('valid_from_date', '') and
                            date_to <= offer.get('expiration_date', '')
                    ):
                        offers.append(offer)
            self.merchant['offers'] = offers
        else:
            self.merchant['offers'] = []

        self.merchant["is_member_on_trial"] = self.customer['is_on_trial']
        if self.customer['is_on_trial']:
            self.merchant["redemptions_left_for_trial"] = (
                self.customer['onboarding_redemptions_limit'] - self.customer['onboarding_redemptions_count']
            )

    def prepare_response(self):
        self.response = {
            'success': True,
            'message': 'success',
            'data': self.merchant,
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.ok

    def get_merchant(self):
        """
        Finds merchant by supplied id
        - check if company type is `'ent'` then find merchant with selected category else without it.
        """
        selected_category = None

        self.merchant = Merchant.find_by_id(
            merchant_id=self.merchant_id,
            locale=self.message_locale,
            selected_category=selected_category
        )
        if self.merchant:
            self.merchant = self.merchant._asdict()
            self.merchant_module.process_merchant(self.merchant)
        else:
            self.send_response_flag = True
            self.status_code = codes.unprocessable
            self.response = {
                'success': False,
                'message': TranslationManager.get_translation(
                    TranslationManager.merchant_details_not_found,
                    self.message_locale
                ),
                'code': 70
            }
            return self.send_response(self.response, self.status_code)

        self.data = []

    def process_request(self, *args, **kwargs):
        """
        Lifecycle of a request.
        """
        self.initialize_local_variables()
        self.get_company_configs()
        self.initialize_modules()
        self.initialize_api_configs()
        self.initialize_customer()
        self.get_merchant()
        self.get_buy_back_offers_array()
        self.get_all_active_offers()
        self.create_top_up_offers_hash()
        self.process_offers()
        self.get_list_of_offers_array()
        self.format_list_of_offers_array()
        self.prepare_response()
