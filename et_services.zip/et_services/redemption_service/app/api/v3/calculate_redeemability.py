"""
Calculate redeemability API
"""
import datetime

from app_configurations.settings import ET_SERVICES_LOG_PATH
from redemption_service.app.api.v1.calculate_redeemability import \
    CalculateRedeemabilityAPI
from redemption_service.app.api.v3.validations.calculate_redeemability_validation import \
    redeemability_parser_v3
from redemption_service.common.constants import ENT_COMPANY_TYPE
from redemption_service.common.models.api_configuration import ApiConfiguration
from redemption_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from redemption_service.common.models.offer import Offer
from redemption_service.common.models.product import Product
from redemption_service.common.models.share_offer import ShareOffer
from redemption_service.common.models.top_up_offers import TopUpOffer
from redemption_service.common.utils.api_utils import format_company
from redemption_service.common.utils.authentication import token_decorator_v3
from redemption_service.modules.api_utils import user_redemptions_lookup_hash
from redemption_service.modules.api_utils_v3 import (calculate_redeemability,
                                                     get_birthday_offer_validity_in_days,
                                                     user_redemptions_lookup_for_ent)


class CalculateRedeemabilityAPIV3(CalculateRedeemabilityAPI):

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/calculate_redeemability_api_v3.log',
        ),
        'name': 'calculate_redeemability_api_v3'
    }
    validators = [token_decorator_v3]
    request_parser = redeemability_parser_v3

    def populate_request_arguments(self):
        """
        Populate request arguments
        """
        super().populate_request_arguments()
        self.location_id = self.request_args.get('location_id')
        self.is_birthday_enabled = self.request_args.get('is_birthday_offer')
        self.is_family_enabled = self.request_args.get('is_family_offer')
        self.is_shared_offers_enabled = self.request_args.get('is_shared')
        self.is_top_up_offers_enabled = self.request_args.get('is_top_up_offer')
        self.is_takeaways_enabled = self.request_args.get('is_takeaway_offer')

    def initialise_class_attributes(self):
        """
        Initialise class attributes.
        """
        super().initialise_class_attributes()
        self.company = format_company(self.company)

    def initialise_local_variables(self):
        """
        Initialises local variables.
        """
        self.is_app_tutorial = False
        self.birthday_product_ids = []
        self.shared_offers_sent = {}
        self.top_up_offers = {}
        self.offers = []

        # API Configurations.
        self.is_birthday_enabled = self.is_birthday_enabled and self.enable_birthday_feature
        self.is_family_enabled = self.is_family_enabled and self.enable_family_feature
        self.is_shared_offers_enabled = self.is_shared_offers_enabled and self.enable_shared_offers
        self.is_top_up_offers_enabled = self.is_top_up_offers_enabled and self.enable_top_up_offers
        self.is_takeaways_enabled = self.is_takeaways_enabled and self.enable_takeaways

    def get_company_configs(self):
        """
        get company specific configs
        """
        self.api_configs = self.customer.get('api_configs')
        self.is_ent = self.api_configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE
        self.enable_birthday_feature = self.api_configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE)
        self.enable_family_feature = self.api_configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE)
        self.enable_shared_offers = self.api_configs.get(ApiConfiguration.ENABLE_SHARED_OFFERS)
        self.enable_top_up_offers = self.api_configs.get(ApiConfiguration.ENABLE_TOP_UP_OFFERS)
        self.enable_takeaways = self.api_configs.get(ApiConfiguration.ENABLE_TAKEAWAYS)

    def load_customer_profile_and_member_group(self):
        """
        Load the customer-profile and customer session_data
        """

        if self.customer:
            self.customer_id = self.customer.get('customer_id')
            self.primary_user_id = self.customer_id
            self.member_group = self.customer.get('new_member_group')
            self.member_type_id = self.customer.get('member_type_id')

        if self.is_family_enabled:
            if (
                self.customer.get('is_user_in_family', False) and
                self.customer.get('family_is_active', False) and
                not self.is_birthday_enabled
            ):
                if (
                        not self.is_shared_offers_enabled and
                        self.customer['family_info'].status == 1
                ):
                    self.primary_user_id = self.customer['customer_id']
                    if not self.customer.get('is_primary', False):
                        self.primary_user_id = self.customer['primary_member_info'].user_id
            if self.customer:
                if (
                    self.customer.get('is_user_in_family', False) and
                    self.customer.get('family_is_active', False) and
                    not self.customer.get('is_primary', False) and
                    self.customer.get('primary_member_info', {}) and
                    len(self.customer.get('product_ids', [])) > 0
                ):
                    self.member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER
                    self.member_type_id = EntCustomerProfile.MEMBERSTATUS_MEMBER

    def get_offers_from_db(self):
        """
        Gets offers from db
        """
        if self.customer['product_ids']:
            self.offers = Offer.get_by_offer_ids_and_product_ids(
                offer_ids=self.offer_ids,
                product_ids=self.customer['product_ids'],
                company=self.company,
                is_ent=self.is_ent
            )

    def set_offer_validation_dates(self):
        """
        """
        self.current_date = datetime.datetime.now()
        self.date_from = self.current_date + datetime.timedelta(
            hours=Offer.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM
        )
        self.date_to = self.current_date + datetime.timedelta(hours=Offer.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)

    def get_redemption_quantities(self):
        """
        Sets redemption quantities
        :return:
        """
        if self.is_ent:
            self.redemption_quantities = user_redemptions_lookup_for_ent(
                customer_id=self.primary_user_id,
                offer_ids=self.offer_ids,
                is_using_trial=self.customer.get('is_using_trial'),
                company=self.company
            )
        else:
            self.redemption_quantities = user_redemptions_lookup_hash(
                self.customer['user_id'],
                self.company,
                None
            )

    def check_birthday_offers(self):
        """
        Process birthday offers
        """
        if self.is_birthday_enabled:
            self.birth_date = self.customer_profile.date_of_birth
            if self.birth_date:
                self.number_of_birthday_validity_days = get_birthday_offer_validity_in_days(
                    self.birth_date
                )
                if self.number_of_birthday_validity_days >= -1:
                    self.birthday_product_ids = Product.get_birthday_products(
                        self.location_id, self.company, column_to_get='id',
                    )
                    for offer in self.offers:
                        if offer.product_id in self.birthday_product_ids:
                            self.is_birthday_enabled = True
                            self.primary_user_id = self.customer['customer_id']

    def get_top_up_offers(self):
        """
        Gets top up offers
        """
        if self.is_top_up_offers_enabled:
            top_up_offers = TopUpOffer.get_top_up_offers_primary(
                self.primary_user_id,
                self.location_id,
                offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY,
                offer_id=self.offer_ids
            )
            for top_up_offer in top_up_offers:
                self.top_up_offers[top_up_offer.offer_id] = top_up_offer

    def get_shared_offers(self):
        """
        Shared offers
        """
        if self.is_shared_offers_enabled:
            shared_offers_sent = ShareOffer.get_shared_offers_by_sender_primary(
                self.primary_user_id,
                offer_id=self.offer_ids
            )
            for shared_offer in shared_offers_sent:
                self.shared_offers_sent[shared_offer.offer_id] = shared_offer

    def process_offers(self):
        """
        Process offers
        """
        for offer in self.offers:
            shared_offer_sent = []
            shared_offer = self.shared_offers_sent.get(offer.id)
            if shared_offer:
                shared_offer_sent.append(shared_offer)

            is_top_up_offer = False
            top_up_offer = self.top_up_offers.get(offer.id)
            if top_up_offer:
                is_top_up_offer = True

            redeemability = calculate_redeemability(
                offer=offer,
                product_id=offer.product_id,
                customer_product_ids=self.customer.get('product_ids', []),
                redemption_quantities=self.redemption_quantities,
                date_from=self.date_from,
                date_to=self.date_to,
                is_ent=self.is_ent,
                member_group=self.member_group,
                shared_offers_sent=shared_offer_sent,
                is_top_up_offer=is_top_up_offer,
                birthday_product_ids=self.birthday_product_ids,
                is_take_away_enabled=self.is_takeaways_enabled,
                company=self.company
            )
            self.redeemability_response['{0}_{1}'.format(offer.id, offer.product_id)] = redeemability

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialise_class_attributes()
        self.get_company_configs()
        self.initialise_local_variables()
        self.load_customer_profile_and_member_group()
        self.set_offer_validation_dates()
        self.get_offers_from_db()
        self.get_redemption_quantities()
        self.check_birthday_offers()
        self.get_top_up_offers()
        self.get_shared_offers()
        self.process_offers()
        self.generate_final_response()
