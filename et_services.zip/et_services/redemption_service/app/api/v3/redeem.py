"""
Implementation: Validate the existence of the offers, the user, the outlet, and whether the offers are redeemable
by this user at this outlet. From the outlet, merchant information can be retrieved and the PIN can then be
verified. If all is OK, create a new record in the redemption table and calculate the redemption_code.
"""
import datetime

from app_configurations.settings import ET_SERVICES_LOG_PATH
from flask import request
from redemption_service.app.api.v1.redeem import RedemptionAPI
from redemption_service.app.api.v3.validations.redeem_api_validation import \
    redemption_parser_v3
from redemption_service.common.constants import ENT_COMPANY_TYPE
from redemption_service.common.models.api_configuration import ApiConfiguration
from redemption_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from redemption_service.common.models.merchant_translation import \
    MerchantTranslation
from redemption_service.common.models.mobile_redemption import MobileRedemption
from redemption_service.common.models.offer import Offer
from redemption_service.common.models.outlet import Outlet
from redemption_service.common.models.product import Product
from redemption_service.common.models.product_offer import ProductOffer
from redemption_service.common.models.redemption import Redemption
from redemption_service.common.models.redemption_custom_codes import \
    RedemptionCustomCode
from redemption_service.common.models.share_offer import ShareOffer
from redemption_service.common.models.top_up_offers import TopUpOffer
from redemption_service.common.models.user_saving import UserSaving
from redemption_service.common.rest_urls import RedemptionServiceAPIUrlsV3
from redemption_service.common.utils.api_utils import get_current_date_time
from redemption_service.common.utils.authentication import token_decorator_v3
from redemption_service.common.utils.http_helpers import make_post_request
from redemption_service.common.utils.translation_manager import \
    TranslationManager
from redemption_service.modules.api_utils import (generate_redemption_code,
                                                  user_redemptions_lookup_hash)
from redemption_service.modules.api_utils_v3 import (allowed_smiles_earned,
                                                     calculate_redeemability,
                                                     earn_smiles,
                                                     get_api_version,
                                                     get_birthday_offer_validity_in_days,
                                                     get_custom_code_info,
                                                     get_deal_validity_data,
                                                     send_notification_on_trial_expiration,
                                                     send_notification_on_trial_redemption,
                                                     user_redemptions_lookup_for_ent)
from redemption_service.modules.constants import (APP_TUTOR, INVALID_OUTLET,
                                                  INVALID_PRODUCT,
                                                  SMILES_ACTION_EARN_REDEMPTION_ID)
from requests import codes


class RedemptionAPIV3(RedemptionAPI):
    """
    @api {post} /v3/redemptions Post Redeem the offer
    @apiSampleRequest /v1/redemptions
    @apiVersion 3.0.0

    @apiName Redemption
    @apiGroup Redemptions
    @apiParam {Integer}                                     offer_id                Offer ID
    @apiParam {Integer}                                     outlet_id               Outlet ID
    @apiParam {Integer}                                     merchant_pin            Merchant PIN
    @apiParam {Integer}                                     location_id             ID of location to filter outlets by.
    @apiParam {Integer}                                     transaction_id          Transaction ID
    @apiParam {Integer}                                     product_id              Product ID
    @apiParam {String}                                      platform                Platform of device.
    @apiParam {String="en", "ar", "cn", "el","zh"}          [language]              Response Language
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='redemption_service/redemption_api_v3.log',
        ),
        'name': 'redemption_api_v3'
    }
    validators = [token_decorator_v3]
    request_parser = redemption_parser_v3

    def populate_request_arguments(self):
        """
        Populates request arguments of API.
        """
        super().populate_request_arguments()
        self.location_id = self.request_args.get('location_id', '')
        self.is_shared = self.request_args.get('is_shared')
        self.triggered_by = self.request_args.get('triggered_by')
        self.platform = self.request_args.get('__platform', '')
        self.device_model = self.request_args.get('device_model', '')
        self.device_language = self.request_args.get('language', '')
        self.is_delivery = self.request_args.get('is_delivery')
        self.is_family_offer = self.request_args.get('is_family_offer')
        if not self.is_family_offer:
            self.is_family_offer = self.request_args.get('quantity')
        self.is_birthday_offer = self.request_args.get('is_birthday_offer[]')
        if not self.is_birthday_offer:
            self.is_birthday_offer = self.request_args.get('is_birthday_offer')
        self.earn_gv_smiles = self.request_args.get('earn_gv_smiles')
        self.is_top_up_offers_enabled = self.request_args.get('is_top_up_offer')
        self.is_takeaways_enabled = self.request_args.get('is_takeaway_offer')
        self.is_offline_redemption = self.request_args.get('is_offline')

    def initialize_local_variables(self):
        """
        Sets variables to be used locally in the API.
        """
        super().initialize_local_variables()
        self.smiles_earned = 0
        self.is_entertainer_product = False
        self.redemption_code = ''
        self.custom_code_id = 0
        self.top_up_offers = []
        self.shared_offers_sent = []
        self.birthday_product_ids = []
        self.api_configs = self.customer.get('api_configs')

    def initialize_api_configurations(self):
        """
        API configurations for a particular API request.
        """
        self.is_birthday_enabled = self.is_birthday_offer and self.enable_birthday_feature
        self.is_family_enabled = self.is_family_offer and self.enable_family_feature
        self.is_shared_offers_enabled = self.is_shared and self.enable_shared_offers
        self.is_top_up_offers_enabled = self.is_top_up_offers_enabled and self.enable_top_up_offers
        self.is_takeaways_enabled = self.is_takeaways_enabled and self.enable_takeaways
        self.is_smile_enabled = self.enable_smile

    def get_company_configs(self):
        """
        Get company specific API configurations on which feature has been turned on for a company.
        """
        self.is_ent = self.api_configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE
        self.enable_birthday_feature = self.api_configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE)
        self.enable_family_feature = self.api_configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE)
        self.enable_shared_offers = self.api_configs.get(ApiConfiguration.ENABLE_SHARED_OFFERS)
        self.enable_top_up_offers = self.api_configs.get(ApiConfiguration.ENABLE_TOP_UP_OFFERS)
        self.enable_takeaways = self.api_configs.get(ApiConfiguration.ENABLE_TAKEAWAYS)
        self.enable_smile = self.api_configs.get(ApiConfiguration.ENABLE_SMILE_FEATURE)

    def verify_reattempt_code_and_transaction(self):
        """
        Verify reattempt redemption code and transactions.
        """
        redemption = None
        if self.is_ent and self.transaction_id:
            redemption = Redemption.get_reattempt_redemption_info(
                self.customer['customer_id'],
                self.transaction_id,
                self.offer_id,
                self.outlet_id
            )
        elif not self.is_ent and self.is_reattempt and self.transaction_id:
            redemption = Redemption.get_by_transaction_id_and_customer_id(
                transaction_id=self.transaction_id,
                customer_id=self.customer_id
            )

        if redemption:
            self.message = TranslationManager.get_translation(TranslationManager.SUCCESS, self.locale)
            self.response = {
                'data': {
                    "referenceNo": {
                        'redemption_code': redemption.code,
                        'is_redemption_already_made': True,
                        'redemption_id': redemption.id
                    }
                },
                'message': self.message,
                'success': True
            }
            self.status_code = codes.CREATED
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def load_customer_profile_and_member_group(self):
        """
        Load the customer profile and customer session data in local variables to be used in request.
        """
        self.customer_profile = EntCustomerProfile.get_customer_profile(self.customer_id)
        self.member_group = EntCustomerProfile.MEMBERSTATUS_PROSPECT
        self.is_user_member = False
        self.is_user_family_member = False
        self.primary_user_id = self.customer_id

        self.is_on_boarding = self.customer.get('is_using_trial', False)
        self.is_using_extended_trial = self.customer.get('is_using_extended_trial', False)

        if self.customer_profile:
            self.member_group = self.customer_profile.member_type
            self.member_type_id = self.customer.get('member_type_id')
            self.is_user_member = self.member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER

        if self.is_family_enabled:
            if (
                self.customer.get('is_user_in_family', False) and
                self.customer.get('family_is_active', False) and
                not self.is_birthday_offer
            ):
                if (
                    not self.is_shared_offers_enabled and
                    self.customer['family_info'].status == 1
                ):
                    self.primary_user_id = self.customer['customer_id']
                    if not self.customer.get('is_primary', False):
                        self.primary_user_id = self.customer['primary_member_info'].user_id
                        self.is_user_member = False
                        self.is_user_family_member = True

            if self.customer_profile:
                if (
                    self.customer.get('is_user_in_family', False) and
                    self.customer.get('family_is_active', False) and
                    not self.customer.get('is_primary', False) and
                    self.customer.get('primary_member_info', {}) and
                    len(self.customer.get('product_ids', [])) > 0
                ):
                    self.is_user_member = True
                    self.member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER
                    self.member_type_id = EntCustomerProfile.MEMBERSTATUS_MEMBER

    def initialize_offers_data(self):
        """
        Gets offer against provided offer id and product id.
        """
        self.offer = Offer.get_by_offer_and_product_id(
            offer_id=self.offer_id,
            product_id=self.product_id,
            company=self.company,
            is_ent=self.is_ent
        )
        if self.offer:
            if self.offer and isinstance(self.offer.valid_to, datetime.date):
                self.offer.valid_to.replace(hour=19, minute=59, second=59)

    def verify_app_tutorial(self):
        """
        Verifies app tutorial merchant
        """
        merchant_translation = MerchantTranslation.get_by_merchant_id(self.offer.merchant_id)
        self.is_app_tutorial = merchant_translation.name.__contains__(APP_TUTOR)
        calculate_redeemed_offer_count_in_last_x_hours = False
        if self.is_ent and self.offer.type == Offer.TYPE_MEMBER and not self.is_app_tutorial:
            calculate_redeemed_offer_count_in_last_x_hours = True
        elif not self.is_ent and not self.is_app_tutorial:
            calculate_redeemed_offer_count_in_last_x_hours = True

        if calculate_redeemed_offer_count_in_last_x_hours:
            redeemed_offer_count_in_last_x_hours = Redemption.get_number_of_redemptions_within_last_x_hours(
                self.customer_id,
                self.offer_id,
                self.company,
                self.offer.hours_to_consider_for_redemption_cap
            )
            if redeemed_offer_count_in_last_x_hours >= self.offer.redemptions_limit_in_x_hours:
                monthly_limit_messages = TranslationManager.get_translation(
                    TranslationManager.MONTHLY_LIMIT_MESSAGE,
                    locale=self.locale
                ).format(
                    MONTHLY_LIMIT=self.offer.redemptions_limit_in_x_hours,
                    MONTHLY_HOURS=self.offer.hours_to_consider_for_redemption_cap
                )
                self.response = self.generate_response_dict(
                    message=monthly_limit_messages,
                    custom_code=codes.UNPROCESSABLE_ENTITY
                )
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response(self.response, codes.UNPROCESSABLE_ENTITY)

    def verify_trial_period(self):
        """
        Checking is the user on trial period.
        """

        onboarding_redemptions_count = EntCustomerProfile.ONBOARDING_LIMIT

        if (
            not self.is_shared and
            not self.is_app_tutorial and
            self.customer['member_type_id'] == EntCustomerProfile.MEMBERSTATUS_ONBOARDING and
            self.customer_profile.onboarding_redemptions_count >= onboarding_redemptions_count and
            self.customer.get('is_using_trial', False)
        ):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="You have already redeemed {limit} offers. You can't redeem more offers for free.".format(
                    limit=onboarding_redemptions_count
                )
            )
            self.send_response(self.response, self.status_code)

        self.check_offer_redeemability = False
        if self.is_shared or not self.is_on_boarding:
            self.check_offer_redeemability = True

    def check_redeemability(self):
        """
        Checks redeemabilty of the offer.
        """
        redeemability = {}
        if self.is_ent:
            if not self.is_app_tutorial:
                if self.is_shared:
                    redeemability = {'redeemability': Offer.REDEEMABLE}
                else:
                    process_redeemability = False
                    if self.is_user_member or self.is_birthday_offer:
                        process_redeemability = True
                    if not process_redeemability:
                        redeemability = {'redeemability': Offer.NOT_REDEEMABLE}

        if not redeemability:
            if self.is_birthday_enabled:
                self.birth_date = self.customer.get('date_of_birth')
                if self.birth_date:
                    self.number_of_birthday_validity_days = get_birthday_offer_validity_in_days(self.birth_date)
                    if self.number_of_birthday_validity_days >= -1:
                        self.birthday_product_ids = Product.get_birthday_products(
                            self.location_id,
                            self.company,
                            column_to_get='id'
                        )
                        if self.product_id in self.birthday_product_ids:
                            self.is_birthday_offer = True
                            self.primary_user_id = self.customer_id

            if self.is_shared_offers_enabled:
                self.shared_offers_sent = ShareOffer.get_shared_offers_by_sender_primary(
                    self.primary_user_id,
                    offer_id=self.offer_id
                )

            if self.is_top_up_offers_enabled:
                self.top_up_offers = TopUpOffer.get_top_up_offers_primary(
                    self.primary_user_id,
                    self.location_id,
                    offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY,
                    offer_id=self.offer_id
                )

            if self.is_ent:
                redemption_quantities = user_redemptions_lookup_for_ent(
                    customer_id=self.primary_user_id,
                    is_using_trial=self.customer.get('is_using_trial'),
                    offer_ids=self.offer_id,
                    company=self.company
                )
            else:
                redemption_quantities = user_redemptions_lookup_hash(self.customer_id, self.company, [self.offer_id])

            current_date = datetime.datetime.now()
            date_from = current_date + datetime.timedelta(hours=Offer.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM)
            date_to = current_date + datetime.timedelta(hours=Offer.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)

            is_top_up_offer = False
            for top_up_offer in self.top_up_offers:
                if top_up_offer.offer_id == self.offer_id:
                    is_top_up_offer = True
                    break

            redeemability = calculate_redeemability(
                offer=self.offer,
                product_id=self.product_id,
                customer_product_ids=self.customer['product_ids'],
                redemption_quantities=redemption_quantities,
                date_from=date_from,
                date_to=date_to,
                is_ent=self.is_ent,
                member_group=self.member_group,
                shared_offers_sent=self.shared_offers_sent,
                is_top_up_offer=is_top_up_offer,
                birthday_product_ids=self.birthday_product_ids,
                is_take_away_enabled=self.is_takeaways_enabled,
                company=self.company
            )
            if not redeemability['is_redeemable']:
                self.send_response_flag = True
                self.status_code = 422
                self.response = {
                    "message": TranslationManager.get_translation(
                        TranslationManager.already_redeemed,
                        locale=self.locale
                    ),
                    "success": False,
                    "code": codes.UNPROCESSABLE_ENTITY
                }
                return self.send_response(self.response, self.status_code)
        else:
            if redeemability.get('redeemability', 0) in (Offer.NOT_REDEEMABLE, Offer.REDEEMED):
                self.send_response_flag = True
                self.status_code = 422
                self.response = {
                    "message": TranslationManager.get_translation(
                        TranslationManager.offer_is_not_redeemable,
                        locale=self.locale
                    ),
                    "success": False,
                    "code": 422
                }
                return self.send_response(self.response, self.status_code)

    def get_outlet_information(self):
        """
        Gets outlet information.
        """
        if self.is_ent:
            self.outlet = Outlet.get_by_id(self.outlet_id)
        else:
            self.outlet = Outlet.get_by_id_and_offer_id(self.outlet_id, self.offer_id)

        if not self.outlet:
            self.response = self.generate_response_dict(message=INVALID_OUTLET)
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response(self.response, self.status_code)

    def check_offer_is_related_to_product(self):
        """
        Checks if offer is bound with the respective product id.
        """
        if self.is_ent:
            self.product_offer = Product.get_product_by_offer_id(self.offer_id)
            if not self.is_shared:
                if self.product_id != self.product_offer.id:
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(
                        message=INVALID_PRODUCT.format(self.offer_id, self.product_id)
                    )
                    self.send_response(self.response, self.status_code)
            self.product_id = self.product_offer.id
        else:
            self.product_offer = ProductOffer.get_by_product_and_offer_id(self.product_id, self.offer_id)

    def verify_and_initialize_offer_for_custom_redemption_code(self):
        """
        Verifies and initializes offer for customer redemption code.
        """

        if self.offer and self.offer.has_red_custom_code:
            custom_code_info = get_custom_code_info(self.offer_id, True)
            if custom_code_info.get('code_id'):
                self.redemption_code = custom_code_info.get('custom_code')
                self.custom_code_id = custom_code_info.get('code_id')
            else:
                self.send_response_flag = True
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.OFFER_OUT_OF_CUSTOM_CODES,
                        self.locale
                    )
                )

    def set_company(self):
        """
        Sets company info.
        """
        self.company = get_api_version(company_code=self.company, request=request)
        if self.triggered_by == Redemption.REDEMPTION_TRIGGERED_BY_OFFLINE_API:
            self.company += '-off'

    def set_root_codes(self):
        """
        Get root codes from db for redemption.
        """
        self.root_code = None
        self.root_codes_from_offer = Product.get_root_code_by_offer(self.offer_id)
        if self.root_codes_from_offer:
            self.root_code = self.root_codes_from_offer.root_code

    def redeem(self):
        """
        Redeems the offer.
        """
        self.redemption_object = Redemption(
            customer_id=self.customer_id,
            offer_id=self.offer_id,
            outlet_id=self.outlet_id,
            session_token=self.session_token,
            transaction_id=self.transaction_id,
            product_id=self.product_id,
            company=self.company,
        )
        if self.is_ent:
            self.set_company()
            self.set_root_codes()
            self.savings_estimates = Offer.find_saving_estimates_by_offer_id(offer_id=self.offer_id).savings_estimate
            self.redemption_object.code = self.redemption_code
            self.redemption_object.is_shared = self.is_shared or False
            self.redemption_object.device_os = self.platform
            self.redemption_object.device_model = self.device_model
            self.redemption_object.device_language = self.device_language
            self.redemption_object.is_onboarding = self.is_on_boarding
            self.redemption_object.root_code = self.root_code
            self.redemption_object.primary_user_id = self.primary_user_id
            self.redemption_object.is_birthday_offer = self.is_birthday_offer
            self.redemption_object.conflict = len(self.root_codes_from_offer) > 1
            if self.offer.is_promo_code_offer:
                self.redemption_instance.az_sync = Offer.OFFER_AZ_SYNC
                self.redemption_instance.status = Offer.OFFER_ON_HOLD_STATUS

            if self.is_shared and not self.is_family_offer:
                del self.redemption_object.primary_user_id
        else:
            self.savings_estimates = self.offer.savings_estimate_local_currency
            self.redemption_object.az_sync = 0
            self.redemption_object.root_code = self.product_offer.root_code

        self.redemption_object.savings_estimate = self.savings_estimates
        self.redemption_object.insert_record()

        if self.is_ent and self.custom_code_id:
            custom_code_info = RedemptionCustomCode.get_custom_code_by_id(self.custom_code_id)
            custom_code_info.status = RedemptionCustomCode.CUSTOM_CODE_STATUS_USED
            custom_code_info.redemption_id = self.redemption_object.id
            custom_code_info.is_used = True
            custom_code_info.update_record()

        self.product_info = Product.get_by_id(self.product_id)
        if self.product_info.delivery_enabled:
            redemption_type = Redemption.TYPE_DELIVERY
        else:
            redemption_type = Redemption.TYPE_DEFAULT
        if self.is_ent and not self.redemption_code:
            self.redemption_object.code = generate_redemption_code(self.redemption_object.id, redemption_type)
        if not self.is_ent:
            self.redemption_object.code = generate_redemption_code(self.redemption_object.id, redemption_type)
        self.redemption_object.update_record()

    def update_user_savings(self):
        """
        Updates user savings
        :return:
        """
        user_savings = UserSaving.get_by_user_id_and_company(self.customer_id, self.company)
        if user_savings:
            UserSaving.update_user_savings(user_savings.id, self.customer_id, self.savings_estimates, self.points)
        else:
            new_user_savings = UserSaving(
                total_savings=self.savings_estimates,
                current_year_savings=self.savings_estimates,
                current_year_redemptions=1,
                total_redemptions=1,
                total_points=self.points,
                current_year_points=self.points,
                is_user_rank_processed=0,
                user_id=self.customer_id,
                company=self.company,
            )
            if self.is_ent:
                new_user_savings.user_rank = 1
                new_user_savings.is_user_rank_processed = 0
            new_user_savings.insert_record()

    def smiles_process(self):
        """
        Smiles Earn Process after redemption completed.
        """
        if self.is_smile_enabled:
            if self.product_info:
                if (
                    self.product_info.is_ent == 1 or
                    self.product_info.product_type == Product.PRODUCT_TYPE_BIRTHDAY
                ):
                    self.is_entertainer_product = True

            self.allowed_smiles_earned = allowed_smiles_earned(
                self.member_type_id,
                self.is_entertainer_product,
                self.is_app_tutorial
            )

            if self.allowed_smiles_earned and self.earn_gv_smiles:
                self.smile_to_earn_user_id = self.customer_profile.user_id
                self.secondary_user_id = None
                self.transaction_response = earn_smiles(
                    self.smile_to_earn_user_id,
                    self.locale,
                    self.savings_estimates,
                    SMILES_ACTION_EARN_REDEMPTION_ID,
                    secondary_user_id=self.secondary_user_id,
                    session_token=self.session_token
                )
                if self.transaction_response and self.transaction_response['transaction_id'] > 0:
                    self.smiles_earned = self.offer.savings_estimate

    def update_customer_profile_for_redemption(self):
        """
        Update customer profile for redemption.
        """
        if not self.is_app_tutorial:
            if not self.is_shared and self.is_on_boarding:
                self.redemption_count = self.customer_profile.onboarding_redemptions_count + 1
                data = {
                    'onboarding_redemptions_count': self.redemption_count
                }
                trial_redemption_limit = self.customer_profile.onboarding_redemptions_limit
                if not trial_redemption_limit:
                    trial_redemption_limit = EntCustomerProfile.TRAIL_REDEMPTIONS_LIMIT

                if self.redemption_count >= trial_redemption_limit:
                    data['onboarding_status'] = 2
                    data['member_group'] = EntCustomerProfile.MEMBERSTATUS_PROSPECT
                    data['new_member_group'] = EntCustomerProfile.MEMBERSTATUS_PROSPECT
                    data['onboarding_status'] = EntCustomerProfile.ONBOARDING_FINISHED
                    data['onboarding_enddate'] = get_current_date_time()
                    EntCustomerProfile.update_customer_profile(self.customer_id, data)
                    if self.is_using_extended_trial:
                        send_notification_on_trial_expiration(self.customer_id)
                else:
                    EntCustomerProfile.update_customer_profile(self.customer_id, data)
                    if self.is_using_extended_trial:
                        send_notification_on_trial_redemption(self.customer_profile)

    def insert_redemption_table_entry(self):
        """
        Insert a DB entry to redemption_ent_active table.
        """
        redemption_ent_active = Redemption(
            redemption_id=self.redemption_object.id,
            customer_id=self.redemption_object.customer_id,
            offer_id=self.offer_id,
            is_shared=self.is_shared,
            is_onboarding=self.is_on_boarding,
            primary_user_id=self.primary_user_id
        )
        if self.is_shared and not self.is_family_offer:
            del redemption_ent_active.primary_user_id
        redemption_ent_active.insert_record()

    def insert_informatica_db_entry(self):
        """
        Insert into INFORMATICA db.
        """
        mobile_redemption = MobileRedemption(
            id=self.redemption_object.id,
            customer_id=self.customer_id,
            quantity=self.redemption_object.quantity,
            code=self.redemption_object.code,
            offer_sf_id=self.offer.sf_id,
            outlet_sf_id=self.outlet.sf_id,
            merchant_sf_id=self.merchant.sf_id,
            root_code=self.redemption_object.root_code,
            company=self.company
        )
        if self.is_ent:
            mobile_redemption.session_token = self.session_token
            mobile_redemption.membership_code = self.customer_profile.membership_code   # check value in customer data
            mobile_redemption.date_created = self.redemption_object.date_created
        try:
            mobile_redemption.insert_record()
        except Exception as e:
            self.logger.warning("Error occurred while inserting redemption into informatica db: {}".format(e))

    def process_live_offers(self):
        """
        Get data dict containing deal_details & hours_validation_text keys of offer.
        deals details dict containing day wise data list will be in same order as displaying on redemption screen.
        """
        if self.offer.is_deals_product:
            redeemability_validity_data = get_deal_validity_data(
                self.offer, self.locale, self.location_id
            )
            can_redeem = False
            if redeemability_validity_data.get('is_redeemable'):
                can_redeem = True

            if not can_redeem:
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.OFFER_RESTRICTION_MESSAGE,
                        locale=self.locale
                    )
                )
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response(self.response, self.status_code)

    def build_redemption_response(self):
        """
        Builds redemption response.
        """
        self.redemption_response = {
            'redemption_code': self.redemption_object.code,
            'redemption_id': self.redemption_object.id,
            'is_redemption_already_made': False,
            'smiles_earned': self.smiles_earned,
            'coupon': ''
        }

    def call_business_db_update_api(self):
        """
        Calls business DB update API that creates entries in CustomerOrder, CustomerOrderItem, etc tables.
        """
        if self.is_offline_redemption:
            api_url = RedemptionServiceAPIUrlsV3.BUSINESS_DB_UPDATE_API
            auth_ = {"Authorization": request.environ.get('HTTP_AUTHORIZATION')},
            api_body = {
                "r_i": self.redemption_object.id,
                "locale": self.locale
            }
            biz_api_response = make_post_request(api_url=api_url, auth_headers=auth_, api_body=api_body)
            if not biz_api_response:
                self.status_code = codes.internal_server_error

    def generates_final_response(self):
        """
        Sets final response
        :rtype: dict
        """
        success = self.status_code == codes.OK
        if success:
            self.send_response_flag = True
            self.response = {
                'success': success,
                'message': TranslationManager.get_translation(
                    TranslationManager.SUCCESS,
                    self.locale
                ),
                'data': {"referenceNo": self.redemption_response}
            }
        else:
            self.send_response_flag = True
            self.response = {
                'success': success,
                'message': TranslationManager.get_translation(
                    TranslationManager.FAILURE,
                    self.locale
                ),
                'data': {"referenceNo": self.redemption_response}
            }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        self.get_company_configs()
        self.initialize_api_configurations()
        self.verify_reattempt_code_and_transaction()
        if self.send_response_flag:
            return
        self.load_customer_profile_and_member_group()
        self.initialize_offers_data()
        self.is_offer_exist()
        if self.send_response_flag:
            return

        self.verify_app_tutorial()
        if self.send_response_flag:
            return
        self.check_merchant()
        if self.send_response_flag:
            return
        self.verify_trial_period()
        if self.send_response_flag:
            return
        self.check_redeemability()
        if self.send_response_flag:
            return
        self.get_outlet_information()
        if self.send_response_flag:
            return
        self.check_offer_is_related_to_product()
        if self.send_response_flag:
            return
        self.verify_and_initialize_offer_for_custom_redemption_code()
        if self.send_response_flag:
            return
        self.process_live_offers()
        if self.send_response_flag:
            return
        self.redeem()
        if not self.offer.is_promo_code_offer:
            self.smiles_process()
            self.update_user_savings()
        self.update_customer_profile_for_redemption()
        self.insert_informatica_db_entry()
        self.build_redemption_response()
        self.call_business_db_update_api()
        self.generates_final_response()
