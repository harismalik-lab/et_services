"""
This modules loads APIs for a specific service
"""
from flask import g

from redemption_service.app.routings.routings_v1 import RedemptionAPIV1
from redemption_service.app.routings.routings_v2 import RedemptionAPIV2
from redemption_service.app.routings.routings_v3 import RedemptionAPIV3Routing


def api_urls():
    RedemptionAPIV1(app=g.app, name=RedemptionAPIV1.__name__).map_urls()
    RedemptionAPIV2(app=g.app, name=RedemptionAPIV2.__name__).map_urls()
    RedemptionAPIV3Routing(app=g.app, name=RedemptionAPIV3Routing.__name__).map_urls()
