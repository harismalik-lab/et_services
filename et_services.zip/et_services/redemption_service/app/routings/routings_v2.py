"""
This module contains routing for an app
"""
from redemption_service.app.routings.routings_v1 import RedemptionAPIV1


class RedemptionAPIV2(RedemptionAPIV1):
    api_version = '2'

    def set_routing_collection(self):
        super().set_routing_collection()
