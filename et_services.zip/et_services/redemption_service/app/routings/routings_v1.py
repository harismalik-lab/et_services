"""
This module contains routing for an app
"""
from flask import current_app
from redemption_service.app.api.v1.calculate_redeemability import \
    CalculateRedeemabilityAPI
from redemption_service.app.api.v1.offer_redeemability import \
    OfferRedeemability
from redemption_service.app.api.v1.redeem import RedemptionAPI
from redemption_service.common.base_routing import BaseRouting


class RedemptionAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['REDEMPTION_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['check_redeemability'] = {
            'url': '/offer/check/redeemability',
            'view': CalculateRedeemabilityAPI
        }
        self.routing_collection['redeem'] = {
            'url': '/offer/redeem',
            'view': RedemptionAPI
        }
        self.routing_collection['offer_redeemability'] = {
            'url': '/offer/redeemability',
            'view': OfferRedeemability
        }
