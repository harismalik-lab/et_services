"""
This module contains routing for an app
"""

from redemption_service.app.api.v3.calculate_redeemability import \
    CalculateRedeemabilityAPIV3
from redemption_service.app.api.v3.redeem import RedemptionAPIV3
from redemption_service.app.routings.routings_v2 import RedemptionAPIV2


class RedemptionAPIV3Routing(RedemptionAPIV2):
    api_version = '3'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['check_redeemability'] = {
            'url': '/offer/check/redeemability',
            'view': CalculateRedeemabilityAPIV3
        }
        self.routing_collection['redeem'] = {
            'url': '/offer/redeem',
            'view': RedemptionAPIV3
        }
