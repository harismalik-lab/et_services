import datetime
from json import JSONDecodeError
from urllib import parse

import requests
from dateutil.tz import tz
from flask import current_app

from common.constants import LOCATION_TIME_ZONE_MAP
from common.utils.api_utils import calculate_dc_prospect_offer_redeemability
from common.utils.translation_manager import TranslationManager
from redemption_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from redemption_service.common.models.offer import Offer
from redemption_service.common.models.redemption import Redemption
from redemption_service.common.models.redemption_custom_codes import \
    RedemptionCustomCode
from redemption_service.common.utils.appboy_push_notifications import \
    send_user_data
from redemption_service.modules.constants import (ENTERTAINER_GAMIFICATION_ACTION_EARN,
                                                  RESPONSE_CODE_FAILURE_CALL_FAILED_TO_GAMIFICATION_PLATFORM,
                                                  RESPONSE_CODE_SUCCESS)


def get_api_version(company_code='entertainer', request=None):
    if not request or not request.url:
        return company_code
    else:
        try:
            blueprint = getattr(request, 'blueprint', '')
            # example if blueprint is api_v59
            api_version = blueprint.split('_')[1]  # v59
            return "{company_code}-{api_version}".format(company_code=company_code, api_version=api_version)
        except Exception:
            return company_code


def get_custom_code_info(offer_id, lock_code_if_available=False):
    """
    This function returns unused custom code associated to the offer.
    :param int offer_id: offer Id
    :param bool lock_code_if_available: Pass True if you need to reserve the the custom code being returned by
    this function
    :return:
    """
    offer_custom_code_info = {
        'offer_id': int(offer_id),
        'code_id': 0,
        'custom_code': ''
    }
    custom_code_info = RedemptionCustomCode.get_custom_code_for_offer(offer_id)
    if custom_code_info:
        if lock_code_if_available:
            custom_code_info.status = RedemptionCustomCode.CUSTOM_CODE_STATUS_RESERVED
            custom_code_info.redemption_id = 0
            custom_code_info.is_used = False
            custom_code_info.update_record()
        offer_custom_code_info['code_id'] = int(custom_code_info.id)
        offer_custom_code_info['custom_code'] = str(custom_code_info.code)
    return offer_custom_code_info


def send_notification_on_trial_expiration(customer_id):
    """
    Sends notification on trial expiration
    """
    user_data = {
        'user_id': customer_id,
        'extended_trial_ended': True,
        'external_id': customer_id
    }
    send_user_data(user_data=user_data)


def send_notification_on_trial_redemption(customer_profile):
    """
    Sends notification on trial redemption
    """
    user_data = {
        'user_id': customer_profile.user_id,
        'external_id': customer_profile.user_id
    }
    if customer_profile.onboarding_redemptions_count == 1:
        user_data['first_redemption'] = True
    if customer_profile.onboarding_redemptions_count == 2:
        user_data['second_redemption'] = True
    if customer_profile.onboarding_redemptions_count == 3:
        user_data['third_redemption'] = True
    if customer_profile.onboarding_redemptions_count <= 3:
        send_user_data(user_data=user_data)


def allowed_smiles_earned(membership_type, is_entertainer_product, is_app_tutorial):
    if (
            membership_type == EntCustomerProfile.MEMBERSTATUS_MEMBER and
            is_entertainer_product and not is_app_tutorial
    ):
        return True
    return False


def earn_smiles(user_id, locale, points, app_action_id, secondary_user_id=None, session_token=''):
    transaction_response = {
        'is_succeeded': False,
        'response_code': 0,
        'transaction_id': 0,
        'message': '',
        'balance': 0
    }
    try:
        gamification_url = get_gamification_url()
        smiles_url = '{}{}'.format(gamification_url, ENTERTAINER_GAMIFICATION_ACTION_EARN)
        data = {
            'token': current_app.config['ENTERTAINER_GAMIFICATION_API_KEY'],
            'user_id': user_id,
            'lang': locale,
            'app_action_id': app_action_id,
            'points': points,
            'session_token': session_token
        }
        if secondary_user_id:
            data['secondary_user_id'] = secondary_user_id
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        response = perform_request(smiles_url, 'post', data, headers=headers)
        try:
            json_response = response.json()
            status = json_response.get('success', False)
        except JSONDecodeError:
            status = False
            json_response = {
                'data': None
            }
        if not status:
            transaction_response['is_succeeded'] = False
            transaction_response['message'] = "This feature is currently unavailable. Please try again later."
            transaction_response['response_code'] = RESPONSE_CODE_FAILURE_CALL_FAILED_TO_GAMIFICATION_PLATFORM
            transaction_response['transaction_id'] = json_response['data']['info']['transaction_id']
        else:
            if 'data' in json_response.keys() and 'info' in json_response['data'].keys():
                transaction_response['message'] = json_response['data']['info']['message']
                transaction_response['response_code'] = RESPONSE_CODE_SUCCESS
                if json_response['data']['info']['transaction_id'] > 0:
                    transaction_response['is_succeeded'] = True
                    transaction_response['transaction_id'] = json_response['data']['info']['transaction_id']
    except Exception:
        # self.logger.exception('Failed to earn smiles for user_id:{user_id}.'.format(user_id=user_id))
        pass
    return transaction_response


def get_gamification_url():
    return current_app.config['GAMIFICATION_URL']


def perform_request(url, request_type, data, headers=None):
    response = None
    if request_type == 'post':
        response = requests.post(
            url,
            data=data,
            auth=(
                current_app.config['GAMIFICATION_CONFIG'].get('user'),
                current_app.config['GAMIFICATION_CONFIG'].get('password')
            )
        )
    elif request_type == 'get':
        response = requests.get(
            '{0}?{1}'.format(url, parse.urlencode(data)),
            auth=(
                current_app.config['GAMIFICATION_CONFIG'].get('user'),
                current_app.config['GAMIFICATION_CONFIG'].get('password')
            )
        )
    return response


def user_redemptions_lookup_for_ent(customer_id, is_using_trial, offer_ids, company):
    """
    Returns user redemptions lookup hash
    :rtype: dict
    """

    user_redemptions = Redemption.get_redeemed_quantities_for_customer_primary_v3(
        customer_id=customer_id,
        is_onboarding=is_using_trial,
        offer_id=offer_ids,
        company=company
    )

    redemption_quantities = {}

    for redemption in user_redemptions:

        index = "{}_{}".format(redemption.offer_id, redemption.product_id)
        if not redemption_quantities.get(index):
            redemption_quantities[index] = int(redemption.quantity)
        else:
            redemption_quantities[index] = redemption_quantities.get(index) + int(redemption.quantity)

    return redemption_quantities


def get_birthday_offer_validity_in_days(birth_date):
    current_date = datetime.datetime.now().date()
    try:
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=birth_date.day
        )
    except ValueError:  # For 29th Feb on non leap year
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=28
        )
    birthday_start_period = birthday_period + datetime.timedelta(days=EntCustomerProfile.HAPPY_BIRTHDAY_START_RANGE_DAYS)
    birthday_end_period = birthday_period + datetime.timedelta(days=EntCustomerProfile.HAPPY_BIRTHDAY_END_RANGE_DAYS)
    if birthday_start_period <= current_date <= birthday_end_period:
        return (birthday_end_period - current_date).days
    return -1


def calculate_redeemability(**kwargs):
    """
    Calculates if an offer is redeemable or not and returns it's redeemability dict.
    """

    # Read keyword arguments.

    offer = kwargs.get('offer')
    product_id = kwargs.get('product_id')
    customer_product_ids = kwargs.get('customer_product_ids')
    redemption_quantities = kwargs.get('redemption_quantities')
    date_from = kwargs.get('date_from')
    date_to = kwargs.get('date_to')
    member_group = kwargs.get('member_group')
    shared_offers_sent = kwargs.get('shared_offers_sent')
    birthday_product_ids = kwargs.get('birthday_product_ids', [])
    quantity = kwargs.get('quantity', 0)
    location_id = kwargs.get('location_id', 0)
    is_top_up_offer = kwargs.get('is_top_up_offer')
    is_take_away_enabled = kwargs.get('is_take_away_enabled')
    is_ent = kwargs.get('is_ent')
    company = kwargs.get('company')

    # Set defaults.
    num_purchased = 0
    num_redemptions = 0
    shared_sent_count = 0
    message = ''
    is_redeemable = False
    is_offer_valid_in_future = False
    is_offer_expired = False
    allowed_onboarding = False
    is_show_purchase_button = False

    redeemability_value = Offer.NOT_REDEEMABLE
    total_product_ids = customer_product_ids + birthday_product_ids
    is_purchased = product_id in total_product_ids

    for shared_offer_sent in shared_offers_sent:
        if shared_offer_sent.offer_id == offer.id:
            shared_sent_count = shared_sent_count + 1

    if redemption_quantities:
        redemption_key = "{}_{}".format(offer.id, product_id)
        num_redemptions = redemption_quantities.get(redemption_key) or 0

    if offer.valid_from > date_from:
        is_offer_valid_in_future = True

    if offer.valid_to < date_to:
        is_offer_expired = True

    num_purchased += int((total_product_ids.count(product_id or 0) * int(offer.quantity or 0)))

    if shared_sent_count:
        num_purchased = num_purchased - shared_sent_count

    is_dc_prospect_enabled = calculate_dc_prospect_offer_redeemability(
        offer=dict((zip(offer._fields, offer))),
        member_group=member_group,
        location_id=location_id,
        company=company,
        take_away_enabled=is_take_away_enabled
    )
    if is_dc_prospect_enabled:
        num_purchased = num_redemptions + 1

    # If offer is top up offer then decrease in number of redemptions made by user.
    if is_top_up_offer and num_redemptions:
        num_redemptions = num_redemptions - 1

    if (
        not is_ent and
        offer.type == Offer.TYPE_MEMBER and
        is_purchased
    ):
        num_purchased = int(num_redemptions) + 1

    if (
        is_ent and
        offer.type == Offer.TYPE_MEMBER and
        is_purchased and
        member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER
    ):
        num_purchased = int(num_redemptions) + 1

    if (
        not is_offer_valid_in_future and
        not is_offer_expired and
        int(num_purchased) > int(num_redemptions) and
        int(num_purchased) > 0
    ):
        is_redeemable = True
        if is_ent:
            # Check to validate that either user can redeem the given amount of quantity of offer
            # For example if offer quantity is 2, we are checking here its should be less than
            # redemption_quantity_remaining.

            redemption_quantity_remaining = (num_purchased - num_redemptions)

            if not quantity or (quantity <= redemption_quantity_remaining):
                redeemability_value = (
                    Redemption.REUSABLE if offer.type == Offer.TYPE_MEMBER else Redemption.REDEEMABLE
                )

            elif quantity and (redemption_quantity_remaining < quantity):
                message = 'Offer can only be redeemed {number} times'.format(number=redemption_quantity_remaining)

        else:
            if offer.type == Offer.TYPE_DEFAULT:
                redeemability_value = Redemption.REDEEMABLE

            else:
                redeemability_value = Redemption.REUSABLE

    elif int(num_redemptions) >= int(num_purchased) > 0:
        redeemability_value = Redemption.REDEEMED

    else:
        redeemability_value = Redemption.NOT_REDEEMABLE

    return {
        'is_redeemable': is_redeemable,
        'redeemability': redeemability_value,
        'is_purchased': is_purchased,
        'is_offer_valid_in_future': is_offer_valid_in_future,
        'is_offer_expired': is_offer_expired,
        'quantity_redeemable': offer.quantity if redeemability_value == Redemption.REUSABLE else
        max(0, int(num_purchased) - int(num_redemptions)),
        'quantity_redeemed': 0 if redeemability_value == Redemption.REUSABLE else num_redemptions,
        'quantity_not_redeemable': offer.quantity if not is_purchased and not allowed_onboarding else 0,
        'is_show_purchase_button': is_show_purchase_button,
        'message': message
    }


def get_current_time_of_location(location_id):
    """
    Return current native datetime as per location.
    :param int location_id: user selected location id
    :return datetime: native datetime obj
    """
    location_utc_offset = LOCATION_TIME_ZONE_MAP.get(location_id, 1)
    utc_offset = 'UTC{offset}'.format(offset=location_utc_offset)
    location_current_time = datetime.datetime.now(tz.gettz(utc_offset))
    # convert timezone aware datetime to native datetime because in our app
    # we are using native datetime at all places
    location_current_time = location_current_time.replace(tzinfo=None)
    return location_current_time


def get_deal_validity_data(offer, locale, location_id):
    """
    Verifies offer time and days
    1. verify is offer valid for whole week or not
    2. verify on which day offer is valid
    3. verify offer valid for whole day or for some time span
    :param offer: offer
    :param str locale: language to get error message in selected language
    :param int location_id: location id to calculate time in current location
    :returns dict of offer redeemability flag, offer redeemability value, error message title and error_message
    :rtype dict
    """
    try:
        offer = dict((zip(offer._fields, offer)))
        # extract data from offer
        offer_valid_to_time = offer.get('valid_to_time')
        offer_valid_from_time = offer.get('valid_from_time')
        # get utc_time and convert into user timezone. and then convert it into timedelta object for comparison
        current_location_time = get_current_time_of_location(location_id)
        current_day = current_location_time.strftime('%A')
        utc_time = datetime.timedelta(
            hours=current_location_time.hour, minutes=current_location_time.minute,
            seconds=current_location_time.second
        )
        is_deal_valid_on_day = False
        # check offer settings updated or not w.r.t deals columns
        # check deal valid on that day
        if (
            offer.get('deal_validity_all_week') or
            offer.get('deal_valid_on_{current_day}'.format(current_day=current_day.lower()))
        ):
            is_deal_valid_on_day = True
        # check deal validity on that hours
        if is_deal_valid_on_day and (
            offer.get('deal_validity_all_day') or
            (offer_valid_from_time < utc_time < offer_valid_to_time)
        ):
            return {
                'is_redeemable': True,
                'redeemability': Redemption.REDEEMABLE,
                'restriction_title': '',
                'restriction_message': ''
            }
        # generating error message
        error_message = TranslationManager.get_translation(
            TranslationManager.OFFER_RESTRICTION_MESSAGE,
            locale
        )
        offer_restriction_title = TranslationManager.get_translation(TranslationManager.OOPS_TEXT, locale)
        return {
            'is_redeemable': False,
            'redeemability': Redemption.NOT_REDEEMABLE,
            'restriction_title': offer_restriction_title,
            'restriction_message': error_message
        }
    except Exception:
        return {
            'is_redeemable': False,
            'redeemability': Redemption.NOT_REDEEMABLE,
            'restriction_title': '',
            'restriction_message': ''
        }
