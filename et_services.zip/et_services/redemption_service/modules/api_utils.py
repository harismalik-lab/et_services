"""
API utils methods reside here
"""
import math

from redemption_service.common.models.offer_wl_active import OfferWlActive
from redemption_service.common.models.redemption import Redemption
from redemption_service.modules.constants import REDEMPTION_CODE_FACTOR


def user_redemptions_lookup_hash(customer_id, company, offer_ids):
    """
    Returns user redemptions lookup hash
    :rtype: dict
    """
    user_redemptions = Redemption.get_by_customer_id_and_company(customer_id, company, offer_ids)
    redemption_quantities = {}
    for redemption in user_redemptions:
        index = "{}_{}".format(redemption.offer_id, redemption.product_id)
        if not redemption_quantities.get(index):
            redemption_quantities[index] = redemption.quantity
        else:
            redemption_quantities[index] = redemption_quantities.get(index) + redemption.quantity
    return redemption_quantities


def calculate_redeemability(offer, customer_product_ids, redemption_quantities, date_from, date_to):
    """
    Calculates if an offer is redeemable or not and returns it's redeemability dict
    :param datetime.datetime date_to: Offer expiration date
    :param datetime.datetime date_from: Offer validation date
    :param dict redemption_quantities: Customer redemption hash
    :param list customer_product_ids: Customer purchased product ids
    :param OfferWlActive offer: Offer
    """
    is_redeemable = False
    num_purchased = 0
    num_redemptions = 0
    is_offer_valid_in_future = False
    is_offer_expired = False
    allowed_onboarding = False
    is_purchased = offer.product_id in customer_product_ids

    if redemption_quantities:
        check = "{}_{}".format(offer.id, offer.product_id)
        if redemption_quantities.get(check):
            num_redemptions = redemption_quantities.get(check)
        else:
            num_redemptions = 0

    if offer.valid_from > date_from:
        is_offer_valid_in_future = True

    if offer.valid_to < date_to:
        is_offer_expired = True

    num_purchased += int((customer_product_ids.count(offer.product_id or 0) * int(offer.quantity or 0)))

    if offer.type == OfferWlActive.TYPE_MEMBER and is_purchased:
        num_purchased = int(num_redemptions) + 1

    if (
            not is_offer_valid_in_future and
            not is_offer_expired and
            int(num_purchased) > int(num_redemptions) and
            int(num_purchased) > 0
    ):
        is_redeemable = True
        if offer.type == OfferWlActive.TYPE_DEFAULT:
            redeemability_value = Redemption.REDEEMABLE
        else:
            redeemability_value = Redemption.REUSABLE

    elif int(num_redemptions) >= int(num_purchased) > 0:
        redeemability_value = Redemption.REDEEMED
    else:
        redeemability_value = Redemption.NOT_REDEEMABLE

    is_show_purchase_button = False

    return {
        'is_redeemable': is_redeemable,
        'redeemability': redeemability_value,
        'is_purchased': is_purchased,
        'is_offer_valid_in_future': is_offer_valid_in_future,
        'is_offer_expired': is_offer_expired,
        'quantity_redeemable': offer.quantity if redeemability_value == Redemption.REUSABLE else
        max(0, int(num_purchased) - int(num_redemptions)),
        'quantity_redeemed': 0 if redeemability_value == Redemption.REUSABLE else num_redemptions,
        'quantity_not_redeemable': offer.quantity if not is_purchased and not allowed_onboarding else 0,
        'is_show_purchase_button': is_show_purchase_button
    }


def get_redemption_code(initial_code):
    """
    Generates redemption code prefix, choose alphabet according to initial_code parameter
    :param int initial_code: Alphabets Index
    """
    alphabets = [
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
        "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
    ]
    if initial_code > 25:
        return 'A' + alphabets[initial_code % 26]
    else:
        return alphabets[initial_code]


def generate_redemption_code(redemption_id, redemption_type=1, code_prefix=None):
    """
    Generates redemption code according to provided params
    :param int redemption_id: Redemption Id
    :param int redemption_type: Redemption Type Default or Delivery
    :param str code_prefix: Redemption Code Prefix
    :rtype: str
    """
    code = "Invalid Id."
    if redemption_id and redemption_id > 0:
        initial_code = math.floor((redemption_id - 1) / REDEMPTION_CODE_FACTOR)

        if redemption_id % REDEMPTION_CODE_FACTOR == 0:
            code = REDEMPTION_CODE_FACTOR
        else:
            code = '%09d' % (redemption_id % REDEMPTION_CODE_FACTOR)

        if redemption_type == Redemption.TYPE_DELIVERY:
            code_prefix = "DLC"
        else:
            code_prefix = code_prefix or get_redemption_code(initial_code)
        code = str(code)
        code = '{}-{}-{}-{}'.format(code_prefix, code[0:3], code[3:6], code[6:9])
    return code


def fix_offer_valid_from_and_valid_to_dates(offer):
    """
    convert orm obj to dict to update attr values
    add cushion to offer `valid_from` and `valid_to dates`
    :param offer:
    :return: offer obj from dict
    """
    offer = offer._asdict()
    offer['valid_from'] = offer['valid_from'].replace(
        hour=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_VALID_FROM,
        minute=0,
        second=0
    )
    offer['valid_to'] = offer['valid_to'].replace(
        hour=OfferWlActive.HOURS_ADJUSTMENT_FOR_OFFER_VALID_TO,
        minute=0,
        second=0
    )
    return DictToObj(**offer)


class DictToObj:
    """
    converts a dict into obj
    """

    def __init__(self, **entries):
        self.__dict__.update(entries)
