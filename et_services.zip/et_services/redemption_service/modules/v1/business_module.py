"""
Static variables and helper methods to be used in regards to changes in business tables.

This class can be overridden to change behaviour for different versions of APIs.
"""
from redemption_service.common.constants import BASE_CURRENCY


class BusinessModule(object):

    @staticmethod
    def get_customer_order_object(**kwargs):
        """
        Creating customer order object for insertion in DB.
        """
        if not kwargs.get('customer'):
            raise Exception('Customer not present for order.')

        return {
            'customer_id': kwargs['customer']['customer_id'],
            'customer_email': kwargs['customer']['email'],
            'customer_name': kwargs['customer']['name'],
            'company': kwargs['customer']['company'],
            'order_number': kwargs['order_number'],
            'tracking_number': kwargs['redemption'].transaction_id,
            'merchant_sf_id': kwargs['outlet'].merchant_sf_id,
            'merchant_id': kwargs['outlet'].merchant_id,
            'outlet_sf_id': kwargs['outlet'].outlet_sf_id,
            'outlet_id': kwargs['outlet'].outlet_id,
            'module_id': kwargs['module'].id,
            'order_status_id': kwargs['completed_order_status_id'],
            'order_currency': BASE_CURRENCY,
            'base_currency': BASE_CURRENCY,
            'total_discount': kwargs['redemption'].savings_estimate,
            'base_total_discount': kwargs['redemption'].savings_estimate,
            'placed_from': kwargs['redemption'].device_os,
            'app_version': kwargs['customer']['app_version'],
            'company_id': kwargs['module'].company_id,
            'location_id': kwargs['location_id'],
            'items_count': 1,
            'total_paid': 0,
            'base_total_paid': 0,
            'sub_total': 0,
            'base_sub_total': 0,
            'payment_mode': 0,
            'payment_method': 'offline'
        }

    @staticmethod
    def get_customer_order_item_object(**kwargs):
        return {
            'item_name': 'redemption',
            'offer_sf_id': kwargs['offer'].offer_sf_id,
            'offer_name': kwargs['offer'].offer_name,
            'order_id': kwargs['customer_order_id'],
            'quantity': kwargs['redemption'].quantity,
            'total_price': 0,
            'base_total_price': 0,
            'sub_total': 0,
            'base_sub_total': 0,
            'total_discount': kwargs['redemption'].savings_estimate,
            'base_total_discount': kwargs['redemption'].savings_estimate,
            'redemption_id': kwargs['redemption'].id,
            'offer_id': kwargs['redemption'].offer_id,
            'product_sku': kwargs['product'].sf_id
        }
