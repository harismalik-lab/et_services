import multiprocessing
import os
import sys
service_path = '/home/alftdeploy/alfuttaim'
sys.path.append(service_path)
from redemption_service.common.routes import TEAPIs

parent_directory = os.getcwd()
chdir = parent_directory
pythonpath = '{path}/env'.format(path=parent_directory)
accesslog = '{path}/logs/redemption_service-access.log'.format(path=parent_directory)
errorlog = '{path}/logs/redemption_service-error.log'.format(path=parent_directory)
capture_output = True
raw_env = 'APPLICATION_SETTINGS={path}/et_instance_settings/prod_settings.py'.format(path=service_path)

bind = '0.0.0.0:{port}'.format(port=TEAPIs.REDEMPTION_SERVICE_PORT)
timeout = 120
workers = multiprocessing.cpu_count() * 2 + 1
preload_app = True
proc_name = 'redemption_service'

files_to_create = [accesslog, errorlog]
for log_file in files_to_create:
    open(log_file, "wb").close()
