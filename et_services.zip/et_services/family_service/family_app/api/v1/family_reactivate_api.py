"""
Reactivate Family Endpoint
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.ent_customer_profile import EntCustomerProfile
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.family_app.api.v1.validations.family_reactivate_api_validator import family_reactivate_parser


class FamilyReactivate(BasePostResource):
    """
    Class handles the reactivate family endpoint
    """
    request_parser = family_reactivate_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='family_reactivate/family_reactivate.log',
        ),
        'name': 'family_reactivate'
    }

    def populate_request_arguments(self):
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.location_id = self.request_args.get('location_id', 0)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        self.get_session_info()
        if self.customer_data.get('is_primary', False):
            self.family_info = Family.find_family(
                filters={'user_id': self.customer_data.get('user_id')}
            )
            if self.family_info.status in [Family.EXPIRED, Family.ON_GRACE_PERIOD]:
                activate_members = self.family_info.status == Family.ON_GRACE_PERIOD
                self.family_info = self.family_info.to_dict()
                Family.update_family(
                    filters={'id': self.family_info.get('id')},
                    data={
                        'is_active': 1,
                        'status': Family.ACTIVE,
                        'reason': Family.FAMILY_REACTIVATED
                    }
                )
                if self.family_info.get('is_active') and activate_members:
                    family_members = FamilyMember.find_family_invitations_pending_accepted(
                        family_id=self.family_info.get('id'),
                        include_active_status=False,
                        include_primary=False
                    )
                    if family_members:
                        family_members_email_not_registered = []
                        family_members_user_ids = []
                        filtered_users_id = []
                        filtered_families_emails_id = []
                        family_members_hash = dict()
                        for family_member in family_members:
                            if family_member.user_id:
                                family_members_hash[family_member.user_id] = family_member.id
                                family_members_user_ids.append(family_member.user_id)
                            else:
                                family_members_hash[family_member.email] = family_member.id
                                family_members_email_not_registered.append(family_member.email)
                        family_members_families = FamilyMember.find_family_members_part_of_any_family(
                            user_ids=family_members_user_ids,
                            email_list=family_members_email_not_registered,
                            family_id=self.family_info.get('id')
                        )
                        for family_member in family_members_families:
                            if family_member.user_id:
                                filtered_users_id.append(family_member.user_id)
                            else:
                                filtered_families_emails_id.append(family_member.email)

                        family_members_user_ids = list(
                            set(family_members_user_ids) - set(filtered_users_id)
                        )
                        family_members_email_not_registered = list(
                            set(family_members_email_not_registered) - set(filtered_families_emails_id)
                        )
                        customer_profiles = EntCustomerProfile.load_customer_profile_and_user_info_by_id(
                            customer_ids=family_members_user_ids
                        )
                        family_members_user_ids = []
                        for customer_profile in customer_profiles:
                            if customer_profile.user_id == self.customer_data.get('user_id'):
                                family_members_user_ids.append(customer_profile.get('user_id'))
                            elif customer_profile.new_member_group != EntCustomerProfile.MEMBERSTATUS_MEMBER:
                                family_members_user_ids.append(customer_profile.user_id)
                        family_members_user_ids = list(set(family_members_user_ids))
                        family_members_ids = []
                        for family_members_user_id in family_members_user_ids:
                            family_members_ids.append(family_members_hash[family_members_user_id])
                        for family_member_email_not_registered in family_members_email_not_registered:
                            family_members_ids.append(family_members_hash[family_member_email_not_registered])

                        FamilyMember.update_member(
                            data={'is_active': 1},
                            filters={'is_active': 0, 'family_id': self.family_info.get('id')},
                            in_filters=[{'id': family_members_ids}]
                        )
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': True,
                'message': 'success'
            }
            self.status_code = 200
            return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': Family.NOT_ALLOWED_FAMILY_REACTIVATED
            }
            self.status_code = 422
            return
