"""
Family Pending Invites Api
"""
import datetime

import timeago
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.ent_customer_profile import EntCustomerProfile
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.models.location import Location
from family_service.common.utils.api_utils import multi_key_sort
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.pending_invites_validator import pending_family_invites_parser


class PendingInvites(BasePostResource):
    """
    Class handles the family pending invites endpoint
    """
    request_parser = pending_family_invites_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='family_pending_invites/family_pending_invites.log',
        ),
        'name': 'family_pending_invites'
    }

    def populate_request_arguments(self):
        """
        Populates Request Arguments
        """
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.location_id = self.request_args.get('location_id', '')

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def traverse_pending_invites(
            self, pending_invites, customer_profiles, families_primaries_users, location_name, data
    ):
        """
        Setting the Pending invites data
        """
        for pending_invite in pending_invites:
            is_cheers_to_include = bool(pending_invite.show_cheers_popup)
            pending_invite_data = {
                "family_id": pending_invite.family_id,
                "identifier": pending_invite.identifier,
                "time_stamp": timeago.format(
                    datetime.datetime.now(), pending_invite.date_created
                ).replace('in ', '') + ' ago',
                'time_seconds': (pending_invite.date_created - datetime.datetime.now()).seconds,
                'is_alcohal': is_cheers_to_include,
                'join_family_text': self.translation_manager.get_translation(
                    self.translation_manager.JOIN_FAMILY_TITLE,
                    self.device_language
                ),
                'decline_family_text': FamilyMember.DECLINE_FAMILY_TITLE,
                'join_family_button_color': FamilyMember.JOIN_FAMILY_BUTTON_COLOR,
                "decline_family_button_color": FamilyMember.DECLINE_FAMILY_BUTTON_COLOR,
                'decline_family_button_border_color': FamilyMember.DECLINE_FAMILY_BORDER_COLOR
            }
            email = customer_profiles[families_primaries_users[pending_invite.family_id].get('user_id')].email
            name = customer_profiles[
                families_primaries_users[pending_invite.family_id].get('user_id')
            ].firstname
            pending_invite_data['profile_img'] = customer_profiles[
                families_primaries_users[pending_invite.family_id]['user_id']
            ].profile_image
            pending_invite_data['message'] = FamilyMember.MEMBER_INVITATION_MESSAGE.format(
                name=name, email=email
            )
            pending_invite_data['name'] = name
            if is_cheers_to_include:
                if self.location_id and self.location_id in Location.GCC_LOCATION_IDS:
                    pending_invite_data["restriction_message"] = FamilyMember.CONSENT_CONFIRMATION_MESSAGE_WANT_CHEERS.format(location=location_name)  # noqa: E501
                else:
                    pending_invite_data["restriction_message"] = FamilyMember.CONSENT_CONFIRMATION_MESSAGE_WANT_CHEERS_NON_GCC.format(location=location_name)  # noqa: E501
                pending_invite_data[
                    'restriction_message_no_cheers_message'] = FamilyMember.CONSENT_CONFIRMATION_MESSAGE_DONOT_WANT_CHEERS  # noqa: E501
            data['pending_invites'].append(pending_invite_data)
        data['pending_invites'] = multi_key_sort(data['pending_invites'], columns=['-time_seconds', 'name'])

    def process_request(self, *args, **kwargs):
        """
        Process the request
        """
        self.get_session_info()
        self.translation_manager = TranslationManager()
        data = {'message': FamilyMember.NO_INVITATION_FOUND}
        if not self.customer_data.get('is_user_in_family', False):
            del data['message']
            data['pending_invites'] = []
            if not self.customer_data.get('is_primary', False):
                family_ids = []
                primary_users_ids = []
                families_primaries_users = {}
                location_name = Location.get_location_translation_by_location_id(
                    self.location_id, self.device_language
                )
                pending_invites = FamilyMember.find_pending_invites_of_user(
                    user_id=self.customer_data.get('user_id', 0)
                )
                for pending_invite in pending_invites:
                    family_ids.append(pending_invite.family_id)
                family_ids = list(set(family_ids))
                if family_ids:
                    families_info = Family.find_family(
                        in_filters=[{'id': family_ids}], single=False
                    )
                    for family_info in families_info:
                        families_primaries_users[family_info.id] = {
                            'user_id': family_info.user_id,
                            'name': family_info.name
                            # 'profile_image': family_info.profile_image
                        }
                        primary_users_ids.append(family_info.user_id)
                    primary_users_ids = list(set(primary_users_ids))
                    if primary_users_ids:
                        customer_profiles = EntCustomerProfile.load_customer_profile_by_user_id(
                            user_id=primary_users_ids
                        )
                self.traverse_pending_invites(
                    pending_invites, customer_profiles, families_primaries_users, location_name, data
                )
            if not data['pending_invites']:
                data['message'] = FamilyMember.NO_INVITATION_FOUND

        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
