"""
My Family Api
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.ent_customer_profile import EntCustomerProfile
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.api_utils import multi_key_sort
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.my_family_api_validator import my_family_parser


class MyFamily(BasePostResource):
    """
    Class handles the family member details endpoint
    """
    request_parser = my_family_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='my_family/my_family.log',
        ),
        'name': 'my_family'
    }

    def populate_request_arguments(self):
        """
        Populates Request Arguments
        """
        self.device_language = self.request_args.get('language', '')

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def set_header_section(self, data, family_status):
        """
        Sets the header section for family screen
        """
        data['header_section'] = dict()
        data['header_section']['title'] = self.translation_manager.get_translation(
            self.translation_manager.FAMILY_HEADER_TITLE, self.device_language
        )
        data['member_info'] = dict()
        data['member_info']['is_expired'] = family_status == Family.EXPIRED
        data['member_info']['is_grace_period_running'] = family_status == Family.ON_GRACE_PERIOD
        data['member_info']['is_primary_member'] = self.customer_data.get('is_primary', False)
        data['member_info']['button_title'] = self.translation_manager.get_translation(
            self.translation_manager.BUTTON_LEAVE_FAMILY_TITLE,
            self.device_language
        )
        data['member_info']['button_color'] = FamilyMember.BUTTON_LEAVE_FAMILY_COLOR
        data['member_info']['family_delete_message'] = self.translation_manager.get_translation(
            self.translation_manager.CONFIRM_LEAVE_SECONDARY,
            self.device_language
        )

    def set_info_for_primary_member(self, data):
        """
        Sets the primary member info
        """
        data['member_info']['family_delete_message'] = self.translation_manager.get_translation(
            self.translation_manager.CONFIRM_LEAVE_PRIMARY,
            self.device_language
        )
        data['member_info']['button_title'] = self.translation_manager.get_translation(
            self.translation_manager.BUTTON_CLOSE_FAMILY_TITLE,
            self.device_language)
        data['member_info']['button_color'] = FamilyMember.BUTTON_CLOSE_FAMILY_COLOR
        if data['member_info']['is_expired']:
            data['member_info']['text'] = self.translation_manager.get_translation(
                self.translation_manager.FAMILY_EXPIRED,
                self.device_language
            )
            data['member_info']['button_title'] = FamilyMember.BUTTON_REACTIVATE_TITLE
            data['member_info']['button_color'] = FamilyMember.BUTTON_REACTIVATE_COLOR
        if data['member_info']['is_grace_period_running']:
            data['member_info']['text'] = self.translation_manager.get_translation(
                self.translation_manager.FAMILY_ACCOUNT_EXPIRED,
                self.device_language
            )
            data['member_info']['sub_title'] = FamilyMember.ACCOUNT_EXPIRE_TITLE
            data['member_info']['date'] = EntCustomerProfile.MEMBERSHIP_EXPIRAION_DATE_MAX
            data['member_info']['button_title'] = self.translation_manager.get_translation(
                self.translation_manager.BUTTON_BUY_NOW_TITLE,
                self.device_language
            )
            data['member_info']['button_color'] = FamilyMember.BUTTON_BUY_NOW_COLOR

    def get_family_member_details(self, family_record):
        """
        Gets Family member details
        """
        member_profiles = []
        customer_ids = []
        for record in family_record:
            if record.user_id:
                customer_ids.append(record.user_id)
        customer_profiles = {}
        if customer_ids:
            customer_profiles = EntCustomerProfile.load_customer_profile_by_user_id(customer_ids)
        for record in family_record:
            record = record._asdict()
            customer_profile = customer_profiles.get(record.get('user_id'), {})
            record['profile_image'] = customer_profile.profile_image
            record['firstname'] = customer_profile.firstname
            record['lastname'] = customer_profile.lastname
            record['email'] = customer_profile.email
            record['customer_id'] = customer_profile.id
            member_profiles.append(record)
        return member_profiles

    def setting_members_info(self, data):
        """
        Sets the family members info
        """
        if self.customer_data.get('is_primary', False):
            family_record = FamilyMember.find_family_members_by_id_or_status(
                family_id=self.family_info.id
            )
            family_members = self.get_family_member_details(family_record)
        else:
            family_record = FamilyMember.find_family_members_by_id_or_status(
                family_id=self.family_info.id,
                status=FamilyMember.ACCEPTED
            )
            family_members = self.get_family_member_details(family_record)
        for family_member in family_members:
            if self.user_id != family_member.get('user_id'):
                data['members'].append({
                    'name': family_member.get('name'),
                    'profile_img': family_member.get('profile_image'),
                    'member_status': family_member.get('status'),
                    'status': FamilyMember.STATUS_TITLES.get(family_member.get('status')),
                    'color': FamilyMember.STATUS_COLOR.get(family_member.get('status')),
                    'status_img': FamilyMember.STATUS_IMAGES.get(family_member.get('status'), FamilyMember.STATUS_IMAGE),
                    'remove_img': FamilyMember.DELETE_IMAGE,
                    'identifier': family_member.get('identifier')
                })
                if self.customer_data.get('is_primary', False):
                    if family_member.get('status') in [
                        FamilyMember.ACCEPTED,
                        FamilyMember.PENDING
                    ]:
                        data['total_members'] += 1
                else:
                    if family_member.get('status') == FamilyMember.ACCEPTED:
                        data['total_members'] += 1

    def process_request(self, *args, **kwargs):
        """
        Process the request
        """
        self.get_session_info()
        self.translation_manager = TranslationManager()
        data = {
            'message': self.translation_manager.get_translation(
                self.translation_manager.NO_FAMILY_SECONDARY_FOUND,
                self.device_language
            )}
        if self.customer_data.get('is_user_in_family', False):
            del data['message']
            family_status = self.family_info.status

            # Setting header section
            self.set_header_section(data, family_status)
            if data['member_info']['is_primary_member']:
                # Setting info for primary
                self.set_info_for_primary_member(data)

            self.customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(
                self.customer_data.get('primary_member_info', {}).user_id
            )
            data['member_info']['primary_member_name'] = '{firstname} {lastname}'.format(
                firstname=self.customer_profile.firstname,
                lastname=self.customer_profile.lastname
            ).strip()
            data['members'] = []
            data['total_members'] = 0
            if self.customer_data.get('family_is_active', False):
                self.setting_members_info(data)

                if self.customer_data.get('is_primary', False):
                    if not data['members']:
                        try:
                            del data['header_section']
                            del data['member_info']['button_title']
                            del data['member_info']['button_color']
                        except KeyError:
                            pass
                        data['message'] = Family.NO_FAMILY_PRIMARY_FOUND
                    else:
                        data['header_section']['limit_text'] = '{total_members}/{total_limit}'.format(
                            total_members=data['total_members'],
                            total_limit=FamilyMember.FAMILY_MEMBERS_LIMIT - 1
                        )
                else:
                    data['header_section']['limit_text'] = '{total_members}/{total_limit}'.format(
                        total_members=data['total_members'],
                        total_limit=FamilyMember.FAMILY_MEMBERS_LIMIT - 1
                    )

                data['members'] = multi_key_sort(data['members'], columns=['name'])
        else:
            data['member_info'] = dict()
            data['member_info']['is_expired'] = False
            data['member_info']['is_grace_period_running'] = False
            data['member_info']['is_primary_member'] = self.customer_data.get('is_primary', False)
            data['member_info']['button_title'] = FamilyMember.BUTTON_LEAVE_FAMILY_TITLE
            data['member_info']['button_color'] = FamilyMember.BUTTON_LEAVE_FAMILY_COLOR
            data['member_info']['primary_member_name'] = '{firstname} {lastname}'.format(
                firstname=self.customer_data.get('firstname'),
                lastname=self.customer_data.get('lastname')
            ).strip()
        if data['member_info']['is_primary_member']:
            if not self.customer_data.get('is_user_in_family', False):
                data['message'] = Family.NO_FAMILY_PRIMARY_FOUND
            data['member_info']['purchased_product_id'] = self.customer_data.get('product_ids', [])
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
