"""
Cancel Family Invitation Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.cancel_family_invitation_validator import cancel_invitation_parser


class CancelInvitation(BasePostResource):
    """
    class handles the cancel family invitation endpoint
    """
    request_parser = cancel_invitation_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='cancel_invitation/cancel_invitation.log',
        ),
        'name': 'cancel_invitation'
    }

    def populate_request_arguments(self):
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.location_id = self.request_args.get('location_id', 0)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def cancel_invitation_process(
            self, reason=FamilyMember.CANCELLED_BY_PRIMARY_USER, family_id=0,
            status=FamilyMember.CANCELLED
    ):
        filters_ = {
            'identifier': self.identifier,
            'is_active': 1,
            'status': FamilyMember.PENDING
        }
        if family_id:
            filters_['family_id'] = family_id
        self.invitation = FamilyMember.find_family_member(filters=filters_)
        if not self.invitation:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.INVITATION_NOT_FOUND
            }
            self.status_code = 422
            return

        if family_id:
            if self.invitation.family_id != family_id:
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.NOT_ALLOWED_TO_CANCEL_INVITATION
                }
                self.status_code = 422
                return
        else:
            if self.invitation.user_id and self.invitation.user_id != self.customer_data.get('user_id'):
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.NOT_ALLOWED_TO_CANCEL_INVITATION
                }
                self.status_code = 422
                return

        data = {
            'status': status,
            'reason': reason,
        }
        FamilyMember.update_member(
            filters={'identifier': self.identifier},
            data=data
        )
        self.send_response_flag = True
        self.response = {
            'data': {},
            'success': True,
            'message': self.translation_manager.get_translation(
                self.translation_manager.INVITATION_CANCELLED,
                self.device_language
            )
        }
        self.status_code = 200
        return

    def process_request(self, *args, **kwargs):
        self.get_session_info()
        self.translation_manager = TranslationManager()
        if all([
            self.customer_data.get('is_user_in_family', False),
            self.customer_data.get('is_primary', False),
            self.customer_data.get('family_is_active', False)
        ]):
            self.cancel_invitation_process(family_id=self.family_info.id)
            if self.is_send_response_flag_on():
                return
        elif all([
            not self.customer_data.get('is_user_in_family', False),
            not self.customer_data.get('is_primary', False)
        ]):
            self.cancel_invitation_process(
                reason=FamilyMember.REJECTED_BY_USER,
                status=FamilyMember.REJECTED
            )
            if self.is_send_response_flag_on():
                return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': True,
                'message': FamilyMember.NOT_ALLOWED_TO_CANCEL_INVITATION
            }
            self.status_code = 422
            return
