"""
Resend Family Invitation Api
"""
import datetime

from phpserialize import dumps as php_json_dumps

from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.constants import COMPANY_SERVICE_MESSAGE, FAMILY_SECONDARY_TYPE
from family_service.common.models.ent_customer_profile import EntCustomerProfile
from family_service.common.models.ent_send_email import EntSendEmail
from family_service.common.models.family_member import FamilyMember
from family_service.common.models.user import User
from family_service.common.utils.api_utils import get_locale
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.add_family_member import AddFamilyMember
from family_service.family_app.api.v1.validations.resend_family_invitation_validator import resend_invitation_parser


class ResendInvitation(AddFamilyMember):
    """
    Resend Family Invitation Api
    """
    request_parser = resend_invitation_parser
    validators = [token_decorator_v3]
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='resend_invitation/resend_invitation.log',
        ),
        'name': 'resend_invitation'
    }

    def populate_request_arguments(self):
        """
        Populates Request Arguments
        """
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.nick_name = self.request_args.get('nick_name', '')
        self.email = self.request_args.get('email', '')

    def initialize_local_variables(self):
        """
        Initializing local variables
        """
        self.data = {}
        self.family_invite = dict()
        self.cheers_product_ids = []
        self.created_family = False
        self.recipient_profile = dict()
        self.recipient_user_info = dict()
        self.messages_locale = get_locale(self.device_language)
        self.update_member = False
        self.with_user = False

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def is_user_primary(self):
        if not self.customer_data.get('family_is_active', False):
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_ADD_MEMBERS
            }
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

        if not self.customer_data.get('is_primary', False) and self.customer_data.get('family_is_active', False):
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_RESEND_INVITATION
            }
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

    def check_black_listed_user(self):
        """
        Checking the black listed user and device.
        """
        self.recipient_family_member_info = FamilyMember.find_family_member(
            filters={
                'identifier': self.identifier,
                'is_active': 1,
                'family_id': self.family_info.id,
            },
            in_filters=[{'status': [FamilyMember.PENDING, FamilyMember.REJECTED]}]
        )

        if self.recipient_family_member_info and not self.email and not self.nick_name:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_ALREADY_EXISTS,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        if not self.recipient_family_member_info:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_NOT_FOUND,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        if self.recipient_family_member_info:
            if self.recipient_family_member_info.email and not self.recipient_family_member_info.user_id:
                self.update_member = True
                self.with_user = False
            else:
                self.recipient_profile = EntCustomerProfile.load_customer_profile_by_user_id(
                    user_id=self.recipient_family_member_info.user_id
                )

                if not self.recipient_profile:
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": "No user found.",
                        "data": {},
                        "success": False
                    }
                    return self.send_response(self.response, self.status_code)

                if(
                    self.recipient_profile and
                    self.recipient_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER
                ):
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": self.translation_manager.get_translation(
                            self.translation_manager.MEMBER_NOT_ALLOWED,
                            self.messages_locale
                        ).format(name=self.email),
                        "data": {},
                        "success": False
                    }
                    FamilyMember.update_member(
                        filters={'identifier': self.identifier},
                        data={
                            'reason': 'Cancelled due to membership',
                            'status': FamilyMember.CANCELLED,
                            'is_active': 0
                        }
                    )
                    return self.send_response(self.response, self.status_code)

                if self.recipient_profile:
                    self.recipient_user_info = User.load_customer_by_id(customer_id=self.recipient_profile.user_id)
                    if not self.recipient_user_info:
                        self.status_code = 422
                        self.send_response_flag = True
                        self.response = {
                            "message": "No user found.",
                            "data": {},
                            "success": False
                        }
                        return self.send_response(self.response, self.status_code)

                if self.recipient_user_info and self.recipient_user_info.status == EntCustomerProfile.STATUS_BLACKLISTED:
                    self.status_code = 422
                    self.send_response_flag = True
                    self.response = {
                        "message": COMPANY_SERVICE_MESSAGE,
                        "data": {},
                        "success": False
                    }
                    FamilyMember.update_member(
                        filters={'identifier': self.identifier},
                        data={
                            'reason': 'Black Listed',
                            'status': FamilyMember.CANCELLED,
                            'is_active': 0
                        }
                    )
                    return self.send_response(self.response, self.status_code)

                if self.recipient_profile.email == self.email:
                    self.update_member = True

            if not self.update_member:
                FamilyMember.update_member(
                    filters={'identifier': self.identifier},
                    data={
                        'reason': 'Resend to other user',
                        'status': FamilyMember.CANCELLED,
                        'is_active': 0
                    }
                )

    def get_family_invitations(self):
        self.family_invitations = FamilyMember.find_family_invitations_pending_accepted(
            family_id=self.family_info.id
        )
        if not self.update_member:
            if len(self.family_invitations) >= FamilyMember.INVITATION_LIMIT:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": FamilyMember.INVITATION_LIMIT_MESSAGE,
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

    def load_recipient(self):
        self.recipient_profile_new = {}
        self.recipient_profile_new = EntCustomerProfile.load_customer_profile_by_email(self.email)
        self.invitation_already_send = False
        for family_invitation in self.family_invitations:
            if self.recipient_profile_new and self.recipient_profile_new.user_id == family_invitation.user_id:
                self.invitation_already_send = True
                break
            if family_invitation.email and family_invitation.email == self.email:
                self.update_member = True
                self.invitation_already_send = True
                break

        if self.invitation_already_send:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_ALREADY_SENT,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        if self.recipient_profile_new:
            if self.recipient_profile_new.new_member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": self.translation_manager.get_translation(
                        self.translation_manager.MEMBER_NOT_ALLOWED,
                        self.messages_locale
                    ).format(name=self.email),
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            self.recipient_user_info = User.load_customer_by_id(
                customer_id=self.recipient_profile_new.user_id
            )
            if not self.recipient_user_info:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": "No user found.",
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            if self.recipient_user_info and self.recipient_user_info.status == EntCustomerProfile.STATUS_BLACKLISTED:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": COMPANY_SERVICE_MESSAGE,
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

        self.recipient_family_member_info = {}
        if not self.with_user:
            self.recipient_family_member_info = FamilyMember.find_family_member(
                filters={
                    'email': self.email,
                    'is_active': 1,
                    'status': FamilyMember.ACCEPTED
                })
        elif self.recipient_profile_new:
            self.recipient_family_member_info = FamilyMember.find_family_member(
                filters={
                    'user_id': self.recipient_profile_new.user_id,
                    'is_active': 1,
                    'status': FamilyMember.ACCEPTED
                })

        if self.recipient_family_member_info:
            message = FamilyMember.ALREADY_MEMBER
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": message.format(name=self.recipient_profile_new.firstname),
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_local_variables()
        self.get_session_info()
        self.translation_manager = TranslationManager()

        self.family_exists()
        if self.is_send_response_flag_on():
            return

        self.is_user_primary()
        if self.is_send_response_flag_on():
            return

        self.check_black_listed_user()
        if self.is_send_response_flag_on():
            return

        self.get_family_invitations()
        if self.is_send_response_flag_on():
            return

        self.load_recipient()
        if self.is_send_response_flag_on():
            return

        if self.update_member:
            data = {
                'reason': 'Resend invitation',
                'status': FamilyMember.PENDING
            }
            if self.nick_name:
                data['relationship'] = self.nick_name
            if not self.with_user:
                data['email'] = self.email
                if self.recipient_profile_new.id:
                    data['email'] = ''
                    data['user_id'] = self.recipient_profile_new.user_id
                    self.check_invitation_limit(user_id=data['user_id'])
                    if self.is_send_response_flag_on():
                        return
                    email_data = php_json_dumps({'user_id': self.customer_data.get('customer_id')})
                    optional_data = php_json_dumps({})
                    send_email_data = {}
                    send_email_data.update({
                        'email_template_type_id': FAMILY_SECONDARY_TYPE,
                        'email_template_data': email_data.decode(errors='ignore'),
                        'email_to': self.email,
                        'language': self.messages_locale,
                        'priority': EntSendEmail.PRIORITY_MEDIUM,
                        'created_date': datetime.datetime.now(),
                        'optional_data': optional_data.decode(errors="ignore"),
                        'is_sent': 0
                    })
                    ent_send_email = EntSendEmail(
                        **send_email_data
                    )
                    ent_send_email.insert_record()
                else:
                    self.check_invitation_limit(email=data['email'])
                    if self.is_send_response_flag_on():
                        return
            FamilyMember.update_member(
                filters={'identifier': self.identifier}, data=data
            )
        else:
            email_data = php_json_dumps({'user_id': self.customer_data.get('customer_id')})
            optional_data = php_json_dumps({})
            if not self.with_user:
                self.check_invitation_limit(email=self.email)
                if self.is_send_response_flag_on():
                    return
                self.add_invitation(
                    email=self.email,
                    is_cheers_to_include=False,
                    show_cheers_popup=True
                )
                send_email_data = {}
                send_email_data.update({
                    'email_template_type_id': FAMILY_SECONDARY_TYPE,
                    'email_template_data': email_data.decode(errors='ignore'),
                    'email_to': self.email,
                    'language': self.messages_locale,
                    'priority': EntSendEmail.PRIORITY_MEDIUM,
                    'created_date': datetime.datetime.now(),
                    'optional_data': optional_data.decode(errors="ignore"),
                    'is_sent': 0
                })
                ent_send_email = EntSendEmail(
                    **send_email_data
                )
                ent_send_email.insert_record()
            else:
                self.check_invitation_limit(user_id=self.recipient_profile_new.user_id)
                if self.is_send_response_flag_on():
                    return
                if self.recipient_profile_new.email:
                    email = self.recipient_profile_new.email
                else:
                    email = self.email
                self.add_invitation(
                    user_id=self.recipient_profile_new.user_id,
                    email=email,
                    is_cheers_to_include=False,
                    show_cheers_popup=True
                )
                send_email_data = {}
                send_email_data.update({
                    'email_template_type_id': FAMILY_SECONDARY_TYPE,
                    'email_template_data': email_data.decode(errors='ignore'),
                    'email_to': email,
                    'language': self.messages_locale,
                    'priority': EntSendEmail.PRIORITY_MEDIUM,
                    'created_date': datetime.datetime.now(),
                    'optional_data': optional_data.decode(errors="ignore"),
                    'is_sent': 0
                })
                ent_send_email = EntSendEmail(
                    **send_email_data
                )
                ent_send_email.insert_record()
        self.send_response_flag = True
        self.response = {
            "message": self.translation_manager.get_translation(
                self.translation_manager.SUCCESS_INVITATION,
                self.messages_locale
            ),
            "data": self.data,
            "success": True
        }
        return self.send_response(self.response, self.status_code)
