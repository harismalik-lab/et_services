"""
Edit Family Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.family_app.api.v1.validations.edit_family_api_validator import edit_family_member_parser


class EditFamilyMember(BasePostResource):
    """
    class handles the edit family member endpoint
    """
    request_parser = edit_family_member_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='edit_family_member/edit_family_member.log',
        ),
        'name': 'edit_family_member'
    }

    def populate_request_arguments(self):
        self.identifier = self.request_args.get('identifier', '')
        self.name = self.request_args.get('name', '')

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        self.get_session_info()
        if all([
            self.customer_data.get('is_user_in_family', False),
            self.customer_data.get('family_is_active', False)
        ]):
            if self.customer_data.get('is_primary', False):
                self.recipient_family_member = FamilyMember.find_family_member(
                    filters={'identifier': self.identifier, 'is_active': 1}
                )
                if not self.recipient_family_member:
                    self.send_response_flag = True
                    self.response = {
                        'data': {},
                        'success': False,
                        'message': FamilyMember.FAMILY_MEMBER_NOT_FOUND
                    }
                    self.status_code = 422
                    return
                if self.recipient_family_member.family_id != self.family_info.id:
                    self.send_response_flag = True
                    self.response = {
                        'data': {},
                        'success': False,
                        'message': FamilyMember.MEMBER_NOT_PART_OF_YOUR_ENTERTAINER_FAMILY
                    }
                    self.status_code = 422
                    return
                data = {'relationship': self.name}
                FamilyMember.update_member(
                    filters={'family_id': self.family_info.id, 'identifier': self.identifier},
                    data=data
                )
                self.send_response_flag = True
                self.response = {
                    'data': {'name': self.name},
                    'success': True,
                    'message': FamilyMember.EDITED_SUCCESSFULLY
                }
                self.status_code = 200
                return
            else:
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.NOT_ALLOWED_TO_EDIT_MEMBERS
                }
                self.status_code = 422
                return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NO_ENTERTAINER_FAMILY
            }
            self.status_code = 422
            return
