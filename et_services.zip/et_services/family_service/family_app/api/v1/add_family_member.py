"""
Adding new member to family
"""
import datetime
import uuid

from flask import current_app
from phpserialize import dumps as php_json_dumps

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.constants import FAMILY_SECONDARY_TYPE
from family_service.common.base_resource import BasePostResource
from family_service.common.constants import COMPANY_SERVICE_MESSAGE
from family_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from family_service.common.models.ent_send_email import EntSendEmail
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.models.product_ent_active import ProductEntActive
from family_service.common.models.user import User
from family_service.common.utils.api_utils import (get_current_date_time,
                                                   get_locale,
                                                   send_push_notification)
from family_service.common.utils.authentication import (get_current_customer,
                                                        token_decorator_v3)
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.add_family_member_validator import \
    add_family_member_parser


class AddFamilyMember(BasePostResource):
    """
    Add Family member api
    """
    request_parser = add_family_member_parser
    validators = [token_decorator_v3]
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='add_family_member/add_family_member.log',
        ),
        'name': 'add_family_member'
    }

    def populate_request_arguments(self):
        """
        Populates Request Arguments
        """
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.nick_name = self.request_args.get('nick_name', '')
        self.email = self.request_args.get('email', '')
        self.cheers_accepted = self.request_args.get('cheers_accepted', False)

    def initialize_local_variables(self):
        """
        Initializing local variables
        """
        self.data = {}
        self.family_invite = dict()
        self.cheers_product_ids = []
        self.created_family = False
        self.recipient_profile = dict()
        self.recipient_user_info = dict()
        self.messages_locale = get_locale(self.device_language)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def family_exists(self):
        if self.customer_data.get('is_primary', False) and not self.customer_data.get('is_user_in_family', False):
            family_exist = Family.find_family(
                filters={'user_id': self.customer_data.get('user_id')}
            )
            if family_exist:
                if any([
                    family_exist.is_active,
                    family_exist.status == Family.INACTIVE
                ]):
                    self.family_info = family_exist
                    self.family_info.update_family(
                        filters={'id': family_exist.id},
                        data={
                            'is_active': 1,
                            'status': Family.ACTIVE,
                            'reason': 'Family Re-created'
                        }
                    )
            elif not family_exist:
                self.family_info = dict()
                self.family_info['user_id'] = self.customer_data.get('user_id')
                self.family_info['name'] = self.customer_data.get('firstname')
                self.family_info['status'] = Family.ACTIVE
                created_time = get_current_date_time()
                new_member_data = {
                    'is_active': True, 'date_created': created_time,
                    'date_updated': created_time, 'identifier': str(uuid.uuid4()),
                    'company': self.customer_data.get('company')
                }
                self.family_info.update(new_member_data)
                new_family = Family(
                    **self.family_info
                )
                self.family_info = new_family.insert_record()
            self.created_family = True
            self.cheers_product_ids = ProductEntActive.get_cheers_product_by_product_ids(
                product_ids=self.customer_data.get('product_ids', []), convert_to_string=True
            )
            filtered_product_ids = []
            for record in self.cheers_product_ids:
                product_id = record.id
                product_id = str(product_id)
                filtered_product_ids.append(product_id)
            self.cheers_product_ids = filtered_product_ids
            self.family_member = FamilyMember.find_family_member(
                filters={
                    'user_id': self.customer_data.get('user_id'),
                    'is_primary': 1,
                    'family_id': self.family_info.id
                }
            )
            if self.family_member and not self.family_member.is_active:
                FamilyMember.update_member(
                    filters={'id': self.family_member.id},
                    data={'is_active': 1, 'reason': '', 'status': FamilyMember.ACCEPTED}
                )
            elif not self.family_member:
                self.add_invitation(
                    user_id=self.customer_data.get('user_id', 0),
                    family_id=self.family_info.id,
                    is_primary=True,
                    status=FamilyMember.ACCEPTED,
                    is_cheers_to_include=len(self.cheers_product_ids) > 0,
                    show_cheers_popup=not len(self.cheers_product_ids) > 0,
                    cheers_consent_date=get_current_date_time(),
                    relationship=self.customer_data.get('firstname'),
                    member_since=True
                )
                del self.data['invitation']
            self.customer_data['is_user_in_family'] = True
            self.customer_data['family_is_active'] = True
            self.family_invite = {}

        if not self.customer_data.get('is_user_in_family', False):
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NO_ENTERTAINER_FAMILY
            }
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

    def is_user_primary(self):
        if not self.customer_data.get('family_is_active', False):
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_ADD_MEMBERS
            }
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

        if not self.customer_data.get('is_primary', False) and self.customer_data.get('family_is_active', False):
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_ADD_MEMBERS
            }
            self.status_code = 422
            return self.send_response(self.response, self.status_code)

    def check_black_listed_user(self):
        """
        Checking the black listed user and device
        """
        self.recipient_profile = EntCustomerProfile.load_customer_profile_by_email(self.email)
        if self.recipient_profile:
            if self.recipient_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER:
                message = self.translation_manager.get_translation(
                    self.translation_manager.MEMBER_NOT_ALLOWED,
                    self.messages_locale
                )
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": message.format(
                        name=self.recipient_profile.firstname
                    ),
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            self.recipient_user_info = User.load_customer_by_id(
                customer_id=self.recipient_profile.user_id
            )
            if not self.recipient_user_info:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": "No user found.",
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            if self.recipient_user_info and not self.recipient_user_info.is_active:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    "message": "user is inactive",
                    "data": {},
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

            if self.recipient_user_info and self.recipient_user_info.status == EntCustomerProfile.STATUS_BLACKLISTED:
                self.status_code = 422
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    "message": COMPANY_SERVICE_MESSAGE,
                    "success": False
                }
                return self.send_response(self.response, self.status_code)

    def get_family_invitations(self):
        self.family_invitations = FamilyMember.find_family_invitations_pending_accepted(
            family_id=self.family_info.id
        )
        if len(self.family_invitations) >= FamilyMember.INVITATION_LIMIT:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_LIMIT_MESSAGE,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def load_recipient(self):
        invitation_already_send = False
        for family_invitation in self.family_invitations:
            if not self.recipient_profile and family_invitation.email == self.email:
                invitation_already_send = True
                break
            if self.recipient_profile and family_invitation.user_id == self.recipient_profile.user_id:
                invitation_already_send = True
                break

        if invitation_already_send:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_ALREADY_SENT,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        if not self.recipient_profile:
            self.check_invitation_limit(email=self.email)
            if self.is_send_response_flag_on():
                return
            self.add_invitation(
                email=self.email,
                is_cheers_to_include=False,
                show_cheers_popup=True
            )
            self.family_invite = {}
            self.send_response_flag = True
            self.response = {
                "message": self.translation_manager.get_translation(
                    self.translation_manager.SUCCESS_INVITATION,
                    self.messages_locale
                ),
                "data": self.data,
                "success": True
            }

            email_data = php_json_dumps({'user_id': self.customer_data.get('customer_id')})
            optional_data = php_json_dumps({})
            send_email_data = {}
            send_email_data.update({
                'email_template_type_id': FAMILY_SECONDARY_TYPE,
                'email_template_data': email_data.decode(errors='ignore'),
                'email_to': self.email,
                'language': self.messages_locale,
                'priority': EntSendEmail.PRIORITY_MEDIUM,
                'created_date': datetime.datetime.now(),
                'optional_data': optional_data.decode(errors="ignore"),
                'is_sent': 0
            })
            # inserting email data
            ent_send_email = EntSendEmail(
                **send_email_data
            )
            ent_send_email.insert_record()
            return self.send_response(self.response, self.status_code)

        self.recipient_family_member_info = FamilyMember.find_family_member(
            filters={
                'user_id': self.recipient_profile.user_id,
                'is_active': 1,
                'status': FamilyMember.ACCEPTED
            })

        if self.recipient_family_member_info:
            message = FamilyMember.ALREADY_MEMBER
            if self.recipient_family_member_info.is_primary:
                message = self.translation_manager.get_translation(
                    self.translation_manager.MEMBER_NOT_ALLOWED,
                    self.messages_locale
                )
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": message.format(name=self.recipient_profile.firstname),
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

        self.check_invitation_limit(user_id=self.recipient_profile.user_id)
        if self.is_send_response_flag_on():
            return

    def add_invitation(
            self, user_id=None, status=FamilyMember.PENDING, is_primary=False, is_cheers_to_include=False,
            relationship=None, family_id=None, member_since=None, show_cheers_popup=True, cheers_consent_date=None,
            email=None
    ):
        self.family_invite['family_id'] = self.family_info.id
        if family_id:
            self.family_invite['family_id'] = family_id
        if user_id:
            self.family_invite['user_id'] = user_id
        if member_since:
            self.family_invite['member_since'] = get_current_date_time()
        if email:
            self.family_invite['email'] = email
        self.family_invite['is_primary'] = is_primary
        self.family_invite['is_cheers_to_include'] = is_cheers_to_include
        self.family_invite['show_cheers_popup'] = show_cheers_popup
        if cheers_consent_date:
            self.family_invite['cheers_consent_date'] = cheers_consent_date
        if not self.created_family:
            self.cheers_product_ids = ProductEntActive.get_cheers_product_by_product_ids(
                product_ids=self.customer_data.get('product_ids', []), convert_to_string=True
            )
            filtered_product_ids = []
            for record in self.cheers_product_ids:
                product_id = record.id
                product_id = str(product_id)
                filtered_product_ids.append(product_id)
            self.cheers_product_ids = filtered_product_ids
        if not self.cheers_product_ids:
            self.family_invite['is_cheers_to_include'] = False
            self.family_invite['show_cheers_popup'] = False

        self.family_invite['status'] = status
        self.family_invite['relationship'] = self.nick_name
        if relationship:
            self.family_invite['relationship'] = relationship
        filters = {'family_id': self.family_invite['family_id']}
        if user_id:
            filters['user_id'] = user_id
        if email:
            filters['email'] = email

        _identifier = FamilyMember.find_family_member(filters=filters)
        if _identifier:
            self.family_invite['is_active'] = True
            self.family_invite['reason'] = ''
            self.family_invite.update(
                FamilyMember.update_member(
                    data=self.family_invite, filters={'identifier': _identifier.identifier}
                )
            )
        else:
            created_time = get_current_date_time()
            new_member_data = {
                'is_active': True, 'date_created': created_time,
                'date_updated': created_time, 'identifier': str(uuid.uuid4()),
                'email': ''
            }
            if email:
                new_member_data.update({'email': email})
            self.family_invite.update(new_member_data)

            # adding new family member
            new_family_member = FamilyMember(**self.family_invite)
            new_family_member.insert_record()
            self.family_invite.update({'id': new_family_member.id})
        self.data['invitation'] = self.family_invite
        if user_id:
            data = {
                "api_key": current_app.config.get('BRAZE_API_KEY', ''),
                "campaign_id": current_app.config.get('BRAZE_CAMPAIGN_ID', ''),
                "recipients": [
                    {
                        "external_user_id": user_id,
                        "trigger_properties": {
                            "string_property": self.customer_data.get('email', '')
                        }
                    }
                ]
            }
            url = current_app.config.get('FAMILY_INVITE_BRAZE_URL', '')
            family_invite_notification = send_push_notification(url=url, data=data)  # noqa: F841

    def check_invitation_limit(self, user_id=None, email=None):
        filters = {'status': FamilyMember.PENDING, 'is_active': 1}
        if user_id:
            filters['user_id'] = user_id
        if email:
            filters['email'] = email
        invitation_count = FamilyMember.find_family_member_count(filters)
        if invitation_count >= FamilyMember.INVITATION_RECIEVE_COUNT:
            self.status_code = 422
            self.send_response_flag = True
            self.response = {
                "message": FamilyMember.INVITATION_PENDING_LIMIT_MESSAGE,
                "data": {},
                "success": False
            }
            return self.send_response(self.response, self.status_code)

    def send_email_to_user(self):
        """
        Sends email to user
        """
        if self.recipient_profile.new_member_group in [
            EntCustomerProfile.MEMBERSTATUS_PROSPECT,
            EntCustomerProfile.MEMBERSTATUS_REPROSPECT,
            EntCustomerProfile.MEMBERSTATUS_ONBOARDING
        ]:
            email_data = php_json_dumps({'user_id': self.customer_data.get('customer_id')})
            optional_data = php_json_dumps({})
            send_email_data = {}
            send_email_data.update({
                'email_template_type_id': FAMILY_SECONDARY_TYPE,
                'email_template_data': email_data.decode(errors='ignore'),
                'email_to': self.recipient_profile.email,
                'language': self.messages_locale,
                'priority': EntSendEmail.PRIORITY_MEDIUM,
                'created_date': datetime.datetime.now(),
                'optional_data': optional_data.decode(errors="ignore"),
                'is_sent': 0
            })
            ent_send_email = EntSendEmail(
                **send_email_data
            )
            ent_send_email.insert_record()

    def process_request(self, *args, **kwargs):
        self.initialize_local_variables()
        self.get_session_info()
        self.translation_manager = TranslationManager()

        self.family_exists()
        if self.is_send_response_flag_on():
            return

        self.is_user_primary()
        if self.is_send_response_flag_on():
            return

        self.check_black_listed_user()
        if self.is_send_response_flag_on():
            return

        self.get_family_invitations()
        if self.is_send_response_flag_on():
            return

        self.load_recipient()
        if self.is_send_response_flag_on():
            return

        self.add_invitation(
            user_id=self.recipient_profile.user_id,
            is_cheers_to_include=False,
            cheers_consent_date=None,
            show_cheers_popup=True
        )

        self.send_email_to_user()
        self.send_response_flag = True
        self.data['message'] = self.translation_manager.get_translation(
            self.translation_manager.SUCCESS_INVITATION,
            self.messages_locale
        )
        self.response = {
            "message": self.translation_manager.get_translation(
                self.translation_manager.SUCCESS_INVITATION,
                self.messages_locale
            ),
            "data": self.data,
            "success": True
        }
        return self.send_response(self.response, self.status_code)
