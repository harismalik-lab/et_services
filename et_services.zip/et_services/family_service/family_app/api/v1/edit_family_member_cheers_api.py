"""
Edit Family Member Cheers Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.api_utils import get_current_date_time
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.family_app.api.v1.validations.edit_family_member_cheers_api_validator import (
    family_member_cheers_update_parser
)


class EditFamilyMemberCheers(BasePostResource):
    """
    Class handles the edit family member cheers endpoint
    """
    request_parser = family_member_cheers_update_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='family_member_cheers_update/family_member_cheers_update.log',
        ),
        'name': 'family_member_cheers_update'
    }

    def populate_request_arguments(self):
        self.cheers_accepted = self.request_args.get('cheers_accepted', False)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        self.get_session_info()
        if all([
            self.customer_data.get('is_user_in_family', False),
            self.customer_data.get('family_is_active', False),
            not self.customer_data.get('is_primary', False)
        ]):
            self.recipient_family_member = self.customer_data.get('family_member_info', {})
            if not self.recipient_family_member:
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.FAMILY_MEMBER_NOT_FOUND
                }
                self.status_code = 422
                return

            data = dict()
            if all([
                self.recipient_family_member.show_cheers_popup,
                self.recipient_family_member.user_id
            ]):
                data['is_cheers_to_include'] = False
                data['cheers_consent_date'] = get_current_date_time()
                data['show_cheers_popup'] = False
                if self.customer_data.get('owns_cheer_products', []) and self.cheers_accepted:
                    data['is_cheers_to_include'] = True

                FamilyMember.update_member(
                    filters={'id': self.recipient_family_member.id},
                    data=data
                )
            self.send_response_flag = True
            self.response = {
                'data': data,
                'success': True,
                'message': 'success'
            }
            self.status_code = 200
            return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_EDIT_MEMBERS
            }
            self.status_code = 422
            return
