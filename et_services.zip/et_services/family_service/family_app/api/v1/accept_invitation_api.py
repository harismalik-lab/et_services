"""
Accept Family Invitation Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.utils.api_utils import get_current_date_time
from family_service.common.base_resource import BasePostResource
from family_service.common.models.api_configuration import ApiConfiguration
from family_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from family_service.common.models.extended_trial_activation import \
    ExtendedTrialActivation
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.models.location import Location
from family_service.common.models.session import Session
from family_service.common.utils.authentication import (get_current_customer,
                                                        token_decorator_v3)
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.accecpt_invitation_api_validator import \
    accept_invitation_parser


class AcceptInvitation(BasePostResource):
    """
    class handles the accept family invitation endpoint
    """
    request_parser = accept_invitation_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='accept_invitation/accept_invitation.log',
        ),
        'name': 'accept_invitation'
    }

    def populate_request_arguments(self):
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')
        self.location_id = self.request_args.get('location_id', 0)
        self.cheers_accepted = self.request_args.get('cheers_accepted', False)

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        self.get_session_info()

        if all([
            not self.customer_data.get('is_user_in_family', False),
            not self.customer_data.get('is_primary', False)
        ]):
            self.translation_manager = TranslationManager()
            self.invitation = FamilyMember.find_family_member(
                filters={'identifier': self.identifier, 'is_active': 1, 'status': FamilyMember.PENDING}
            )
            if not self.invitation:
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.INVITATION_NOT_FOUND
                }
                self.status_code = 422
                return

            if self.invitation.user_id != self.customer_data.get('user_id'):
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.NOT_ALLOWED_TO_ACCEPT_INVITATION
                }
                self.status_code = 422
                return

            self.family_info = Family.find_family(
                filters={'is_active': 1, 'id': self.invitation.family_id}
            )
            if self.family_info:
                data = {
                    'status': FamilyMember.ACCEPTED,
                    'member_since': get_current_date_time(),
                    'is_cheers_to_include': self.cheers_accepted,
                    'show_cheers_popup': False
                }
                FamilyMember.update_member(
                    filters={'identifier': self.identifier},
                    data=data
                )
                deactivate_invites_data = dict()
                deactivate_invites_data['is_active'] = 0
                deactivate_invites_data['status'] = FamilyMember.CANCELLED
                deactivate_invites_data['reason'] = "Joined {family_name}'s family".format(
                    family_name=self.family_info.name
                )
                deactivate_invites_data['date_updated'] = get_current_date_time()
                FamilyMember.deactivate_pending_invites(
                    user_id=self.customer_data.get('user_id'),
                    exclude_invitation_ids=[self.invitation.id],
                    data=deactivate_invites_data
                )
                if self.customer_data.get('is_member_on_trial'):
                    #  TODO
                    EntCustomerProfile.update_trial_date(customer_id=self.customer_data.get('user_id'))
                self.send_response_flag = True
                data = {}
                location_name = Location.get_location_translation_by_location_id(
                    self.location_id, self.device_language
                )
                data['invitation_accept_content'] = dict()
                data['invitation_accept_content']['title'] = self.translation_manager.get_translation(
                    self.translation_manager.WELCOME_MESSGAE,
                    self.device_language
                ).format(name=self.family_info.name)

                data['invitation_accept_content']['img'] = FamilyMember.INVITATION_ACCEPT_CONTENT_IMAGE
                data['invitation_accept_content']['button_title'] = self.translation_manager.get_translation(
                    self.translation_manager.MEET_YOUR_FAMILY_TITLE,
                    self.device_language
                )
                data['invitation_accept_content']['message'] = FamilyMember.INVITATION_MESSAGE.format(
                    location=location_name
                )
                if self.customer_data.get('api_configs').get(ApiConfiguration.ENABLE_EXTENDED_TRIAL):
                    ExtendedTrialActivation.deactivate_extended_trial_of_user(
                        customer_id=self.customer_data.get('user_id')
                    )
                    Session.deactivate_extended_trial(customer_id=self.customer_data.get('user_id'))
                self.response = {
                    'data': data,
                    'success': True,
                    'message': data['invitation_accept_content']['title']
                }
                self.status_code = 200
                return
            else:
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': False,
                    'message': FamilyMember.NO_FAMILY_FOUND
                }
                self.status_code = 422
                return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NOT_ALLOWED_TO_ACCEPT_INVITATION
            }
            self.status_code = 422
            return
