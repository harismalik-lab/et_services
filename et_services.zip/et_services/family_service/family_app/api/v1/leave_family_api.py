"""
Leave Family Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.family import Family
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.leave_family_validator import leave_family_parser


class LeaveFamily(BasePostResource):
    """
    Class handles the leave family endpoint
    """
    request_parser = leave_family_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='leave_family/leave_family.log',
        ),
        'name': 'leave_family'
    }

    def populate_request_arguments(self):
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        self.get_session_info()
        self.translation_manager = TranslationManager()

        if all([
            self.customer_data.get('is_user_in_family', False),
            self.customer_data.get('family_is_active', False)
        ]):
            if self.customer_data.get('is_primary', False):
                data = {
                    'is_active': 0,
                    'reason': self.translation_manager.get_translation(
                        self.translation_manager.BUTTON_LEAVE_FAMILY_TITLE,
                        locale='en'
                    ),
                    'status': Family.INACTIVE
                }
                Family.update_family(
                    filters={'id': self.family_info.id},
                    data=data
                )
                data = {
                    'is_active': 0,
                    'reason': FamilyMember.FAMILY_CLOSED,
                    'status': FamilyMember.CANCELLED
                }
                FamilyMember.update_member(
                    filters={'family_id': self.family_info.id},
                    data=data
                )
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': True,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.FAMILY_CLOSED,
                        self.device_language
                    )
                }
                self.status_code = 200
                return
            else:
                data = {
                    'is_active': 0,
                    'reason': FamilyMember.LEAVE_THE_FAMILY,
                    'status': FamilyMember.CANCELLED
                }
                FamilyMember.update_member(
                    filters={'family_id': self.family_info.id, 'user_id': self.customer_data.get('user_id')},
                    data=data
                )
                self.send_response_flag = True
                self.response = {
                    'data': {},
                    'success': True,
                    'message': self.translation_manager.get_translation(
                        self.translation_manager.LEAVED_SUCCESSFULLY,
                        self.device_language
                    )
                }
                self.status_code = 200
                return
        else:
            self.send_response_flag = True
            self.response = {
                'data': {},
                'success': False,
                'message': FamilyMember.NO_ENTERTAINER_FAMILY
            }
            self.status_code = 422
            return
