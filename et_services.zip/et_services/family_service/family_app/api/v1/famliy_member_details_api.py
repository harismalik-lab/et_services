"""
Family Member Details Api
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from family_service.common.base_resource import BasePostResource
from family_service.common.models.ent_customer_profile import EntCustomerProfile
from family_service.common.models.family_member import FamilyMember
from family_service.common.utils.authentication import get_current_customer, token_decorator_v3
from family_service.common.utils.translation_manager import TranslationManager
from family_service.family_app.api.v1.validations.family_member_details_api_validator import (
    family_member_details_parser
)


class FamilyMemberDetails(BasePostResource):
    """
    Class handles the family member details endpoint
    """
    request_parser = family_member_details_parser
    validators = [token_decorator_v3]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='family_member_details/family_member_details.log',
        ),
        'name': 'family_member_details'
    }

    def populate_request_arguments(self):
        """
        Populates Request Arguments
        """
        self.device_language = self.request_args.get('language', '')
        self.identifier = self.request_args.get('identifier', '')

    def get_session_info(self):
        """
        Gets session_token from user info
        """
        self.customer_data = get_current_customer()
        self.family_info = self.customer_data.get('family_info', {})
        self.user_id = 0
        if self.customer_data.get('family_member_info', {}):
            self.user_id = self.customer_data.get('family_member_info').user_id

    def process_request(self, *args, **kwargs):
        """
        Process the request
        """
        self.get_session_info()
        self.translation_manager = TranslationManager()
        data = {}
        if self.customer_data.get('is_user_in_family', False):
            self.customer_profile = None
            self.member_info = None

            if self.customer_data.get('family_is_active', False):
                if not self.identifier:
                    self.member_info = self.customer_data.get('family_member_info', {})
                    self.user_id = 0

                # only primary user of family can see details of others members
                if self.identifier and self.customer_data.get('is_primary', False):
                    if not self.member_info:
                        family_member_details = FamilyMember.find_family_member(
                            filters={'identifier': self.identifier, 'is_active': 1}
                        )
                        self.user_id = family_member_details.user_id
                        family_id_from_session = self.customer_data.get('family_member_info', {}).family_id
                        # check for same family
                        if family_member_details and family_id_from_session == family_member_details.family_id:
                            self.member_info = family_member_details
                if self.member_info:
                    self.customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(self.user_id)
                    data['member_status'] = self.member_info.status
                    data['nick_name'] = self.member_info.relationship
                    data['identifier'] = self.member_info.identifier
                    data['email'] = self.customer_profile.email
                    data['member_since_date'] = self.member_info.member_since
                    if self.member_info.member_since:
                        data['member_since_date'] = self.member_info.member_since.strftime('%d/%m/%Y')
                    data['name'] = ''
                    data['profile_img'] = None
                    data['cancel_message'] = self.translation_manager.get_translation(
                        self.translation_manager.CONFIRM_REMOVE_MEMBER,
                        self.device_language
                    ).format(name=self.member_info.relationship)
                    if self.customer_data.get('is_primary', False):
                        if data['member_status'] in [FamilyMember.PENDING, FamilyMember.REJECTED]:
                            data['button_title'] = self.translation_manager.get_translation(
                                self.translation_manager.BUTTON_CANCEL_TITLE,
                                self.device_language
                            )
                            data['button_color'] = FamilyMember.BUTTON_CANCEL_COLOR
                            data['button_resend_title'] = self.translation_manager.get_translation(
                                self.translation_manager.BUTTON_RESEND_TITLE,
                                self.device_language
                            )
                            data['button_resend_color'] = FamilyMember.BUTTON_RESEND_COLOR
                        if data['member_status'] == FamilyMember.ACCEPTED:
                            data['cancel_message'] = self.translation_manager.get_translation(
                                self.translation_manager.CONFIRM_ACTIVE_REMOVE_MEMBER,
                                self.device_language
                            ).format(name=self.member_info.relationship)
                            data['button_color'] = FamilyMember.BUTTON_LEAVE_FAMILY_COLOR
                            data['button_title'] = self.translation_manager.get_translation(
                                self.translation_manager.REMOVE_FROM_FAMILY,
                                self.device_language
                            )

                if self.customer_profile:
                    data['name'] = '{firstname} {lastname}'.format(
                        firstname=self.customer_profile.firstname,
                        lastname=self.customer_profile.lastname
                    ).strip()
                    data['profile_img'] = self.customer_profile.profile_image

        self.send_response_flag = True
        self.response = {
            'data': {
                'member_detail': data
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
