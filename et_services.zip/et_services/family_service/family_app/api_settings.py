"""
This modules loads APIs for merchant service
"""
from flask import g

from family_service.family_app.routings.routings_v1 import FamilyAPIV3


def api_urls():
    FamilyAPIV3(app=g.app, name=FamilyAPIV3.__name__).map_urls()
