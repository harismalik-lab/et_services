"""
Routing for Family Service
"""
from family_service.common.base_routing import BaseRouting
from family_service.family_app.api.v1.accept_invitation_api import AcceptInvitation
from family_service.family_app.api.v1.add_family_member import AddFamilyMember
from family_service.family_app.api.v1.cancel_family_invitation_api import CancelInvitation
from family_service.family_app.api.v1.edit_family_member_api import EditFamilyMember
from family_service.family_app.api.v1.edit_family_member_cheers_api import EditFamilyMemberCheers
from family_service.family_app.api.v1.family_pending_invites_api import PendingInvites
from family_service.family_app.api.v1.family_reactivate_api import FamilyReactivate
from family_service.family_app.api.v1.famliy_member_details_api import FamilyMemberDetails
from family_service.family_app.api.v1.leave_family_api import LeaveFamily
from family_service.family_app.api.v1.my_family_api import MyFamily
from family_service.family_app.api.v1.remove_family_member import RemoveFamilyMember
from family_service.family_app.api.v1.resend_family_invitation_api import ResendInvitation


class FamilyAPIV3(BaseRouting):
    api_version = '3'

    def set_routing_collection(self):
        self.routing_collection['remove_member'] = {'view': RemoveFamilyMember, 'url': '/family/remove_member'}
        self.routing_collection['my_family'] = {'view': MyFamily, 'url': '/family/my_family'}
        self.routing_collection['member_details'] = {'view': FamilyMemberDetails, 'url': '/family/member_details'}
        self.routing_collection['pending_invites'] = {'view': PendingInvites, 'url': '/family/pending_invites'}
        self.routing_collection['add_member'] = {'view': AddFamilyMember, 'url': '/family/add_member'}
        self.routing_collection['leave_family'] = {'view': LeaveFamily, 'url': '/family/leave_family'}
        self.routing_collection['edit_member'] = {'view': EditFamilyMember, 'url': '/family/edit_member'}
        self.routing_collection['accept_invitation'] = {'view': AcceptInvitation, 'url': '/family/accept_invitation'}
        self.routing_collection['cancel_invitation'] = {'view': CancelInvitation, 'url': '/family/cancel_invitation'}
        self.routing_collection['resend_invitation'] = {'view': ResendInvitation, 'url': '/family/resend_invitation'}
        self.routing_collection['edit_family_member_cheers'] = {
            'view': EditFamilyMemberCheers,
            'url': '/family/edit_family_member_cheers'
        }
        self.routing_collection['reactivate_family'] = {'view': FamilyReactivate, 'url': '/family/reactivate_family'}
