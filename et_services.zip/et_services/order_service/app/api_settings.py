"""
This modules loads APIs for a specific service
"""
from flask import g

from order_service.app.routings.routings_v3 import OrderServiceAPIV3


def api_urls():
    OrderServiceAPIV3(app=g.app, name=OrderServiceAPIV3.__name__).map_urls()
