"""
Edit order Api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.edit_order_validation import order_edit_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import ORDER_NOT_FOUND
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.models.dm_merchant_order_history import DmMerchantOrderHistory
from order_service.common.models.dm_merchant_order_item import DmMerchantOrderItem
from order_service.common.models.dm_merchant_order_status import DmMerchantOrderStatus
from order_service.common.models.redemption import Redemption
from order_service.common.utils.api_utils import get_locale, get_locale_for_messaging
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3


class EditOrderApi(BasePostResource):
    """
    Class handles the edit order endpoint
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='edit_order_api/edit_order_api.log',
        ),
        'name': 'edit_order_api'
    }
    request_parser = order_edit_parser
    validators = [token_decorator_v3]

    ORDER_CAN_NOT_BE_EDITED = "Order cannot be edited now. Order is in "

    def populate_request_arguments(self):
        """
        Populate request arguments
        """
        self.order_id = self.request_args.get('order_id')
        self.delivery_time = self.request_args.get('delivery_time')
        self.locale = self.request_args.get('language')

    def sets_language_and_variables(self):
        """
        Set the locale for user message
        """
        locale = get_locale(self.locale)
        self.messages_locale = get_locale_for_messaging(locale)
        current_customer = get_current_customer()
        self.customer_id = current_customer.get('customer_id')
        self.data = {}
        self.success = False
        self.status_code = 200

    def get_order_status(self):
        """
        Get order status
        """
        if self.merchant_order.get('status_identifier', '').lower() in [DmMerchantOrder.QUEUE]:
            self.order_status = DmMerchantOrderStatus.get_filter_status(
                filters={'short_title': DmMerchantOrder.EDITED}, single=True
            )
            self.merchant_order_changes['order_status_id'] = self.order_status.get('id')
            self.merchant_order_changes['is_cancelable'] = 1
            if DmMerchantOrder.update_merchant_order(self.order_id, data=self.merchant_order_changes):
                self.merchant_order.update(self.merchant_order_changes)
            self.data = {
                'order_id': self.merchant_order.get('id'),
                'status_id': self.order_status.get('id'),
                'status_identifier': self.order_status.get('short_title'),
                'status_title': self.order_status.get('title'),
                'status_label': self.order_status.get('label'),
                'is_active': self.merchant_order.get('is_active'),
                'order_red': self.merchant_order.get('order_number'),
                'tracking_number': self.merchant_order.get('tracking_number'),
                'is_cancelable': self.merchant_order.get('is_cancelable'),
                'is_delivered': self.merchant_order.get('is_delivered'),
                'reject_reason': self.merchant_order.get('reject_reason')
            }
            del self.merchant_order['status_identifier']
            self.merchant_order = DmMerchantOrder.get_merchant_order_by_id(
                self.order_id, customer_id=self.customer_id
            )
        else:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": '{msg}{status} state'.format(
                    msg=self.ORDER_CAN_NOT_BE_EDITED,
                    status=self.merchant_order.get('status_identifier', ''),
                ),
                "success": self.success,
                "code": self.status_code
            }
            return self.send_response(self.response, self.status_code)

    def verify_merchant_order(self):
        """
        Verify merchant order
        """
        merchant_order_data = DmMerchantOrder.get_merchant_order_and_status_by_id(
            self.order_id, customer_id=self.customer_id
        )
        self.merchant_order = {}
        if merchant_order_data:
            self.merchant_order = dict((zip(merchant_order_data._fields, merchant_order_data)))

        if not self.merchant_order:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": ORDER_NOT_FOUND,
                "success": self.success,
                "code": self.status_code
            }
            return self.send_response(self.response, self.status_code)

        if self.merchant_order.get('status_identifier', '').lower() not in [DmMerchantOrder.QUEUE]:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": '{msg}{status} state'.format(
                    msg=self.ORDER_CAN_NOT_BE_EDITED,
                    status=self.merchant_order.get('status_identifier', ''),
                ),
                "success": self.success,
                "code": self.status_code
            }
            return self.send_response(self.response, self.status_code)

    def update_redemption_status(self):
        """
        Update redemption status
        """
        redemption_ids = []
        redemption_ids_list = DmMerchantOrderItem.get_order_redemption_ids(self.order_id)
        for redemption_id in redemption_ids_list:
            redemption_ids.append(redemption_id[0])

        if redemption_ids_list:
            Redemption.update_status_flag(redemption_ids)

    def generating_final_response(self):
        """
        Preparing final response
        """
        self.success = True
        self.send_response_flag = True
        self.message = 'Success'
        self.response = {
            "message": self.message,
            'data': self.data,
            'success': self.success,
            "code": self.status_code
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.populate_request_arguments()
        self.sets_language_and_variables()
        self.verify_merchant_order()
        if self.send_response_flag:
            return

        self.merchant_order_changes = dict()
        self.get_order_status()
        if self.send_response_flag:
            return

        self.order_history = self.merchant_order
        self.order_history['order_id'] = self.merchant_order.get('id')
        del self.order_history['id']
        DmMerchantOrderHistory.insert_into_order_history(self.order_history)
        self.update_redemption_status()
        self.generating_final_response()
