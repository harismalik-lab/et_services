"""
Pending Order Status API
"""
import datetime

from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.pending_order_status_api_validation import pending_order_status_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import SUCCESS_MSG
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3
from order_service.modules.api_modules import ApiModulesOrderServices


class GetPendingOrderStatusApi(BasePostResource):
    """
    Class handles the pending order status endpoint
    """
    request_parser = pending_order_status_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='pending_order_status_api/pending_order_status_api.log'
        ),
        'name': 'pending_order_status_api'
    }
    logger = None
    status_code = 200
    validators = [token_decorator_v3]

    def initialize_local_variables(self):
        """
        Initialze local variables
        """
        current_customer = get_current_customer()
        self.language = self.request_args.get('language')
        self.customer_id = current_customer.get('user_id')
        self.company = current_customer.get('company')
        if not self.company:
            self.company = self.request_args.get('company')

    def get_order_details(self):
        """
        Get order details
        """
        self.fab_ui_section = {
            "fab_image_selected": ApiModulesOrderServices.SELECTED_FAB_IMAGE_URL,
            "fab_image_unselected": ApiModulesOrderServices.UNSELECTED_RESERVATION_DELIVERY_FAB_URL,
            "fab_background_color": ApiModulesOrderServices.RESERVATION_FAB_COLOR
        }
        pending_orders_section = []
        merchant_pending_order_status = {
            "section_identifier": ApiModulesOrderServices.DELIVERY_SECTION_IDENTIFIER,
            "section_title": ApiModulesOrderServices.DELIVERY_SECTION_TITLE,
            "section_title_color": ApiModulesOrderServices.SECTION_TITLE_COLOR,
            "section_background_color": ApiModulesOrderServices.SECTION_BACKGROUND_COLOR,
            "section_list": []
        }
        order_details = ApiModulesOrderServices().get_pending_orders_info(
            self.customer_id, self.language, self.company
        )
        for order in order_details:
            merchant_pending_order_status['section_list'].append({
                'order_id': order.get('order_id'),
                'outlet_id': order.get('outlet_id'),
                'merchant_id': order.get('merchant_id'),
                'title': order.get('outlet_name'),
                'sub_title': order.get('order_status'),
                'image_url': order.get('logo'),
                'title_text_color': ApiModulesOrderServices.TITLE_TEXT_COLOR,
                'sub_title_text_color': order.get('status_color'),
            })
        if merchant_pending_order_status.get('section_list', []):
            pending_orders_section.append(merchant_pending_order_status)
        table_booking_pending_orders = {
            "section_identifier": ApiModulesOrderServices.RESERVATION_SECTION_IDENTIFIER,
            "section_title": ApiModulesOrderServices.RESERVATION_SECTION_TITLE,
            "section_title_color": ApiModulesOrderServices.SECTION_TITLE_COLOR,
            "section_background_color": ApiModulesOrderServices.SECTION_BACKGROUND_COLOR,
            "section_list": []
        }
        table_booking_orders = ApiModulesOrderServices.get_table_booking_order_status_info(
            self.customer_id, self.language
        )
        if table_booking_orders:
            for table_booking_order in table_booking_orders:
                turnaround_time = ApiModulesOrderServices().get_turnaround_time(reservation=table_booking_order)  # noqa
                current_date_time = datetime.datetime.now()
                reservation_time = table_booking_order.get('booking_date')
                cancellation_time = reservation_time + datetime.timedelta(minutes=turnaround_time)
                cancellation_time = cancellation_time + datetime.timedelta(hours=24)
                # Once the reservation is complete, hide the reservation from the FAB icon after 24 hours.
                if table_booking_order.get('booking_status') == ApiModulesOrderServices.ORDER_RESERVED_STATUS_CODE:
                    # Reservation is complete if status is reserved and turnaround time passed away.
                    if current_date_time < cancellation_time:
                        table_booking_pending_orders['section_list'].append({
                            'order_id': table_booking_order.get('order_id'),
                            'outlet_id': table_booking_order.get('outlet_id'),
                            'merchant_id': table_booking_order.get('merchant_id'),
                            'title': table_booking_order.get('outlet_name'),
                            'sub_title': str(reservation_time),
                            'image_url': table_booking_order.get('image_url'),
                            'title_text_color': table_booking_order.get('title_text_color'),
                            'sub_title_text_color': table_booking_order.get('sub_title_text_color')
                        })
                else:
                    table_booking_pending_orders['section_list'].append({
                        'order_id': table_booking_order.get('order_id'),
                        'outlet_id': table_booking_order.get('outlet_id'),
                        'merchant_id': table_booking_order.get('merchant_id'),
                        'title': table_booking_order.get('outlet_name'),
                        'sub_title': str(reservation_time),
                        'image_url': table_booking_order.get('image_url'),
                        'title_text_color': table_booking_order.get('title_text_color'),
                        'sub_title_text_color': table_booking_order.get('sub_title_text_color')
                    })
        if table_booking_pending_orders.get('section_list', []):
            pending_orders_section.append(table_booking_pending_orders)
        if merchant_pending_order_status.get('section_list') and not table_booking_pending_orders.get('section_list'):
            self.fab_ui_section['fab_image_unselected'] = ApiModulesOrderServices.UNSELECTED_DELIVERY_FAB_URL
            self.fab_ui_section['fab_background_color'] = ApiModulesOrderServices.DELIVERY_FAB_COLOR
        if table_booking_pending_orders.get('section_list') and not merchant_pending_order_status.get('section_list'):
            self.fab_ui_section['fab_image_unselected'] = ApiModulesOrderServices.UNSELECTED_RESERVATION_FAB_URL
            self.fab_ui_section['fab_background_color'] = ApiModulesOrderServices.RESERVATION_FAB_COLOR
        return pending_orders_section

    def generate_final_response(self):
        """
        Generate final response
        """
        order_details = self.get_order_details()
        data = {}
        if order_details:
            data['fab_ui'] = self.fab_ui_section
            data['pending_orders'] = order_details
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': data,
            'success': True,
            'message': SUCCESS_MSG,
            'code': self.status_code
        }

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
