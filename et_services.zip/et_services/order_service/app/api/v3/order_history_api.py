"""
Order history API
"""
import datetime

from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.order_history_api_validation import order_history_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import SUCCESS_MSG
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.utils.api_utils import get_locale, get_locale_for_messaging
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3
from order_service.modules.api_modules import ApiModulesOrderServices


class OrderHistoryApi(BasePostResource):
    """
    Class handles order history endpoint
    """
    request_parser = order_history_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='order_history_api/order_history_api.log',
        ),
        'name': 'order_history_api'
    }
    validators = [token_decorator_v3]
    logger = None
    status_code = 200

    def populate_request_arguments(self):
        """
        Populates the request argument
        """
        self.locale = self.request_args.get('language')
        self.company = self.request_args.get('company')
        self.outlet_id = self.request_args.get('outlet_id')

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        locale = get_locale(self.locale)
        self.messages_locale = get_locale_for_messaging(locale)
        self.data = {}
        self.success = False
        customer = get_current_customer()
        self.user_id = customer.get('user_id')
        self.process_monthly = True
        if self.outlet_id:
            self.process_monthly = False

    def get_orders(self):
        """
        Get orders
        """
        orders_history_by_customer = DmMerchantOrder.get_orders_history_by_customer(
            customer_id=self.user_id,
            company=self.company,
            outlet_id=self.outlet_id,
        )
        self.deliveries, self.orders_history = ApiModulesOrderServices().process_order_history(
            orders_history_by_customer,
            process_monthly=self.process_monthly
        )

    def generating_final_response(self):
        """
        Preparing final response
        """
        self.send_response_flag = True
        self.success = True
        self.message = SUCCESS_MSG
        self.data = {
            'current_year': datetime.datetime.now().year,
            'month_wise_orders': self.orders_history,
            'total_deliveries': self.deliveries,
            'orders': []
        }
        if self.outlet_id:
            self.data['orders'] = self.orders_history
            self.data['month_wise_orders'] = []

        self.response = {
            "message": self.message,
            'data': self.data,
            'success': self.success,
            "code": self.status_code
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        self.get_orders()
        self.generating_final_response()
