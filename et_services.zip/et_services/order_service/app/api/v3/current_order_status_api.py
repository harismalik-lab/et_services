"""
Current Order Status API
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.current_order_status_api_validation import current_order_status_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import SUCCESS_MSG
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.utils.api_utils import get_locale, get_locale_for_messaging
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3
from order_service.modules.api_modules import ApiModulesOrderServices


class CurrentOrderStatusApi(BasePostResource):
    """
    Class handles the current order status endpoint
    """
    request_parser = current_order_status_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='current_order_status_api/current_order_status_api.log',
        ),
        'name': 'current_order_status_api'
    }
    logger = None
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Populates the request argument
        """
        self.locale = self.request_args.get('language')
        self.order_id = self.request_args.get('order_id')
        self.time_zone = self.request_args.get('time_zone')
        self.location_id = self.request_args.get('location_id')

    def initialize_local_variables(self):
        """
        Initialize local variable
        """
        locale = get_locale(self.locale)
        self.messages_locale = get_locale_for_messaging(locale)
        self.data = {}
        self.success = False
        customer = get_current_customer()
        self.customer_id = customer.get('customer_id')
        self.statuses = None
        self.order_status = []

    def get_order_status(self):
        """
        populates response data dictionary
        """
        order_info, order_status_data_and_statuses = ApiModulesOrderServices().get_order_status_info(
            self.order_id, self.customer_id, self.time_zone, self.location_id
        )
        try:
            self.data['order_statuses'] = order_status_data_and_statuses[0]
        except IndexError:
            self.data['order_statuses'] = {}
        try:
            order_status_data = order_status_data_and_statuses[1]
        except IndexError:
            order_status_data = {}
        self.data['order_section_title'] = ApiModulesOrderServices.ORDER_SECTION_TITLE
        self.data['estimated_delivery_time'] = order_status_data.get('estimated_delivery_time', None)
        # if order_status is delivered then we have changed delivery status message i.e delivered to Order has arrived
        if order_status_data.get('is_last_mile_delivery', False):
            self.data['is_last_mile_enabled'] = True
            if (
                self.data['order_statuses'][4]['is_selected'] and
                order_status_data.get('order_status') in [ApiModulesOrderServices.COMPLETED, DmMerchantOrder.ACCEPTED]
            ):
                self.data['estimated_delivery_time'] = ApiModulesOrderServices.DELIVERY_STATUS_ARRIVED
                self.data['last_mile_order_completed'] = True
        self.data['is_show_cancel_button'] = order_status_data.get('is_show_cancel_button', False)
        self.data['order_status'] = order_status_data.get('order_status')
        self.data['is_order_rejected'] = order_status_data.get('is_order_rejected', False)
        self.data['is_order_cancelled'] = order_status_data.get('is_order_cancelled', False)
        self.data['order_status_color'] = order_status_data.get('order_status_color', ApiModulesOrderServices.ORDER_STATUS_COLOR_CANCELLED)  # noqa
        self.data['order_arc_gradient_color'] = ApiModulesOrderServices.ORDER_ARC_GRADIENT_COLOR
        driver_info = order_status_data.get('driver_info', {})
        if driver_info:
            self.data['driver_info'] = driver_info
        if order_info:
            self.data['tracking_info'] = order_info

        # check if order status data and also is_take_away_order then show button to pick up order
        if order_status_data_and_statuses:
            if order_status_data_and_statuses[1].get('is_take_away_order', False):
                self.data["section_takeaway_picked_up"] = {
                    "title": ApiModulesOrderServices.IS_ORDER_PICKED_UP,
                    "description": ApiModulesOrderServices.ORDER_PICK_UP_DESCRIPTION_TEXT,
                    "picked_up_btn_txt": ApiModulesOrderServices.PICKED_UP,
                    "show_picked_up_btn": True
                }

    def generate_final_response(self):
        """
        Generate final response
        """
        self.send_response_flag = True
        self.status_code = 200
        self.response = {
            'data': self.data,
            'success': True,
            'message': SUCCESS_MSG,
            'code': self.status_code
        }

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        self.get_order_status()
        self.generate_final_response()
