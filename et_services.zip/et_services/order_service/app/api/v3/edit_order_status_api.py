"""
Edit order status api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.edit_order_status_api_validation import order_edit_status_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import ORDER_NOT_FOUND
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.utils.api_utils import get_locale, get_locale_for_messaging
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3


class OrderEditStatusApi(BasePostResource):
    """
    Class handles the order edit status endpoint
    """
    request_parser = order_edit_status_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='order_edit_status_api/order_edit_status_api.log',
        ),
        'name': 'order_edit_status_api'
    }
    logger = None
    status_code = 200
    validators = [token_decorator_v3]

    ORDER_STATUS_MSG = 'Order is in {status} state'

    def populate_request_arguments(self):
        """
        Populates the request argument
        """
        self.locale = self.request_args.get('language')
        self.order_id = self.request_args.get('order_id')

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        locale = get_locale(self.locale)
        self.messages_locale = get_locale_for_messaging(locale)
        self.data = {}
        self.success = False
        customer = get_current_customer()
        self.customer_id = customer.get('customer_id')

    def get_order_details(self):
        """
        Get order details
        """
        self.merchant_order = DmMerchantOrder.get_merchant_order_and_status_by_id(
            self.order_id, customer_id=self.customer_id
        )
        if not self.merchant_order:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": ORDER_NOT_FOUND,
                "success": self.success,
                "code": self.status_code
            }
            return self.send_response(self.response, self.status_code)

        self.data = {
            'order_in_edit_state': False
        }
        order_status = self.merchant_order.status_identifier.lower() or ''
        if order_status == DmMerchantOrder.EDITED:
            self.data['order_in_edit_state'] = True

        order_message = self.ORDER_STATUS_MSG.format(status=order_status)
        self.data['message'] = order_message

    def generating_final_response(self):
        """
        Preparing final response
        """
        self.send_response_flag = True
        self.success = True
        self.message = 'Success'
        self.response = {
            "message": self.message,
            'data': self.data,
            'success': self.success
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        self.get_order_details()
        self.generating_final_response()
