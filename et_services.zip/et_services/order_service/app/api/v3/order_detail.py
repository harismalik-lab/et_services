"""
Orders details api
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from order_service.app.api.v3.validations.order_details_api_validation import order_detail_parser
from order_service.common.base_resource import BasePostResource
from order_service.common.constants import ORDER_NOT_FOUND, SUCCESS_MSG
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.utils.api_utils import get_locale, get_locale_for_messaging
from order_service.common.utils.authentication import get_current_customer, token_decorator_v3
from order_service.modules.api_modules import ApiModulesOrderServices


class OrderDetailsApi(BasePostResource):
    """
    Class handles the order details endpoint
    """
    request_parser = order_detail_parser
    response = {}
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='order_service/order_detail_api.log',
        ),
        'name': 'order_detail_api'
    }
    logger = None
    status_code = 200
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Populates the request argument
        """
        self.locale = self.request_args.get('language')
        self.order_id = self.request_args.get('order_id')
        self.company = self.request_args.get('company')
        self.location_id = self.request_args.get('location_id', 1)

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        locale = get_locale(self.locale)
        self.messages_locale = get_locale_for_messaging(locale)
        self.data = {}
        self.success = False
        customer = get_current_customer()
        self.customer_id = customer.get('customer_id')

    def get_order_details(self):
        """
        Get order details
        """
        orders_detail_data = DmMerchantOrder.get_order_details(
            order_id=self.order_id,
            customer_id=self.customer_id,
            company=self.company
        )
        if orders_detail_data:
            self.orders_details = ApiModulesOrderServices().process_order_details(
                dict((zip(orders_detail_data._fields, orders_detail_data))),
                self.location_id
            )
        elif not orders_detail_data:
            self.send_response_flag = True
            self.status_code = 422
            self.response = {
                "message": ORDER_NOT_FOUND,
                "success": self.success,
                "code": self.status_code
            }
            return self.send_response(self.response, self.status_code)

    def generating_final_response(self):
        """
        Preparing final response
        """
        self.send_response_flag = True
        self.success = True
        self.message = SUCCESS_MSG
        self.response = {
            "message": self.message,
            'data': self.orders_details,
            'success': self.success,
            "code": self.status_code
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Process request
        """
        self.initialize_local_variables()
        self.get_order_details()
        if self.send_response_flag:
            return
        self.generating_final_response()
