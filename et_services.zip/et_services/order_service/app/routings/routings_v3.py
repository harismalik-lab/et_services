"""
This module contains routing for an app
"""
from order_service.app.api.v3.cancel_order_api import OrderCancelledApi
from order_service.app.api.v3.current_order_status_api import CurrentOrderStatusApi
from order_service.app.api.v3.edit_order_api import EditOrderApi
from order_service.app.api.v3.edit_order_status_api import OrderEditStatusApi
from order_service.app.api.v3.order_detail import OrderDetailsApi
from order_service.app.api.v3.order_history_api import OrderHistoryApi
from order_service.app.api.v3.pending_order_status_api import GetPendingOrderStatusApi
from order_service.common.base_routing import BaseRouting


class OrderServiceAPIV3(BaseRouting):
    api_version = '3'

    def set_routing_collection(self):
        self.routing_collection['order_history'] = {
            'url': '/order_history',
            'view': OrderHistoryApi
        }

        self.routing_collection['order_details'] = {
            'url': '/order_details',
            'view': OrderDetailsApi
        }

        self.routing_collection['edit_order'] = {
            'url': '/edit_order',
            'view': EditOrderApi
        }

        self.routing_collection['edit_order_status'] = {
            'url': '/edit_order_status',
            'view': OrderEditStatusApi
        }

        self.routing_collection['pending_order_status'] = {
            'url': '/pending_order_status',
            'view': GetPendingOrderStatusApi
        }
        self.routing_collection['current_order_status'] = {
            'url': '/current_order_status',
            'view': CurrentOrderStatusApi
        }
        self.routing_collection['cancel_order'] = {
            'url': '/cancel_order',
            'view': OrderCancelledApi
        }
