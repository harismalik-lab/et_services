"""
api modules for order services
"""
import copy
import datetime
import uuid
from collections import OrderedDict
from math import ceil

from order_service.common.constants import EN, ENT_COMPANY
from order_service.common.models.dm_attribute import DmAttribute
from order_service.common.models.dm_merchant_order import DmMerchantOrder
from order_service.common.models.dm_merchant_order_history import DmMerchantOrderHistory
from order_service.common.models.dm_merchant_order_item import DmMerchantOrderItem
from order_service.common.models.dm_merchant_order_status import DmMerchantOrderStatus
from order_service.common.models.dm_quiq_up_order_details import DmQuiqUpOrderDetail
from order_service.common.models.quiq_up_settings import QuiqUpSetting
from order_service.common.models.tb_booking_order import TbBookingOrder
from order_service.common.utils.api_utils import make_to_two_decimal


class ApiModulesOrderServices(object):

    DELIVERY_STATUS_CANCELLED = 'cancelled'
    DELIVERY_STATUS_PICK_START = 'pickup_started'
    DELIVERY_STATUS_PICK_REACHED = 'pickup_arrived'
    DELIVERY_STATUS_DROP_START = 'drop_started'
    DELIVERY_STATUS_DROP_REACHED = 'drop_arrived'
    DELIVERY_STATUS_COMPLETED = 'complete'
    DELIVERY_STATUS_ARRIVED = 'Your order has arrived'
    DELIVERY_STATUS_REQUESTED = 'requested'

    LIVE_TRACKING_TEXT = 'View Live map'
    LIVE_TRACKING_COLOR = '74e77f'
    STANDARD_DELIVERY = 'standard_delivery'
    IS_LAST_MILE_DELIVERY = 'Quiqup'
    COMPLETED = 'completed'
    REJECTED = 'rejected'
    REFUNDED = 'refunded'
    CANCELLED = 'cancelled'
    RECEIVED = 'Received'
    REJECTED_TIMED_OUT = 'rejected-timeout'

    REJECTED_STATUS = 'Order Rejected'
    PENDING_STATUS = 'Pending'
    REFUND_STATUS = 'Refunded'
    CANCELLED_STATUS = 'Cancelled'
    ACCEPTED_STATUS = 'Accepted'
    PREPARATION_STATUS = 'Under Preparation'
    COURIER_ARRIVED_STATUS = "Courier Arrived"
    EN_ROUTE_STATUS = 'En Route'
    DELIVERED_STATUS = 'Delivered'
    PICKED_UP_STATUS = 'Picked-up'

    Refund_Requested = 'refund_requested'
    PARTIAL_Refunded = 'partial_refunded'
    Full_Refunded = 'full_refunded'
    Refund_Cancelled = 'refund_cancelled'

    REJECTED_TITLE = "REJECTED"
    REFUNDED_TITLE = "REFUNDED"
    CANCELLED_TITLE = "Order Cancelled"

    ORDER_RECEIVED = "Order Received"
    ORDER_CONFIRMED = "Order Confirmed"
    COURIER_ARRIVED = "Courier has arrived at restaurant"
    DELIVERED = "Delivered"
    READY_FOR_PICK_UP = 'Order ready for pick-up'
    PICKED_UP = 'Order picked-up'
    IS_ORDER_PICKED_UP = "Order Picked-up?"
    ORDER_PICK_UP_DESCRIPTION_TEXT = "A short description on why they need to confirm."

    ORDER_STATUS_TEXT_COLOR = "636363"
    ORDER_STATUS_LINE_COLOR_NORMAL = "a5a5a5"

    ORDER_STATUS_LINE_COLOR_ACCEPTED = "82d500"
    ORDER_STATUS_LINE_COLOR_REJECTED = "d0021b"

    ORDER_STATUS_COLOR = "636363"
    ORDER_STATUS_COLOR_REJECTED = "d0021b"
    ORDER_STATUS_COLOR_REFUNDED = "091187"
    ORDER_STATUS_COLOR_CANCELLED = "999999"

    ORDER_SECTION_TITLE = 'Order Status'
    DELIVERY_TIME_TITLE = 'Estimated Delivery Time'

    RECEIVED_ORDER_UNSELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_order_receive.png"
    CONFIRMED_ORDER_UNSELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_order_confirm.png"
    PREPARATION_ORDER_UNSELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_under_preparation.png"
    EN_ROUTE_ORDER_UNSELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_route.png"
    DELIVERED_ORDER_UNSELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_delivery.png"

    RECEIVED_ORDER_SELECTED = 'https://s3.amazonaws.com/entertainer-app-assets/ic_order_received.png'
    CONFIRMED_ORDER_SELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_order_confirmed.png"
    PREPARATION_ORDER_SELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_preparation.png"
    COURIER_ARRIVED_SELECTED = "https://entertainer-app-assets.s3.amazonaws.com/icCourierHasArrived%403x.png"
    EN_ROUTE_ORDER_SELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_routed.png"
    DELIVERED_ORDER_SELECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_delivered.png"
    FAB_ICON_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/delivery_icon_white.png'

    RECEIVED_REJECTED = 'https://s3.amazonaws.com/entertainer-app-assets/ic_order_received_rejected.png'
    CONFIRMED_REJECTED = "https://s3.amazonaws.com/entertainer-app-assets/ic_order_confirmed_rejected.png"
    PREPARATION_REJECTED = 'https://s3.amazonaws.com/entertainer-app-assets/ic_preparation_rejected.png'
    EN_ROUTE_REJECTED = 'https://s3.amazonaws.com/entertainer-app-assets/ic_routed_rejected.png'
    DELIVERED_REJECTED = 'https://s3.amazonaws.com/entertainer-app-assets/ic_delivered_rejected.png'

    SECTION_TITLE_COLOR = '282828'
    SECTION_BACKGROUND_COLOR = 'f7f7f7'
    DELIVERY_SECTION_TITLE = 'DELIVERY CASHLESS'
    DELIVERY_SECTION_IDENTIFIER = 'delivery'

    ITEM_MISSING_STATUS_TYPE = "item_availability"
    ITEM_MISSING_TITLE = "Item availability"
    ITEM_MISSING_MESSAGE = "Some of the items and their prices  you originally ordered have changed or are no longer available."  # noqa: E501
    SOME_ITEM_MISSING_BUTTON = "New Order"

    OUTLET_STATUS_TYPE = 'outlet_not_exist'
    OUTLET_STATUS_TITLE = 'Outlet not exist'
    OUTLET_STATUS_MESSAGE = 'Some of the item you orignally waiting are not available or may be their prices have been changed'  # noqa: E501

    OUTLET_NOT_EXIST_STATUS_TYPE = "outlet_not_exist"
    OUTLET_NOT_EXIST_TITLE = "Outlet no longer exists"
    OUTLET_NOT_EXIST_MESSAGE = "Sorry, this outlet no longer exists."

    OUTLET_CLOSE_STATUS_TYPE = "outlet_closed"
    OUTLET_CLOSE_TITLE = "Outlet is closed"
    OUTLET_CLOSE_MESSAGE = "The restauraunt is currently not accepting any order"

    MENU_ITEM_STATUS_ONLINE = 'online'
    MENU_ITEM_STATUS_OFFLINE = 'offline'

    OUTLET_LOCATION_MISMATCH_MESSAGE = 'Sorry, this outlet is unable to deliver at this chosen time/location'
    OUTLET_LOCATION_MISMATCH_TITLE = 'Invalid Outlet Location'

    PICKUP_TIME_TITLE = 'Estimated pick-up Time'
    MERCHANT_PICKED_UP = 'picked-up-merchant'
    CUSTOMER_PICKED_UP = 'picked-up-customer'
    READY_PICKED_UP = 'pick-up-ready'
    PICKED_UP_CUSTOMER = 'picked-up-customer'

    # User booking repository
    CALL_BUTTON_TEXT = "Call"
    CALL_BUTTON_BG_COLOR = "4d97d0"
    ORDER_CANCELLATION_SUCCESS_MESSAGE_BEFORE = 'Your Booking for '
    ORDER_CANCELLATION_SUCCESS_MESSAGE_AFTER = ' has been cancelled.'
    ORDER_NOT_FOUND = 'order not found'
    ORDER_LEAD_TIME_MESSAGE = 'To cancel this booking call to '
    ORDER_CANCELLATION_STATUS = 'order is already cancelled'
    ORDER_CANCELLATION_STATUS_CODE = 6
    ORDER_RESERVED_STATUS_CODE = 11
    COMPLETED_BOOKING_STATUS = 'Complete'

    TITLE_TEXT_COLOR = '282828'
    SUB_TITLE_TEXT_COLOR = 'a9a9a9'
    UNSELECTED_RESERVATION_FAB_URL = 'https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/icFaBreservation%403x.png'  # noqa: E501
    UNSELECTED_DELIVERY_FAB_URL = 'https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/icFaBdelivery.png'  # noqa: E501
    UNSELECTED_RESERVATION_DELIVERY_FAB_URL = 'https://s3.amazonaws.com/entertainer-app-assets/circle-plus.png'
    SELECTED_FAB_IMAGE_URL = 'https://s3.amazonaws.com/entertainer-app-assets/circle-cross.png'
    DELIVERY_FAB_COLOR = 'ed7120'
    RESERVATION_FAB_COLOR = '4d97d0'
    RESERVATION_SECTION_TITLE = 'RESERVATIONS'
    RESERVATION_SECTION_IDENTIFIER = 'tablebooking'

    CANCEL_BUTTON_BORDER_COLOR = 'c60000'
    CANCEL_BUTTON_BG_COLOR = 'ffffff'
    CANCEL_BUTTON_TEXT = 'Cancel'
    CANCELLATION_WARNING_MESSAGE = 'Are you sure you want to\ncancel this booking?'
    CANCEL_BUTTON_TEXT_COLOR = 'c60000'
    PARTY_SIZE_1_START_LIMIT = 1
    PARTY_SIZE_1_END_LIMIT = 4
    PARTY_SIZE_2_START_LIMIT = 5
    PARTY_SIZE_2_END_LIMIT = 8
    PARTY_SIZE_3_START_LIMIT = 9
    PARTY_SIZE_3_END_LIMIT = 15
    PARTY_SIZE_4_START_LIMIT = 16

    RESERVATION_STATUS_LABEL = 'Status'
    RESERVATION_STATUS = {
        0: 'Not Found',
        1: 'Pending',
        6: 'Cancelled',
        11: 'Reserved',
        16: 'Rejected'
    }

    STATUS_COLORS = {
        COMPLETED: '1E8449',
        REJECTED: 'FF0000',
        DmMerchantOrder.PENDING: '82d500',
        CANCELLED: 'FF0000',
        DmMerchantOrder.ACCEPTED: '2874A6',
        REFUNDED: 'F39C12',
        DmMerchantOrder.EDITED: '1E8449',
        DmMerchantOrder.QUEUE: '1E8449',
        DmMerchantOrder.EN_ROUTE: '82d500',
        DELIVERED: '82d500',
        DmMerchantOrder.UNDER_PREPARATION: '82d500'
    }

    HISTORY_STATUS_COLORS = {
        COMPLETED: '1E8449',
        REJECTED: 'FF0000',
        DmMerchantOrder.PENDING: 'f47421',
        CANCELLED: 'FF0000',
        DmMerchantOrder.ACCEPTED: '08b000',
        REFUNDED: 'F39C12',
        DmMerchantOrder.EDITED: '1E8449',
        DmMerchantOrder.QUEUE: '1E8449',
        DmMerchantOrder.EN_ROUTE: '82d500',
        DELIVERED: '82d500',
        DmMerchantOrder.UNDER_PREPARATION: '82d500'
    }

    # Delivery Statuses Repository
    ORDER_STATUS_GREEN_COLOR = '3BB143'
    ORDER_STATUS_RED_COLOR = 'D0021B'
    ORDER_STATUS_GREY_COLOR = 'EDEDED'
    ORDER_ARC_GRADIENT_COLOR = "FFFFFF"
    ORDER_STATUS_BLUE_COLOR = '4A90E2'

    ORDER_UNDER_PREPARATION_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icUnderPreparation.png'
    ORDER_ENROUTE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icEnRoute.png'
    ORDER_CONFIRMED_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icConfirmed.png'
    ORDER_RECEIVED_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icOrderReceived.png'
    ORDER_DELIVERED_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icDelivered.png'
    ORDER_REJECTED_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icOrderRejected.png'
    ORDER_REFUNDED_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icOrderRefunded.png'

    PROGRESS_PERCENTAGE = 10
    PROGRESS_PERCENTAGE_UNDER_PREPARATION = 30
    PROGRESS_PERCENTAGE_EN_ROUTE = 45
    PROGRESS_PERCENTAGE_DELIVERED = 5

    ORDER_REJECTED_STATUS_TEXT = 'Order Rejected'
    ORDER_REFUNDED_STATUS_TEXT = 'Order Refunded'
    ORDER_PARTIALLY_REFUNDED_STATUS_TEXT = 'Order Partially Refunded'

    AWAITING_CONFIRMATION_MESSAGE = "Awaiting restaurant's confirmation"

    # v613 changed statuses repository
    LAST_MILE_DELIVERED = "Order has arrived"
    DRIVER_TEXT = "Your driver"
    ESTIMATED_DELIVERY_TEXT = "Estimated Delivery at"
    DELIVERY_MESSAGE = "Your order is on its way!"

    QUIQ_UP_COMPLETED_IMAGE_URL = 'https://entertainer-app-assets.s3.amazonaws.com/delivery/en/image_2019_08_19T08_04_40_502Z.png'  # noqa: E501
    ORDER_DETAILS_PHONE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icon_phone.png'
    ORDER_DETAILS_ADDRESS_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icon_communication_business.png'
    ORDER_READY_PICK_UP_IMAGE = 'https://entertainer-app-assets.s3.amazonaws.com/icBag_3.png'
    ORDER_PICKED_UP_IMAGE = 'https://entertainer-app-assets.s3.amazonaws.com/icBag_3.png'
    READY_FOR_PICK_UP_ORDER_SELECTED = "https://entertainer-app-assets.s3.amazonaws.com/icBag_3.png"
    PICKED_UP_ORDER_SELECTED = 'https://entertainer-app-assets.s3.amazonaws.com/icBag_3.png'
    PICKED_UP_ORDER_UNSELECTED = 'https://entertainer-app-assets.s3.amazonaws.com/icBag_3.png'

    PAGE_SIZE = 10
    ORDER_STATUS_REFRESH_INTERVAL = 10
    ORDER_STATUS_BG_COLOR = "f47421"
    DISCOUNT_TITLE = "25% off"
    ORDER_ITEM_IMAGE_URL = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/voucher_type_food_1.png"
    ORDER_DETAIL_TITLE = 'Delivering to:'
    CALL_TO_MERCHANT_MESSAGE = 'Questions or concerns about your order? \nCall'
    GROUP_COLOR = "636363"
    ORDER_HEADER_TITLE = "Order Details"
    ORDER_ITEM_DISCOUNT_TITLE = "OFFER APPLIED x 1"
    USER_CANCEL_ORDER_REASON = 'User cancelled the order'
    USER_EDIT_ORDER_REASON = 'User edited the order'
    ORDER_VALUE_TITLE = "Order Value"
    DISCOUNT_APPLIED_TITLE = '25% OFF OFFER APPLIED'
    order_percentage_value_color = 'D92703'
    order_refund_title_color = 'D92703'
    REFUND_TITLE = 'REFUNDED AMOUNT'
    ORDER_SAVINGS_TITLE = 'SAVINGS'
    ORDER_SAVINGS_TITLE_COLOR = 'D92703'
    order_percentage_sub_title_color = 'FFC000'
    ORDER_DELIVERY_TITLE = 'Delivery'
    ORDER_TOTAL_SUB_TITLE = 'Inclusive of VAT'
    SMILE_EARNED_MESSAGE = 'Smiles Earned'
    smile_image = "https://s3.amazonaws.com/entertainer-app-assets/smiles+image.png"
    QATAR_LOCATION_ID = 9

    VIEW_ORDER_DETAILS_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/new_icon_1.png'
    VIEW_ORDER_DETAILS_TEXT = 'View Order Details'
    VIEW_LESS_ORDER_DETAILS_TEXT = 'View Less'

    TAKE_AWAY_COLLECTION_INSTRUCTION_TITLE = 'How to collect your order?'
    SECTION_TAKE_AWAY_MAP_TITLE = 'View Map'
    SECTION_TAKE_AWAY_MAP_IMAGE = 'https://entertainer-app-assets.s3.amazonaws.com/ic_location.png'

    RE_ORDER_SIZE = 5
    RE_ORDER_TITLE = "RE-ORDER"
    VIEW_ORDER_TITLE = "VIEW ORDER"

    def get_pending_orders_info(self, customer_id, language=EN, company=ENT_COMPANY):
        """
        Get pending order status. It gets query set result from DmMerchantOrder

        :param int customer_id: id of customer
        :param str language: language
        :param str company: company
        :rtype dict
        """
        try:
            results = DmMerchantOrder.get_pending_order_status(customer_id, language, company)
            return self.get_multi_order_status(results)
        except Exception:
            raise

    def get_order_status_info(self, order_id, customer_id, order_time_zone, location_id=1):
        """
        Get order status information. It gets query set result from DmMerchantOrder

        :param int order_id: id of order
        :param int customer_id: id of customer
        :param datetime|str order_time_zone: order time zone
        :param int location_id: id of location
        :rtype dict
        """
        try:
            result = DmMerchantOrder.get_status_of_order(order_id, customer_id, location_id)
            return self.calculate_status_of_order(result, order_id, customer_id)
        except Exception:
            raise

    def get_table_booking_order_status_info(self, customer_id, language=EN):
        """
        Get table booking order info.

        :param int customer_id: id of customer
        :param str language: language
        :rtype list
        """
        try:
            table_bookings = TbBookingOrder.get_table_booking_order_status(customer_id, language)
            reservations = []
            if table_bookings:
                for reservation in table_bookings:
                    reservation = dict((zip(reservation._fields, reservation)))
                    reservation['title_text_color'] = ApiModulesOrderServices.TITLE_TEXT_COLOR
                    reservation['sub_title_text_color'] = ApiModulesOrderServices.SUB_TITLE_TEXT_COLOR
                    reservations.append(reservation)
            return reservations
        except Exception:
            raise

    def get_quiq_up_order_status(self, order_delivery_status, order_status, show_order_confirmed_status):
        """
        Gets the QuiqUp order status

        :param str|bool order_delivery_status: status of delivery
        :param str|bool order_status: status of order
        :param str|bool show_order_confirmed_status: show status of confirmed order
        :rtype: tuple
        :return Gets the Order Delivery status
        """
        show_en_route_order_status = False
        show_pending_order_status = False
        show_delivered_order_status = False
        if show_order_confirmed_status:
            return show_order_confirmed_status, show_pending_order_status, show_en_route_order_status, show_delivered_order_status, order_status  # noqa
        if order_delivery_status == self.DELIVERY_STATUS_CANCELLED:
            show_pending_order_status = True
            order_status = self.CANCELLED
        elif order_delivery_status in [
            self.DELIVERY_STATUS_DROP_START,
            self.DELIVERY_STATUS_DROP_REACHED
        ]:
            show_en_route_order_status = True
            order_status = self.COMPLETED
        elif order_delivery_status == self.DELIVERY_STATUS_COMPLETED:
            show_delivered_order_status = True
            order_status = self.COMPLETED
        elif order_delivery_status == self.DELIVERY_STATUS_REQUESTED:
            show_order_confirmed_status = True
        elif order_delivery_status:
            show_pending_order_status = True
        return show_order_confirmed_status, show_pending_order_status, show_en_route_order_status, show_delivered_order_status, order_status  # noqa

    def get_formated_monthly_order(self, _monthly_order):
        """
        Gets the formated monthly order data

        :param dict _monthly_order: monthly orders
        :rtype: dict
        """
        try:
            _monthly_order['month_date'] = str(_monthly_order['date'])
            _monthly_order['date'] = _monthly_order['date'].strftime("%b %d, %Y, %I:%M %p")
        except ValueError:
            _monthly_order['date'] = ''
        _monthly_order['savings'] = '{tag}: {currency} {amount}'.format(
            tag='Savings',
            currency=_monthly_order.get('currency'),
            amount=_monthly_order['savings']
        )
        _monthly_order['total'] = '{tag}: {currency} {amount}'.format(
            tag='Total',
            currency=_monthly_order.get('currency'),
            amount=_monthly_order['total']
        )
        del _monthly_order['created_at']
        del _monthly_order['history_created_at']
        return _monthly_order

    def set_all_monthly_order_data(self, month_data, index, month_orders):
        """
        Sets the monthly order data

        :param dict|list month_data: data of month
        :param str index: index
        :param list month_orders: orders of month
        :rtype: dict
        """
        month_data['index'] = index
        try:
            _date = datetime.datetime.strptime(month_orders[-1]['month_date'], '%Y-%m-%d %H:%M:%S')
            month_data['month'] = '{year} {month}'.format(
                year=_date.year,
                month=_date.strftime("%B")
            )
        except ValueError:
            month_data['month'] = ''
        month_data['orders'] = month_orders
        month_data['deliveries_count'] = len(month_orders)
        return month_data

    def get_multi_order_status(self, delivery_orders=None, history_orders=False):
        """
        Gets the orders list
        :param delivery_orders: orders list
        :param history_orders: Tells that its the call form order history
        :rtype list
        """
        pending_orders = []
        order_sub_status = DmMerchantOrderStatus().get_filter_status(
            filters={'short_title': self.CUSTOMER_PICKED_UP}, single=True
        )
        for order_result in delivery_orders:
            order_result = dict((zip(order_result._fields, order_result)))
            pending_orders.append(order_result)
            current_date_time = datetime.datetime.now()
            show_pending_order_status = False
            show_en_route_order_status = False
            show_delivered_order_status = False
            show_order_confirmed_status = False
            is_order_accepted = True

            accepted_order_time = order_result.get('history_created_at')
            if not accepted_order_time:
                accepted_order_time = order_result.get('created_at')
            order_confirmed = accepted_order_time + datetime.timedelta(minutes=3)
            avg_prep_time = order_result.get('average_prep_time', 0) if order_result.get('average_prep_time', 0) else 0
            # Set is_last_mile_delivery flag true for last mile order
            is_last_mile_delivery = False
            if order_result.get('delivery_type') == self.IS_LAST_MILE_DELIVERY:
                is_last_mile_delivery = True
            # Setting the pending order time
            pending_order_time = order_confirmed
            pending_order_time += datetime.timedelta(seconds=15)
            pending_order_time += datetime.timedelta(minutes=avg_prep_time)

            delivery_time = order_result.get('delivery_time') if order_result.get('delivery_time') else 0
            en_route_order_time = accepted_order_time
            en_route_order_time += datetime.timedelta(minutes=avg_prep_time)
            order_status = order_result.get('order_status_title', self.RECEIVED)
            show_courier_arrived_order_status = False
            # check if order sub_status is picked up for takeaway then we will update statuses accordingly.
            order_picked_up = False
            if order_result.get('is_take_away_order', False):
                takeaways_order_sub_status = DmMerchantOrderStatus().get_filter_status(
                    filters={'id': order_result.get('sub_status_id', 0)}, single=True
                )
                if takeaways_order_sub_status.get('order_sub_status_title') == self.CUSTOMER_PICKED_UP:
                    order_picked_up = True
            if not is_last_mile_delivery:
                en_route_order_time += datetime.timedelta(minutes=delivery_time)
                en_route_order_time += datetime.timedelta(minutes=90)
                # En Route time was calculating after setting the order statuses.
                # Moved the code inside. So that correct time calculation can be made.
                if current_date_time < order_confirmed and is_order_accepted:
                    show_order_confirmed_status = True
                elif current_date_time < pending_order_time:
                    show_pending_order_status = True
                elif current_date_time < en_route_order_time and not order_picked_up:
                    show_en_route_order_status = True
                else:
                    show_delivered_order_status = True
            else:
                # quick_up_job_id = quick_up_order_details.get('quiq_job_id')
                # TODO add waiting time in formula
                # Get wait time from QUICK UP API from field (requested - pending_assignment)
                average_drop_off_time = order_result.get('average_drop_off_time') or 10
                en_route_order_time += datetime.timedelta(minutes=average_drop_off_time)
                en_route_order_time += datetime.timedelta(minutes=1)
                if order_status not in [self.REJECTED, self.REJECTED_TIMED_OUT, self.REFUNDED, self.CANCELLED]:
                    order_delivery_status = order_result.get('quiq_job_status')
                    if current_date_time < order_confirmed and is_order_accepted:
                        show_order_confirmed_status = True
                    show_order_confirmed_status, show_pending_order_status, show_en_route_order_status, \
                        show_delivered_order_status, order_status = self.get_quiq_up_order_status(
                            order_delivery_status, order_status, show_order_confirmed_status
                        )
                    if order_delivery_status:
                        order_status = DmMerchantOrder.ACCEPTED
                    show_courier_arrived_order_status = self.get_courier_arrived_status(order_delivery_status)

            order_time = order_result.get('created_at')
            if order_status in [self.REJECTED, self.REJECTED_TIMED_OUT]:
                order_result['order_status'] = self.REJECTED_STATUS
                order_result['status_color'] = self.STATUS_COLORS[self.REJECTED]
                # pop out the order if 30 minutes over after reject.
                if current_date_time > order_time + datetime.timedelta(minutes=30):
                    if not history_orders:
                        pending_orders.pop()
                continue

            if order_status == self.REFUNDED:
                order_result['order_status'] = self.REFUND_STATUS
                order_result['status_color'] = self.STATUS_COLORS[self.REFUNDED]
                # pop out the order if 30 minutes over after refund.
                if current_date_time > order_time + datetime.timedelta(minutes=30):
                    if not history_orders:
                        pending_orders.pop()
                continue

            if order_status == self.CANCELLED:
                order_result['order_status'] = self.CANCELLED_STATUS
                order_result['status_color'] = self.STATUS_COLORS[self.CANCELLED]
                # pop out the order if 30 minutes over after Cancel.
                if current_date_time > order_time + datetime.timedelta(minutes=30):
                    if not history_orders:
                        pending_orders.pop()
                continue

            if order_status == DmMerchantOrder.PENDING or order_status == DmMerchantOrder.QUEUE or order_status == DmMerchantOrder.EDITED:  # noqa
                order_result['order_status'] = self.PENDING_STATUS
                order_result['status_color'] = self.STATUS_COLORS[DmMerchantOrder.PENDING]
            elif order_status == DmMerchantOrder.ACCEPTED or show_order_confirmed_status:
                order_result['order_status'] = self.ACCEPTED_STATUS
                order_result['status_color'] = self.STATUS_COLORS[DmMerchantOrder.ACCEPTED]
            if any([
                order_status == self.COMPLETED,
                show_pending_order_status and (order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED])
            ]):
                order_result['order_status'] = self.PREPARATION_STATUS
                if is_last_mile_delivery and show_courier_arrived_order_status:
                    order_result['order_status'] = self.COURIER_ARRIVED_STATUS
                order_result['status_color'] = self.STATUS_COLORS[DmMerchantOrder.UNDER_PREPARATION]
            if show_en_route_order_status and order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED]:
                if not order_result.get('is_take_away_order', False):
                    order_result['order_status'] = self.EN_ROUTE_STATUS
                else:
                    order_result['order_status'] = self.READY_PICKED_UP
                order_result['status_color'] = self.STATUS_COLORS[DmMerchantOrder.EN_ROUTE]
            if show_delivered_order_status and order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED]:
                order_result['order_status'] = self.DELIVERED_STATUS
                if order_result.get('is_take_away_order', False):
                    order_result['order_status'] = self.READY_PICKED_UP
                    if order_result.get('sub_status_id', 0) == order_sub_status.id:
                        order_result['order_status'] = self.PICKED_UP_STATUS
                order_result['status_color'] = self.STATUS_COLORS[self.DELIVERED]
                if not history_orders:
                    pending_orders.pop()
        return pending_orders

    def get_courier_arrived_status(self, order_delivery_status):
        """
        Checks that courier has arrived or not on merchant location.
        :param str order_delivery_status: status of delivery order
        :rtype bool
        """
        return order_delivery_status == self.DELIVERY_STATUS_PICK_REACHED

    def get_turnaround_time(self, reservation):
        """
        Gets turnaround time for reservation
        :param reservation: Reservation dict
        :rtype:
        """
        turnaround_time = 0
        if self.PARTY_SIZE_1_START_LIMIT <= reservation.get('number_of_persons', 0) <= self.PARTY_SIZE_1_END_LIMIT:
            turnaround_time = reservation.get('party_size_1')
        if self.PARTY_SIZE_2_START_LIMIT <= reservation.get('number_of_persons', 0) <= self.PARTY_SIZE_2_END_LIMIT:
            turnaround_time = reservation.get('party_size_2')
        if self.PARTY_SIZE_3_START_LIMIT <= reservation.get('number_of_persons', 0) <= self.PARTY_SIZE_3_END_LIMIT:
            turnaround_time = reservation.get('party_size_3')
        if reservation.get('number_of_persons', 0) >= self.PARTY_SIZE_4_START_LIMIT:
            turnaround_time = reservation.get('party_size_4')
        return turnaround_time

    def get_estimated_addition_of_time(self, estimated_time, estimated_time_delta, current_time, order_info):
        """
        Gets the estimated addition of time on the base of reached time of delivery

        :param date estimated_time: estimated delivery time
        :param date estimated_time_delta: current_delivery time
        :param date current_time: current date time
        :param dict order_info: status of order
        :rtype: str
        :return str: Additional estimated delivery time
        """
        time_latency = estimated_time_delta - current_time
        order_status = ''
        if order_info:
            order_status = order_info.get('quiq_job_status')
        if (time_latency.days < 0 and order_status in [
            self.DELIVERY_STATUS_PICK_START,
            self.DELIVERY_STATUS_PICK_REACHED,
            self.DELIVERY_STATUS_DROP_START,
            self.DELIVERY_STATUS_DROP_REACHED
        ]):
            time_latency = current_time - estimated_time_delta
            minutes_delta = time_latency.seconds / 60
            upper_minutes_limit = int(minutes_delta / 10) + 1
            upper_minutes_limit = 10 * upper_minutes_limit
            estimated_time = estimated_time + datetime.timedelta(minutes=upper_minutes_limit)
            estimated_time_delta = estimated_time + datetime.timedelta(minutes=10)
        if order_status == self.DELIVERY_STATUS_COMPLETED and order_info.get('created_date') > estimated_time_delta:
            estimated_time_delta = order_info.get('created_date')
            estimated_time = estimated_time_delta - datetime.timedelta(minutes=10)
        # Formats the time like 11:45am or 11:45pm
        estimated_time = estimated_time.strftime("%I:%M%p").lower()
        estimated_time_delta = estimated_time_delta.strftime("%I:%M%p").lower()
        order_time_to_complete_time = '{}-{}'.format(estimated_time, estimated_time_delta)
        driver_delivery_time_format = '{} - {}'.format(estimated_time, estimated_time_delta)
        return driver_delivery_time_format, order_time_to_complete_time

    def change_order_status_ui_assets(
            self, order_status, order_status_data, order_statuses, order_result,
            show_order_confirmed_status, show_pending_order_status, show_en_route_order_status,
            show_delivered_order_status, show_courier_arrived_order_status=False, is_take_away_order=False
    ):
        """
        change ui assets of order statuses
        :param order_status: order status
        :param order_status_data: order status data
        :param order_statuses: order statuses
        :param order_result: order result
        :param show_order_confirmed_status: order confirmed status flag
        :param show_pending_order_status: pending order status flag
        :param show_en_route_order_status: en route status flag
        :param show_delivered_order_status: delivered order status flag
        :param show_courier_arrived_order_status: status for courier arrived
        :param is_take_away_order: is take away order
        :return: dict
        """
        order_status_data['is_take_away_order'] = False
        order_statuses[0]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
        order_statuses[1]['order_status_image_url'] = self.ORDER_CONFIRMED_IMAGE
        if show_courier_arrived_order_status:
            order_statuses[2]["order_status_text"] = self.COURIER_ARRIVED
            order_statuses[2]["order_status_image_url"] = self.COURIER_ARRIVED_SELECTED
        else:
            order_statuses[2]['order_status_image_url'] = self.ORDER_UNDER_PREPARATION_IMAGE
        if is_take_away_order:
            order_statuses[3]['order_status_image_url'] = self.ORDER_READY_PICK_UP_IMAGE
            order_statuses[4]['order_status_image_url'] = self.ORDER_PICKED_UP_IMAGE
        else:
            order_statuses[3]['order_status_image_url'] = self.ORDER_ENROUTE_IMAGE
            order_statuses[4]['order_status_image_url'] = self.ORDER_DELIVERED_IMAGE
        order_statuses[0]['progress_percentage'] = self.PROGRESS_PERCENTAGE
        order_statuses[1]['progress_percentage'] = self.PROGRESS_PERCENTAGE
        order_statuses[2]['progress_percentage'] = self.PROGRESS_PERCENTAGE_UNDER_PREPARATION
        order_statuses[3]['progress_percentage'] = self.PROGRESS_PERCENTAGE_EN_ROUTE
        order_statuses[4]['progress_percentage'] = self.PROGRESS_PERCENTAGE_DELIVERED
        if order_status in [self.REJECTED, self.REJECTED_TIMED_OUT]:
            order_status_data['is_order_rejected'] = True
            order_status_data['estimated_delivery_time'] = ''
            order_status_data['order_status_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['order_status_image_url'] = self.ORDER_REJECTED_IMAGE
            order_statuses[1]['order_status_image_url'] = self.ORDER_REJECTED_IMAGE
            order_statuses[2]['order_status_image_url'] = self.ORDER_REJECTED_IMAGE
            order_statuses[3]['order_status_image_url'] = self.ORDER_REJECTED_IMAGE
            order_statuses[4]['order_status_image_url'] = self.ORDER_REJECTED_IMAGE
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[3]['is_selected'] = True
            order_statuses[4]['is_selected'] = True
            order_statuses[0]['order_status_text'] = self.ORDER_REJECTED_STATUS_TEXT
            order_statuses[1]['order_status_text'] = self.ORDER_REJECTED_STATUS_TEXT
            order_statuses[2]['order_status_text'] = self.ORDER_REJECTED_STATUS_TEXT
            order_statuses[3]['order_status_text'] = self.ORDER_REJECTED_STATUS_TEXT
            order_statuses[4]['order_status_text'] = self.ORDER_REJECTED_STATUS_TEXT
            return order_statuses, order_status_data

        if order_status == self.REFUNDED or all([
            order_status in [self.COMPLETED, DmMerchantOrder.ACCEPTED],
            order_result.get('sub_status_identifier') in [self.PARTIAL_Refunded, self.Full_Refunded]
        ]):
            order_status_data['estimated_delivery_time'] = ''
            order_status_data['order_status_color'] = self.ORDER_STATUS_BLUE_COLOR
            order_statuses[0]['order_status_image_url'] = self.ORDER_REFUNDED_IMAGE
            order_statuses[1]['order_status_image_url'] = self.ORDER_REFUNDED_IMAGE
            order_statuses[2]['order_status_image_url'] = self.ORDER_REFUNDED_IMAGE
            order_statuses[3]['order_status_image_url'] = self.ORDER_REFUNDED_IMAGE
            order_statuses[4]['order_status_image_url'] = self.ORDER_REFUNDED_IMAGE
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[3]['is_selected'] = True
            order_statuses[4]['is_selected'] = True
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_BLUE_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_BLUE_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_BLUE_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_BLUE_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_BLUE_COLOR
            if order_status == self.REFUNDED:
                order_statuses[0]['order_status_text'] = self.ORDER_REFUNDED_STATUS_TEXT
                order_statuses[1]['order_status_text'] = self.ORDER_REFUNDED_STATUS_TEXT
                order_statuses[2]['order_status_text'] = self.ORDER_REFUNDED_STATUS_TEXT
                order_statuses[3]['order_status_text'] = self.ORDER_REFUNDED_STATUS_TEXT
                order_statuses[4]['order_status_text'] = self.ORDER_REFUNDED_STATUS_TEXT
            else:
                order_statuses[0]['order_status_text'] = self.ORDER_PARTIALLY_REFUNDED_STATUS_TEXT
                order_statuses[1]['order_status_text'] = self.ORDER_PARTIALLY_REFUNDED_STATUS_TEXT
                order_statuses[2]['order_status_text'] = self.ORDER_PARTIALLY_REFUNDED_STATUS_TEXT
                order_statuses[3]['order_status_text'] = self.ORDER_PARTIALLY_REFUNDED_STATUS_TEXT
                order_statuses[4]['order_status_text'] = self.ORDER_PARTIALLY_REFUNDED_STATUS_TEXT
            return order_statuses, order_status_data

        if order_status == self.CANCELLED:
            order_status_data['is_order_cancelled'] = True
            order_status_data['estimated_delivery_time'] = ''
            order_status_data['order_status_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[0]['order_status_text'] = self.CANCELLED_TITLE
            order_statuses[1]['order_status_text'] = self.CANCELLED_TITLE
            order_statuses[2]['order_status_text'] = self.CANCELLED_TITLE
            order_statuses[3]['order_status_text'] = self.CANCELLED_TITLE
            order_statuses[4]['order_status_text'] = self.CANCELLED_TITLE
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[3]['is_selected'] = True
            order_statuses[4]['is_selected'] = True
            order_statuses[0]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
            order_statuses[1]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
            order_statuses[2]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
            order_statuses[3]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
            order_statuses[4]['order_status_image_url'] = self.ORDER_RECEIVED_IMAGE
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_RED_COLOR
            return order_statuses, order_status_data

        if order_status in [DmMerchantOrder.PENDING, DmMerchantOrder.QUEUE, DmMerchantOrder.EDITED]:
            order_status_data['estimated_delivery_time'] = self.AWAITING_CONFIRMATION_MESSAGE
            order_status_data['is_show_cancel_button'] = True
            order_status_data['order_status_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR

        elif order_status == DmMerchantOrder.ACCEPTED or show_order_confirmed_status:
            order_status_data['order_status_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
        if any([
            order_status == self.COMPLETED,
            show_pending_order_status and (order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED])
        ]):
            order_status_data['order_status_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR

        if show_en_route_order_status and order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED]:
            order_status_data['order_status_color'] = self.ORDER_STATUS_GREEN_COLOR
            if is_take_away_order:
                order_status_data['is_take_away_order'] = True
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_GREY_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[3]['is_selected'] = True
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR

        if show_delivered_order_status and order_status in [DmMerchantOrder.ACCEPTED, self.COMPLETED]:
            order_status_data['order_status_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[0]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_line_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[0]['is_selected'] = True
            order_statuses[1]['is_selected'] = True
            order_statuses[2]['is_selected'] = True
            order_statuses[3]['is_selected'] = True
            order_statuses[4]['is_selected'] = True
            order_statuses[0]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[1]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[2]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[3]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
            order_statuses[4]['order_status_text_color'] = self.ORDER_STATUS_GREEN_COLOR
        return order_statuses, order_status_data

    def calculate_status_of_order(self, order_result, order_id, customer_id):
        """
        Calculate status of order to get status info

        :param dict|tuple order_result: result of order
        :param int order_id: id of order
        :param int customer_id: id of customer
        :return tuple
        """
        order_info = dict()

        if order_result:
            order_result = dict((zip(order_result._fields, order_result)))

            is_take_away_order = order_result.get('is_take_away_order', False)
            is_last_mile_delivery = order_result.get('delivery_type') == self.IS_LAST_MILE_DELIVERY

            current_date_time = datetime.datetime.now()
            show_pending_order_status = False
            show_en_route_order_status = False
            show_delivered_order_status = False
            show_order_confirmed_status = False
            is_order_accepted = True
            driver_info = {}
            quick_up_order_detail = {}
            driver_delivery_statuses = (
                self.DELIVERY_STATUS_COMPLETED, self.DELIVERY_STATUS_DROP_REACHED, self.DELIVERY_STATUS_DROP_START
            )

            order_status = DmMerchantOrderStatus.get_filter_status(
                filters={'short_title': DmMerchantOrder.ACCEPTED}, single=True
            )
            accepted_order = DmMerchantOrderHistory.get_accepted_order(order_id, order_status.id)
            if accepted_order:
                accepted_order_time = accepted_order.created_at
            else:
                accepted_order_time = order_result.get('created_at')
                is_order_accepted = False
            order_status = order_result.get('order_status', self.RECEIVED)
            order_confirmed = accepted_order_time + datetime.timedelta(minutes=3)
            avg_prep_time = order_result.get('average_prep_time', 0) if order_result.get('average_prep_time', 0) else 0
            pending_order_time = order_confirmed
            pending_order_time += datetime.timedelta(seconds=15)
            pending_order_time += datetime.timedelta(minutes=avg_prep_time)

            delivery_time = order_result.get('delivery_time') if order_result.get('delivery_time') else 0
            en_route_order_time = accepted_order_time

            # Addition of avg_prep_time
            en_route_order_time += datetime.timedelta(minutes=avg_prep_time)

            order_sub_status = order_result.get('sub_status_identifier')
            is_order_picked_up = False
            if order_sub_status in [self.MERCHANT_PICKED_UP, self.PICKED_UP_CUSTOMER]:
                is_order_picked_up = True

            order_delivery_status = None
            show_courier_arrived_order_status = False
            if not is_last_mile_delivery:
                en_route_order_time += datetime.timedelta(minutes=delivery_time)
                en_route_order_time += datetime.timedelta(minutes=90)
                total_delivery_time_of_order = accepted_order_time
                total_delivery_time_of_order += datetime.timedelta(minutes=delivery_time)
                # Formats the time like 11:45am or 11:45pm
                order_time_to_complete_time = total_delivery_time_of_order.strftime("%-I:%M%p").lower()
                if current_date_time < order_confirmed and is_order_accepted:
                    show_order_confirmed_status = True
                elif current_date_time < pending_order_time:
                    show_pending_order_status = True
                elif current_date_time < en_route_order_time and not is_order_picked_up:
                    show_en_route_order_status = True
                else:
                    show_delivered_order_status = True
            else:
                quick_up_setting_info = QuiqUpSetting.get_avg_drop_off_time(
                    location_id=order_result.get('location_id'),
                    band_id=order_result.get('band_id')
                )
                quick_up_order_detail = DmQuiqUpOrderDetail.get_quiq_up_delivery_status(order_id, customer_id)
                if quick_up_order_detail:
                    quick_up_order_detail = dict((zip(quick_up_order_detail._fields, quick_up_order_detail)))

                average_drop_off_time = quick_up_setting_info.average_drop_off_time
                # Addition of avg_drop_off_time
                en_route_order_time += datetime.timedelta(minutes=average_drop_off_time)
                # Addition of extra 10 minutes
                en_route_order_time += datetime.timedelta(minutes=10)

                total_delivery_time_of_order = accepted_order_time
                total_delivery_time_of_order += datetime.timedelta(minutes=avg_prep_time)
                total_delivery_time_of_order += datetime.timedelta(minutes=average_drop_off_time)
                # addition of extra 10 minutes
                total_delivery_time_of_order += datetime.timedelta(minutes=10)
                estimated_time_addition = total_delivery_time_of_order
                estimated_time_addition += datetime.timedelta(minutes=10)
                driver_delivery_time_format, order_time_to_complete_time = self.get_estimated_addition_of_time(
                    total_delivery_time_of_order, estimated_time_addition,
                    current_date_time, quick_up_order_detail
                )
                if quick_up_order_detail:
                    if order_status not in [self.REJECTED, self.REJECTED_TIMED_OUT, self.REFUNDED, self.CANCELLED]:
                        order_status = DmMerchantOrder.ACCEPTED
                        order_delivery_status = quick_up_order_detail.get('quiq_job_status')
                        order_info.update({
                            "title": self.LIVE_TRACKING_TEXT,
                            "image_url": self.QUIQ_UP_COMPLETED_IMAGE_URL,
                            "title_color": self.LIVE_TRACKING_COLOR,
                            "tracking_url": quick_up_order_detail.get('dropoff_tracking_url', '')
                        })
                    # We were only adding the driver information if order status is "accepted" or "completed",
                    # otherwise driver information is not updated
                    if (
                            quick_up_order_detail.get('quiq_job_status') in driver_delivery_statuses and
                            order_status in [self.COMPLETED, DmMerchantOrder.ACCEPTED]
                    ):
                        driver_info.update({
                            "delivery_message": self.DELIVERY_MESSAGE,
                            "delivery_time_text": self.ESTIMATED_DELIVERY_TEXT,
                            "delivery_time_value": driver_delivery_time_format,
                            "driver_name": quick_up_order_detail.get('driver_name', ''),
                            "driver_number": quick_up_order_detail.get('driver_number', ''),
                            "phone_icon": self.ORDER_DETAILS_PHONE_IMAGE,
                            "driver_text": self.DRIVER_TEXT
                        })

                if current_date_time < order_confirmed and is_order_accepted:
                    show_order_confirmed_status = True

                show_order_confirmed_status, show_pending_order_status, show_en_route_order_status, \
                show_delivered_order_status, order_status = self.get_quiq_up_order_status(
                    order_delivery_status, order_status, show_order_confirmed_status
                )  # noqa
                if show_delivered_order_status or show_order_confirmed_status or show_pending_order_status:
                    order_info = None

            estimated_delivery_time = '{title}: {time}'.format(
                title=self.DELIVERY_TIME_TITLE,
                time=order_time_to_complete_time
            )

            is_show_cancel_button = False
            is_order_rejected = False
            is_order_cancelled = False
            # In case of take_away order we will send estimated_pick_up
            order_status_data = {
                'driver_info': driver_info,
                'estimated_delivery_time': estimated_delivery_time,
                'is_show_cancel_button': is_show_cancel_button,
                'order_status': order_status,
                'is_order_rejected': is_order_rejected,
                'is_order_cancelled': is_order_cancelled,
                'order_status_color': self.ORDER_STATUS_COLOR,
                'is_last_mile_delivery': is_last_mile_delivery
            }
            # In case of take away order estimated delivery time will be override with estimated pick up time
            if is_take_away_order:
                try:
                    order_avg_prep_time = accepted_order_time + datetime.timedelta(minutes=int(avg_prep_time))
                    order_avg_prep_time = order_avg_prep_time.strftime('%I:%M %p')
                except Exception:
                    order_avg_prep_time = datetime.datetime.now()
                estimated_pick_up_time = '{title}: {time}'.format(
                    title=self.PICKUP_TIME_TITLE,
                    time=order_avg_prep_time
                )
                order_status_data['estimated_delivery_time'] = estimated_pick_up_time

            order_statuses = [
                {
                    "order_status": 0,
                    "order_status_text": self.ORDER_RECEIVED,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.RECEIVED_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE

                },
                {
                    "order_status": 1,
                    "order_status_text": self.ORDER_CONFIRMED,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.CONFIRMED_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                },
                {
                    "order_status": 2,
                    "order_status_text": DmMerchantOrder.UNDER_PREPARATION,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.PREPARATION_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                },
                {
                    "order_status": 3,
                    "order_status_text": DmMerchantOrder.EN_ROUTE,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.EN_ROUTE_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                },
                {
                    "order_status": 4,
                    "order_status_text": self.DELIVERED,
                    "order_number": 'Order Number: {order_number}'.format(
                        order_number=quick_up_order_detail.get('order_number', 0)
                    ),
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.DELIVERED_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                }
            ]
            # If take away order then we will update statuses (enroute, completed) to (ready_for_pick-up and Picked-UP)
            if is_take_away_order:
                order_statuses[3].update({
                    "order_status": 3,
                    "order_status_text": self.READY_FOR_PICK_UP,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.READY_FOR_PICK_UP_ORDER_SELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                })
                order_statuses[4].update({
                    "order_status": 4,
                    "order_status_text": self.PICKED_UP,
                    "order_status_text_color": self.ORDER_STATUS_TEXT_COLOR,
                    "order_status_image_url": self.PICKED_UP_ORDER_UNSELECTED,
                    "order_status_line_color": self.ORDER_STATUS_LINE_COLOR_NORMAL,
                    "is_selected": False,
                    'order_status_fab_image': self.FAB_ICON_IMAGE
                })
            if is_last_mile_delivery and not is_take_away_order:
                order_statuses[4].update({
                    "order_number": 'Order Number: {}'.format(quick_up_order_detail.get('order_number', 0)),
                    "order_status_text": self.LAST_MILE_DELIVERED
                })
                show_courier_arrived_order_status = self.get_courier_arrived_status(order_delivery_status)
            return order_info, self.change_order_status_ui_assets(
                order_status,
                order_status_data,
                order_statuses,
                order_result,
                show_order_confirmed_status,
                show_pending_order_status,
                show_en_route_order_status,
                show_delivered_order_status,
                show_courier_arrived_order_status,
                is_take_away_order
            )
        return order_info, (order_result, {})

    def get_order_items_details(self, order_detail, get_add_ons=False):
        """
        Get order items details

        :param list|dict order_detail: order details
        :param bool get_add_ons: add on flag
        :return tuple
        """
        records = DmMerchantOrderItem.get_order_items_detail(order_detail)
        addons_records = []
        if get_add_ons:
            attribute_ids = []
            for record in records:
                if record.attribute_id:
                    attribute_ids.append(record.attribute_id)
            addons_records = DmAttribute.get_add_ons_by_attribute_id(attr_ids=attribute_ids)
        return records, addons_records

    def set_order_percentage_title(self, order_detail):
        """
        Set order percentage title

        :param dict order_detail: detail of order
        :rtype str
        """
        if order_detail.get('status_identifier') in [
            self.COMPLETED, DmMerchantOrder.ACCEPTED
        ] and order_detail.get('sub_status_identifier') not in [
            ApiModulesOrderServices.PARTIAL_Refunded,
            ApiModulesOrderServices.Full_Refunded
        ]:
            order_percentage_sub_title = '{} {}'.format(
                # Taking floor to make it consistent with Web team
                ceil(float(make_to_two_decimal(order_detail.get('total_discount')))),
                self.SMILE_EARNED_MESSAGE
            )
            return order_percentage_sub_title
        return None

    def process_order_details(self, order_detail, location_id):
        """
        Process order details

        :param dict order_detail: detail of order
        :param int location_id: id of location
        :rtype dict
        """
        order_all_information = {}
        if order_detail:
            customer_address = order_detail.get('home_office_address', '')
            order_to_details = {
                'title': self.ORDER_DETAIL_TITLE,
                'customer_name': '{first_name} {last_name}'.format(
                    first_name=order_detail.get('firstname'),
                    last_name=order_detail.get('lastname')
                ),
                'customer_email': order_detail.get('customer_email'),
                'phone_number': order_detail.get('phone_number', ''),
                'customer_address': customer_address,
                'address_icon': self.ORDER_DETAILS_ADDRESS_IMAGE
            }
            # if takeaway order then need to send outlet address in customer address
            if not order_detail.get('is_take_away_order', False):
                order_to_details['outlet_address'] = '{human_location} {hotel} {mall} {neighborhood}'.format(
                    human_location=('{}{}'.format(order_detail['human_location'], ','))
                    if order_detail.get('human_location', '') else '',  # noqa: E501
                    hotel=('{}{}'.format(order_detail['hotel'], ',')) if order_detail.get('hotel', '') else '',
                    mall=('{}{}'.format(order_detail['mall'], ',')) if order_detail.get('mall', '') else '',
                    neighborhood=(order_detail['neighborhood']) if order_detail.get('neighborhood', '') else ''
                )
            order_details_info = dict()
            call_to_merchant_message = '{} {}'.format(
                self.CALL_TO_MERCHANT_MESSAGE,
                order_detail.get('outlet_name', '')
            )
            order_details_info['order_id'] = order_detail.get('order_id')
            order_details_info['order_number'] = order_detail.get('order_number', '')
            order_details_info['order_header_title'] = self.ORDER_HEADER_TITLE
            order_details_info['order_header_subtitle'] = "Order Number: {}".format(order_detail.get('order_number'))
            order_details_info['order_status_bottom_text'] = call_to_merchant_message
            order_details_info['description'] = ""
            order_details_info['outlet_contact_number'] = order_detail.get('outlet_contact_number', '')
            order_details_info['order_status_bottom_text_bg_color'] = self.ORDER_STATUS_BG_COLOR
            order_details_info['status_id'] = order_detail.get('status_id', '')
            order_details_info['status_title'] = order_detail.get('status_title', '')
            order_details_info['order_time'] = str(order_detail.get('order_time'))
            order_details_info['order_total_amount'] = make_to_two_decimal(order_detail.get('order_total_amount'))
            order_details_info['order_total_savings'] = make_to_two_decimal(order_detail.get('total_discount'))
            order_details_info['delivery_charges'] = make_to_two_decimal(order_detail.get('delivery_charges'))
            order_details_info['currency'] = order_detail.get('order_currency')
            order_details_info['discount_applied'] = (order_detail.get('total_discount') > 0)
            order_details_info['discount_title'] = self.DISCOUNT_TITLE
            order_details_info['discount_value'] = make_to_two_decimal(order_detail.get('total_discount'))
            order_details_info['discount_currency'] = order_detail.get('order_currency')
            order_details_info['special_instruction'] = order_detail.get('delivery_instructions')
            order_details_info['updated_at'] = str(order_detail.get('updated_at'))
            order_details_info['order_items'] = []
            order_details_info['latitude'] = order_detail.get('latitude')
            order_details_info['longitude'] = order_detail.get('longitude')
            order_details_info['phone_icon'] = self.ORDER_DETAILS_PHONE_IMAGE
            order_items_processed_hash = OrderedDict()
            order_items, add_on_items = self.get_order_items_details(order_detail.get('order_id'), get_add_ons=True)
            order_item_processed = dict()
            selected_item_total_price = 0
            order_item_parent_id = 0
            order_percentage_title = False
            percent_discount_applied = False

            for order_item in order_items:
                order_item = dict((zip(order_item._fields, order_item)))
                if order_item.get('promo'):
                    if int(order_item.get('promo')):
                        percent_discount_applied = True
                if not all([
                    order_item.get('parent_order_item_id'),
                    order_item.get('dm_attribute_group_id'),
                    order_item.get('attribute_id')
                ]):
                    order_hash_key = '{menu_item_id}_{random_code}'.format(
                        menu_item_id=order_item.get('dm_menu_item_id'),
                        random_code=uuid.uuid4()
                    )
                try:
                    order_item_processed = order_items_processed_hash[order_hash_key]
                except KeyError:
                    if percent_discount_applied:
                        order_percentage_title = True
                        selected_item_price = '{} {}'.format(
                            order_detail.get('order_currency'),
                            make_to_two_decimal(order_item.get('total_price', 0) + order_item.get('total_discount', 0))
                        )
                        selected_item_total_price = order_item.get('total_price', 0) + order_item.get('total_discount',
                                                                                                      0)
                    elif order_item.get('total_discount', 0) > 0:
                        selected_item_price = '{} {}'.format(
                            order_detail.get('order_currency'),
                            make_to_two_decimal(order_item.get('total_price', 0) + order_item.get('total_discount', 0))
                        )
                        if order_item.get('total_price', 0) > 0:
                            selected_item_total_price = order_item.get('total_price', 0)
                        else:
                            selected_item_total_price = 0
                    else:
                        selected_item_price = '{} {}'.format(
                            order_detail.get('order_currency'),
                            make_to_two_decimal(order_item.get('total_price', 0))
                        )
                        selected_item_total_price = order_item.get('total_price', 0)
                    if not all([
                        order_item.get('parent_order_item_id'),
                        order_item.get('dm_attribute_group_id'),
                        order_item.get('attribute_id')
                    ]):
                        order_item_processed = {
                            "item_id": order_item.get('dm_menu_item_id'),
                            "name": order_item.get('item_title'),
                            "description": order_item.get('item_description'),
                            "item_savings": '{} {}'.format(
                                order_detail.get('order_currency'),
                                make_to_two_decimal(order_item.get('total_discount', 0.0))
                            ),
                            "sub_total": '{} {}'.format(
                                order_detail.get('order_currency'),
                                order_item.get('total_price', 0.0)
                            ),
                            "discount_applied": order_item.get('total_discount', 0) > 0,
                            "discount_value": '-{} {}'.format(
                                order_detail.get('order_currency'),
                                make_to_two_decimal(order_item.get('total_discount', 0.0))
                            ),
                            "selected_item_total_price": selected_item_price,
                            "discount_currency": order_detail.get('order_currency'),
                            "discount_title": self.ORDER_ITEM_DISCOUNT_TITLE if (
                                    order_item.get('total_discount', 0) > 0) else "",  # noqa
                            "imageURL": self.ORDER_ITEM_IMAGE_URL if not (order_item.get('total_price', 0) > 0) else "",
                            "selectedOptions": []
                        }
                        order_item_parent_id = order_item.get('id')
                        if percent_discount_applied:
                            order_item_processed["discount_title"] = ''
                            order_item_processed['discount_applied'] = False
                if not selected_item_total_price:
                    order_item_processed["sub_total"] = "Free"
                else:
                    order_item_processed["sub_total"] = '{} {}'.format(
                        order_detail.get('order_currency'), make_to_two_decimal(selected_item_total_price)
                    )
                order_items_processed_hash[order_hash_key] = order_item_processed
                if order_item_parent_id == order_item.get('parent_order_item_id'):
                    new_group = {
                        'attribute_id': order_item.get('attribute_id'),
                        'section_title': order_item.get('sub_title', ''),
                        'options': [],
                        'section_title_color': self.SECTION_TITLE_COLOR
                    }
                    if percent_discount_applied:
                        add_on_price = order_item.get('total_price') + order_item.get('total_discount')
                    else:
                        add_on_price = order_item.get('total_price')
                    new_group['options'].append({
                        'title': order_item.get('item_title'),
                        'sub_title': '{} {}'.format(
                            order_detail.get('order_currency'), make_to_two_decimal(add_on_price)
                        ),
                        "color": self.GROUP_COLOR
                    })
                    if not order_item.get('total_price'):
                        new_group['options'][-1]['sub_title'] = "Free"
                    else:
                        order_item_processed['sub_total'] = make_to_two_decimal(selected_item_total_price)
                        if percent_discount_applied:
                            selected_item_total_price += add_on_price
                        else:
                            selected_item_total_price += order_item.get('total_price')
                    if not selected_item_total_price:
                        order_item_processed["sub_total"] = "Free"
                    else:
                        order_item_processed["sub_total"] = '{} {}'.format(
                            order_detail.get('order_currency'), make_to_two_decimal(selected_item_total_price)
                        )
                    order_item_processed['selectedOptions'].append(new_group)
                del order_item['attribute_id']

            for order_items_processed_hash_key in order_items_processed_hash.keys():
                order_details_info['order_items'].append(order_items_processed_hash[order_items_processed_hash_key])

            order_sub_total_value = order_detail.get('order_total_amount') + order_detail.get('total_discount') - \
                                    order_detail.get('delivery_charges')  # noqa
            order_sub_total_value = '{} {}'.format(
                order_detail.get('order_currency'),
                make_to_two_decimal(order_sub_total_value)
            )
            order_percentage_value = '{} -{}'.format(
                order_detail.get('order_currency'),
                make_to_two_decimal(order_detail.get('total_discount'))
            )
            if not order_detail.get('is_take_away_order', False):
                order_value_after_discount = order_detail.get('order_total_amount') - order_detail.get(
                    'delivery_charges')
                order_value_after_discount = '{} {}'.format(
                    order_detail.get('order_currency'),
                    make_to_two_decimal(order_value_after_discount)
                )
                order_delivery_fee = '{} {}'.format(
                    order_detail.get('order_currency'),
                    make_to_two_decimal(order_detail.get('delivery_charges'))
                )
                order_all_information.update({'order_delivery_title': self.ORDER_DELIVERY_TITLE})
                order_all_information.update({'order_delivery_fee': order_delivery_fee})
            else:
                order_value_after_discount = '{} {}'.format(
                    order_detail.get('order_currency'),
                    make_to_two_decimal(order_detail.get('order_total_amount', 0))
                )
            order_total = '{} {}'.format(
                order_detail.get('order_currency'),
                make_to_two_decimal(order_detail.get('order_total_amount'))
            )
            # In case of dc_prospect order we will not send order_percentage_sub_title
            if not order_detail.get('is_prospect_order', True):
                order_percentage_sub_title = self.set_order_percentage_title(order_detail)
                order_all_information.update({'order_percentage_sub_title': order_percentage_sub_title})
            order_all_information.update({'merchant_id': order_detail.get('merchant_id')})
            order_all_information.update({'customer_details': order_to_details})
            order_all_information.update({'order': order_details_info})
            order_all_information.update({'order_status_refresh_interval': self.ORDER_STATUS_REFRESH_INTERVAL})
            order_all_information.update({'order_sub_total_value': order_sub_total_value})
            order_all_information.update({'order_percentage_title': None})
            order_all_information.update({'order_value_title': self.ORDER_VALUE_TITLE})
            order_all_information.update({'order_percentage_value': order_percentage_value})
            order_all_information.update({'order_percentage_value_color': self.order_percentage_value_color})
            order_all_information.update({'order_sub_total_value_after_discount': order_value_after_discount})
            order_all_information.update({'order_total': order_total})
            order_all_information.update({'order_total_sub_title': self.ORDER_TOTAL_SUB_TITLE})
            order_all_information.update({'order_percentage_sub_title_img': self.smile_image})
            order_all_information.update({'order_percentage_sub_title_color': self.order_percentage_sub_title_color})
            order_all_information.update({'view_detail_text': self.VIEW_ORDER_DETAILS_TEXT})
            order_all_information.update({'view_less_text': self.VIEW_LESS_ORDER_DETAILS_TEXT})
            order_all_information.update({'view_detail_icon': self.VIEW_ORDER_DETAILS_IMAGE})
            order_all_information.update({'view_less_icon': self.VIEW_ORDER_DETAILS_IMAGE})
            if order_detail.get('is_take_away_order', False):
                order_all_information["section_takeaway_map"] = {
                    "title": self.SECTION_TAKE_AWAY_MAP_TITLE,
                    "icon": self.SECTION_TAKE_AWAY_MAP_IMAGE,
                    "outlet_lat": order_detail.get('outlet_lat'),
                    "outlet_lng": order_detail.get('outlet_lng'),
                    "outlet_name": order_detail.get('outlet_name', '')
                }
                order_all_information["section_takeaway_collect_instructions"] = {
                    "title": self.TAKE_AWAY_COLLECTION_INSTRUCTION_TITLE,
                    "description": order_detail.get('collect_order_value', '')
                }

            if location_id == self.QATAR_LOCATION_ID:
                del order_all_information['order_total_sub_title']
            refund_amount = order_detail.get('refund_amount')
            order_refund_value = '{} {}'.format(
                order_detail.get('order_currency'),
                make_to_two_decimal(refund_amount)
            )
            if order_detail.get('status_identifier', '').lower() in [
                self.REFUNDED
            ] or order_detail.get('sub_status_identifier') in [
                ApiModulesOrderServices.PARTIAL_Refunded,
                ApiModulesOrderServices.Full_Refunded
            ]:
                order_all_information.update({'order_refund_value': order_refund_value})
                order_all_information.update({'order_refund_title': self.REFUND_TITLE})
                order_all_information.update({'order_refund_color': self.order_refund_title_color})

            is_order_cancel = all([
                order_detail.get('is_cancelable'),
                order_detail.get('status_identifier', '').lower() in [
                    DmMerchantOrder.EDITED, DmMerchantOrder.QUEUE, DmMerchantOrder.PENDING
                ]])
            if order_percentage_title:
                order_all_information['order_percentage_title'] = self.DISCOUNT_APPLIED_TITLE
            elif float(order_detail.get('total_discount', 0)) == 0:
                order_all_information['order_percentage_title'] = None
            else:
                order_all_information['order_percentage_title'] = self.ORDER_SAVINGS_TITLE
            is_order_rejected = order_detail.get('status_identifier', '').lower() == self.REJECTED
            order_all_information.update({'is_show_cancel_button': is_order_cancel})
            order_all_information.update({'is_order_rejected': is_order_rejected})
        return order_all_information

    def process_order_history(self, orders, process_monthly=True):
        """
        Process order history

        :param dict orders: orders
        :param bool process_monthly: monthly process
        :rtype tuple
        """
        self.order_status_list = [
            DmMerchantOrder.UNDER_PREPARATION.lower(), DmMerchantOrder.EN_ROUTE.lower(),
            DmMerchantOrder.EDITED.lower(), DmMerchantOrder.PENDING.lower(), DmMerchantOrder.QUEUE.lower(),
            DmMerchantOrder.ACCEPTED.lower()
        ]
        monthly_orders = []
        if orders:
            for order in orders:
                # convert is_take_away_order param in boolean for android.
                order = order._asdict()
                order['is_take_away_order'] = bool(order.get('is_take_away_order' or False))
            orders = ApiModulesOrderServices().get_multi_order_status(delivery_orders=orders, history_orders=True)
            re_order_orders_count = 0
            for order in orders:
                order['reorder_button_title'] = self.VIEW_ORDER_TITLE
                if order['outlet_lat'] is None or order['outlet_lng'] is None:
                    order.pop('outlet_lat')
                    order.pop('outlet_lng')
                if (
                    order.get('order_status').lower() not in self.order_status_list or
                    order.get('order_status_title').lower() not in self.order_status_list
                ) and re_order_orders_count < self.RE_ORDER_SIZE:
                    re_order_orders_count += 1
                    order['show_reorder_button'] = 1
                    order['reorder_button_title'] = self.RE_ORDER_TITLE
                if not process_monthly:
                    order['order_status_color'] = order['status_color']
                    ApiModulesOrderServices().get_formated_monthly_order(order)
            if process_monthly:
                index = orders[0].get('date').month
                month_data = dict()
                month_orders = []
                for month_order in orders:
                    month_order['order_status_color'] = month_order['status_color']
                    month_order['status'] = month_order['order_status']
                    if month_order.get('order_status_title', '').lower() == DmMerchantOrder.QUEUE:
                        month_order['order_status_title'] = DmMerchantOrder.PENDING
                    if index == month_order.get('date').month:
                        _month_order = copy.deepcopy(month_order)
                        _month_order = ApiModulesOrderServices().get_formated_monthly_order(_month_order)
                        month_orders.append(_month_order)
                    else:
                        month_data = ApiModulesOrderServices().set_all_monthly_order_data(
                            month_data, index, month_orders
                        )
                        monthly_orders.append(copy.deepcopy(month_data))
                        index = month_order.get('date').month
                        month_data.clear()
                        month_orders.clear()
                        _month_order = copy.deepcopy(month_order)
                        _month_order = ApiModulesOrderServices().get_formated_monthly_order(_month_order)
                        month_orders.append(_month_order)

                if month_orders:
                    month_data = ApiModulesOrderServices().set_all_monthly_order_data(month_data, index, month_orders)
                    monthly_orders.append(month_data)
                total_deliveries = len(orders)
                return total_deliveries, monthly_orders
        return len(orders), orders
