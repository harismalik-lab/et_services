"""
This module contains custom processor for apm logs.
"""
import elasticapm
from elasticapm.base import Client
from elasticapm.conf import constants
from elasticapm.conf.constants import SPAN
from elasticapm.contrib.flask import ElasticAPM
from elasticapm.contrib.flask.utils import get_data_from_response
from elasticapm.processors import for_events
from elasticapm.utils import build_name_with_http_method_prefix, compat, get_url_dict, is_master_process
from elasticapm.utils.wsgi import get_environ, get_headers
from flask import request
from werkzeug.exceptions import ClientDisconnected


@for_events(SPAN)
def apm_cutom_span_filter_processor(client, event):
    """
    This custom processor sanitizes spans in all frames and keeps only custom spans.

    :param client: an ElasticAPM client
    :param event: a transaction or error event
    :return: The modified event
    """
    if 'context' in event and 'tags' in event['context'] and 'type' in event['context']['tags']:
        if event['context']['tags']['type'] == 'company':
            return event
    return {}


def queue(self, event_type, data, flush=False):
    if self.config.disable_send:
        return
    # Run the data through processors
    for processor in self.processors:
        if not hasattr(processor, "event_types") or event_type in processor.event_types:
            data = processor(self, data)
    if data:
        if flush and is_master_process():
            # don't flush in uWSGI master process to avoid ending up in an unpredictable threading state
            flush = False
        self._transport.queue(event_type, data, flush)


def get_data_from_request(request, capture_body=False, capture_headers=True):
    """
    We are overriding the get_data_from_request method of module elasticapm.contrib.flask.utils. As we have dict in
    request.form and this method expects it to be a multidict so we override it according to our needs.
    """
    result = {
        "env": dict(get_environ(request.environ)),
        "method": request.method,
        "socket": {"remote_address": request.environ.get("REMOTE_ADDR"), "encrypted": request.is_secure},
        "cookies": request.cookies,
    }
    if capture_headers:
        result["headers"] = dict(get_headers(request.environ))
    if request.method in constants.HTTP_WITH_BODY:
        body = {}
        if request.content_type == "application/x-www-form-urlencoded":
            if not isinstance(request.form, dict):
                body = compat.multidict_to_dict(request.form)
        elif request.content_type and request.content_type.startswith("multipart/form-data"):
            if not isinstance(request.form, dict):
                body = compat.multidict_to_dict(request.form)
            if request.files:
                body["_files"] = {
                    field: val[0].filename if len(val) == 1 else [f.filename for f in val]
                    for field, val in compat.iterlists(request.files)
                }
        else:
            try:
                body = request.get_data(as_text=True)
            except ClientDisconnected:
                pass

        if body is not None:
            result["body"] = body if capture_body else "[REDACTED]"

    result["url"] = get_url_dict(request.url)
    return result


def handle_exception(self, *args, **kwargs):
    if not self.client:
        return

    if self.app.debug and not self.client.config.debug:
        return

    self.client.capture_exception(
        exc_info=kwargs.get("exc_info"),
        context={
            "request": get_data_from_request(
                request,
                capture_body=self.client.config.capture_body in ("errors", "all"),
                capture_headers=self.client.config.capture_headers,
            )
        },
        custom={"app": self.app},
        handled=False,
    )


def request_finished(self, app, response):
    if not self.app.debug or self.client.config.debug:
        rule = request.url_rule.rule if request.url_rule is not None else ""
        rule = build_name_with_http_method_prefix(rule, request)
        elasticapm.set_context(
            lambda: get_data_from_request(
                request,
                capture_body=self.client.config.capture_body in ("transactions", "all"),
                capture_headers=self.client.config.capture_headers,
            ),
            "request",
        )
        elasticapm.set_context(
            lambda: get_data_from_response(response, capture_headers=self.client.config.capture_headers), "response"
        )
        if response.status_code:
            result = "HTTP {}xx".format(response.status_code // 100)
        else:
            result = response.status
        elasticapm.set_transaction_name(rule, override=False)
        elasticapm.set_transaction_result(result, override=False)
        # Instead of calling end_transaction here, we defer the call until the response is closed.
        # This ensures that we capture things that happen until the WSGI server closes the response.
        response.call_on_close(self.client.end_transaction)


# Patching ElasticAPM class methods so that they use our method of get_data_from_request
ElasticAPM.request_finished = request_finished
ElasticAPM.handle_exception = handle_exception
# Patching ElasticAPM class method so that we can filter spans
Client.queue = queue
