"""
This module contains app environment specific attributes
"""
import os

from app_configurations.settings import LOCAL, mongo_db_uri, secret_key_default


class Config(object):

    SECRET_KEY = secret_key_default
    DEBUG = False
    TESTING = False
    BASE_DIR_PATH = os.path.dirname(__file__)
    MONGODB_SETTINGS = {'host': mongo_db_uri}
    MONGODB_CONNECT = False
    LOGS_PATH = 'logs'
    GENERATE_ALL_APM_LOGS = False
    GENERATE_APM_ERROR_LOGS = False
    HWW_CACHE_DEFAULT_TIMEOUT = 600  # 10 minutes
    CACHE_TYPE = 'simple'
    ELASTIC_APM = {
        'SERVICE_NAME': 'Entertainer',
        'SECRET_TOKEN': '',
        'SERVER_URL': '',
        'AUTO_LOG_STACKS': False,
        'SERVER_TIMEOUT': 1,
        'PROCESSORS': (
            'common.flask_elastic_apm.apm_jinja_span_filter_processor',
            'common.flask_elastic_apm.apm_status_code_processor',
            'elasticapm.processors.sanitize_stacktrace_locals',
            'elasticapm.processors.sanitize_http_request_cookies',
            'elasticapm.processors.sanitize_http_headers',
            'elasticapm.processors.sanitize_http_wsgi_env',
            'elasticapm.processors.sanitize_http_request_querystring',
            'elasticapm.processors.sanitize_http_request_body'
        )
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    ELASTIC_SEARCH_BASE_URL = 'http://localhost:9222/'
    ELASTIC_SEARCH_URL = "http://fuzzy.theentertainerme.com:9222/entertainer_en/data_en/_search"
    ELASTIC_SEARCH_IS_ON = True
    ELASTIC_SEARCH_MIN_STRING_LENGTH_FOR_SEARCH = 3
    ELASTIC_SEARCH_MAX_SEC_FOR_TIMEOUT = 3
    AWS_SECRET_ACCESS_KEY = 'DB1U0tyQnBp56XXMKwsRefr/llCAprz9SW4JMHFR'
    AWS_ACCESS_KEY_ID = 'AKIA5KDCXYVLAS4ORGHY'
    PASSWORD_RESET_URL = "https://entqacart.etenvbiz.com/resetpassword?token="
    # SQLALCHEMY_POOL_RECYCLE = 60  # TODO: Just added for testing purpose
    CONFIG_SERVICE_AFFIX = 'api_ets'
    ENT_SERVICE_AFFIX = 'api_ets'
    MERCHANT_SERVICE_AFFIX = 'api_ets'
    OUTLET_SERVICE_AFFIX = 'api_ets'
    REDEMPTION_SERVICE_AFFIX = 'api_ets'
    USER_SERVICE_AFFIX = 'api_ets'
    ALIVE = True
    GENERATE_NEW_RELIC_ERROR_LOGS = True


class LocalConfig(Config):
    DEBUG = True
    ENV = LOCAL
    SQLALCHEMY_DATABASE_URI = 'mysql://root:adminpass@localhost:3306'


class DevelopmentConfig(Config):
    DEBUG = True
    ENV = 'DEV'
    NEW_CART_URL = "https://dventawsm.etenvbiz.com/products2019?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa
    CACHE_KEY_PREFIX = 'DEV'
    CACHE_TYPE = 'filesystem'
    CACHE_DIR = '{present_directory}/.entertainer_cache'.format(present_directory=os.getcwd())
    ELASTIC_SEARCH_IS_ON = False
    ELASTIC_SEARCH_BASE_URL = 'http://134.213.40.131:9222/'
    SQL_USER = 'ent_has_sam_mni'
    SQL_PWD = 'GAlHaG49ZVRFbyaU'
    SQL_HOST = '10.3.11.122'
    SQL_PORT = '6033'
    SQL_HOST_WRITE = 'te-dev-rds-pro-cluster.cluster-cx9bkl0httv4.eu-west-1.rds.amazonaws.com'
    SQL_PORT_WRITE = '3306'
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://dummy:dummy@127.0.0.1:9999'
    SQLALCHEMY_BINDS = {
        'master': 'mysql+mysqlconnector://edv_mret_api:YCB4sfRTSRhoQMQbTDDY@te-dev-rds-pro-cluster.cluster-cx9bkl0httv4.eu-west-1.rds.amazonaws.com:3306',  # noqa
        'slave': 'mysql+mysqlconnector://edv_mret_api:YCB4sfRTSRhoQMQbTDDY@te-dev-rds-pro-cluster.cluster-ro-cx9bkl0httv4.eu-west-1.rds.amazonaws.com:3306',  # noqa
    }
    MONGODB_SETTINGS = {
        'host': '10.4.11.7',
        'port': 22222,
        'db': 'prio_tickets_hub',
        'username': 'apiuatusr',
        'password': 'SJFDewyfqwuyIEYEWOWOD',
        'connect': False
    }
    PRIO_API_CREDENTIALS = {
        'user': 'demo-distributor@prioticket.com',
        'password': 'NpEZ&x4QBQV6#L&v',
        'env': 'sandbox-distributor-api',
        'version': '3.2',
        'distributor': 501
    }
