"""
Contains API Specific Modules
"""

from user_service.common.models.chb_lookup import ChbLookup
from user_service.common.models.wl_company import WlCompany


def get_key_prefix_by_company(company):
    company = company.lower()
    prefix = 'te'
    prefixes = {
        WlCompany.COMPANY_CODE_ENTERTAINER_GEMS: 'ge',
        WlCompany.COMPANY_CODE_ENTERTAINER_CRG: 'ce',
        WlCompany.COMPANY_CODE_ENTERTAINER_NAAMA: 'nm',
        WlCompany.COMPANY_CODE_ENTERTAINER_EMAX: 'em',
        WlCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS: 'de',
        WlCompany.COMPANY_CODE_DHL: 'dh',
        WlCompany.COMPANY_CODE_UAEEX_ENTERTAINER: 'UE',
        WlCompany.COMPANY_CODE_MEETHAQ: 'ms'
    }

    if prefixes.get(company):
        prefix = prefixes[company]

    return prefix


def get_look_up_data(company, is_parent_base_company, parent_id, email):
    look_up_table = {
        WlCompany.COMPANY_CODE_CHALHOUB: ChbLookup,
    }
    if look_up_table.get(company):
        if is_parent_base_company:
            return look_up_table.get(company).get_one_by_parent_id(parent_id=parent_id)
        else:
            return look_up_table.get(company).get_one_by_email(email=email)
    return None
