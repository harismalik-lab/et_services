"""
Contains API Specific Modules
"""
import datetime
from math import floor

import boto3
from flask import current_app
from requests import codes

from user_service.common.models.user_saving import UserSaving
from user_service.common.models.wl_company import WlCompany
from user_service.common.models.wl_invoice_header import WlInvoiceHeader
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import generate_unique_id, get_user_group_based_on_spend
from user_service.common.utils.security import Security
from user_service.modules.constants import (
    MEMBERSHIP_CODE_DEFAULT_CARD_NUMBER, MEMBERSHIP_CODE_DEFAULT_LOCATION, MEMBERSHIP_CODE_PREFIX
)


class AwsS3Manager(object):
    ACL_PRIVATE = 'private'
    ACL_PUBLIC_READ = 'public-read'
    ACL_PUBLIC_READ_WRITE = 'public-read-write'
    ACL_AUTHENTICATED_READ = 'authenticated-read'
    STORAGE_CLASS_STANDARD = 'STANDARD'
    STORAGE_CLASS_RRS = 'REDUCED_REDUNDANCY'
    STORAGE_CLASS_STANDARD_IA = 'STANDARD_IA'
    FILE_MAXIMUM_ALLOWED_SIZE = 2097152
    RESPONSE_CODE_SUCCESS = 200
    RESPONSE_CODE_BAD_REQUEST = 400
    ENDPOINT = 's3.amazonaws.com'
    BUCKET = 'entertainer-profile-images'
    URLS = {
        'http': 'http://s3-us-west-2.amazonaws.com/bucket',
        'https': 'https://s3-us-west-2.amazonaws.com/bucket'
    }
    HEADERS = {
        'Cache-Control': 'max-age=2592000',
        'Expires': 2592000
    }
    S3 = boto3.resource('s3')
    allowed_types = [
        'image/jpeg',
        'image/jpg',
        'image/gif',
        'image/png',
        'image/*'
    ]

    def _put_object(self, file, image_name):
        """
        Puts the object in the bucket
        :param file:
        :param image_name:
        :param data:
        :param urls:
        :param headers:
        :return:
        """
        response = {
            'code': self.RESPONSE_CODE_BAD_REQUEST,
            'error': True,
            'message': 'Something went wrong!',
            'url': ''
        }
        if file.content_type not in self.allowed_types:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'Invalid file type. Only JPG, GIF and PNG types are accepted.',
                'url': ''
            }
            return response
        blob = file.read()
        if len(blob) > self.FILE_MAXIMUM_ALLOWED_SIZE or not blob:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'File too large. File must be less than 2 megabytes.',
                'url': ''
            }
            return response
        try:
            client = boto3.client(
                's3',
                aws_secret_access_key=current_app.config['AWS_SECRET_ACCESS_KEY'],
                aws_access_key_id=current_app.config['AWS_ACCESS_KEY_ID']
            )
            upload_response = client.put_object(
                Bucket=self.BUCKET,
                Key=image_name,
                Body=blob,
                ACL=self.ACL_PUBLIC_READ,
                StorageClass=self.STORAGE_CLASS_STANDARD,
            )
            if upload_response and isinstance(upload_response, dict):
                status = upload_response.get('ResponseMetadata', {}).get('HTTPStatusCode', 400)
                if status == codes.OK:
                    response = {
                        'code': self.RESPONSE_CODE_SUCCESS,
                        'error': False,
                        'message': '',
                        'url': 'https://entertainer-profile-images.s3.amazonaws.com/{}'.format(image_name)
                    }
        except Exception:
            pass
        return response


def upload_profile_image(user_file, user_id):
    """
    Upload user profile image
    :param str user_file: location for profile image file
    :param int user_id: user id
    :rtype dict
    """
    response_message = {}
    if user_file and user_id:
        response_message['code'] = AwsS3Manager.RESPONSE_CODE_BAD_REQUEST
        try:
            ext = user_file.filename.split(".")
            image_name = "{user_id}_{md5}.{digit}".format(
                user_id=user_id,
                md5=Security.generate_random_string(),
                digit=ext[-1]
            )
            response_message = AwsS3Manager()._put_object(
                file=user_file,
                image_name=image_name,
            )
        except:
            pass
    return response_message


def generate_member_code(country, user_id):
    """
    Generates Membership code
    :param str country:  Country
    :param int user_id:  User id
    :rtype str
    """
    year = datetime.datetime.now().year
    location_code = country
    if not location_code:
        location_code = MEMBERSHIP_CODE_DEFAULT_LOCATION
    user_id = str(user_id)
    user_id = user_id.rjust(8, '0')
    membership_code = "{membership_code}{year}{location_code}{user_id}{card_number}".format(
        membership_code=MEMBERSHIP_CODE_PREFIX,
        year=year,
        location_code=location_code,
        user_id=user_id,
        card_number=MEMBERSHIP_CODE_DEFAULT_CARD_NUMBER
    )
    return membership_code


def add_invoice_to_user(invoice, user_savings, company, user_id, email, number_of_valid_keys):
    """
    Add invoice to user
    :param int number_of_valid_keys: Number of valid keys
    :param UserSaving user_savings: User Saving object
    :param WlInvoiceHeader invoice: invoice object
    :param str company: company
    :param int user_id: id of user
    :param str email: email
    :rtype: bool
    """
    is_user_upgraded = False
    if invoice:
        invoice.user_id = user_id
        create = False
        # add invoice savings to users_savings table
        if not user_savings:
            user_savings = UserSaving(company=company, user_id=user_id, user_rank=1, total_points=0)
            create = True
        try:
            savings = int(invoice.transaction_total_price or 0)
        except Exception:
            raise TypeError('savings invalid type')
        # commented as now web team setup a cron which is syncing savings from points source after 30 days
        if user_savings.total_points:
            user_savings.total_points += savings
        else:
            user_savings.total_points = savings
        user_savings.total_points = user_savings.total_points + savings
        if create:
            user_savings.insert_record()
        else:
            user_savings.update_record()
        emax_user_group = WlInvoiceHeader.get_highest_emax_user_group(user_id, company)
        user_group = get_user_group_based_on_spend(emax_user_group, user_savings.total_points)
        is_user_upgraded = assign_user_group_and_vip_key(user_id, email, company, user_group, number_of_valid_keys)
    return is_user_upgraded


def assign_user_group_and_vip_key(user_id, email, company, user_group, number_of_valid_keys):
    """
    Assign user group and vip key
    :param int number_of_valid_keys: Number of valid keys
    :param int user_id: Id of the user
    :param str email: email
    :param str company: company
    :param int user_group: user group
    """
    is_user_upgraded = False
    if number_of_valid_keys < 1:
        prefix = WlCompany.get_key_prefix_by_company(company)
        wl_key = generate_unique_id(prefix, 7)
        wl_validation = Wlvalidation(
            wl_key=wl_key,
            wl_company=company,
            email=email,
            isused=True,
            activation_date=datetime.datetime.utcnow,
            active=True,
            user_group=user_group,
            existing=True,
            customer_id=user_id
        )
        wl_validation.insert_record()
    else:
        wl_validation = Wlvalidation.get_active_by_company_and_email(company, email)
        if user_group > wl_validation.user_group:
            is_user_upgraded = True
        # TODO: Check with Tahir what's the purpose of this
        wl_validation.user_group = user_group
    return is_user_upgraded


def calculate_months_and_years(days_since_registration):
    """
    calculates user's months and years since registration
    :param int days_since_registration: days
    :return: months and years converted from days
    """
    months = floor(days_since_registration) / 30
    years = floor(days_since_registration) / 365
    if months >= 1:
        months = months
    else:
        months = 1
    if years >= 1:
        years = years
    else:
        years = 1
    return months, years


def calculate_aging(days):
    """
    calculates user membership since registration
    :param int days:
    :return: days, months, years accordingly
    """
    if days < 30:
        if days > 1:
            return '{} Days'.format(days)
        else:
            return '1 Day'
    else:
        months = floor(days / 30)
        remaining_days = days % 30
    if months < 12:
        if remaining_days >= 15:
            return str(months) + '.5 Months'
        else:
            if months > 1:
                return str(months) + ' Months'
            else:
                return str(months) + ' Month'
    else:
        years = floor(months / 12)
        remaining_months = months % 12
        if remaining_months >= 6:
            return str(years) + '.5 Years'
        else:
            if years > 1:
                return str(years) + ' Years'
            else:
                return str(years) + ' Year'
