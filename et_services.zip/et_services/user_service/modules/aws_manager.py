"""
AWS S3 Manager class
    - upload image to s3 bucket
"""
import boto3

from flask import current_app
from requests import codes


class AwsS3Manager(object):
    ACL_PRIVATE = 'private'
    ACL_PUBLIC_READ = 'public-read'
    ACL_PUBLIC_READ_WRITE = 'public-read-write'
    ACL_AUTHENTICATED_READ = 'authenticated-read'
    STORAGE_CLASS_STANDARD = 'STANDARD'
    STORAGE_CLASS_RRS = 'REDUCED_REDUNDANCY'
    STORAGE_CLASS_STANDARD_IA = 'STANDARD_IA'
    FILE_MAXIMUM_ALLOWED_SIZE = 2097152
    RESPONSE_CODE_SUCCESS = 200
    RESPONSE_CODE_BAD_REQUEST = 400
    ENDPOINT = 's3.amazonaws.com'
    BUCKET = 'entertainer-profile-images'
    URLS = {
        'http': 'http://s3-us-west-2.amazonaws.com/bucket',
        'https': 'https://s3-us-west-2.amazonaws.com/bucket'
    }
    HEADERS = {
        'Cache-Control': 'max-age=2592000',
        'Expires': 2592000
    }
    S3 = boto3.resource('s3')
    allowed_types = [
        'image/jpeg',
        'image/jpg',
        'image/gif',
        'image/png',
        'image/*'
    ]

    def _put_object(self, file, image_name):
        """
        Puts the object in the bucket
        :param file:
        :param image_name:
        :return response:
        """
        response = {
            'code': self.RESPONSE_CODE_BAD_REQUEST,
            'error': True,
            'message': 'Something went wrong!',
            'url': ''
        }
        if file.content_type not in self.allowed_types:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'Invalid file type. Only JPG, GIF and PNG types are accepted.',
                'url': ''
            }
            return response
        blob = file.read()
        if len(blob) > self.FILE_MAXIMUM_ALLOWED_SIZE or not blob:
            response = {
                'code': self.RESPONSE_CODE_BAD_REQUEST,
                'error': True,
                'message': 'File too large. File must be less than 2 megabytes.',
                'url': ''
            }
            return response
        try:
            client = boto3.client(
                's3',
                aws_secret_access_key=current_app.config['AWS_SECRET_ACCESS_KEY'],
                aws_access_key_id=current_app.config['AWS_ACCESS_KEY_ID']
            )
            upload_response = client.put_object(
                Bucket=self.BUCKET,
                Key=image_name,
                Body=blob,
                ACL=self.ACL_PUBLIC_READ,
                StorageClass=self.STORAGE_CLASS_STANDARD,
            )
            if upload_response and isinstance(upload_response, dict):
                status = upload_response.get('ResponseMetadata', {}).get('HTTPStatusCode', 400)
                if status == codes.OK:
                    response = {
                        'code': self.RESPONSE_CODE_SUCCESS,
                        'error': False,
                        'message': '',
                        'url': 'https://entertainer-profile-images.s3.amazonaws.com/{}'.format(image_name)
                    }
        except Exception:
            pass
        return response


aws_manager = AwsS3Manager()
