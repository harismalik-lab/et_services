from user_service.common.models.wl_company import WlCompany

MEMBERSHIP_CODE_PREFIX = 'M'
MEMBERSHIP_CODE_DEFAULT_CARD_NUMBER = 1
MEMBERSHIP_CODE_DEFAULT_LOCATION = "XX"

CURRENCIES_AGAINST_COMPANIES = {

    WlCompany.company_code_ENTERTAINER_VDF: {
        'currency': "QAR",
        'default_currency': 45
    },
    WlCompany.COMPANY_CODE_ENTERTAINER_MTN: {
        'currency': "EUR",
        'default_currency': 34
    },

    WlCompany.COMPANY_CODE_ENTERTAINER_QGIRCO: {
        'currency': "QAR",
        'default_currency': 42},

    WlCompany.COMPANY_CODE_ENTERTAINER_HUT: {
        'currency': "HKD",
        'default_currency': 36,
        'receive_email': 1},

    WlCompany.COMPANY_CODE_ALBILAD: {
        'currency': "SAR",
        'default_currency': 43},
    WlCompany.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER: {
        'currency': "SGD",
        'default_currency': 44},

    WlCompany.COMPANY_CODE_AAG: {
        'currency': "SGD",
        'default_currency': 44},

    WlCompany.COMPANY_CODE_ENTERTAINER_NAAMA: {
        'currency': "OMR",
        'default_currency': 41},

    WlCompany.COMPANY_CODE_ENTERTAINER_EMAX: {
        'currency': "AED",
        'default_currency': 31},

    WlCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS: {
        'currency': "AED",
        'default_currency': 31},

    WlCompany.company_code_SOLIDATIRy: {
        'currency': "BHD",
        'default_currency': 32,
        'country_of_residence': "BH"},
    WlCompany.COMPANY_CODE_ENTERTAINER_GEMS: {
        'currency': "AED",
        'default_currency': 31},

    WlCompany.COMPANY_CODE_DU: {
        'currency': "AED",
        'default_currency': 31}
}

LOG_PATH = 'user_service/'

CUSTOM_NO_VALID_USER_CODE = 55

PASSWORD_RESET_SUCCESS_MESSAGE = "Password reset link sent to your email address."
EMAIL_NOT_FOUND = 'Email address not found.'

INVALID_TOKEN_MESSAGE = "You have provided an invalid reset_token"
EXPIRED_TOKEN_MESSAGE = "Your reset token has been expired."
INVALID_RESET_TOKEN_ERROR_CODE = 40
