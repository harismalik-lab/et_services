"""
This module contains V3 routing for user service
"""
from user_service.app.api.v3.get_user_profile import GetUserProfileApiV3
from user_service.app.api.v3.password_reset import UserPasswordResetApiV3
from user_service.app.routings.routings_v2 import UserAPIV2


class UserAPIV3(UserAPIV2):
    api_version = '3'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['get-user-profile'] = {
            'url': '/user/profile',
            'view': GetUserProfileApiV3
        }
        self.routing_collection['password-reset'] = {
            'url': '/user/password/reset',
            'view': UserPasswordResetApiV3
        }
