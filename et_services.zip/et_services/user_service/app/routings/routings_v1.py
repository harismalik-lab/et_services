"""
This module contains routing for an app
"""
from flask import current_app

from user_service.app.api.v1.login import LoginApi
from user_service.app.api.v1.signup import SignupApi
from user_service.app.api.v1.get_user_profile import GetUserProfileApi
from user_service.app.api.v1.update_user_profile import UpdateUserProfileApi
from user_service.app.api.v1.password_reset import UserPasswordResetApi
from user_service.app.api.v1.upload_profile_image import UploadProfileImageApi
from user_service.app.api.v1.user_passowrd_token import UserPasswordTokenApi
from user_service.app.api.v1.logout import LogoutApi
from user_service.app.api.v1.validates import ValidatesApi
from user_service.common.base_routing import BaseRouting


class UserAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['USER_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['login'] = {
            'url': '/user/login',
            'view': LoginApi
        }
        self.routing_collection['signup'] = {
            'url': '/user/signup',
            'view': SignupApi
        }
        self.routing_collection['get-user-profile'] = {
            'url': '/user/profile',
            'view': GetUserProfileApi
        }
        self.routing_collection['update-user-profile'] = {
            'url': '/user/profile',
            'view': UpdateUserProfileApi
        }
        self.routing_collection['password-reset'] = {
            'url': '/user/password/reset',
            'view': UserPasswordResetApi
        }
        self.routing_collection['user-password-token'] = {
            'url': '/user/password/token',
            'view': UserPasswordTokenApi
        }
        self.routing_collection['validates'] = {
            'url': '/user/validates',
            'view': ValidatesApi
        }
        self.routing_collection['logout'] = {
            'url': '/user/logout',
            'view': LogoutApi
        }
        self.routing_collection['user-profile-image'] = {
            'url': '/user/profile/image',
            'view': UploadProfileImageApi
        }
