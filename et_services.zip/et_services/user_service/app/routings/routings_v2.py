"""
This module contains V2 routing for user service
"""
from user_service.app.api.v2.send_email import SendEmail
from user_service.app.api.v2.signup import SignupApiV2
from user_service.app.routings.routings_v1 import UserAPIV1


class UserAPIV2(UserAPIV1):
    api_version = '2'

    def set_routing_collection(self):
        super().set_routing_collection()

        self.routing_collection['signup'] = {'view': SignupApiV2, 'url': '/user/signup'}
        self.routing_collection['send-email'] = {'view': SendEmail, 'url': '/email/send'}
