"""
This modules loads APIs for a specific service
"""
from flask import g

from user_service.app.routings.routings_v1 import UserAPIV1
from user_service.app.routings.routings_v2 import UserAPIV2
from user_service.app.routings.routings_v3 import UserAPIV3


def api_urls():
    UserAPIV1(app=g.app, name=UserAPIV1.__name__).map_urls()
    UserAPIV2(app=g.app, name=UserAPIV2.__name__).map_urls()
    UserAPIV3(app=g.app, name=UserAPIV3.__name__).map_urls()
