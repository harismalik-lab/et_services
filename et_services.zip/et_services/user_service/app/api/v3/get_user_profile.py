"""
Get User Profile api
    - Get user id from get_customer() method
    - Get user profile using customer id
    - Convert orm obj into dict and process customer_profile attrs
    - Get user owned(purchased) products
    - Get user savings
    - Process user info
        - calculate months and years since registration
        - process/calculate redemption_count
        - process/calculate user's savings
    If family feature is on and user have a pending invite then send primary_member_invite section in response
"""
from flask import current_app

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.get_user_profile import GetUserProfileApi
from user_service.common.constants import ENT_COMPANY_TYPE
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.ent_customer_profile import EntCustomerProfile
from user_service.common.models.family_member import FamilyMember
from user_service.common.utils.api_utils import get_api_configurations
from user_service.common.utils.authentication import token_decorator_v3


class GetUserProfileApiV3(GetUserProfileApi):
    """
    @api {GET} /v3/user/profile | Get User Profile

    @apiVersion 1.0.0
    @apiName user/profile
    @apiGroup UserService
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    @apiParam {String}                              [currency]          Currency
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='get_user_profile_api/get_user_profile_api_v3.log',
        ),
        'name': 'get_user_profile_api_v3'
    }

    validators = [token_decorator_v3]

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        super().initialize_local_veriables()
        self.owned_products = []

    def get_company_configs(self):
        """
        get company specific configs
        """
        self.configs = get_api_configurations(company=self.company, environment=current_app.config['ENV'].lower())
        self.is_ent = self.configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE

    def process_user_family_data(self):
        """
        User family data process
        """
        self.user_profile["primary_member_invite"] = None
        if self.configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE) and not self.customer.get('is_user_in_family'):
            invites = FamilyMember.find_family_member(
                filters={
                    'user_id': self.customer.get('user_id'),
                    'status': FamilyMember.PENDING,
                    'is_active': 1
                }
            )
            if invites:
                primary_user_info = FamilyMember.find_family_member(
                    filters={
                        'family_id': invites.family_id,
                        'is_primary': 1,
                        'is_active': 1
                    }
                )
                primary_user = EntCustomerProfile.load_customer_profile_by_user_id(primary_user_info.user_id)
                if primary_user:
                    primary_user = primary_user.to_dict()
                    if primary_user.get('gender', ''):
                        if primary_user.get('gender', '').lower() == FamilyMember.GENDER_FEMALE:
                            self.user_profile["primary_member_invite"] = {
                                'message': FamilyMember.FAMILY_INVITATION_MESSAGE.format(
                                    email=primary_user.get('email'),
                                    gender=FamilyMember.FEMALE_GENDER_TEXT
                                ),
                                'title': FamilyMember.FAMILY_INVITATION_TITLE.format(
                                    name=primary_user.get('firstname'),
                                    gender=FamilyMember.FEMALE_GENDER_TEXT
                                ),
                                "button_title": FamilyMember.FAMILY_INVITATION_BUTTON_TITLE,
                                "button_color": "ff0000"
                            }
                        else:
                            self.user_profile["primary_member_invite"] = {
                                'message': FamilyMember.FAMILY_INVITATION_MESSAGE.format(
                                    email=primary_user.get('email'),
                                    gender=FamilyMember.MALE_GENDER_TEXT
                                ),
                                'title': FamilyMember.FAMILY_INVITATION_TITLE.format(
                                    name=primary_user.get('firstname'),
                                    gender=FamilyMember.MALE_GENDER_TEXT
                                ),
                                "button_title": FamilyMember.FAMILY_INVITATION_BUTTON_TITLE,
                                "button_color": "ff0000"
                            }
                    else:
                        self.user_profile["primary_member_invite"] = {
                            'message': FamilyMember.FAMILY_INVITATION_MESSAGE.format(
                                email=primary_user.get('email'),
                                gender=FamilyMember.MALE_GENDER_TEXT
                            ),
                            'title': FamilyMember.FAMILY_INVITATION_TITLE.format(
                                name=primary_user.get('firstname'),
                                gender=FamilyMember.MALE_GENDER_TEXT
                            ),
                            "button_title": FamilyMember.FAMILY_INVITATION_BUTTON_TITLE,
                            "button_color": "ff0000"
                        }

    def process_request(self, *args, **kwargs):
        """
        Handles the process of api
        """
        self.initialize_local_veriables()
        self.get_company_configs()
        self.get_user_profile()
        self.get_user_savings()
        self.process_user_profile_dict()
        self.process_user_family_data()
        self.generate_final_response()
