"""
Reset Password API
    - Find active user by email
    - if user found:
        - create a random reset_password_token
        - set reset_password token in user record and update
        - make password reset url with reset_password_token
        - get user group
        - get email template by reset param
        - get email template by company and email_type
        - sets email data
        - create/insert EntSendEmail new record
"""
import datetime

from flask import current_app
from phpserialize import dumps as php_json_dumps

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.password_reset import UserPasswordResetApi
from user_service.app.api.v3.validations.password_reset_validator import user_password_reset_parser_v3
from user_service.common.constants import ENT_COMPANY_TYPE
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.ent_send_email import EntSendEmail
from user_service.common.models.user import User
from user_service.common.models.wl_template import Wltemplate
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import get_api_configurations
from user_service.common.utils.security import security


class UserPasswordResetApiV3(UserPasswordResetApi):
    """
    @api {post} /v3/user/password/reset | Reset Password

    @apiName UserPasswordResetApi
    @apiGroup Users
    @apiParam {String}                                         email         Email of user
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}      [language]    Response language
    """

    request_parser = user_password_reset_parser_v3
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='password_reset_api/password_reset_api_v3.log',
        ),
        'name': 'password_reset_api_v3'
    }

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        super().populate_request_arguments()
        self.reset_password = self.request_args.get('reset_password')

    def get_company_configs(self):
        """
        get company specific configs
        """
        self.configs = get_api_configurations(company=self.company, environment=current_app.config['ENV'].lower())
        self.is_ent = self.configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE

    def create_send_email_to_customer_record(self):
        """
        - generate random password reset token
        - update password reset token for USER
        - construct password rest url for user
        - set email template and insert new EntSendEmail record
        :return:
        """
        if self.customer:
            password_reset_token = security.generate_random_string(length=20)
            User.update_password_reset_token(
                self.customer.id,
                password_reset_token
            )

            password_reset_url = current_app.config.get('PASSWORD_RESET_URL')
            password_reset_url = '{password_reset_url}{password_reset_token}'.format(
                password_reset_url=password_reset_url,
                password_reset_token=password_reset_token
            )

            template = Wltemplate.FORGOT_PASSWORD
            if self.reset_password:
                template = Wltemplate.FRESH_START_FORGOT_PASSWORD
            if not self.is_ent:
                user_group = Wlvalidation.get_user_group(self.company, self.customer.id)
                email_template = Wltemplate.get_template_by_company_and_type(
                    self.company,
                    Wltemplate.FORGOT_PASSWORD,
                    user_group
                )
                if email_template:
                    template = email_template.id
                else:
                    template = None

            email_data = php_json_dumps({
                "user_id": self.customer.id,
                "{PASSWORD_RESET_URL}": password_reset_url
            })

            ent_send_email = EntSendEmail(
                email_template_type_id=template,
                email_template_data=email_data.decode(errors='ignore'),
                email_to=self.email,
                language=self.locale,
                priority=EntSendEmail.PRIORITY_HIGH,
                created_date= datetime.datetime.now(),
                optional_data=php_json_dumps({}).decode(errors="ignore")
            )
            ent_send_email.insert_record()

            self.setting_language_and_message()
            self.generate_response()
        else:
            self.generate_response_on_no_valid_customer()

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.initialize_local_veriables()
        self.get_company_configs()
        self.create_send_email_to_customer_record()
