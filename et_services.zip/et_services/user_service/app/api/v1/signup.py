"""
Signup Api
 - creates a new user with given valid information.
    - check if user already exists or not with given info. if exists then return error response.
    - validates wl_key
 - creates customer profile.
 - Assigns wl_key to the user
 - creates active session record.
 - creates session addendum record
 - Add device
 - Returns response
"""

import datetime
import random
import time
import uuid

from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.signup_validator import sign_up_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.constants import (CUSTOM_DOB_ERROR_CODE,
                                           CUSTOM_ERROR_CODE,
                                           CUSTOM_USER_EXISTS_ERROR_CODE,
                                           USED_UUID_CODE)
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.customer_device import CustomerDevice
from user_service.common.models.ent_customer_profile import EntCustomerProfile
from user_service.common.models.session import Session
from user_service.common.models.session_addendum import SessionAddendum
from user_service.common.models.user import User
from user_service.common.models.wl_product import WlProduct
from user_service.common.models.wl_user_group import WlUserGroup
from user_service.common.models.wl_user_seemless_validation import \
    WlUserSeemlessValidation
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import (get_api_configurations,
                                                 get_locale)
from user_service.common.utils.authentication import get_company
from user_service.common.utils.security import security
from user_service.common.utils.translation_manager import TranslationManager
from user_service.modules.api_modules import generate_member_code
from user_service.modules.constants import CURRENCIES_AGAINST_COMPANIES

__author__ = "azeemu@theentertainerasia.com"


class SignupApi(BasePostResource):
    """
        @api {post} /v1/user/signup | POST | Registers and Create new User

        @apiVersion 1.0.0
        @apiName SignupApi
        @apiGroup user_service

        @apiParam {String="ios","android", "web"}               [platform]                        Mobile Platform
        @apiParam {String}                                      email                             Email address
        @apiParam {String}                                      [affiliate_code]                    affiliate_code
        @apiParam {String}                                      password                          Customer password
        @apiParam {String}                                      confirm_password                  Confirm customer password         # noqa
        @apiParam {String}                                      [device_model]                    Customer device model
        @apiParam {String}                                      [terms_acceptance]                User terms acceptance
        @apiParam {String}                                      [device_key]                      Customer device key
        @apiParam {String}                                      [key]                             SMG provided key
        @apiParam {String}                                      [mobile_phone]                    Mobile phone number
        @apiParam {String}                                      [device_install_token]            Customer device install token     # noqa
        @apiParam {String}                                      [device_uid]                      Device uid
        @apiParam {String}                                      [firstname]                       First name of the user
        @apiParam {String}                                      [lastname]                        Last name of the user
        @apiParam {String}                                      [country_of_residence]            User's country of residence       # noqa
        @apiParam {String}                                      [gender]                          User's gender
        @apiParam {String}                                      [nationality]                     User's nationality
        @apiParam {String}                                      [date_of_birth]                   User's date of birth
        @apiParam {String="en", "ar", "cn", "el", "de", "zh"}   [language]                        Response language
        @apiParam {int}                                         [do_not_email]                    do_not_email
        """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='signup_api/signup_api.log',
        ),
        'name': 'currencies_api'
    }

    request_parser = sign_up_parser
    required_token = False

    def populate_request_arguments(self):
        """
        Populates the request arguments
        """
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.device_os = self.request_args.get('device_os')  # required (device_os)
        self.device_model = self.request_args.get('device_model')
        self.device_install_token = self.request_args.get('device_install_token')  # provided by app
        self.device_id = self.request_args.get('device_uid')  # unique id of the device
        self.nationality = self.request_args.get('nationality')
        self.date_of_birth = self.request_args.get('date_of_birth')
        self.device_key = self.request_args.get('device_key')
        self.affiliate_code = self.request_args.get('affiliate_code')
        self.first_name = self.request_args.get('firstname')
        self.last_name = self.request_args.get('lastname')
        self.country_of_residence = self.request_args.get('country_of_residence')
        self.confirm_password = self.request_args.get('confirm_password')
        self.gender = self.request_args.get('gender')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.wl_key = self.request_args.get('key')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')
        self.messages_locale = get_locale(self.request_args.get('language'))
        self.terms_acceptance = self.request_args.get('terms_acceptance')
        self.do_not_email = self.request_args.get('do_not_email')
        self.uuid = self.request_args.get('unique_login_token')

    def setting_language_and_variables_normal_flow(self):
        """
        Sets the variables for normal flow
        """
        self.company = get_company()
        self.number_of_offers = 0
        self.session_id = 0
        self.user_group = 0
        self.number_of_valid_keys = 0
        self.look_up_data = {}
        self.wl_validation_status = Wlvalidation.INVALID_KEY
        self.is_valid_date_of_birth = True
        self.user_already_exist = False
        self.wl_key_already_validated = False

    def checking_registration_type(self):
        """
        Checks registration type then alters the flow accordingly
        """
        self.api_config = get_api_configurations(self.company, current_app.config['ENV'].lower())
        if self.api_config.get('login_type') == WlUserSeemlessValidation.UUID_LOGIN_TYPE:
            if not self.uuid:
                return self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    "Missing required field 'unique_login_token'.",
                    CUSTOM_ERROR_CODE
                )
            user_seemless_validation = WlUserSeemlessValidation.get_active_by_uuid_and_company(self.uuid, self.company)
            if user_seemless_validation:
                return self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    "A User has already registered with this uuid.",
                    USED_UUID_CODE
                )
            self.email = "{}@com.{}".format(self.uuid, self.company)
            self.password = WlUserSeemlessValidation.STATIC_PASSWORD
            self.confirm_password = WlUserSeemlessValidation.STATIC_PASSWORD

    def return_error_response(self, status_code, message, response_code):
        """
        generate error response and returns
        :param int status_code:
        :param str message:
        :param int response_code:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {
            "message": message,
            "code": response_code,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def check_date_of_birth(self):
        """
        - Checks the date of birth of the user
        - validate if user is eligible for registration on the basis of date of birth
        """
        if self.date_of_birth:
            try:
                self.date_of_birth = parse(self.date_of_birth)

                current_date = datetime.datetime.now()
                date_13_years_back = current_date - relativedelta(years=13)
                minimum_valid_dob = current_date - relativedelta(years=120)

                if self.date_of_birth > current_date or self.date_of_birth < minimum_valid_dob:
                    return self.return_error_response(
                        codes.UNPROCESSABLE_ENTITY,
                        TranslationManager.get_translation(TranslationManager.invalid_dob, self.messages_locale),
                        CUSTOM_DOB_ERROR_CODE
                    )

                if date_13_years_back < self.date_of_birth:
                    return self.return_error_response(
                        codes.UNPROCESSABLE_ENTITY,
                        TranslationManager.get_translation(
                            TranslationManager.dob_minimum_value_error,
                            self.messages_locale
                        ),
                        CUSTOM_DOB_ERROR_CODE
                    )

            except Exception:
                self.is_valid_date_of_birth = False

        if not self.is_valid_date_of_birth:
            self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.dob_minimum_value_error,
                    self.messages_locale
                ),
                CUSTOM_DOB_ERROR_CODE
            )

    def check_email_password(self):
        """
        1 - Checks email and the password of user
        2 - Checks if password and confirm password are same
        """
        if not self.email or not self.password:
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(TranslationManager.email_password_required, self.messages_locale),
                CUSTOM_ERROR_CODE
            )
        if self.confirm_password != self.password:
            self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                "[password] and [confirm_password] did not match.",
                CUSTOM_ERROR_CODE
            )

    def validate_customer_already_exist(self):
        """
        Validates the customer exists in the db or not
        """
        customer_exist = User.active_user_by_email_exists(email=self.email)
        if customer_exist:
            self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(
                    TranslationManager.customer_with_this_email_address_already_exists,
                    self.messages_locale
                ),
                CUSTOM_USER_EXISTS_ERROR_CODE
            )

    def validate_key(self):
        """
        check wl validation status against given wl_key
        """
        if self.api_config.get(ApiConfiguration.KEY_LESS_ACTIVATION):
            wl_validation = Wlvalidation(
                wl_key=uuid.uuid4().hex[0:20],
                wl_company=self.company,
                email=self.email,
                isused=0,
                active=1,
                user_group=WlUserGroup.DEFAULT_USER_GROUP,
                deactivation_date=None,
                existing=1
            )
            wl_validation.insert_record()
            self.wl_key = wl_validation.wl_key
        if self.wl_key:
            self.wl_validation_status = Wlvalidation.validate_key(
                wl_key=self.wl_key,
                company=self.company,
                email=self.email
            )
            if self.wl_validation_status == Wlvalidation.INVALID_KEY:
                self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    TranslationManager.get_translation(TranslationManager.invalid_wl_key, self.messages_locale),
                    CUSTOM_ERROR_CODE
                )
        else:
            self.number_of_valid_keys = Wlvalidation.get_number_of_valid_keys(self.company, self.email)
            if self.number_of_valid_keys < 1:
                self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    TranslationManager.get_translation(
                        TranslationManager.you_are_not_allowed_to_access_this_application,
                        self.messages_locale
                    ),
                    CUSTOM_ERROR_CODE
                )

    def create_new_customer(self):
        """
        Creates the new customer and validates if its created
        """
        self.customer = User(
            auth_key=security.generate_random_key().encode('utf-8'),
            password_hash=security.generate_password_hash(self.password),
            email=self.email,
            username=self.email,
            first_name=self.first_name if self.first_name else None,
            last_name=self.last_name if self.last_name else None
        )
        self.customer.insert_record()

    def create_customer_profile(self):
        """
        creates customer profile and validates if its created
        """
        self.ent_customer_profile = EntCustomerProfile(
            user_id=self.customer.id,
            email=self.email,
            new_member_group=EntCustomerProfile.MEMBERSTATUS_PROSPECT,
            default_currency=EntCustomerProfile.CURRENCY_ID,
            currency=EntCustomerProfile.CURRENCY,
            member_group=EntCustomerProfile.TRIAL,
            membership_code=generate_member_code(self.country_of_residence, self.customer.id),
            onboarding_status=EntCustomerProfile.ONBOARDING_FINISHED,
            accepted_terms=self.terms_acceptance,
            receive_email=self.do_not_email
        )
        if self.first_name:
            self.ent_customer_profile.firstname = self.first_name
        if self.last_name:
            self.ent_customer_profile.lastname = self.last_name
        if self.gender:
            self.ent_customer_profile.gender = self.gender
        if self.mobile_phone:
            self.ent_customer_profile.mobile_phone = self.mobile_phone
        if self.nationality:
            self.ent_customer_profile.nationality = self.nationality
        if self.affiliate_code:
            self.ent_customer_profile.affiliate_code = self.affiliate_code
        if self.country_of_residence:
            self.ent_customer_profile.country_of_residence = self.country_of_residence
        currency_conf = CURRENCIES_AGAINST_COMPANIES.get(self.company)

        if currency_conf:
            self.ent_customer_profile.currency = currency_conf.get('currency')
            self.ent_customer_profile.default_currency = currency_conf.get('default_currency')
            if currency_conf.get('receive_email'):
                self.ent_customer_profile.receive_email = currency_conf.get('receive_email')
            if currency_conf.get('country_of_residence'):
                self.ent_customer_profile.country_of_residence = currency_conf['country_of_residence']
        # TODO: Verify
        if self.date_of_birth:
            self.ent_customer_profile.birthdate = self.date_of_birth
        self.ent_customer_profile.insert_record()

    def assign_key_to_customer(self):
        """
        assign wl key to customer
        """
        if self.wl_validation_status == Wlvalidation.UNUSED_VALID_KEY:
            Wlvalidation.assign_key_to_customer(
                wl_key=self.wl_key,
                company=self.company,
                email=self.email,
                is_customer_exists=True,
                customer_id=self.customer.id
            )

    def update_wl_validation(self):
        """
        Updates wl_validation entries for unregistered emails
        """
        if self.number_of_valid_keys:
            Wlvalidation.update_customer_validation(
                self.company,
                self.email,
                self.customer.id
            )

    def set_user_group(self):
        """
        Sets User group
        """
        self.user_groups = Wlvalidation.get_user_groups(self.company, self.customer.id)
        if not self.user_groups:
            self.user_groups = [WlUserGroup.DEFAULT_USER_GROUP]

    def make_seemless_validation_entry(self):
        """
        Inserts data into WlUserSeemlessValidation Table.
        """
        if self.api_config.get('login_type') == WlUserSeemlessValidation.UUID_LOGIN_TYPE:
            seemless_validation = WlUserSeemlessValidation(
                company=self.company,
                email=self.email,
                user_id=self.ent_customer_profile.user_id,
                user_group=self.user_groups[-1],
                uuid=self.uuid,
                status=WlUserSeemlessValidation.ACTIVE
            )
            seemless_validation.insert_record()

    def create_session(self):
        """
        1 - get user groups
        2 - get production ids
        3 - create session record
        """
        self.product_ids = WlProduct.get_configured_product_ids(self.company, self.user_groups)
        self.session = Session(
            session_token=str(uuid.uuid4()),
            customer_id=self.customer.id,
            product_ids=','.join(map(str, self.product_ids)),
            company=self.company,
            isagreed=True,
            date_cached=int(time.time()),
            date_agreed=datetime.datetime.now()
        )
        self.session.insert_record()

    def create_session_addendum(self):
        """
        create session addendum record
        """
        self.session_token = self.session.session_token
        self.session_id = self.session.id

        session_addendum = SessionAddendum(
            session_id=self.session_id,
            user_id=self.customer.id,
            device_key=self.device_key,
            device_os=self.device_os,
            device_model=self.device_model,
            device_language=self.messages_locale,
            lat=self.lat,
            lng=self.lng,
            company=self.company
        )
        session_addendum.insert_record()

    def add_new_device(self):
        """
        Adds new device
        """
        if self.device_key:
            self.device_id = self.device_key

        customer_device = CustomerDevice(
            customer_id=self.customer.id,
            device_install_token=self.device_install_token,
            device_model=self.device_model,
            session_id=self.session_id,
            primary_device=True,
            device_id=self.device_id
        )
        customer_device.insert_record()

    def generating_final_response(self):
        """
        Generating the final response in normal flow case.
        """
        is_demographics_updated = bool(
            self.ent_customer_profile.gender and
            self.ent_customer_profile.nationality and
            self.ent_customer_profile.birthdate
        )
        self.status_code = codes.OK
        self.send_response_flag = True
        data = {
            'user_id': self.ent_customer_profile.user_id,
            'currency': self.ent_customer_profile.currency,
            'session_token': self.session_token,
            'device_uid': self.device_id,
            'device_os': self.device_os,
            'device_model': self.device_model,
            'is_demographics_updated': is_demographics_updated,
            'user_group': WlUserGroup.DEFAULT_USER_GROUP,
            'number_of_offers': self.number_of_offers,
        }
        self.response = {
            "message": 'success',
            'data': data,
            'success': True,
            "code": 0
        }
        return self.send_response(self.response, self.status_code)

    def normal_flow_of_sign_up(self):
        """
        Normal flow of user's sign up
        """
        self.setting_language_and_variables_normal_flow()
        self.checking_registration_type()
        self.check_date_of_birth()
        if self.send_response_flag:
            return
        self.check_email_password()
        if self.send_response_flag:
            return
        self.validate_customer_already_exist()
        if self.send_response_flag:
            return
        self.validate_key()
        if self.send_response_flag:
            return
        self.create_new_customer()
        self.create_customer_profile()
        self.assign_key_to_customer()
        self.update_wl_validation()
        self.set_user_group()
        self.make_seemless_validation_entry()
        self.create_session()
        self.create_session_addendum()
        self.add_new_device()
        self.generating_final_response()

    def process_request(self, *args, **kwargs):
        """
        process request with normal flow signup
        :return:
        """
        self.normal_flow_of_sign_up()
