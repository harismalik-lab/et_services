"""
Update User Profile api
    - Get customer/user from get_customer() method
    - if customer exists
        - get fields for changes
            - if date_of_birth found, validates it
        - get verification state to update_demographic_state
        - update customer_profile with new valid changes and demographic_state
        
    NOTE: (In this api uploading user profile feature is not available,
            as profile_image_url is set to update profile image if given.)
"""
import datetime

from dateutil.relativedelta import relativedelta
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.update_user_profile_validator import update_user_profile_parser
# from user_service.modules.api_modules import AwsS3Manager, upload_profile_image
from user_service.common.base_resource import BasePutResource
from user_service.common.constants import CUSTOM_DOB_ERROR_CODE, CUSTOM_ERROR_CODE, CUSTOM_USER_EXISTS_ERROR_CODE, EN
from user_service.common.models.currency import Currency
from user_service.common.models.ent_customer_profile import EntCustomerProfile
from user_service.common.models.wl_company import WlCompany
from user_service.common.utils.api_utils import get_locale
from user_service.common.utils.authentication import get_company, get_current_customer
from user_service.common.utils.translation_manager import TranslationManager

__author__ = "azeemu@theentertainerasia.com"


class UpdateUserProfileApi(BasePutResource):
    """
    @api {post} /v1/users/action PUT | Update user's profile information.

    @apiName UpdateUserProfileApi
    @apiGroup UsersService

    @apiParam {String}             [language]                    Response language
    @apiParam {String}             [default_currency]            Currency Preference
    @apiParam {String}             [mobile_phone]                Mobile phone number
    @apiParam {String}             [nationality]                 Nationality
    @apiParam {String}             [date_of_birth]               Date of birth
    @apiParam {String}             [push_notifications]          Push notifications
    @apiParam {String}             [do_not_email]                Would you like to receive emails?
    @apiParam {String}             [work_address]                Work address
    @apiParam {String}             [home_address]                Home address
    @apiParam {String}             [currency]                    Currency
    @apiParam {String}             [marital_status]              Marital Status
    @apiParam {String}             [gender]                      Gender
    @apiParam {String}             [country]                     Country name
    @apiParam {String}             [about_me]                    About me
    @apiParam {String}             [profile_image_url]           Profile image location
    """
    request_parser = update_user_profile_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='post_user_action_api/post_user_action_api.log',
        ),
        'name': 'post_user_action_api'
    }
    strict_token = True
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of post user action id
        """
        self.locale = self.request_args.get('language')
        self.date_of_birth = self.request_args.get('date_of_birth')

    def initialize_class_attributes(self):
        """
        Initialize class attributes of post user action api
        """
        self.customer = get_current_customer()
        self.company = get_company()
        self.messages_locale = get_locale(self.locale)
        self.user_id = self.customer.get('customer_id')
        self.profile_image_name = ""

    def return_error_response(self, status_code, message, response_code):
        """
        generate error response and returns
        :param int status_code:
        :param str message:
        :param int response_code:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {
            "message": message,
            "code": response_code,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def check_customer(self):
        """
        Check customer
        :rtype: dict
        """
        if not self.user_id:
            self.return_error_response(
                codes.FORBIDDEN,
                TranslationManager.get_translation(
                    TranslationManager.you_are_not_allowed_to_access_this_application,
                    self.messages_locale
                ),
                CUSTOM_USER_EXISTS_ERROR_CODE,
            )

    def test_and_validate_date_of_birth(self):
        """
        Test and validate user date of birth
        :rtype: dict
        """
        is_valid_date_of_birth = True
        if self.date_of_birth:
            try:
                current_date = datetime.datetime.now()
                date_13_years_back = current_date - relativedelta(years=13)
                minimum_valid_dob = current_date - relativedelta(years=120)

                if self.date_of_birth > current_date or self.date_of_birth < minimum_valid_dob:
                    return self.return_error_response(
                        codes.UNPROCESSABLE_ENTITY,
                        TranslationManager.get_translation(TranslationManager.invalid_dob, self.messages_locale),
                        CUSTOM_DOB_ERROR_CODE
                    )
                if date_13_years_back < self.date_of_birth:
                    return self.return_error_response(
                        codes.UNPROCESSABLE_ENTITY,
                        TranslationManager.get_translation(
                            TranslationManager.dob_minimum_value_error,
                            self.messages_locale
                        ),
                        CUSTOM_DOB_ERROR_CODE
                    )
            except Exception:
                is_valid_date_of_birth = False
        if not is_valid_date_of_birth:
            self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                TranslationManager.get_translation(TranslationManager.invalid_dob, self.messages_locale),
                CUSTOM_DOB_ERROR_CODE
            )

    def set_profile_image_name(self):
        """
        Upload user profile image. If upload successful set `self.profile_image_name` as image url.
        """
        # TODO: This method has been commented as profile_image is taken from args as url [str]
        # if hasattr(request, 'files') and request.files.get('profile_image'):
        #     response_message = upload_profile_image(
        #         request.files.get('profile_image'),
        #         self.user_id
        #     )
        #     if response_message.get("code", 0) == AwsS3Manager.RESPONSE_CODE_BAD_REQUEST:
        #         return self.return_error_response(
        #             codes.BAD_REQUEST,
        #             response_message.get('message', ''),
        #             codes.BAD_REQUEST
        #         )
        #
        #     self.profile_image_name = response_message.get("url", '')

    def update_demographic_state(self):
        """
        This method updates verification state of a user.
        :param int user_id: Customer Id
        :rtype: bool
        """
        changes = {}
        customer_profile = EntCustomerProfile.get_by_user_id(self.user_id)
        if customer_profile:
            customer_profile = customer_profile.__dict__
            verification_state = customer_profile.get('verification_state')
            if verification_state == EntCustomerProfile.VERIFICATION_STATE_NOT_STARTED:
                verification_state = EntCustomerProfile.VERIFICATION_STATE_STARTED
            elif verification_state == EntCustomerProfile.VERIFICATION_STATE_STARTED:
                verification_state = EntCustomerProfile.VERIFICATION_STATE_PHONE_NOT_VERIFIED_BUT_DEMOGRAPHIC_UPDATED  # noqa E501
            elif verification_state == EntCustomerProfile.VERIFICATION_STATE_PHONE_VERIFIED:
                verification_state = EntCustomerProfile.VERIFICATION_STATE_VERIFICATION_COMPLETED
            if customer_profile.get('verification_state') == verification_state:
                return changes
            changes = {'verification_state': verification_state}
        return changes

    def update_user_profile(self):
        """
        1 - set changes and parse into dict to be updated in ent profile user table.
        2 - update user demographic state
        3 - update user profile.
        :param dict data:
        :param str company:
        :param dict data:
        :return: changes dictionary
        """
        changes = {}
        data = self.request_args

        if data.get('gender'):
            changes.update({'gender': data.get('gender')})
        if data.get('third_do_not_email'):
            changes.update({'third_email_opt_out': data.get('third_do_not_email')})
        if data.get('work_address'):
            changes.update({'work_address': data.get('work_address')})
        if data.get('home_address'):
            changes.update({'home_address': data.get('home_address')})
        if data.get('push_notifications'):
            changes.update({'push_notifications': data.get('push_notifications')})
        if data.get('affiliate_code'):
            changes.update({'affiliate_code': data.get('affiliate_code')})
        if data.get('do_not_email'):
            changes.update({'receive_email': data.get('do_not_email')})
        if data.get('mobile_phone'):
            changes.update({'mobile_phone': data.get('mobile_phone')})
        if data.get('marital_status'):
            changes.update({'marital_status': data.get('marital_status')})
        if data.get('nationality'):
            changes.update({'nationality': data.get('nationality')})
        if data.get('country_of_residence'):
            changes.update({'country_of_residence': data.get('country_of_residence')})
        if data.get('about_me'):
            changes.update({'about_me': data.get('about_me')})
        if data.get('date_of_birth'):
            changes.update({'birthdate': data.get('date_of_birth')})
        if data.get('profile_image_url'):
            changes.update({'profile_image': data.get('profile_image_url')})

        current_date = datetime.datetime.now()
        current_date = datetime.datetime.strftime(current_date, '%Y-%m-%d %H:%M:%S')
        changes.update({'update_time': current_date})
        if not data.get('language_preference'):
            data['language_preference'] = EN
        if data.get('currency'):
            data['default_currency'] = data.get('currency')
        else:
            data['default_currency'] = WlCompany.get_by_code(
                code=self.company
            ).default_currency if True else EntCustomerProfile.CURRENCY

        currency_info = Currency.get_currency_by_code(
            data.get('language_preference'),
            data.get('default_currency').upper()
        )
        data['currency'] = data.get('default_currency').upper()
        if currency_info:
            data['default_currency'] = currency_info.currency_id

        changes.update({'currency': data.get('currency')})
        changes.update({'default_currency': data.get('default_currency')})

        verification_state = self.update_demographic_state()
        if verification_state:
            changes['verification_state'] = verification_state.get('verification_state')

        self.cutomer_updated = EntCustomerProfile.update_customer_profile(customer_id=self.user_id, changes=changes)

    def generate_final_response(self):
        if self.cutomer_updated:
            self.status_code = codes.ok
            self.send_response_flag = True
            self.response = {
                "message": "success",
                "success": True,
                "data": []
            }
            return self.send_response(self.response, self.status_code)
        else:
            self.return_error_response(
                codes.BAD_REQUEST,
                TranslationManager.get_translation(
                    TranslationManager.problems_with_your_submission,
                    self.messages_locale
                ),
                CUSTOM_ERROR_CODE
            )

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.initialize_class_attributes()
        self.check_customer()
        if self.is_send_response_flag_on():
            return
        self.test_and_validate_date_of_birth()
        if self.is_send_response_flag_on():
            return
        # self.set_profile_image_name()
        # if self.is_send_response_flag_on():
        #     return
        self.update_user_profile()
        self.generate_final_response()
