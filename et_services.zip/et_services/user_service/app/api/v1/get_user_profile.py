"""
Get User Profile api
    - Get user id from get_customer() method
    - Get user profile using customer id
    - Convert orm obj into dict and process customer_profile attrs
    - Get user owned(purchased) products
    - Get user savings
    - Process user info
        - calculate months and years since registration
        - process/calculate redemption_count
        - process/calculate user's savings
"""
from datetime import datetime
from math import floor

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.get_user_profile_validator import user_profile_parser
from user_service.common.base_resource import BaseGetResource
from user_service.common.models.ent_customer_profile import EntCustomerProfile
from user_service.common.models.ent_order import EntOrder
from user_service.common.models.redemption import Redemption
from user_service.common.models.user_saving import UserSaving
from user_service.common.utils.api_utils import get_locale
from user_service.common.utils.authentication import get_company, get_current_customer
from user_service.modules.api_modules import calculate_aging, calculate_months_and_years

__author__ = "azeemu@theentertainerasia.com"


class GetUserProfileApi(BaseGetResource):
    """
    @api {GET} /v1/user/profile | Get User Profile

    @apiVersion 1.0.0
    @apiName user/profile
    @apiGroup UserService
    @apiParam {String="en", "ar", "cn", "el","zh"}  [language]          Response Language
    @apiParam {String}                              [currency]          Currency
    """

    request_parser = user_profile_parser

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='signup_api/signup_api.log',
        ),
        'name': 'currencies_api'
    }

    required_token = True
    strict_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.locale = self.request_args.get('language')
        self.currency = self.request_args.get('currency', '')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.messages_locale = get_locale(self.locale)
        self.current_year = datetime.now().year

    def get_user_profile(self):
        """
        Gets user profile data
        """
        self.user_profile = EntCustomerProfile.get_customer_profile(self.customer_id)
        user_profile = self.user_profile._asdict()

        # adding new fields
        user_profile["days_since_registration"] = (datetime.now() - user_profile.get('created_at')).days
        user_profile["member_since"] = calculate_aging(user_profile['days_since_registration'])
        user_profile['is_demographics_updated'] = 0
        if all([user_profile['gender'], user_profile['nationality'], user_profile['date_of_birth']]):
            user_profile['is_demographics_updated'] = 1
        if user_profile['date_of_birth']:
            if isinstance(user_profile['date_of_birth'], str):
                user_profile['date_of_birth'] = datetime.strptime(user_profile['date_of_birth'], '%Y-%m-%d').strftime(
                    '%d/%m/%Y'
                )
            else:
                user_profile['date_of_birth'] = user_profile['date_of_birth'].strftime('%d/%m/%Y')
        if not user_profile['currency']:
            user_profile['currency'] = EntCustomerProfile.CURRENCY

        if user_profile.get('using_trial') and user_profile.get('using_trial') != 1:
            user_profile['using_trial'] = False
        user_profile['push_notifications'] = int(user_profile['push_notifications'])
        user_profile['default_currency'] = user_profile['currency'].upper()
        user_profile['created_at'] = str(user_profile.get('created_at'))
        if user_profile['membership_expiration_date']:
            user_profile['membership_expiration_date'] = str(user_profile.get('membership_expiration_date'))
        user_profile['onboarding_startdate'] = str(user_profile.get('onboarding_startdate'))
        user_profile['updated_at'] = str(user_profile.get('updated_at'))
        user_profile['accepted_terms'] = user_profile.get('accepted_terms')
        user_profile['do_not_email'] = user_profile.get('do_not_email')
        user_profile['redemptions_count'] = Redemption.find_redemptions_count_by_customer(
            customer_id=self.customer_id,
            company=self.company
        )

        self.user_profile = user_profile

    def get_user_owned_products(self):
        self.owned_products = EntOrder.get_customer_purchased_skus_profile(
            self.customer_id,
            self.company,
            self.messages_locale
        )

    def get_user_savings(self):
        self.savings = UserSaving.get_user_savings_online(
            self.customer_id,
            self.currency,
            self.company
        )
        if self.savings:
            self.savings['current_year'] = self.current_year
            self.savings['lifetime'] = self.savings.get('savings')
            self.savings['yearly'] = self.savings.get('yearly_savings')

    def process_user_profile_dict(self):
        """
        process and set user profile attr
        :return:
        """
        user_profile = self.user_profile

        if user_profile.get('days_since_registration'):
            days_since_registration = int(user_profile.get('days_since_registration')) + 1
        else:
            days_since_registration = 1

        months, years = calculate_months_and_years(days_since_registration)

        # delete unnecessary keys from dict
        if 'days_since_registration' in user_profile.keys():
            del user_profile['days_since_registration']

        user_profile['savings'] = self.savings.get('lifetime')
        user_profile['savings_yearly_int'] = int(self.savings.get('yearly'))
        user_profile['savings_lifetime_int'] = int(self.savings.get('lifetime'))
        user_profile['savings_monthly_avg_int'] = floor(int(self.savings.get('lifetime')) / months)
        user_profile['savings_yearly_avg_int'] = floor(int(self.savings.get('lifetime')) / years)
        user_profile['user_creation_date'] = str(user_profile.get('user_creation_date'))
        user_profile['redemptionsCount'] = user_profile.get('redemptions_count')
        user_profile['userId'] = user_profile.get('user_id')
        user_profile['products'] = self.owned_products
        user_profile['external_savings'] = int(self.savings.get('points', 0))

        self.user_profile = user_profile

        try:
            del self.user_profile['user_id']
            del self.user_profile['redemptions_count']
        except KeyError:
            pass

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.ok
        self.response = {
            'data': self.user_profile,
            'message': 'success',
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Handles the process of api
        """
        self.initialize_local_veriables()
        self.get_user_profile()
        self.get_user_owned_products()
        self.get_user_savings()
        self.process_user_profile_dict()
        self.generate_final_response()
