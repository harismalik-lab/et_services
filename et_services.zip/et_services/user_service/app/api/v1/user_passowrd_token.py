"""
User password token api
    - Get active User's object by given password_token previously generated and updated by '/user/password/reset' API
    - checks password token expiry date
    - if password is given then:
        - sets new given password has as user's password.
        - sets password_token as None.
        - sets password_token_expiry as None.
        - updates user's record with above changes.
        - deactivates user's session.
    - returns response accordingly
"""
import datetime

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.user_passowrd_token_validator import user_password_token_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.models.session import Session
from user_service.common.models.user import User
from user_service.common.utils.authentication import get_company
from user_service.common.utils.security import security
from user_service.common.utils.translation_manager import TranslationManager
from user_service.modules.constants import EXPIRED_TOKEN_MESSAGE, INVALID_RESET_TOKEN_ERROR_CODE, INVALID_TOKEN_MESSAGE

__author__ = "azeemu@theentertainerasia.com"


class UserPasswordTokenApi(BasePostResource):
    """
    @api {post} /v1/user/password/token | Authenticate User PasswordToken

    @apiGroup UsersService
    @apiParam {String}          password_token       Password Reset Token
    @apiParam {String}          [password]           Password
    """
    request_parser = user_password_token_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='user_password_token_api/user_password_token_api.log',
        ),
        'name': 'user_password_token_api'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Add request arguments of user password token
        """
        self.password_token = self.request_args.get('password_token')
        self.password = self.request_args.get('password')

    def initialize_class_attributes(self):
        """
        Initialize class attributes of user password token api
        """
        self.is_valid_member = False
        self.company = get_company()

    def return_error_response(self, status_code, message, response_code):
        """
        generate error response and returns
        :param int status_code:
        :param str message:
        :param int response_code:
        """
        self.status_code = status_code
        self.send_response_flag = True
        self.response = {
            "message": message,
            "code": response_code,
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def is_customer_valid_member(self):
        """
        - Check customer is a valid member by getting with password token
        - check token expiry date
        - check password and update customer record
        - deactivate user's active session
        """
        customer = 0
        if self.password_token:
            customer = User.get_by_password_reset_token(self.password_token)
            if not customer:
                return self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    INVALID_TOKEN_MESSAGE,
                    INVALID_RESET_TOKEN_ERROR_CODE
                )
        if customer.token_exp_date < datetime.datetime.now():
            return self.return_error_response(
                codes.UNPROCESSABLE_ENTITY,
                EXPIRED_TOKEN_MESSAGE,
                INVALID_RESET_TOKEN_ERROR_CODE
            )

        if self.password:
            customer.password_hash = security.generate_password_hash(self.password)
            customer.token_exp_date = None
            customer.password_reset_token = None
            customer.update_record()
            Session.deactivate_sessions(self.company, customer.id)
            self.is_valid_member = True

    def prepare_response(self):
        """
        Sets final response of user password token api
        :rtype: dict
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        self.response = {
            'data': {
                'is_valid_member': self.is_valid_member
            },
            'message': TranslationManager.get_translation(TranslationManager.success),
            'success': True
        }
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Handles the process of user password token api
        """
        self.initialize_class_attributes()
        self.is_customer_valid_member()
        if self.send_response_flag:
            return
        self.prepare_response()
