"""
Reset Password API
    - Find active user by email
    - if user found:
        - create a random reset_password_token
        - set reset_password token in user record and update
        - make password reset url with reset_password_token
        - get user group
        - get email template by company and email_type
        - sets email data
        - create/insert EntSendEmail new record
"""
import datetime

from flask import current_app
from phpserialize import dumps as php_json_dumps
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.password_reset_validator import user_password_reset_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.constants import AR, CN
from user_service.common.models.ent_send_email import EntSendEmail
from user_service.common.models.user import User
from user_service.common.models.wl_template import Wltemplate
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import get_locale
from user_service.common.utils.authentication import get_company
from user_service.common.utils.security import security
from user_service.common.utils.translation_manager import TranslationManager
from user_service.modules.constants import CUSTOM_NO_VALID_USER_CODE, EMAIL_NOT_FOUND, PASSWORD_RESET_SUCCESS_MESSAGE

__author__ = "azeemu@theentertainerasia.com"


class UserPasswordResetApi(BasePostResource):
    """
    @api {post} /v1/user/password/reset | Reset Password

    @apiName UserPasswordResetApi
    @apiGroup Users
    @apiParam {String}                                         email         Email of user
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}      [language]    Response language
    """

    request_parser = user_password_reset_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='password_reset_api/password_reset_api.log',
        ),
        'name': 'password_reset_api'
    }
    required_token = False

    def populate_request_arguments(self):
        """
        Setting the arguments
        """
        self.email = self.request_args.get('email')
        self.locale = self.request_args.get('language')

    def initialize_local_veriables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = get_locale(self.locale)
        self.customer = User.find_active_user_by_email(self.email)

    def setting_language_and_message(self):
        self.message = PASSWORD_RESET_SUCCESS_MESSAGE
        if self.locale == CN:
            self.message = TranslationManager.LOCALE_CN_RESET_PASSWORD
        if self.locale == AR:
            self.message = TranslationManager.LOCALE_AR_RESET_PASSWORD

    def generate_response(self):
        """
        response for success case
        """
        data = {
            'is_sent': True,
            'message': self.message
        }
        self.status_code = codes.CREATED
        self.send_response_flag = True
        self.response = {
            "message": 'success',
            'data': data,
            "success": True
        }
        return self.send_response(self.response, self.status_code)

    def generate_response_on_no_valid_customer(self):
        """
        response for failure case
        """
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.send_response_flag = True
        self.response = {
            "message": EMAIL_NOT_FOUND,
            'code': CUSTOM_NO_VALID_USER_CODE,
            "data": [],
            "success": False
        }
        return self.send_response(self.response, self.status_code)

    def create_send_email_to_customer_record(self):
        """
        - generate random password reset token
        - update password reset token for USER
        - construct password rest url for user
        - set email template and insert new EntSendEmail record
        :return:
        """
        if self.customer:
            password_reset_token = security.generate_random_string(length=20)
            User.update_password_reset_token(
                self.customer.id,
                password_reset_token
            )

            password_reset_url = current_app.config.get('PASSWORD_RESET_URL')
            password_reset_url = '{password_reset_url}{password_reset_token}'.format(
                password_reset_url=password_reset_url,
                password_reset_token=password_reset_token
            )

            user_group = Wlvalidation.get_user_group(self.company, self.customer.id)
            email_template = Wltemplate.get_template_by_company_and_type(
                self.company,
                Wltemplate.FORGOT_PASSWORD,
                user_group
            )
            email_data = php_json_dumps({
                "user_id": self.customer.id,
                "{PASSWORD_RESET_URL}": password_reset_url
            })

            ent_send_email = EntSendEmail(
                email_template_type_id=email_template.template_id if email_template else None,
                email_template_data=email_data.decode(errors='ignore'),
                email_to=self.email,
                language=self.locale,
                priority=EntSendEmail.PRIORITY_HIGH,
                created_date=datetime.datetime.now(),
                optional_data=php_json_dumps({"{FIRST_NAME}": "", "{LAST_NAME}": ""}).decode(errors="ignore")
            )
            ent_send_email.insert_record()

            self.setting_language_and_message()
            self.generate_response()
        else:
            self.generate_response_on_no_valid_customer()

    def process_request(self, *args, **kwargs):
        """
        Process the request
        :return: Response
        """
        self.initialize_local_veriables()
        self.create_send_email_to_customer_record()
