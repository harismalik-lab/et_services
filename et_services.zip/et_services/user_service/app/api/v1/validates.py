"""
Validates Api
    - Find user by email
        - if exists set vars corresponding user info
    - get wl_company and check its subscription status
    - try to validate given key
        - if key validated
            - assign key to user
            - update user's all sessions
            - get email template for user
            - insert a new record for EntSendEmail
        - if key is not validated then return response regarding key status
"""
import uuid

from flask import current_app
from phpserialize import dumps as php_json_dumps
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.validates_api_validator import validates_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.ent_send_email import EntSendEmail
from user_service.common.models.session import Session
from user_service.common.models.user import User
from user_service.common.models.wl_company import WlCompany
from user_service.common.models.wl_product import WlProduct
from user_service.common.models.wl_template import Wltemplate
from user_service.common.models.wl_user_group import WlUserGroup
from user_service.common.models.wl_user_seemless_validation import WlUserSeemlessValidation
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import get_api_configurations, get_locale
from user_service.common.utils.authentication import get_company, get_current_customer
from user_service.common.utils.translation_manager import TranslationManager


class ValidatesApi(BasePostResource):
    """
    @api {POST} /v1/validates | Post Validates.

    @apiGroup UserService
    @apiParam {String}                                  email                       User Email
    @apiParam {String}                                  key                         Validation Key
    @apiParam {Boolean}                                 [is_secondary_key]          Check Secondary Key
    @apiParam {Boolean}                                 [afterlogin]                Afterlogin Check
    @apiParam {String="en", "ar", "cn", "el","zh"}      [language]                  Response Language
    @apiParam {Boolean}                                 [using_branch_activation]   Using Branch Activation
    """
    request_parser = validates_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='validates_api/validates_api.log',
        ),
        'name': 'validates_api'
    }
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of config api
        """
        self.locale = self.request_args.get('language')
        self.email = self.request_args.get('email')
        self.key = self.request_args.get('key')
        self.is_secondary_key = self.request_args.get('is_secondary_key')
        self.after_login = self.request_args.get('afterlogin')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.updated_user_group = self.request_args.get('updated_group')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.locale = get_locale(self.locale)
        self.is_key_validated = False
        self.is_customer_exists = False
        self.message = TranslationManager.get_translation(TranslationManager.invalid_wl_key, self.locale)

        self.existing_user_id = 0

        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id', 0)

        self.product_to_purchase = False
        self.email_data = {'user_id': 0}
        self.email_data_optional = php_json_dumps({}).decode(errors="ignore")

        if self.is_secondary_key or self.after_login:
            self.is_secondary_key = True
        self.api_config = get_api_configurations(self.company, current_app.config['ENV'].lower())
        self.key_less_activation = self.api_config.get(ApiConfiguration.KEY_LESS_ACTIVATION)
        self.uuid_based_login = self.api_config.get('login_type') == WlUserSeemlessValidation.UUID_LOGIN_TYPE

    def check_key_is_passed(self):
        """
        Validates key is passed
        """
        if not self.key:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Missing required parameter "key".'
            }
            self.status_code = codes.BAD_REQUEST

            return self.send_response(self.response, self.status_code)

    def check_email(self):
        """
        Validates Email is passed
        """
        if not self.email and not self.customer_id:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Missing required parameter "email".'
            }
            self.status_code = codes.BAD_REQUEST

            return self.send_response(self.response, self.status_code)

    def validate_key_less_activation(self):
        """
        Validates key less activation parameters
        """
        if not self.updated_user_group:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Missing required parameter "updated_group".'
            }
            self.status_code = codes.BAD_REQUEST

            return self.send_response(self.response, self.status_code)
        validation = Wlvalidation.get_active_by_company_email_and_user_group(
            self.company,
            self.email,
            self.updated_user_group
        )
        if validation and validation.isused:
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': True,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'User group already updated.'
            }
            self.status_code = codes.OK
            return self.send_response(self.response, self.status_code)

        if not WlUserGroup.get_group_info(self.updated_user_group, self.company):
            self.send_response_flag = True
            self.response = {
                'data': {
                    'validation_status': self.is_key_validated,
                    'is_customer_exists': self.is_customer_exists
                },
                'success': True,
                'message': 'Invalid "updated_group".'
            }
            self.status_code = codes.UNPROCESSABLE_ENTITY

            return self.send_response(self.response, self.status_code)
        # If key is generated before and not used but email is populated, reuse it
        if validation and not validation.isused:
            self.key = validation.wl_key
        else:
            _key = uuid.uuid4().hex[0:20]
            if Wlvalidation.key_already_exists(self.company, _key):
                _key = uuid.uuid4().hex[0:20]
            wl_validation = Wlvalidation(
                wl_key=_key,
                wl_company=self.company,
                email=self.email,
                isused=0,
                active=1,
                user_group=self.updated_user_group,
                deactivation_date=None
            )
            wl_validation.insert_record()
            self.key = _key

    def get_customer_info(self):
        """
        - find user by email
            - if user exists set user related data
        """
        if self.customer_id:
            self.customer = User.get_active_by_id(self.customer_id)
            self.email = self.customer.email
        else:
            self.customer = User.find_active_user_by_email(self.email)
        if self.customer:
            self.is_customer_exists = True
            self.customer_id = self.customer.id
            self.email_data['user_id'] = self.customer_id

    def get_url_from_config_and_change_company(self):
        """
        - get wl_company and check its subscription status
        - try to validate given key
        - if key validated
            - assign key to user
            - update user's all sessions
            - get email template for user
            - insert a new record for EntSendEmail
        :return:
        """

        is_multiple_subscription_allowed = False
        wl_company = WlCompany.get_by_code(self.company)
        if wl_company:
            is_multiple_subscription_allowed = bool(wl_company.is_multiple_allowed)

        if not is_multiple_subscription_allowed and self.is_secondary_key:
            self.is_key_validated = False
            if self.using_branch_activation:
                validation_status = Wlvalidation.validate_key(self.key, self.company, self.email)
                if validation_status == Wlvalidation.ALREADY_ACTIVATED_VALID_KEY:
                    self.message = TranslationManager.get_translation(
                        TranslationManager.you_have_already_activated_the_app_for_multiple_keys_not_allowed,
                        self.locale
                    )

                else:
                    self.message = TranslationManager.get_translation(
                        TranslationManager.invalid_wl_key_with_branch,
                        self.locale
                    )
            else:
                self.message = TranslationManager.get_translation(
                    TranslationManager.you_are_not_allowed_to_subscribe_multiple_keys,
                    self.locale
                )
        else:
            validation_status = Wlvalidation.validate_key(self.key, self.company, self.email)
            if validation_status == Wlvalidation.INVALID_KEY:
                self.is_key_validated = False
                self.message = TranslationManager.get_translation(
                    TranslationManager.invalid_wl_key,
                    self.locale
                )
                if self.using_branch_activation:
                    self.message = TranslationManager.get_translation(
                        TranslationManager.invalid_wl_key_with_branch,
                        self.locale
                    )

            if validation_status == Wlvalidation.ALREADY_ACTIVATED_VALID_KEY:
                if self.is_secondary_key:
                    self.is_key_validated = False
                    self.message = TranslationManager.get_translation(
                        TranslationManager.you_have_already_activated_this_key,
                        self.locale
                    )
                else:
                    self.is_key_validated = True
                    self.message = TranslationManager.get_translation(
                        TranslationManager.you_have_successfully_activated_the_key,
                        self.locale
                    )
                    if self.using_branch_activation:
                        self.message = TranslationManager.get_translation(
                            TranslationManager.you_have_successfully_activated_the_key_with_branch,
                            self.locale
                        )
            if validation_status == Wlvalidation.UNUSED_VALID_KEY:
                self.is_key_validated = True
                if not is_multiple_subscription_allowed:
                    number_of_keys = Wlvalidation.get_number_of_valid_keys(self.company, self.email)
                    if number_of_keys > 0:
                        self.send_response_flag = True
                        self.response = {
                            'data': {
                                'validation_status': self.is_key_validated,
                                'is_customer_exists': self.is_customer_exists
                            },
                            'success': True,
                            'message': self.message
                        }
                        self.status_code = codes.OK

                        return self.send_response(self.response, self.status_code)

            if not self.is_key_validated:
                self.send_response_flag = True
                self.response = {
                    'data': {
                        'validation_status': self.is_key_validated,
                        'is_customer_exists': self.is_customer_exists
                    },
                    'success': True,
                    'message': self.message
                }
                self.status_code = codes.OK
                return self.send_response(self.response, self.status_code)

            if self.using_branch_activation:
                self.message = TranslationManager.get_translation(
                    TranslationManager.you_have_successfully_activated_the_key_with_branch,
                    self.locale
                )
            else:
                self.message = TranslationManager.get_translation(
                    TranslationManager.you_have_successfully_activated_the_key,
                    self.locale
                )

            # bind a key with customer's email
            Wlvalidation.assign_key_to_customer(
                self.key,
                self.company,
                self.email,
                self.is_customer_exists,
                self.customer_id
            )

            # if customer exists, then get user groups
            if self.is_customer_exists:
                user_groups = Wlvalidation.get_user_groups(self.company, self.customer_id)
                if not user_groups:
                    user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                configured_product_ids = WlProduct.get_configured_product_ids(self.company, user_groups)
                product_ids = ','.join(map(str, configured_product_ids))

                Session.update_all_sessions_for_customer(
                    self.customer_id,
                    product_ids,
                    self.company
                )

                wl_validation_obj = Wlvalidation.get_user_group_id_by_key(self.key, self.company)
                if wl_validation_obj:
                    user_group = wl_validation_obj.user_group
                else:
                    user_group = WlUserGroup.DEFAULT_USER_GROUP

                # Get Email Template Based on the Company and User Group
                email_template = Wltemplate.get_template_by_company_and_type(
                    self.company,
                    Wltemplate.ACTIVATION_OF_TRAIL,
                    user_group
                )

                # Send Email to Customer
                if not self.uuid_based_login:
                    ent_send_email = EntSendEmail(
                        email_to=self.email,
                        email_template_data=php_json_dumps(self.email_data).decode(errors="ignore"),
                        email_template_type_id=email_template.template_id if email_template else None,
                        optional_data=php_json_dumps(self.email_data_optional).decode(errors="ignore"),
                        language=self.locale,
                        priority=EntSendEmail.PRIORITY_HIGH
                    )
                    ent_send_email.insert_record()

                self.is_key_validated = True
                self.message = TranslationManager.get_translation(
                    TranslationManager.you_have_successfully_activated_the_key,
                    self.locale
                )

                if self.using_branch_activation:
                    self.message = TranslationManager.get_translation(
                        TranslationManager.you_have_successfully_activated_the_key_with_branch,
                        self.locale
                    )

    def generate_final_response(self):
        """
        generating final response.
        """
        self.send_response_flag = True
        self.response = {
            'data': {
                'validation_status': self.is_key_validated,
                'is_customer_exists': self.is_customer_exists
            },
            'success': True,
            'message': self.message
        }
        self.status_code = codes.ok

    def process_request(self, *args, **kwargs):
        self.setting_variables()
        self.check_email()
        if self.send_response_flag:
            return
        self.get_customer_info()
        if self.send_response_flag:
            return
        if self.key_less_activation and not self.key:
            self.validate_key_less_activation()
        else:
            self.check_key_is_passed()
        if self.send_response_flag:
            return
        self.get_url_from_config_and_change_company()
        if self.is_send_response_flag_on():
            return
        self.generate_final_response()
        if self.is_send_response_flag_on():
            return
