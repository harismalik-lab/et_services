"""
This module contains authenticate API endpoint
    - Normal Flow:
        - Authenticates a user from provided username and password
        - generates a session_token, jwt and a refresh token
    - Seemless Flow:
        - get api configuration
        - check if company has login type as `uuid`
            - get seemless record by unique_login_token and company
            - get email from seemless record to set as email for login
            - get static password from seemless model and set as password for login
"""
import datetime
import time
import uuid

from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.validations.login_validator import authentication_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.constants import CUSTOM_ERROR_CODE, DEVICE_LIMIT_EXCEEDED, INVALID_UUID_CODE
from user_service.common.models.customer_device import CustomerDevice
from user_service.common.models.db import with_master
from user_service.common.models.ent_customer_profile import EntCustomerProfile
from user_service.common.models.session import Session
from user_service.common.models.user import User
from user_service.common.models.wl_company import WlCompany
from user_service.common.models.wl_product import WlProduct
from user_service.common.models.wl_user_group import WlUserGroup
from user_service.common.models.wl_user_seemless_validation import WlUserSeemlessValidation
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import get_api_configurations, get_locale
from user_service.common.utils.authentication import get_company
from user_service.common.utils.translation_manager import TranslationManager


class LoginApi(BasePostResource):

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='user_service/login_api.log',
        ),
        'name': 'login_api'
    }

    request_parser = authentication_parser
    required_token = False

    def populate_request_arguments(self):
        """
        Add request arguments of sign in api
        """
        self.platform = self.request_args.get('platform')
        self.app_version = self.request_args.get('app_version')
        self.locale = self.request_args.get('language')

        # params contain login information
        self.email = self.request_args.get('email')
        self.password = self.request_args.get('password')
        self.unique_login_token = self.request_args.get('unique_login_token')

        self.device_model = self.request_args.get('device_model')
        self.device_install_token = self.request_args.get('device_install_token')
        self.device_id = self.request_args.get('device_uid')
        self.mobile_phone = self.request_args.get('mobile_phone')
        self.device_key = self.request_args.get('device_key')
        self.wl_key = self.request_args.get('key')
        self.using_branch_activation = self.request_args.get('using_branch_activation')
        self.invoice_number = self.request_args.get('invoice_number')
        self.is_user_agreement_accepted = self.request_args.get('is_user_agreement_accepted')
        self.is_privacy_policy_accepted = self.request_args.get('is_privacy_policy_accepted')

    def local_variables(self):
        """
        Initialize local variables for sign in api
        """
        # TODO: get company from company api key and secret key
        self.wl_company = get_company()
        # self.session_id = 0
        self.user_group = 0
        self.user_group_code = ""
        self.user_group_logo = ""
        self.number_of_offers = 0
        self.number_of_valid_keys = 0
        self.is_new_key_added = False
        self.messages_locale = get_locale(self.locale)
        self.is_lookup_based_company = False
        # self.customer = get_current_customer()
        # self.customer_id = self.customer.get('id')

    def get_api_configuration(self):
        """
        get api configuration by company and env
        """
        self.api_config = get_api_configurations(self.wl_company, current_app.config['ENV'].lower())

    def seemless_validation(self):
        """
        - if api_configs ha login_type `uuid`
            - get seemless record by unique_login_token and company
            - if record found:
                - get email and set as self.email for login
                - get static password defined in WlUserSeemlessValidation model and set as self.password for login
            - else return with invalid login token message
        """
        if self.api_config:
            login_type = self.api_config.get('login_type')
            if login_type == WlUserSeemlessValidation.UUID_LOGIN_TYPE:
                if not self.unique_login_token:
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(
                        message="Missing required field 'unique_login_token'",
                        custom_code=INVALID_UUID_CODE
                    )
                    return self.send_response(self.response, self.status_code)
                seemless_obj = WlUserSeemlessValidation.get_active_by_uuid_and_company(
                    self.unique_login_token,
                    self.wl_company
                )
                if seemless_obj:
                    # set primary email and passwords as login creds
                    self.email = seemless_obj.email
                    self.password = WlUserSeemlessValidation.STATIC_PASSWORD

                else:
                    self.send_response_flag = True
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.response = self.generate_response_dict(
                        message="Invalid 'unique_login_token' provided.",
                        custom_code=INVALID_UUID_CODE
                    )
                    return self.send_response(self.response, self.status_code)

    def set_number_of_valid_keys(self):
        """
        Sets number of valid keys
        """
        self.number_of_valid_keys = Wlvalidation.get_number_of_valid_keys(
            company=self.wl_company,
            email=self.email
        )

    # def set_look_up_based_company_flag(self):
    #     self.is_lookup_based_company = WlCompany.is_lookup_based_company(company=self.wl_company)

    # def check_invoiced_based_apps(self):
    #     """
    #     Check invoiced based apps
    #     :rtype: dict
    #     """
    #     if self.invoice_number:
    #         # TODO:
    #         return self.process_request_invoiced_based()

    # def check_lookup_based_company(self):
    #     """
    #     Check lookup based company
    #     :rtype: dict
    #     """
    #     if self.is_lookup_based_company:
    #         # TODO:
    #         return self.post_session_lookup_based()

    # def check_branch_io_activation(self):
    #     """
    #     Check branch activation
    #     :rtype: dict
    #     """
    #     if self.using_branch_activation:
    #         # TODO:
    #         return self.post_session_gem_branch_io_based_action()

    def check_email(self):
        """
        Check email
        :rtype: dict|None
        """
        if not self.email:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.email_required,
                    self.locale
                ),
                custom_code=CUSTOM_ERROR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def generate_missing_email_password_response(self):
        self.send_response_flag = True
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.email_password_required,
                self.locale
            ),
            custom_code=CUSTOM_ERROR_CODE
        )
        return self.send_response(self.response, self.status_code)

    def check_password(self):
        """
        Checks password
        :rtype: dict|None
        """
        if not self.password:
            self.generate_missing_email_password_response()

    def check_device_key(self):
        """
        Sets device_id as device_key if provided device key
        """
        if not self.device_key:
            self.device_id = self.device_key

    def check_email_and_company(self, wl_company_name):
        """
        Checks email and company against given wl_company_name
        :param str wl_company_name: company name
        """
        if self.email:
            self.email_data_optional["EMAIL"] = self.email

        if self.wl_company:
            self.email_data_optional["WLCOMAPANY"] = self.wl_company

        if wl_company_name:
            self.email_data_optional["WLCOMPANY_NAME"] = wl_company_name

    def check_customer_email(self):
        """
        Checks customer email
        :rtype: dict
        """
        self.customer_by_email = User.find_active_user_by_email(self.email)
        if not self.customer_by_email:
            self.message = TranslationManager.get_translation(
                TranslationManager.you_are_not_allowed_to_access_this_application,
                self.locale
            )
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.you_are_not_allowed_to_access_this_application_due,
                    self.locale
                ),
                custom_code=CUSTOM_ERROR_CODE
            )
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.send_response_flag = True
            return self.send_response(self.response, self.status_code)

    def validate_key(self):
        """
        Validates key
        :rtype: dict
        """
        self.set_number_of_valid_keys()
        if self.number_of_valid_keys < 1:
            if self.wl_key:
                wl_validation_status = Wlvalidation.validate_key(
                    wl_key=self.wl_key,
                    company=self.wl_company,
                    email=self.email
                )
                if wl_validation_status == Wlvalidation.INVALID_KEY:
                    self.response = self.generate_response_dict(
                        message=TranslationManager.get_translation(
                            TranslationManager.invalid_wl_key,
                            self.messages_locale
                        ),
                        custom_code=CUSTOM_ERROR_CODE,
                    )
                    self.status_code = codes.UNPROCESSABLE_ENTITY
                    self.send_response_flag = True
                    return self.send_response(self.response, self.status_code)

                if wl_validation_status == Wlvalidation.UNUSED_VALID_KEY:
                    Wlvalidation.assign_key_to_customer(
                        wl_key=self.wl_key,
                        company=self.wl_company,
                        email=self.email,
                        is_customer_exists=True,
                        customer_id=self.customer_by_email.id if self.customer_by_email else None
                    )
            else:
                message = TranslationManager.get_translation(
                    TranslationManager.you_are_not_allowed_to_access_this_application,
                    self.locale
                )
                if self.wl_company == WlCompany.COMPANY_CODE_DU:
                    message = self.translation_manager.get_translation(
                        self.translation_manager.you_are_not_allowed_to_access_this_application_due,
                        self.locale
                    )
                self.response = self.generate_response_dict(
                    message=message,
                    custom_code=CUSTOM_ERROR_CODE,
                )
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def check_user_password(self):
        """
        Check user password
        :rtype: dict
        """
        password_hashed = User.get_active_user_password_hash_by_email(self.email)
        if password_hashed:
            self.customer = User.login(
                self.email,
                self.password,
                password_hashed
            )
            if not self.customer:
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.invalid_password,
                        self.messages_locale
                    ),
                    custom_code=CUSTOM_ERROR_CODE,
                )
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)
        else:
            self.response = self.generate_response_dict(
                message=TranslationManager.get_translation(
                    TranslationManager.invalid_password,
                    self.messages_locale
                ),
                custom_code=CUSTOM_ERROR_CODE,
            )
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            return self.send_response(self.response, self.status_code)

    def update_customer_validation_info(self):
        """
        Update customer validation information
        """
        self.customer_id = self.customer.id
        Wlvalidation.update_customer_validation(self.wl_company, self.email, self.customer_id)

    def check_device_info(self):
        """
        Check device information
        :rtype: dict
        """
        self.device_info = CustomerDevice.get_one_by_device_id_customer_id_and_company(
            customer_id=self.customer_id,
            device_id=self.device_id,
            company=self.wl_company
        )
        if not self.device_info:
            self.device_num = CustomerDevice.get_number_of_devices_by_customer_id_and_company(
                customer_id=self.customer_id,
                company=self.wl_company
            )
            device_limit_to_check = WlCompany.get_device_limit_by_company(self.wl_company)
            if device_limit_to_check and self.device_num > device_limit_to_check:
                self.response = self.generate_response_dict(
                    message=TranslationManager.get_translation(
                        TranslationManager.you_have_exceeded_your_devices_limit,
                        self.locale
                    ),
                    custom_code=DEVICE_LIMIT_EXCEEDED,
                )
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.send_response_flag = True
                return self.send_response(self.response, self.status_code)

    def load_customer_profile(self):
        """
        Load customer profile by id
        """
        self.customer_profile = EntCustomerProfile.get_by_user_id(self.customer_id)

    def generate_session_token(self):
        """
        Generate session token
        """
        self.user_group_ids = Wlvalidation.get_user_groups(self.wl_company, self.customer_id)
        user_groups = self.user_group_ids
        if not user_groups:
            user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
        product_ids = WlProduct.get_configured_product_ids(self.wl_company, user_groups)
        # noinspection PyArgumentList
        session = Session(
            session_token=str(uuid.uuid4()),
            customer_id=self.customer_id,
            product_ids=','.join(map(str, product_ids)),
            company=self.wl_company,
            isagreed=True,
            date_cached=time.time(),
            date_agreed=datetime.datetime.now()
        )
        session.insert_record()
        self.session_token = session.session_token
        if session.id:
            self.session_id = session.id

    def device_info_customer(self):
        """
        If not device info then create new record
        """
        if not self.device_info:
            customer_device = CustomerDevice(
                customer_id=self.customer_id,
                device_install_token=self.device_install_token,
                device_os=self.platform,
                device_model=self.device_model,
                session_id=self.session_id,
                primary_device=0 if self.device_num else 1,
                device_id=self.device_id
            )
            CustomerDevice.insert_record(customer_device)

    # def update_phone_number(self):
    #     """
    #     Update mobile phone number
    #     """
    #     if self.wl_company == WlCompany.COMPANY_CODE_ENTERTAINER_HUT and self.mobile_phone:
    #         self.customer_profile.mobile_phone = self.mobile_phone

    def write_customer_profile_changes_in_db(self):
        self.customer_profile.update_record()

    def save_customer_profile(self):
        """
        Commits changes in db
        """
        self.customer_profile.update_record()

    def set_user_group(self):
        """
        Sets user group
        """
        if self.user_group_ids:
            self.user_group = self.user_group_ids[-1]
        else:
            self.user_group = 0

    # def check_company_code_for_entertainer(self):
    #     """
    #     Check company code for entertainer
    #     """
    #     self.pop_up_screen_upon_successful_activation = ""
    #     if self.wl_company == WlCompany.COMPANY_CODE_ENTERTAINER_LIFE:
    #         if self.user_group in [1, 2]:
    #             self.pop_up_screen_upon_successful_activation = TranslationManager.get_translation(
    #                 TranslationManager.elf_pop_up_screen_upon_successful_activation,
    #                 locale=self.locale
    #             )
    #         elif self.user_group in [3, 4]:
    #             self.pop_up_screen_upon_successful_activation = TranslationManager.get_translation(
    #                 TranslationManager.elf_pop_up_screen_upon_successful_activation_30_june_2018,
    #                 locale=self.locale
    #             )
    #         elif self.user_group in [5, 6]:
    #             self.pop_up_screen_upon_successful_activation = TranslationManager.get_translation(
    #                 TranslationManager.elf_pop_up_screen_upon_successful_activation_30_dec_2018,
    #                 locale=self.locale
    #             )

    # def check_company_code_for_master_cards(self):
    #     """
    #     Check company code for master
    #     """
    #     if self.wl_company == WlCompany.COMPANY_CODE_MASTER_CARDS:
    #         user_group_info = WlUserGroup.get_group_info(self.user_group, self.wl_company)
    #         if user_group_info:
    #             self.user_group_code = user_group_info.code
    #             self.user_group_logo = user_group_info.logo
    #             self.number_of_offers = user_group_info.number_of_offers

    def set_final_response(self):
        """
        Sets final response
        :rtype: dict
        """
        is_demographics_updated = bool(
            self.customer_profile.gender and
            self.customer_profile.nationality and
            self.customer_profile.birthdate
        )
        data = {
            'message': "",
            'user_id': self.customer_id,
            'session_token': self.session_token,
            'member_type': 3,
            'currency': self.customer_profile.currency,
            'new_user': False,
            'device_install_token': self.device_install_token,
            'device_uid': self.device_id,
            'device_os': self.platform,
            'device_model': self.device_model,
            "user_group": self.user_group,
            "user_group_code": self.user_group_code,
            "user_group_logo": self.user_group_logo,
            "number_of_offers": self.number_of_offers,
            'is_demographics_updated': is_demographics_updated
        }
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.success,
                self.locale
            ),
            success_flag=True,
            data=data
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    # Invoice Based Flow

    # def check_email_password_invoice_based(self):
    #     """
    #     Check email and password invoice based
    #     :rtype: dict
    #     """
    #     if not self.email or not self.password:
    #         self.generate_missing_email_password_response()

    # def check_customer_email_invoice_based(self):
    #     """
    #     Check customer by email
    #     :rtype: dict
    #     """
    #     if self.device_key:
    #         self.device_id = self.device_key
    #     self.customer_by_email = User.find_active_user_by_email(self.email)
    #     if not self.customer_by_email:
    #         self.response = self.generate_response_dict(
    #             message=TranslationManager.get_translation(
    #                 TranslationManager.email_not_exist,
    #                 self.messages_locale
    #             ),
    #             custom_code=CUSTOM_ERROR_CODE,
    #         )
    #         self.status_code = codes.UNPROCESSABLE_ENTITY
    #         self.send_response_flag = True
    #         return self.send_response(self.response, self.status_code)

    # def check_invoice_number(self):
    #     """
    #     Check invoice number
    #     :rtype: dict
    #     """
    #     self.customer_id = self.customer_by_email.id
    #     if self.invoice_number:
    #         self.set_number_of_valid_keys()
    #         invoice = WlInvoiceHeader.get_by_company_and_invoice_number(self.wl_company, self.invoice_number)
    #         invoice_validation_status = validate_invoice_number(
    #             invoice,
    #             is_for_sign_up_or_sign_in=True,
    #             invoice_amount=self.invoice_number
    #         )
    #         if invoice_validation_status != WlInvoiceHeader.wl_invoice_repo.VALID_STATUS:
    #             message = get_invoice_validation_message(
    #                 invoice_validation_status,
    #                 self.locale
    #             )
    #             self.response = self.generate_response_dict(
    #                 message=message,
    #                 data={'validation_status': False},
    #                 custom_code=INVOICE_CUSTOM_ERROR_CODE
    #             )
    #             self.status_code = codes.BAD_REQUEST
    #             self.send_response_flag = True
    #             return self.send_response(self.response, self.status_code)
    #
    #         if self.number_of_valid_keys < 1:
    #             self.is_new_key_added = True
    #         add_invoice_to_user(
    #             invoice=invoice,
    #             company=self.wl_company,
    #             user_id=self.customer_id,
    #             email=self.email,
    #             number_of_valid_keys=self.number_of_valid_keys,
    #             user_savings=UserSaving.get_by_user_id_and_company(self.customer_id, self.wl_company)
    #         )
    #     else:
    #         invoice = WlInvoiceHeader.get_by_user_id(self.customer_id)
    #         if not invoice:
    #             message = get_invoice_validation_message(
    #                 self.wl_invoice_repo.Invoice_Status_Invalid_Transaction_Type,
    #                 self.locale
    #             )
    #             self.response = self.generate_response_dict(
    #                 message=message,
    #                 data={'validation_status': False},
    #                 custom_code=CUSTOM_ERROR_CODE
    #             )
    #             self.status_code = codes.BAD_REQUEST
    #             self.send_response_flag = True
    #             return self.send_response(self.response, self.status_code)

    # def check_password_hash_invoice_based(self):
    #     """
    #     Check password hash of invoice based
    #     :rtype: dict
    #     """
    #     password_hashed = User.get_active_user_password_hash_by_email(self.email)
    #     if password_hashed:
    #         self.customer = User.login(
    #             self.email, self.password,
    #             password_hashed, lookup_based_company=self.is_lookup_based_company
    #         )
    #         if not self.customer:
    #             self.response = self.generate_response_dict(
    #                 message=TranslationManager.get_translation(
    #                     TranslationManager.invalid_password,
    #                     self.messages_locale
    #                 ),
    #                 custom_code=CUSTOM_ERROR_CODE
    #             )
    #             self.status_code = codes.UNPROCESSABLE_ENTITY
    #             self.send_response_flag = True
    #             return self.send_response(self.response, self.status_code)
    #     else:
    #         self.response = self.generate_response_dict(
    #             message=TranslationManager.get_translation(
    #                 TranslationManager.invalid_password,
    #                 self.messages_locale
    #             ),
    #             custom_code=CUSTOM_ERROR_CODE
    #         )
    #         self.status_code = codes.UNPROCESSABLE_ENTITY
    #         self.send_response_flag = True
    #         return self.send_response(self.response, self.status_code)

    # def check_customer_profile_invoice_based(self):
    #     """
    #     Check customer profile invoice based
    #     """
    #     self.customer_profile = EntCustomerProfile.get_by_user_id(self.customer_id)

    # def check_session_invoice_based(self):
    #     """
    #     Check session token invoice based
    #
    #     Keeping this function as a duplicate as this is a logic for an alternate login, and we cannot afford changing
    #     this logic affecting the original flow logic
    #     """
    #     self.user_group_ids = Wlvalidation.get_user_groups(self.wl_company, self.customer_id)
    #     user_groups = self.user_group_ids
    #     if not user_groups:
    #         user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
    #     product_ids = WlProduct.get_configured_product_ids(self.wl_company, user_groups)
    #     session = Session(
    #         session_token=str(uuid.uuid4()),
    #         customer_id=self.customer_id,
    #         product_ids=','.join(map(str, product_ids)),
    #         company=self.wl_company,
    #         isagreed=True,
    #         date_cached=time.time(),
    #         date_agreed=datetime.datetime.utcnow()
    #     )
    #     session.insert_record()
    #     self.session_token = session.session_token
    #     if session.id:
    #         self.session_id = session.id

    # def check_device_info_for_all(self):
    #     """
    #     Checks device info
    #     :return:
    #     """
    #     device_info = CustomerDevice.get_one_by_device_id_customer_id_and_company(
    #         customer_id=self.customer_id,
    #         device_id=self.device_id,
    #         company=self.wl_company
    #     )
    #     if not device_info:
    #         self.device_num = CustomerDevice.get_number_of_devices_by_customer_id_and_company(
    #             customer_id=self.customer_id,
    #             company=self.wl_company
    #         )
    #         customer_device = CustomerDevice(
    #             customer_id=self.customer_id,
    #             device_install_token=self.device_install_token,
    #             device_os=self.platform,
    #             device_model=self.device_model,
    #             session_id=self.session_id,
    #             primary_device=1 if self.device_num else 0,
    #             device_id=self.device_id,
    #             is_black_listed=0,
    #             device_first_used=datetime.datetime.utcnow()
    #         )
    #         CustomerDevice.insert_record(customer_device)

    # def check_new_key_added(self):
    #     """
    #     New key added
    #     """
    #     if self.is_new_key_added:
    #         self.user_group_ids = Wlvalidation.get_user_groups(self.wl_company, self.customer_id)
    #         if self.user_group_ids:
    #             self.user_group = self.user_group_ids[-1]
    #         self.user_group = self.wl_validation_repo.get_user_group(self.wl_company, self.customer_id)
    #         email_template_id = self.wl_templates_repo.get_template_by_company_and_type(
    #             self.wl_company,
    #             self.wl_templates_repo.ACTIVATION_OF_TRAIL,
    #             self.user_group
    #         )
    #
    #         email_data = php_json_dumps({'user_id': self.customer_id})
    #         optional_data = php_json_dumps({"{FIRST_NAME}": self.customer_profile.get("firstname")})
    #
    #         self.customer_repo.send_email(
    #             email_type_id=email_template_id,
    #             email_data=email_data.decode(errors='ignore'),
    #             email=self.email,
    #             language=self.locale,
    #             priority=self.wl_email_send_repo.Priority_Medium,
    #             dump=False,
    #             optional_data=optional_data
    #         )

    # def process_request_invoiced_based(self):
    #     """
    #     Handles the process of sign in post invoiced base session
    #     """
    #     self.check_email_password_invoice_based()
    #     if self.send_response_flag:
    #         return
    #     self.check_customer_email_invoice_based()
    #     if self.send_response_flag:
    #         return
    #
    #     self.check_invoice_number()
    #     if self.send_response_flag:
    #         return
    #
    #     self.check_password_hash_invoice_based()
    #     if self.send_response_flag:
    #         return
    #
    #     self.load_customer_profile()
    #     self.check_session_invoice_based()
    #     self.check_device_info_for_all()
    #     self.add_customer_in_trial()
    #     self.check_new_key_added()
    #     self.set_final_response_invoice_based()

    def process_request(self, *args, **kwargs):
        self.local_variables()
        self.get_api_configuration()
        self.seemless_validation()
        if self.send_response_flag:
            return
        self.check_email()
        if self.send_response_flag:
            return
        self.check_password()
        if self.send_response_flag:
            return
        self.check_device_key()
        self.check_customer_email()
        if self.send_response_flag:
            return
        self.validate_key()
        if self.send_response_flag:
            return
        self.check_user_password()
        if self.send_response_flag:
            return
        self.update_customer_validation_info()
        self.check_device_info()
        if self.send_response_flag:
            return
        self.load_customer_profile()
        self.generate_session_token()
        self.device_info_customer()
        self.write_customer_profile_changes_in_db()
        self.set_user_group()
        self.set_final_response()
