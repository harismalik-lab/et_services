"""
Send Email API
"""
from flask import current_app
from phpserialize import dumps as php_json_dumps
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v2.validations.send_email_validation import send_email_parser
from user_service.common.base_resource import BasePostResource
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.ent_send_email import EntSendEmail
from user_service.common.models.wl_template import Wltemplate
from user_service.common.utils.api_utils import get_api_configurations
from user_service.common.utils.authentication import get_company, get_current_customer


class SendEmail(BasePostResource):
    request_parser = send_email_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='user_service/send_email_api.log',
        ),
        'name': 'send_email'
    }
    required_token = True

    def populate_request_arguments(self):
        """
        Add request arguments of post user action id
        """
        self.email = self.request_args.get('email')
        self.template_id = self.request_args.get('template_id')
        self.locale = self.request_args.get('language')
        self.priority = self.request_args.get('priority')
        self.first_name = self.request_args.get('first_name', '')
        self.last_name = self.request_args.get('last_name', '')
        self.phone = self.request_args.get('phone', '')
        self.password_reset_url = self.request_args.get('password_reset_url')
        self._email = self.request_args.get('_email', '')
        self.extra = self.request_args.get('extra')

    def initialize_class_attributes(self):
        """
        Initialize class attributes of post user action api
        """
        self.customer = get_current_customer()
        self.company = get_company()

    def is_company_allowed_to_consume_email_feature(self):
        """
        Checks if company is able to consume this service
        """
        api_configs = get_api_configurations(self.company, current_app.config['ENV'].lower())
        if not api_configs.get(ApiConfiguration.EMAIL_SERVICE_ENABLED):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid Usage"
            )
            return self.send_response(self.response, self.status_code)

    def validate_template_id(self):
        """
        Validates template id
        """
        template = Wltemplate.get_template_by_id_and_company(self.template_id, self.company)
        if not template:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid 'template_id'"
            )
            return self.send_response(self.response, self.status_code)

    def send_email(self):
        """
        Inserts a row in ent_send_email, cron will handle the actual email sending part
        """
        self.email_data_optional, self.email_data = {}, {}
        if self.first_name:
            self.email_data_optional['{FIRST_NAME}'] = self.first_name
        if self.last_name:
            self.email_data_optional['{LAST_NAME}'] = self.last_name
        if self.password_reset_url:
            self.email_data['{PASSWORD_RESET_URL}'] = self.password_reset_url
        if self.phone:
            self.email_data_optional['{PHONE_NUMBER}'] = self.phone
        if self._email:
            self.email_data_optional['{EMAIL}'] = self._email
        if self.extra:
            self.email_data_optional.update(self.extra)
        ent_send_email = EntSendEmail(
            email_to=self.email,
            email_template_type_id=self.template_id,
            email_template_data=php_json_dumps(self.email_data).decode(errors="ignore"),
            optional_data=php_json_dumps(self.email_data_optional).decode(errors="ignore"),
            language=self.locale,
            priority=self.priority
        )
        ent_send_email.insert_record()

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict(
            success_flag=True,
        )
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_class_attributes()
        self.is_company_allowed_to_consume_email_feature()
        if self.send_response_flag:
            return
        self.validate_template_id()
        if self.send_response_flag:
            return
        self.send_email()
        self.set_final_response()
