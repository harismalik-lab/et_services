"""
Signup Api
 - if lookup based company
    - Check lookup data exist
    - If key is not given then generate key
 - creates a new user with given valid information.
    - check if user already exists or not with given info. if exists then return error response.
    - validates wl_key
 - creates customer profile.
 - Assigns wl_key to the user
 - creates active session record.
 - creates session addendum record
 - Add device
 - add record for welcome email into `ent_send_email` table
 - Returns response
"""

import datetime

from requests import codes
from phpserialize import dumps as php_json_dumps

from app_configurations.settings import ET_SERVICES_LOG_PATH
from user_service.app.api.v1.signup import SignupApi
from user_service.app.api.v2.validations.signup_validator import sign_up_parser_v2
from user_service.common.constants import CUSTOM_ERROR_CODE
from user_service.common.models.api_configuration import ApiConfiguration
from user_service.common.models.ent_send_email import EntSendEmail
from user_service.common.models.wl_template import Wltemplate
from user_service.common.models.wl_validation import Wlvalidation
from user_service.common.utils.api_utils import generate_unique_id
from user_service.common.utils.translation_manager import TranslationManager
from user_service.modules.api_modules_v2 import get_key_prefix_by_company, get_look_up_data


class SignupApiV2(SignupApi):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='signup_api_v2/signup_api_v2.log',
        ),
        'name': 'signup_api_v2'
    }

    request_parser = sign_up_parser_v2

    def populate_request_arguments(self):
        """
        Populates the request arguments
        """
        super().populate_request_arguments()
        self.parent_id = self.request_args.get('unique_login_token')

    def validate_look_up_based_company(self):
        if self.api_config.get(ApiConfiguration.IS_LOOKUP_BASED):
            if self.api_config.get(ApiConfiguration.IS_PARENT_BASED) and not self.parent_id:
                self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    TranslationManager.get_translation(TranslationManager.parent_id_is_required, self.messages_locale),
                    CUSTOM_ERROR_CODE
                )

            self.look_up_data = get_look_up_data(
                self.company,
                self.api_config.get(ApiConfiguration.IS_PARENT_BASED),
                self.parent_id,
                self.email
            )

            if not self.look_up_data:
                self.return_error_response(
                    codes.UNPROCESSABLE_ENTITY,
                    TranslationManager.get_translation(
                        TranslationManager.you_are_not_allowed_to_access_this_application,
                        self.messages_locale
                    ),
                    CUSTOM_ERROR_CODE
                )
                return

            if not self.wl_key:
                prefix = get_key_prefix_by_company(self.company)
                self.wl_key = generate_unique_id(prefix, 7)
                wl_validation = Wlvalidation(
                    wl_key=self.wl_key,
                    wl_company=self.company,
                    email=self.email,
                    isused=False,
                    activation_date=datetime.datetime.now(),
                    active=True,
                    existing=False,
                )
                wl_validation.insert_record()

    def create_new_customer(self):
        """
        Creates the new customer and validates if its created
        """
        super().create_new_customer()
        if self.look_up_data:
            self.look_up_data.user_id = self.customer.id
            self.look_up_data.update_record()

    def send_welcome_email(self):
        """
        add record for welcome email in `ent_send_email` table
        """
        if self.api_config.get(ApiConfiguration.ENABLE_USER_WELCOME_EMAIL):
            email_template = Wltemplate.get_template_by_company_and_type(
                    self.company,
                    Wltemplate.ACTIVATION_OF_TRAIL,
                    self.user_groups
            )
            email_data = php_json_dumps({'user_id': self.customer.id})
            optional_data = php_json_dumps({
                '{FIRST_NAME}': self.ent_customer_profile.firstname,
                '{LAST_NAME}': self.ent_customer_profile.lastname,
                '{MIDDLE_NAME}': ''
            })
            ent_send_email = EntSendEmail(
                email_template_type_id=email_template.template_id if email_template else None,
                email_template_data=email_data.decode(errors='ignore'),
                email_to=self.email,
                language=self.messages_locale,
                priority=EntSendEmail.PRIORITY_HIGH,
                created_date=datetime.datetime.now(),
                optional_data=optional_data.decode(errors='ignore')
            )
            ent_send_email.insert_record()

    def normal_flow_of_sign_up(self):
        """
        Normal flow of user's sign up
        """
        self.setting_language_and_variables_normal_flow()
        self.checking_registration_type()
        self.check_date_of_birth()
        if self.send_response_flag:
            return
        self.check_email_password()
        if self.send_response_flag:
            return
        self.validate_customer_already_exist()
        if self.send_response_flag:
            return
        self.validate_look_up_based_company()
        if self.send_response_flag:
            return
        self.validate_key()
        if self.send_response_flag:
            return
        self.create_new_customer()
        self.create_customer_profile()
        self.assign_key_to_customer()
        self.update_wl_validation()
        self.set_user_group()
        self.make_seemless_validation_entry()
        self.create_session()
        self.create_session_addendum()
        self.add_new_device()
        self.send_welcome_email()
        self.generating_final_response()

    def process_request(self, *args, **kwargs):
        """
        process request with normal flow signup
        :return:
        """
        self.normal_flow_of_sign_up()
