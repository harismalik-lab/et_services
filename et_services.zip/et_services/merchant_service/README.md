# Merchants Service
It contains merchant related API endpoints.

## Url Pattern
{{base-url}}/v1/merchants/<merchant_id>
