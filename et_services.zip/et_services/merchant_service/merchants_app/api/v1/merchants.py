"""
This module contains API endpoint to get merchants.
"""

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from merchant_service.common.base_resource import BaseGetResource
from merchant_service.common.constants import CUSTOM_ERROR_CODE
from merchant_service.common.models.offer import Offer
from merchant_service.common.models.product import Product
from merchant_service.common.utils.authentication import get_company
from merchant_service.merchants_app.api.v1.validations.merchants import merchant_parser
from merchant_service.modules.api_modules import get_product_price_details, set_merchants
from merchant_service.modules.constants import MAX_MERCHANTS

__author__ = 'tamoor'


class MerchantsApi(BaseGetResource):
    """
    @api {get} /v1/merchants Get merchants
    @apiSampleRequest /v1/merchants
    @apiVersion 1.0.0
    @apiName MerchantsApi
    @apiGroup Merchants
    @apiParam {String="android", "ios"}       [platform]      All supported platform
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='merchants_service/merchants_api.log',
        ),
        'name': 'merchants_api'
    }
    request_parser = merchant_parser

    def populate_request_arguments(self):
        """
        Add request arguments for merchant_api_action
        """
        self.platform = self.request_args.get('platform')
        self.locale = self.request_args.get('language')
        self.product_sku = self.request_args.get('product_sku')
        self.offset = self.request_args.get('offset')
        self.limit = self.request_args.get('limit')
        self.location_id = self.request_args.get('location_id')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        self.company = get_company()
        self.bundled_product_skus = []

    def check_limit(self):
        if self.limit > MAX_MERCHANTS or self.limit < 0:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="limit should be > 0 and <= {}".format(MAX_MERCHANTS),
                custom_code=CUSTOM_ERROR_CODE
            )
            return self.send_response(self.response, self.status_code)

        if not self.offset >= 0:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="offset should not be a negative number".format(MAX_MERCHANTS),
                custom_code=CUSTOM_ERROR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def set_current_customer(self):
        """
        Gets the bundled skus against the purchasable product
        """
        bundled_result = Product.get_bundled_product(self.product_sku)
        if bundled_result:
            bundled_result = bundled_result._asdict()
            if bundled_result.get('bundled_product_sku'):
                self.bundled_product_skus = bundled_result.get('bundled_product_sku').split(',')

        if self.product_sku:
            self.bundled_product_skus.append(self.product_sku)
        self.merchants = Offer.get_merchant_offers(
            self.locale,
            self.bundled_product_skus,
            location_id=self.location_id
        )

    def set_merchants(self):
        """
        Set merchants data
        """
        set_merchants(self.merchants)
        self.product_price_details = get_product_price_details(
            self.company,
            self.product_sku,
            self.locale,
            self.platform
        )

    def prepare_response(self):
        """
        Set final response for MerchantApiAction api
        """
        self.response = {
            'success': True,
            'message': 'success',
            'data': {
                'merchants': self.merchants[self.offset: self.offset + self.limit],
                'total_records': len(self.merchants),
                'limit': MAX_MERCHANTS,
                'payment_info': self.product_price_details
            },
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Controls the flow of merchant_api_action
        """
        self.check_limit()
        if self.send_response_flag:
            return
        self.initialize_local_variables()
        self.set_current_customer()
        self.set_merchants()
        self.prepare_response()
