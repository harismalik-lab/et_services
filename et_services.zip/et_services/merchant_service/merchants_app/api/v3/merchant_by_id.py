"""
This module contains API endpoint to get merchant by id.
"""
import json

from flask import current_app
from requests import codes
from shapely import speedups
from shapely.geometry import Point, Polygon, mapping
from sqlalchemy.exc import SQLAlchemyError

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.utils.api_utils import (get_delivery_enabled_location_ids_against_company,
                                    get_table_booking_enabled_location_ids_against_company)
from merchant_service.common.constants import (AED, CATEGORY_NAME_BODY,
                                               CATEGORY_NAME_RESTAURANTS_AND_BARS,
                                               DUBAI_LOCATION_ID,
                                               EDIT_ORDER_IDLE_TIMER_VALUE,
                                               EDIT_ORDER_TIMER_VALUE,
                                               ENT_COMPANY_TYPE,
                                               VALID_CATEGORIES)
from merchant_service.common.models.api_configuration import ApiConfiguration
from merchant_service.common.models.api_messages import APIMessages
from merchant_service.common.models.category import Category
from merchant_service.common.models.dm_area_coordinate import DmAreaCoordinate
from merchant_service.common.models.dm_devices import DmDevice
from merchant_service.common.models.dm_outlet_setting import DmOutletSetting
from merchant_service.common.models.dm_user_delivery_address import \
    DmUserDeliveryAddres
from merchant_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from merchant_service.common.models.exchange_rate import ExchangeRate
from merchant_service.common.models.location import Location
from merchant_service.common.models.merchant import Merchant
from merchant_service.common.models.outlet import Outlet
from merchant_service.common.models.product import Product
from merchant_service.common.models.quiq_up_settings import QuiqUpSetting
from merchant_service.common.models.share_offer import ShareOffer
from merchant_service.common.models.top_up_offers import TopUpOffer
from merchant_service.common.models.user import User
from merchant_service.common.models.user_favourites import UserFavourites
from merchant_service.common.models.user_smile_summary import UserSmileSummary
from merchant_service.common.rest_urls import RedemptionServiceAPIUrlsV2
from merchant_service.common.utils.api_utils import (format_company,
                                                     generic_boolean_conversion,
                                                     get_hotel_rating,
                                                     get_locale_location_id,
                                                     multi_key_sort)
from merchant_service.common.utils.authentication import (get_current_customer,
                                                          token_decorator_v3)
from merchant_service.common.utils.translation_manager import \
    TranslationManager
from merchant_service.merchants_app.api.v2.merchant_by_id import \
    MerchantByIdApiV2
from merchant_service.merchants_app.api.v3.validations.merchant_by_id_validator import \
    merchant_by_id_parser_v3
from merchant_service.modules.api_modules import (format_merchant_attributes,
                                                  get_analytics_codes_against_categories,
                                                  get_merchant_attributes_by_merchant_id,
                                                  process_merchant,
                                                  split_and_filter_null_entries)
from merchant_service.modules.api_modules_v3 import (allowed_offer_buy_back,
                                                     calculate_outlet_availability,
                                                     find_distance,
                                                     formulate_offer_details_array_v3,
                                                     get_and_process_offers_v3,
                                                     get_bat_section,
                                                     get_birthday_offer_validity,
                                                     get_birthday_offer_validity_in_days,
                                                     get_extended_trial_rules_current_customer,
                                                     get_geo_point_from_lat_lng,
                                                     get_ping_details,
                                                     get_quip_up_service_availability,
                                                     handle_deliverable_offer,
                                                     inject_distances_and_sort_v3,
                                                     populate_cinema_offers,
                                                     process_menu_details_v3,
                                                     show_smile_earn_values,
                                                     update_action_buttons_list_for_merchant)
from merchant_service.modules.constants import (ALLERGY_INFORMATION,
                                                ALLERGY_INFORMATION_TITLE,
                                                BUTTON_TITLE_CALL,
                                                BUTTON_TITLE_CATALOGUE,
                                                BUTTON_TITLE_FAVOURITES,
                                                BUTTON_TITLE_MENU,
                                                BUTTON_TITLE_PING,
                                                BUTTON_TITLE_SHARE,
                                                BUTTON_TYPE_CALL,
                                                BUTTON_TYPE_CATALOGUE,
                                                BUTTON_TYPE_EMAIL,
                                                BUTTON_TYPE_FAVOURITES,
                                                BUTTON_TYPE_MENU,
                                                BUTTON_TYPE_PING,
                                                BUTTON_TYPE_SHARE,
                                                BUTTON_VALUE_FAVORITES,
                                                BUTTON_VALUE_SHARE,
                                                DELIVERY_HOURS,
                                                DELIVERY_TIMINGS,
                                                FAVOURITE_IMAGE_URL,
                                                LOCATION_IDS_1_FOR_1,
                                                OMAN_LOCATION_ID,
                                                RADIUS_CONVERSION_UNIT,
                                                SMILES_ACTION_BURN_OFFERS_TOP_UP_ID,
                                                SPONSOR_IMAGE_DEFAULT,
                                                SPONSOR_IMAGE_OMAN,
                                                SPONSOR_IMAGE_TARGET_LINK_ANDROID_DEFAULT,
                                                SPONSOR_IMAGE_TARGET_LINK_ANDROID_OMAN,
                                                SPONSOR_IMAGE_TARGET_LINK_IOS_DEFAULT,
                                                SPONSOR_IMAGE_TARGET_LINK_IOS_OMAN,
                                                SPONSOR_IMAGE_TARGET_LINK_WINDOWS_DEFAULT,
                                                SPONSOR_IMAGE_TARGET_LINK_WINDOWS_OMAN,
                                                SPONSOR_TITLE_DEFAULT,
                                                SPONSOR_TITLE_OMAN,
                                                TOP_UP_OFFER_BURN_VALUE,
                                                UN_FAVOURITE_IMAGE_URL)

__author__ = 'azeemu@theentertainerasia.com'


class MerchantByIdApiV3(MerchantByIdApiV2):
    """
    @api {GET} /v3/merchants/{merchant_id} Get merchant id
    @apiSampleRequest /v3/merchants/{merchant_id}
    @apiVersion 1.0.0
    @apiName MerchantName
    @apiGroup Merchants
    @apiParam {String}                                  [app_version]           App_version
    @apiParam {Float}                                   [lat]                   Latitude
    @apiParam {Float}                                   [lng]                   Longitude
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}     [currency]    Currency  # noqa:E501
    @apiParam {Boolean}                                 [is_cuckoo]             Is_cuckoo flag
    @apiParam {Boolean}                                 [user_include_cheers]   User_include_cheers flag
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='merchants_service/merchants_by_id_v3.log',
        ),
        'name': 'merchants_by_id_v3'
    }
    request_parser = merchant_by_id_parser_v3
    required_token = True
    # url to communicate redemption service
    redeemability_api_urls = RedemptionServiceAPIUrlsV2

    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Add request arguments of merchant_api
        """
        super().populate_request_arguments()
        self.redeemability = self.request_args.get('redeemability')
        self.offer_id = self.request_args.get('offer_id')
        self.platform = self.request_args.get('platform')
        self.device_key = self.request_args.get('device_key')
        self.new_order_status_flow = self.request_args.get('is_new_order_status_flow')
        self.all_offers_active = self.request_args.get('all_offers_active', True)
        self.show_monthly_offers_on_product = self.request_args.get('show_monthly_product')  # arg from b2c v613
        # TODO: This arg is not added in req.parser. move it to api.cls.vars
        # args from b2c v67
        self.outlet_id = self.request_args.get('outlet_id')
        self.cashless_delivery_enabled = self.request_args.get('cashless_delivery')
        self.live_offers_enabled = self.request_args.get('is_live_offers_enabled')
        self.last_mile_enabled = self.request_args.get('is_last_mile_enabled')
        self.takeaways_enabled = self.request_args.get('is_take_away')
        self.family_feature_enabled = self.request_args.get('is_family_offer')
        self.top_up_offers_enabled = self.request_args.get('is_top_up_offer')
        self.outlet_location_id = self.request_args.get('outlet_location_id')

    def initialize_local_variables(self, *args, **kwargs):
        """
        Initialize local variables
        """
        super().initialize_local_variables()    # local vars from current v2
        # local vars from b2c v67
        self.menus = []
        self.merchant_offer_ids = []
        self.hide_delivery_phone_button = False
        self.delivery_hours_dict = {}
        self.delivery_fee = {}
        self.over_ride_delivery_cart_params = {}
        self.outlet_over_ride_params = {}

        self.top_up_offers = []
        self.shared_offers_received = []
        self.shared_offers_sent = []
        self.outlet_ids_having_offers = []
        self.outlets_filtered = []
        self.offers_array = []
        self.outlet_ids = []

        self.customer_info = {}
        self.get_love_dining_skus = {}
        self.outlet_ids_having_offers = []
        self.outlets_filtered = []
        self.outlet_ids = []
        self.purchasable_product_ids = []     # always empty list
        self.offer_categories = []
        self.offer_sub_categories = []
        self.redeemability_for_delivery = {}
        self.delivery_offers_count = 0

        self.show_pinged_offers_delivery_section = False
        self.show_pinged_offers_non_delivery_section = False
        self.product_name_exists = False
        self.is_any_offer_pingable = False
        self.top_up_offer_against_product = False
        self.has_birthday_month = False
        self.birthday_skus = []
        self.birthday_offers_validity = None
        self.delivery_offers_count = 0
        self.product_id_owned_by_user = []
        self.shared_offers_pinged = []

        self.onboarding_redemption_count = 0
        self.onboarding_status = False
        self.onboarding_end_date = None
        self.shared_offers_received_family = []
        self.shared_offers_pinged_family = []
        self.show_personal_pinged_offers_delivery_section = False
        self.show_personal_pinged_offers_non_delivery_section = False
        self.show_old_delivery = False
        self.ping_details = {}
        self.family_identifier = ""
        self.is_birthday_offer = False
        self.birthday_offer_ids = []
        self.show_cheers_offers = True
        self.outlet_merlin_urls = {}
        self.personal_family_pinged_received = []
        self.personal_cheer_offers = []
        self.environment = current_app.config.get('ENV')

        self.sections = []
        self.is_dc_prospect = False
        self.user_favourite_model = UserFavourites()
        self.company = format_company(self.company)
        self.same_outlet_and_search_location_id = True
        if not self.outlet_location_id:
            self.outlet_location_id = Outlet.get_outlet_location_id(
                merchant_id=kwargs['merchant_id'], outlet_id=self.outlet_id
            )
        if self.outlet_location_id:
            if self.location_id != self.outlet_location_id:
                self.same_outlet_and_search_location_id = False
            self.location_id = self.outlet_location_id

        self.is_travel = self.category == Category.TRAVEL
        self.customer = get_current_customer()

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        self.lat_long = "{},{}".format(self.latitude, self.longitude)
        self.locale = get_locale_location_id(self.locale, self.location_id)

        self.member_group = EntCustomerProfile.MEMBERSTATUS_PROSPECT
        self.is_on_trial = False
        self.is_onboarding = False
        self.is_active_family_member = False
        self.primary_user_id = 0
        self.is_user_account_frozen = False
        self.is_user_onboard = False
        self.is_user_member = False
        self.replace_241_type_with_141 = False

        # API Configurations.
        self.last_mile_enabled = self.last_mile_enabled and self.enable_last_mile
        self.cashless_delivery_enabled = self.cashless_delivery_enabled and self.enable_cashless_delivery
        self.takeaways_enabled = self.takeaways_enabled and self.enable_takeaways
        self.live_offers_enabled = self.live_offers_enabled and self.enable_live_offers
        self.family_feature_enabled = self.family_feature_enabled and self.enable_family_feature
        self.top_up_offers_enabled = self.top_up_offers_enabled and self.enable_top_up_offers
        self.ping_feature_enabled = self.enable_ping_feature
        self.birthday_feature_enabled = self.enable_birthday_feature
        self.smile_feature_enabled = self.enable_smile_feature
        self.table_reservation_enabled = self.enable_table_reservation
        self.cinema_enabled = self.enable_cinema_integration

    def get_company_configs(self):
        """
        get company specific configs
        - set config flags
        """
        self.configs = self.customer.get('api_configs', {})
        self.is_ent = self.configs.get('company_type') == ENT_COMPANY_TYPE
        self.enable_family_feature = self.configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE)
        self.enable_ping_feature = self.configs.get(ApiConfiguration.ENABLE_PING_FEATURE)
        self.enable_cashless_delivery = self.configs.get(ApiConfiguration.ENABLE_DELIVERY_CASHLESS)
        self.enable_smile_feature = self.configs.get(ApiConfiguration.ENABLE_SMILE_FEATURE)
        self.enable_last_mile = self.configs.get(ApiConfiguration.ENABLE_LAST_MILE)
        self.enable_cinema_integration = self.configs.get(ApiConfiguration.ENABLE_CINEMA_INTEGRATION)
        self.enable_live_offers = self.configs.get(ApiConfiguration.ENABLE_LIVE_OFFERS)
        self.enable_takeaways = self.configs.get(ApiConfiguration.ENABLE_TAKEAWAYS)
        self.enable_birthday_feature = self.configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE)
        self.enable_table_reservation = self.configs.get(ApiConfiguration.ENABLE_TABLE_RESERVATION)
        self.enable_top_up_offers = self.configs.get(ApiConfiguration.ENABLE_TOP_UP_OFFERS)

    def set_current_customer_data(self):
        """
        Sets current customer data
        - get customer info from decoded jwt
        - if company `is_ent`
            - set `is_user_onboard` from user member_type_id compared to
            - set `product_id_owned_by_user` as customer product ids
        - else v2 flow
        """
        self.customer_id = self.customer.get('customer_id')
        self.is_customer_logged_in = self.customer['is_user_logged_in']

        if self.is_ent:
            self.product_id_owned_by_user = self.customer.get('product_ids')
            if self.customer and self.customer.get('product_ids'):
                self.customer['product_ids'] = list(map(int, filter(None, self.customer['product_ids'])))
        else:
            super().set_current_customer_data()

    def get_merchant(self, **kwargs):
        """
        Finds merchant by supplied id
        - check if company type is `'ent'` then find merchant with selected category else without it.
        """
        selected_category = None
        if self.is_ent:
            if self.category in VALID_CATEGORIES:
                selected_category = self.category
        self.merchant = Merchant.find_by_id(
            merchant_id=kwargs.get('merchant_id'),
            locale=self.message_locale,
            selected_category=selected_category
        )
        if self.merchant:
            self.merchant = self.merchant._asdict()
            process_merchant(self.merchant, skip_app_version_check=True)
            self.merchant['cuisines'] = split_and_filter_null_entries(self.merchant['cuisines'], ';')
            self.merchant['sub_categories'] = list(filter(None, (self.merchant['sub_categories'] or '').split(',')))
            self.merchant['offer_categories'] = split_and_filter_null_entries(self.merchant['offer_categories'], ',')
            self.merchant['categories'] = split_and_filter_null_entries(self.merchant['merchant_categories'], ';')
            self.merchant['merchant_categories'] = self.merchant['categories']
            self.merchant['booking_request'] = self.merchant.get('booking_request').decode('utf-8')
            self.merchant['categories_analytics'] = get_analytics_codes_against_categories(
                self.merchant['merchant_categories']
            )
            if self.merchant.get('offer_categories'):
                self.merchant['categories'] = self.merchant['offer_categories']
        else:
            self.send_response_flag = True
            self.status_code = codes.unprocessable
            self.response = {
                'success': False,
                'message': TranslationManager.get_translation(
                    TranslationManager.merchant_details_not_found,
                    self.message_locale
                ),
                'code': 70
            }
            return self.send_response(self.response, self.status_code)

        self.data = []

    def get_customer_profile(self):
        """
        Gets customer info from EntCustomerProfile model.
        """
        if self.is_customer_logged_in:
            self.customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(self.customer_id)

    def set_customer_features(self):
        """
        - set customer member_group
        - set customer on_boarding status
        - Family feature check
            - set flags from customer session dict
        - Ping feature check
            - check validity and calculate pings
        - get user `birth_date` from customer_profile obj
            - validate birth date
                - Assign the Birthday Skus against all the locations to member on his/her birthday
        """
        if self.is_customer_logged_in and self.customer_profile:
            self.is_user_member = self.customer.get('member_type_id') == EntCustomerProfile.MEMBERSTATUS_MEMBER
            self.member_group = self.customer_profile.new_member_group
            self.is_onboarding = self.member_group == EntCustomerProfile.MEMBERSTATUS_ONBOARDING
            self.is_user_onboard = self.customer.get('member_type_id') == EntCustomerProfile.MEMBERSTATUS_ONBOARDING
            self.onboarding_redemption_count = self.customer_profile.onboarding_redemptions_count or 0
            self.onboarding_status = self.customer_profile.onboarding_status or 0

            if self.family_feature_enabled:
                self.is_active_family_member = (
                    self.customer.get('family_is_active') and
                    self.customer.get('is_user_in_family')
                )
                if self.is_active_family_member:
                    if self.customer.get('is_primary'):
                        self.primary_user_id = self.customer_id
                    else:
                        self.primary_user_id = self.customer.get('primary_member_info').user_id
                        self.show_cheers_offers = self.customer.get('family_member_info').is_cheers_to_include

                    self.family_identifier = self.customer.get('family_member_info').identifier
                    self.member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER

            if self.ping_feature_enabled:
                if (
                    not self.is_active_family_member and
                    self.is_user_member
                ):
                    if not self.cashless_delivery_enabled:
                        self.ping_details = get_ping_details(
                            self.customer_id,
                            self.customer['member_type_id'],
                            self.product_id_owned_by_user,
                            True,
                            is_family_member=self.is_active_family_member,
                        )
                else:
                    product_ids_owned = self.product_id_owned_by_user
                    if self.customer['owns_cheer_products'] and not self.show_cheers_offers:
                        product_ids_owned = list(
                            map(int,
                                filter(
                                    None,
                                    self.customer['product_ids'] + self.customer.get('cheers_product_ids', [])
                                ))
                        )
                    if not self.cashless_delivery_enabled:
                        self.ping_details = get_ping_details(
                            self.primary_user_id, self.customer['member_type_id'],
                            product_ids_owned, True,
                            is_family_member=self.is_active_family_member,
                            primary_user_id=self.primary_user_id
                        )

            if self.birthday_feature_enabled:
                if self.is_user_member or self.is_active_family_member:
                    birth_date = self.customer_profile.birthdate
                    if birth_date:
                        number_of_birthday_validity_days = get_birthday_offer_validity_in_days(birth_date)
                        if number_of_birthday_validity_days > -1:
                            self.has_birthday_month = True
                            self.birthday_offer_ids = Product.get_birthday_products_with_id(self.location_id)
                            self.customer['product_ids'] = (
                                self.customer.get('product_ids', []) + self.birthday_offer_ids
                            )
                            self.birthday_offers_validity = get_birthday_offer_validity()

    def set_is_on_trial(self):
        """
        - Get user's `on_boarding_redemption_limit` or `ONBOARDING_LIMIT`
        - set `is_on_trial` flag
        """
        if self.is_customer_logged_in:
            on_boarding_redemption_limit = (
                self.customer_profile.onboarding_redemptions_limit or
                EntCustomerProfile.ONBOARDING_LIMIT
            )

            if (
                self.is_onboarding and
                self.onboarding_status == EntCustomerProfile.ONBOARDING_INPROGRESS and
                self.onboarding_redemption_count < on_boarding_redemption_limit
            ):
                self.is_on_trial = True

    def get_smiles_balance_and_update_merchant(self):
        """
        - set user_id
        - query user_smile_summary model to get smiles
        - update merchant dict with smiles
        """
        if self.smile_feature_enabled:
            if self.is_active_family_member:
                user_id = self.primary_user_id
            else:
                user_id = self.customer_id

            smiles_total_balance = UserSmileSummary.get_user_smiles_from_gamification_db(user_id)

            try:
                smiles_total_balance = int(smiles_total_balance.smiles)
            except (ValueError, TypeError):
                smiles_total_balance = 0

            self.merchant['smiles_total_balance'] = smiles_total_balance
            self.merchant['is_pingable'] = bool(self.merchant['is_pingable'])
            self.merchant['is_tutorial'] = self.merchant['is_tutorial'] > 0

    def set_order_addresses(self):
        """
        - get user's delivery addresses
        - generate a list of address from orm objs
        - update merchant dict
        """
        if self.smile_feature_enabled and self.cashless_delivery_enabled:
            addresses_list = []
            delivery_addresses = DmUserDeliveryAddres.get_customer_delivery_addresses(self.customer_id)
            for delivery_address in delivery_addresses:
                addresses_list.append({
                    'deliveryAddressName': delivery_address.title,
                    'street': delivery_address.street,
                    'areaORCity': delivery_address.area_city,
                    'specialInstructions': delivery_address.special_instructions,
                    "latitude": delivery_address.latitude,
                    "longitude": delivery_address.longitude,
                })
            self.merchant['selected_locations'] = addresses_list

    def get_last_mile_outlet_delivery_regions(self, outlet_bands, outlet_settings):
        """
        Get last mile outlet delivery regions
        :param dict outlet_bands: outlet bands
        :param kwargs outlet_settings: outlet settings
        """
        geo_point = get_geo_point_from_lat_lng(
            lat=self.latitude,
            lng=self.longitude,
            location_id=self.location_id,
            company=self.company
        )
        for band_index, band_obj in enumerate(outlet_bands):
            band = band_obj._asdict()
            area_coordinates = band['polygon_coordinates']
            delivery_region = []
            map_type = band.get('map_type', DmDevice.POLYGON_SHAPE_CONSTANT)
            outlet_exist_in_region = False
            set_merchant_delivery_region = False
            radius = 0
            band_latitude = 0.0
            band_longitude = 0.0
            destinations = []
            bands_coordinates = []
            if area_coordinates:
                area_coordinates = json.loads(area_coordinates)
                if isinstance(area_coordinates, str):
                    area_coordinates = json.loads(area_coordinates)
                shape = None
                if map_type == DmDevice.POLYGON_SHAPE_CONSTANT:
                    try:
                        shape = Polygon(area_coordinates[0])
                        bands_coordinates.append(area_coordinates)
                    except Exception:
                        continue
                elif map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                    try:
                        radius = area_coordinates.get('radius', 0)
                        band_latitude = area_coordinates.get('lat', 0)
                        band_longitude = area_coordinates.get('lng', 0)
                        shape = Point(band_longitude, band_latitude).buffer(
                            (radius / RADIUS_CONVERSION_UNIT)
                        )
                        # circle coordinates
                        area_coordinates = mapping(shape)['coordinates']
                        bands_coordinates.append(area_coordinates)
                    except Exception:
                        continue
                if shape:
                    destinations.append(shape)
                if shape and shape.contains(geo_point) and not outlet_exist_in_region:
                    if band['average_drop_off_time']:
                        outlet_settings.average_drop_off_time = band.get('average_drop_off_time', 0)
                    self.over_ride_delivery_cart_params = {}
                    self.over_ride_delivery_cart_params['zone_id'] = band.get('outlet_zone_id', 0)
                    set_merchant_delivery_region = True
                for coordinates in area_coordinates:
                    _regions = dict()
                    _regions['coordinates'] = []
                    for inner_coordinate in coordinates:
                        coordinates_info = {
                            "lat": inner_coordinate[1],
                            "lng": inner_coordinate[0]
                        }
                        delivery_region.append(coordinates_info)
                        _regions['coordinates'].append(coordinates_info)
                    _regions['title'] = 'region_{index}'.format(index=band_index + 1)
                    _regions['zone_id'] = band.get('outlet_zone_id', 0)
                    _regions['map_shape_info'] = {}
                    _regions['map_shape_info']['shape_type'] = map_type
                    if map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                        _regions['map_shape_info']['radius'] = radius
                        _regions['map_shape_info']['lat'] = band_latitude
                        _regions['map_shape_info']['lng'] = band_longitude
                    self.merchant['delivery_regions'].append(_regions)
                if set_merchant_delivery_region:
                    self.merchant['delivery_region'] = delivery_region
            elif not area_coordinates:
                shape = None
                if map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                    try:
                        radius = self.band_end_range
                        band_latitude = band.get('lat', 0)
                        band_longitude = band.get('lng', 0)
                        shape = Point(band_longitude, band_latitude).buffer(
                            (radius / RADIUS_CONVERSION_UNIT)
                        )
                        # circle coordinates
                        area_coordinates = mapping(shape)['coordinates']
                        bands_coordinates.append(area_coordinates)
                    except Exception:
                        continue
                if shape:
                    destinations.append(shape)
                if band['average_drop_off_time']:
                    outlet_settings.average_drop_off_time = band.get('average_drop_off_time', 0)
                self.over_ride_delivery_cart_params = {}
                self.over_ride_delivery_cart_params['zone_id'] = band.get('outlet_zone_id', 0)
                set_merchant_delivery_region = True
                for coordinates in area_coordinates:
                    _regions = dict()
                    _regions['coordinates'] = []
                    _regions['is_enabled'] = False
                    for inner_coordinate in coordinates:
                        coordinates_info = {
                            "lat": inner_coordinate[1],
                            "lng": inner_coordinate[0]
                        }
                        delivery_region.append(coordinates_info)
                        _regions['coordinates'].append(coordinates_info)
                    _regions['title'] = 'region_{index}'.format(index=band_index + 1)
                    _regions['zone_id'] = band.get('outlet_zone_id', 0)
                    if _regions['coordinates']:
                        _regions['is_enabled'] = True
                    _regions['map_shape_info'] = {}
                    _regions['map_shape_info']['shape_type'] = map_type
                    if map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                        _regions['map_shape_info']['radius'] = radius
                        _regions['map_shape_info']['lat'] = band_latitude
                        _regions['map_shape_info']['lng'] = band_longitude
                    self.merchant['delivery_regions'].append(_regions)
                if set_merchant_delivery_region:
                    self.merchant['delivery_region'] = delivery_region

    def get_delivery_details(self, **kwargs):
        """
        Get delivery details i.e standard delivery flow or last mile flow.
        """
        self.device_info = {}
        self.customer_last_mile_band_id = None
        customer_within_last_mile_band = False
        self.outlet_info = Outlet.get_outlet_lat_lng_band_info(self.outlet_id, self.location_id)
        if self.outlet_info:
            outlet_settings = DmOutletSetting.get_merchant_delivery_details(
                kwargs['merchant_id'], self.outlet_id, location_id=self.location_id
            )
            # Only if outlet has cash less delivery and has last band delivery 'True'.
            if (
                    self.cashless_delivery_enabled and
                    self.last_mile_enabled and
                    hasattr(self.outlet_info, 'last_mile_delivery') and
                    not self.takeaways_enabled
            ):
                self.merchant['is_last_mile_delivery'] = True
                # Find the distance between customer and outlet.
                distance = find_distance(
                    self.latitude,
                    self.longitude,
                    self.outlet_info.lat,
                    self.outlet_info.lng
                )
                outlet_band_in_location = QuiqUpSetting.get_band_range_info(self.location_id)
                if self.outlet_info.bands:
                    outlet_band_ids = [int(outlet_band_id) for outlet_band_id in self.outlet_info.bands.split(',')]
                    for band in outlet_band_in_location:
                        if band.id in outlet_band_ids:
                            band_start_range = band.start_range or 0
                            band_end_range = band.end_range or 0
                            if distance >= 0 and (band_start_range <= distance <= band_end_range):
                                self.customer_last_mile_band_id = band.id
                                customer_within_last_mile_band = True
                                self.band_start_range = band_start_range
                                self.band_end_range = band_end_range

                self.merchant['cashless_delivery'] = bool(self.cashless_delivery_enabled)
                self.merchant['d_cart_url'] = current_app.config['D_CART_URL']
                self.merchant['edit_order_timer_value'] = EDIT_ORDER_TIMER_VALUE
                self.merchant['edit_order_idle_timer_value'] = EDIT_ORDER_IDLE_TIMER_VALUE
                self.merchant['outletCurrency'] = outlet_settings.currency
                self.merchant['offersDetail'] = []
                if outlet_settings:
                    self.merchant['allergyTitle'] = ALLERGY_INFORMATION_TITLE
                    self.merchant['allergyDetail'] = outlet_settings.allergy_information or ''
                    self.device_info = DmDevice.get_dm_devices_against_merchant_id(
                        merchant_id=kwargs['merchant_id'],
                        outlet_id=self.outlet_id
                    )
                    if self.device_info:
                        self.merchant['device_id'] = self.device_info.device_id
                self.outlet_bands = DmAreaCoordinate.get_area_coordinates_v3(
                    kwargs['merchant_id'], self.outlet_id, self.customer_last_mile_band_id
                )
                self.merchant['delivery_region'] = []
                self.merchant['delivery_regions'] = []

            user_location = Location.get_location_id(
                company=self.company,
                is_ent=self.is_ent,
                latitude=self.latitude,
                longitude=self.longitude,
                quiq_up_order_flow=True
            )

            # Only if customer within outlet's last mile bands.
            if (
                self.last_mile_enabled and
                customer_within_last_mile_band and
                not self.takeaways_enabled and
                user_location == DUBAI_LOCATION_ID
            ):
                if self.outlet_bands:
                    if speedups.available:
                        speedups.enable()
                    self.get_last_mile_outlet_delivery_regions(self.outlet_bands, outlet_settings)
                self.merchant['is_open'], delivery_hours = calculate_outlet_availability(
                    self.device_info.last_ping or 0,
                    self.device_info.is_device_online or False,
                    outlet_settings.delivery_start_time or 0,
                    outlet_settings.delivery_end_time or 0,
                    outlet_settings.total_minutes or 0,
                    self.location_id
                )
                if self.merchant['is_open']:
                    quiqup_service_availability = get_quip_up_service_availability()
                    if not quiqup_service_availability:
                        self.merchant['is_open'] = 0
                    elif quiqup_service_availability.get('delay_message'):
                        try:
                            quiqup_service_delay_message = APIMessages.get_api_message_for_quiqup_delay_service(self.locale)            # NOQA
                        except Exception:
                            quiqup_service_delay_message = ''
                        if not quiqup_service_delay_message:
                            quiqup_service_delay_message = quiqup_service_availability.get('delay_message')
                        self.merchant['last_mile_delivery_message'] = quiqup_service_delay_message

                delivery_timing = DELIVERY_TIMINGS
                delivery_timing["value"] = "{} mins".format(outlet_settings.default_delivery_time or 60)
                self.merchant['offersDetail'] = [delivery_timing]
                self.merchant['outletCurrency'] = outlet_settings.currency or AED
            elif (
                    not customer_within_last_mile_band and
                    self.outlet_info.last_mile_delivery and
                    not self.takeaways_enabled
            ):
                self.merchant['is_open'] = 0
                delivery_timing = DELIVERY_TIMINGS
                delivery_timing["value"] = "{} mins".format(outlet_settings.default_delivery_time or 60)
                self.merchant['offersDetail'] = [delivery_timing]
                self.merchant['outletCurrency'] = outlet_settings.currency or AED

            # if customer isn't in last mile band
            elif self.cashless_delivery_enabled and not self.outlet_info.last_mile_delivery:
                self.merchant['cashless_delivery'] = True
                self.merchant['d_cart_url'] = current_app.config['D_CART_URL']
                self.merchant['edit_order_timer_value'] = EDIT_ORDER_TIMER_VALUE
                self.merchant['edit_order_idle_timer_value'] = EDIT_ORDER_IDLE_TIMER_VALUE
                self.merchant['outletCurrency'] = outlet_settings.currency or AED  # Default currency
                self.merchant['offersDetail'] = []
                if outlet_settings and not self.takeaways_enabled:
                    self.merchant['allergyTitle'] = ALLERGY_INFORMATION
                    self.merchant['allergyDetail'] = outlet_settings.allergy_information or ''
                    device_info = DmDevice.get_dm_devices_against_merchant_id(
                        merchant_id=kwargs['merchant_id'],
                        outlet_id=self.outlet_id
                    )
                    if device_info:
                        self.merchant['device_id'] = device_info.device_id
                    outlet_zones = DmAreaCoordinate.get_area_coordinates_v3(kwargs['merchant_id'], self.outlet_id)
                    self.merchant['delivery_region'] = []
                    self.merchant['delivery_regions'] = []
                    destinations = []
                    zones_coordinates = []
                    if outlet_zones:
                        if speedups.available:
                            speedups.enable()
                        geo_point = get_geo_point_from_lat_lng(
                            lat=self.latitude,
                            lng=self.longitude,
                            location_id=self.location_id,
                            company=self.company
                        )
                        for zone_index, zone in enumerate(outlet_zones):
                            area_coordinates = zone.polygon_coordinates
                            delivery_region = []
                            map_type = zone.map_type or DmDevice.POLYGON_SHAPE_CONSTANT
                            outlet_exist_in_region = False
                            set_merchant_delivery_region = False
                            radius = 0
                            zone_latitude = 0.0
                            zone_longitude = 0.0
                            if area_coordinates:
                                area_coordinates = json.loads(area_coordinates)
                                if isinstance(area_coordinates, str):
                                    area_coordinates = json.loads(area_coordinates)
                                shape = None
                                if map_type == DmDevice.POLYGON_SHAPE_CONSTANT:
                                    try:
                                        shape = Polygon(area_coordinates[0])
                                        zones_coordinates.append(area_coordinates)
                                    except Exception:
                                        continue
                                elif map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                                    try:
                                        radius = area_coordinates.get('radius')
                                        zone_latitude = area_coordinates.get('lat')
                                        zone_longitude = area_coordinates.get('lng')
                                        shape = Point(zone_longitude, zone_latitude).buffer(
                                            (radius / RADIUS_CONVERSION_UNIT)
                                        )
                                        # circle coordinates
                                        area_coordinates = mapping(shape)['coordinates']
                                        zones_coordinates.append(area_coordinates)
                                    except Exception:
                                        continue
                                if shape:
                                    destinations.append(shape)
                                if shape and shape.contains(geo_point) and not outlet_exist_in_region:
                                    if zone.default_delivery_time:
                                        outlet_settings.default_delivery_time = zone.default_delivery_time
                                    self.over_ride_delivery_cart_params = {}
                                    self.over_ride_delivery_cart_params['zone_id'] = zone.outlet_zone_id or 0
                                    outlet_exist_in_region = True
                                    set_merchant_delivery_region = True
                                for coordinates in area_coordinates:
                                    _regions = dict()
                                    _regions['coordinates'] = []
                                    for inner_coordinate in coordinates:
                                        coordinates_info = {
                                            "lat": inner_coordinate[1],
                                            "lng": inner_coordinate[0]
                                        }
                                        delivery_region.append(coordinates_info)
                                        _regions['coordinates'].append(coordinates_info)
                                    _regions['title'] = 'region_{index}'.format(index=zone_index + 1)
                                    _regions['zone_id'] = zone.outlet_zone_id or 0
                                    _regions['map_shape_info'] = {}
                                    _regions['map_shape_info']['shape_type'] = map_type
                                    if map_type == DmDevice.CIRCLE_SHAPE_CONSTANT:
                                        _regions['map_shape_info']['radius'] = radius
                                        _regions['map_shape_info']['lat'] = zone_latitude
                                        _regions['map_shape_info']['lng'] = zone_longitude
                                    delivery_timing = DELIVERY_TIMINGS
                                    delivery_timing["value"] = "{} mins".format(zone.default_delivery_time)
                                    _regions['delivery_rules'].append(delivery_timing)
                                    delivery_fee = {
                                        "type": 1,
                                        "key": "delivery_fee",
                                        "name": "Delivery Fee",
                                        "image_url": "",
                                        "value": "{0} {1:.2f}".format(
                                            self.merchant.get('outletCurrency', 'AED'),
                                            zone.del_charge_total or zone.del_charge_min or 0.0
                                        )
                                    }
                                    _regions['delivery_rules'].append(delivery_fee)
                                    if zone.min_order_amount or 0:
                                        min_order_amount = {
                                            "type": 0,
                                            "key": "minimum",
                                            "name": "Min order after discount",
                                            "image_url": "https://d30y9cdsu7xlg0.cloudfront.net/png/21216-200.png",
                                            "value": "{0} {1:.2f}".format(self.merchant.get('outletCurrency', 'AED'),
                                                                          zone.min_order_amount)
                                        }
                                        _regions['delivery_rules'].append(min_order_amount)
                                    self.merchant['delivery_regions'].append(_regions)
                                if set_merchant_delivery_region:
                                    self.merchant['delivery_region'] = delivery_region
                                    set_merchant_delivery_region = False

                        #  If delivery location doesn't exist in any zone then find the nearest zone and
                        #  set in delivery region.
                        if not self.merchant['delivery_region'] and destinations:
                            distances = []
                            for destination in destinations:
                                distances.append(destination.exterior.distance(geo_point))
                            minimum_distance_zone_index = distances.index(min(distances))
                            for coordinates in zones_coordinates[minimum_distance_zone_index]:
                                for inner_coordinate in coordinates:
                                    self.merchant['delivery_region'].append({
                                        "lat": inner_coordinate[1], "lng": inner_coordinate[0]
                                    })

                        self.merchant['is_open'], delivery_hours = calculate_outlet_availability(
                            device_info.last_ping,
                            device_info.is_device_online,
                            outlet_settings.delivery_start_time,
                            outlet_settings.delivery_end_time,
                            outlet_settings.total_minutes or 0,
                            self.location_id
                        )
                        delivery_timing = DELIVERY_TIMINGS
                        delivery_timing["value"] = "{} mins".format(outlet_settings.default_delivery_time)
                        self.delivery_hours_dict = DELIVERY_HOURS
                        self.delivery_hours_dict["value"] = delivery_hours
                        self.merchant['offersDetail'] = [delivery_timing]
                        self.merchant['outletCurrency'] = outlet_settings.currency
                else:
                    self.merchant['allergyTitle'] = ALLERGY_INFORMATION
                    self.merchant['allergyDetail'] = outlet_settings.allergy_information or ''
                    device_info = DmDevice.get_dm_devices_against_merchant_id(
                        merchant_id=kwargs['merchant_id'],
                        outlet_id=self.outlet_id
                    )
                    if device_info:
                        self.merchant['device_id'] = device_info.device_id
                    self.merchant['is_open'], delivery_hours = calculate_outlet_availability(
                        device_info.last_ping,
                        device_info.is_device_online,
                        outlet_settings.delivery_start_time,
                        outlet_settings.delivery_end_time,
                        outlet_settings.total_minutes,
                        self.location_id
                    )
            elif self.cashless_delivery_enabled and self.takeaways_enabled:

                self.merchant['cashless_delivery'] = True
                self.merchant['d_cart_url'] = current_app.config['D_CART_URL']
                self.merchant['edit_order_timer_value'] = EDIT_ORDER_TIMER_VALUE
                self.merchant['edit_order_idle_timer_value'] = EDIT_ORDER_IDLE_TIMER_VALUE
                self.merchant['outletCurrency'] = outlet_settings.currency or AED  # currency from settings
                self.merchant['offersDetail'] = []
                self.merchant['allergyTitle'] = ALLERGY_INFORMATION
                self.merchant['allergyDetail'] = outlet_settings.allergy_information or ''

                device_info = DmDevice.get_dm_devices_against_merchant_id(
                    merchant_id=kwargs['merchant_id'],
                    outlet_id=self.outlet_id
                )

                if device_info:
                    self.merchant['device_id'] = device_info.device_id

                self.merchant['is_open'], delivery_hours = calculate_outlet_availability(
                    device_info.last_ping,
                    device_info.is_device_online,
                    outlet_settings.delivery_start_time,
                    outlet_settings.delivery_end_time,
                    outlet_settings.total_minutes,
                    self.location_id
                )

            if not self.same_outlet_and_search_location_id:
                self.merchant['is_open'] = 0

    def get_merchant_attributes(self, **kwargs):
        """
        Gets merchant attributes
        """
        self.merchant['is_tutorial'] = self.merchant.get('is_tutorial') > 0

        merchant_attributes = get_merchant_attributes_by_merchant_id(
            merchant_id=kwargs.get('merchant_id'),
            merchant_category=self.merchant.get('category'),
        )

        if merchant_attributes:
            self.merchant_attributes = format_merchant_attributes(
                kwargs.get('merchant_id'),
                merchant_attributes,
                self.merchant.get('category'),
                self.message_locale,
            )
        else:
            self.merchant_attributes = None

    def check_dc_prospect_enabled_on_merchant(self):
        """
        Check is dc prospect enabled on merchant level or not
        User should not be the part of family and also should not be a member
        Merchant should have dc_prospect feature enabled.
        """
        self.is_dc_prospect = (
            not self.customer.get('is_user_in_family', True) and
            self.customer.get('member_type_id', 0) != EntCustomerProfile.MEMBERSTATUS_MEMBER and
            self.merchant.get('dc_prospect_enabled')
        )

    def get_active_outlets(self, **kwargs):
        """
        Grab active outlets for this merchant
        :param kwargs:
        """
        self.outlets = []
        self.outlet_ids = []

        self.outlets = Outlet.find_by_merchant_v3(
            merchant_id=kwargs['merchant_id'],
            outlet_id=self.outlet_id,
            locale=self.locale,
            cashless_delivery=self.cashless_delivery_enabled,
            table_reservation_enabled=self.table_reservation_enabled,
            table_booking_location_id=self.location_id,
            company=self.company
        )
        if self.outlets:
            self.outlet_ids = inject_distances_and_sort_v3(
                self.outlets,
                self.lat_long,
                platform=self.platform,
                do_extra_work=True,
                return_ids=True,
                device_key=self.device_key,
                merchant_contact_number=self.merchant['delivery_contact_no']
            )

            for outlet in self.outlets:
                # The app will use this param to show and hide the trip advisor section
                outlet['is_open'] = 1
                if self.cashless_delivery_enabled and outlet.get('last_mile_delivery'):
                    outlet['is_open'] = 0

                outlet['show_trip_adv_section'] = outlet.get('tripadvisor_id') > 0
                outlet['tb_reservation_disabled'] = int(outlet.get('tb_reservation_disabled', 1))

                if not self.table_reservation_enabled or not outlet['table_reservation_enabled']:
                    outlet['table_reservation_enabled'] = False

                if outlet['show_trip_adv_section']:
                    outlet['trip_adv_webview_link'] = '{ta_web_url}{ta_location_id}'.format(
                        ta_web_url=current_app.config.get('TRIPADVISOR_WEB_URL'),
                        ta_location_id=outlet.get('tripadvisor_id')
                    )

        if self.outlets and self.outlet_id and self.cashless_delivery_enabled:
            outlet = self.outlets[0]
            if not outlet['delivery_telephone']:
                self.hide_delivery_phone_button = True
            redemptions_left_for_trail = EntCustomerProfile.TRAIL_REDEMPTIONS_LIMIT
            redemptions_left_for_trail -= self.customer.get("onboarding_redemptions_count", 0)

            # is_dc_prospect flag will be used to hide smiles in case of DC-Prospect on Order Basket Screen by web.
            self.check_dc_prospect_enabled_on_merchant()

            delivery_cart_params = {
                "min_order_amount": outlet['min_order_amount'],
                "del_charge_total": outlet['del_charge_total'],
                "del_charge_min": outlet['del_charge_min'],
                "min_order_cap": bool(outlet['min_order_cap']),
                "del_charge_on_total_order": False,
                "del_charge_on_less_than_min": False,
                "smiles_total_balance": self.merchant.get('smiles_total_balance', 0),
                "is_member_on_trial": self.customer.get('is_member_on_trial', False),
                "redemptions_left_for_trail": redemptions_left_for_trail,
                'company': self.customer.get('company', 'entertainer'),
                'is_take_away_order': self.takeaways_enabled,
                'dc_prospect_user': self.is_dc_prospect
            }
            if self.takeaways_enabled:
                delivery_cart_params['min_order_cap'] = False
                delivery_cart_params['del_charge_min'] = 0

            if self.over_ride_delivery_cart_params:
                delivery_cart_params.update(self.over_ride_delivery_cart_params)

            if self.outlet_over_ride_params:
                outlet.update(self.outlet_over_ride_params)

            if outlet['del_charge_on_less_than_min'] and not self.takeaways_enabled:
                delivery_cart_params['del_charge_on_less_than_min'] = generic_boolean_conversion(
                    outlet['del_charge_on_less_than_min']
                )

            if outlet['del_charge_on_total_order'] and not self.takeaways_enabled:
                delivery_cart_params['del_charge_on_total_order'] = generic_boolean_conversion(
                    outlet['del_charge_on_total_order']
                )
            if outlet['min_order_cap'] and not self.takeaways_enabled:
                delivery_cart_params['min_order_cap'] = generic_boolean_conversion(outlet['min_order_cap'])

            self.merchant['delivery_cart_params'] = delivery_cart_params
            self.merchant['deliveryCharges'] = outlet['del_charge_total']
            self.merchant['noDeliveryFeeAboveAmount'] = outlet['del_charge_min']
            self.merchant['minimum_order_amount'] = int(outlet['min_order_amount'])
            self.merchant['delivery_minimum_amount_message'] = TranslationManager.get_translation(
                TranslationManager.MINIMUM_DELIVERY_FEE, self.message_locale
            ).format(
                currency=self.merchant.get('outletCurrency', AED),  # For Now
                delivery_fee=round(outlet['del_charge_total']),
                delivery_minimum_amount=round(outlet['min_order_amount'])
            )
            if outlet['min_order_amount']:
                min_order_amount = {
                    "type": 0,
                    "key": "minimum",
                    "name": "Min order after discount",
                    "image_url": "https://d30y9cdsu7xlg0.cloudfront.net/png/21216-200.png",
                    "value": "{0} {1:.2f}".format(self.merchant.get('outletCurrency', 'AED'), outlet['min_order_amount'])
                }
                if self.merchant.get('offersDetail'):
                    self.merchant['offersDetail'].append(min_order_amount)
                else:
                    self.merchant['offersDetail'] = [min_order_amount]

            delivery_fee_value = self.merchant['delivery_cart_params'].get('del_charge_total', 0)
            if not delivery_fee_value:
                delivery_fee_value = self.merchant['delivery_cart_params'].get('del_charge_min', 0)

            if not self.takeaways_enabled:
                self.delivery_fee = {
                    "type": 1,
                    "key": "delivery_fee",
                    "name": "Delivery Fee",
                    "image_url": "",
                    "value": "{0} {1:.2f}".format(
                        self.merchant.get('outletCurrency', 'AED'),
                        delivery_fee_value
                    )
                }
                self.merchant['offersDetail'].append(self.delivery_fee)

            else:
                # This will work for takeaways outlets to get outlet average prep time.
                outlet_avg_prep_time = DmOutletSetting.get_outlet_avg_prep_time(outlet_id=outlet.get('id', ''))
                self.order_prep_time = {
                    "type": 1,
                    "key": Outlet.AVERAGE_PREP_TIME_KEY,
                    "name": Outlet.AVERAGE_PREP_TIME_TEXT,
                    "image_url": "",
                    "value": "{time} minutes".format(
                        time=outlet_avg_prep_time
                    )
                }
                self.merchant['offersDetail'].append(self.order_prep_time)

    def get_buy_back_offers_array(self):
        """
        - if user is logged_in and has family feature
            - calculate and get top up offers for user
        """

        if self.top_up_offers_enabled:
            if self.customer.get('is_user_logged_in'):
                if self.family_feature_enabled and self.is_active_family_member:
                    self.top_up_offers = TopUpOffer.get_top_up_offers_primary(
                        customer_id=self.primary_user_id,
                        location_id=self.location_id,
                        merchant_id=self.merchant['id'],
                        offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY
                    )
                else:
                    self.top_up_offers = TopUpOffer.get_top_up_offers_primary(
                        customer_id=self.customer_id,
                        location_id=self.location_id,
                        merchant_id=self.merchant['id'],
                        offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY
                    )

    def load_customer_object(self):
        """
        - get user obj from User table
        - check user status, if status -> frozen set flag.
        - update user_info from customer_profile obj
        - get demographic info of user
        - calculate family shared offers
        - update user_info dict with new keys
        """
        if self.is_customer_logged_in and self.customer_profile:
            user_info = User.load_customer_by_id(self.customer['customer_id'])
            if user_info:
                status = user_info.status
                if status in (
                    EntCustomerProfile.STATUS_FROZEN,
                    EntCustomerProfile.STATUS_BLACKLISTED,
                    EntCustomerProfile.STATUS_TEMPORARILY_WHITELISTED
                ):
                    self.is_user_account_frozen = True

            self.customer_info["is_user_account_frozen"] = self.is_user_account_frozen
            self.customer_info["user_id"] = self.customer_id
            self.customer_info["member_type"] = self.member_group
            self.customer_info["membership_expiration_date"] = self.customer_profile.membership_expiry
            self.customer_info["using_trial"] = (self.customer_profile.onboarding_status == 1)
            self.customer_info['is_demographics_updated'] = 0

            customer_demo_info = EntCustomerProfile.get_demographics_info(self.customer_id)
            if customer_demo_info:
                if customer_demo_info.gender and customer_demo_info.nationality and customer_demo_info.birthdate:
                    self.customer_info['is_demographics_updated'] = 1

            self.customer_info["max_number_allowed_shares"] = 0
            self.customer_info["total_shares"] = 0
            if not self.cashless_delivery_enabled:
                if self.family_feature_enabled and self.is_active_family_member:
                    self.shared_offers_received_family = ShareOffer.get_shared_offers_accepted_family(
                        self.primary_user_id
                    )

                    self.shared_offers_pinged_family = ShareOffer.get_shared_offers_by_sender_merchant_controller(
                        sender_id=self.customer_id,
                        primary_user_id=self.primary_user_id
                    )

                    if self.primary_user_id == self.customer_id:
                        self.shared_offers_received = ShareOffer.get_shared_offers_accepted(
                            recipient_id=self.customer_id,
                            primary_user_id=self.primary_user_id,
                            get_family_flag=True
                        )
                    else:
                        self.shared_offers_received = ShareOffer.get_personal_shared_offers_accepted_for_secondary(
                            recipient_id=self.customer_id,
                            get_family_flag=True
                        )
                    # To show cheers offers before joining family after cheer consent.
                    for shared_offer_received_personal in self.shared_offers_received:
                        if not shared_offer_received_personal.get('is_family_offer'):
                            self.personal_cheer_offers.append(shared_offer_received_personal.get('offer_id', 0))
                else:
                    self.shared_offers_pinged = ShareOffer.get_shared_offers_by_sender_merchant_controller(
                        self.customer_id
                    )
                    self.shared_offers_received = ShareOffer.get_personal_shared_offers_accepted_for_secondary(
                        self.customer_id,
                        get_family_flag=True
                    )
                    for shared_offer_received_personal in self.shared_offers_received:
                        if hasattr(shared_offer_received_personal, 'is_family_offer'):
                            self.personal_family_pinged_received.append(shared_offer_received_personal.offer_id or 0)

                self.customer_info["max_number_allowed_shares"] = self.ping_details.get('total_quota_to_send_pings', 0)
                self.customer_info["total_shares"] = self.ping_details.get('total_pings_sent', 0)

    def find_offers_data(self):
        """
        Find offers for merchant outlet

        1. This function is override in this version from previous to implement new product monthly logic.
            Split the function (get_all_active_offers) in two parts. To avoid extra code overriding.

        :return:
        """
        (
            self.offers,
            self.outlet_ids_having_offers,
            self.offer_categories,
            self.offer_sub_categories,
            self.merchant_offer_ids,
            self.delivery_offers_count,
            self.has_dinner_offers,
            self.has_take_away_offers
        ) = get_and_process_offers_v3(
            company=self.company,
            is_ent=self.is_ent,
            outlet_ids=self.outlet_ids,
            locale=self.locale,
            customer=self.customer,
            member_group=self.member_group,
            offer_redeemability=self.redeemability,
            is_user_onboard=self.is_user_onboard,
            offer_id=self.offer_id,
            top_up_offers=self.top_up_offers,
            shared_offers_sent_family=self.shared_offers_pinged_family,
            shared_offers_received_family=self.shared_offers_received_family,
            offer_categories=[],
            offer_sub_categories=[],
            location_id=self.location_id,
            is_skip_mode=self.customer_id == 0,
            return_outlet_ids=True,
            selected_category=self.category,
            is_merlin_offers_to_show=True,
            offers_es=self.offers,
            is_on_trial=self.is_on_trial,
            onboarding_redemption_count=self.onboarding_redemption_count,
            primary_user_id=self.primary_user_id,
            is_active_family_member=self.is_active_family_member,
            shared_offers_received=self.shared_offers_received,
            shared_offers_sent=self.shared_offers_pinged,
            show_cheer_offers=self.show_cheers_offers,
            outlet_merlin_urls=self.outlet_merlin_urls,
            personal_cheer_offers=self.personal_cheer_offers,
            only_delivery=self.cashless_delivery_enabled,
            outlet_id=self.outlet_id,
            merchant_id=self.merchant['id'],
            merchant_name=self.merchant['name'],
            rules=self.rules,
            all_offers_active=self.all_offers_active,
            show_monthly_offers_on_product=self.show_monthly_offers_on_product,
            is_take_away=self.takeaways_enabled,
            enable_delivery_cashless=self.cashless_delivery_enabled
        )

    def get_all_active_offers(self):
        """
        Gets the array of all active offers against this merchant
        """
        self.offers = []
        cashless_delivery_outlets = {}
        # Don't use self.cashless_delivery_enabled here.
        if self.enable_cashless_delivery:
            # In case a customer has opened a dine-in outlet, we need to show outlets that have cashless delivery
            # enabled as well. This will only be shown for customers who have enabled the cashless delivery feature.
            if (
                not self.cashless_delivery_enabled and
                self.location_id in get_delivery_enabled_location_ids_against_company(self.company)
            ):
                cashless_delivery_outlets_result = Outlet.cashless_delivery_outlets(
                    outlet_ids=sorted(list(set(self.outlet_ids))),
                    company=self.company
                )
                cashless_delivery_outlets.update({row.outlet_id: row for row in cashless_delivery_outlets_result})

        # Getting merlin urls and adding bat section
        for index, outlet in enumerate(self.outlets):
            if (
                not outlet.get('is_published') or
                not self.table_reservation_enabled or
                not outlet.get('table_reservation_enabled') or
                outlet.get('tb_reservation_disabled') or
                not self.user_id or
                self.location_id not in get_table_booking_enabled_location_ids_against_company(self.company)
            ):
                outlet["bat_section"] = {}

            else:
                outlet["bat_section"] = get_bat_section(
                    session_token=self.customer.get('session_token', ''),
                    merchant_id=self.merchant.get('id', ''),
                    merchant_name=self.merchant.get('name', ''),
                    outlet_id=outlet.get('id', ''),
                    message_locale=self.message_locale
                )
            try:
                del outlet['tb_reservation_disabled']
            except KeyError:
                pass

            if cashless_delivery_outlets:
                try:
                    cashless_delivery_outlets[outlet.get('id')]
                    outlet['is_cashless_enable'] = 1
                    outlet['has_delivery_offers'] = 1
                    outlet['cashless_delivery_params'] = {
                        'outlet_id': outlet.get('id'),
                        'cashless_delivery': True,
                        'is_take_away': bool(outlet.get('take_away_enabled', False))
                    }
                except KeyError:
                    outlet['is_cashless_enable'] = 0
                    outlet['has_delivery_offers'] = 0
                    outlet['cashless_delivery_params'] = dict()

            try:
                del outlet['min_order_cap']
            except KeyError:
                pass

            try:
                del outlet['del_charge_on_total_order']
            except KeyError:
                pass

            try:
                del outlet['del_charge_on_less_than_min']
            except KeyError:
                pass

            self.outlet_merlin_urls[str(outlet['id'])] = outlet.get('merlin_url', '').rstrip('\n')

        self.rules = dict()

        if self.customer.get('is_member_on_trial') and self.customer.get('is_using_extended_trial'):
            self.rules = get_extended_trial_rules_current_customer(location_id=self.location_id)

        self.find_offers_data()

        self.merchant['category'] = self.offer_categories[0] if self.offer_categories else ""
        self.merchant['categories'] = self.offer_categories
        self.merchant['merchant_categories'] = self.offer_categories
        self.merchant['categories_analytics'] = get_analytics_codes_against_categories(
            self.offer_categories
        )
        self.merchant['show_view_dine_offer_section'] = self.has_dinner_offers
        self.merchant['offer_categories'] = self.offer_categories
        self.merchant['sub_categories'] = self.offer_sub_categories
        self.merchant['digital_section'] = ', '.join(self.offer_sub_categories)

        if self.is_travel:
            self.merchant['hotel_rating'] = get_hotel_rating(self.merchant['sub_categories'])

    def get_delivery_menu_item(self, **kwargs):

        if self.cashless_delivery_enabled:
            self.merchant_menu_items = {'menu_section': []}
            self.menus = DmOutletSetting.get_outlet_delivery_categories_and_items(
                merchant_id=kwargs['merchant_id'],
                outlet_id=self.outlet_id,
                company=self.company,
                is_take_aways_enabled=self.takeaways_enabled
            )
            self.menu_details = process_menu_details_v3(
                menus_details=self.menus,
                offer_ids=self.merchant_offer_ids,
                locale=self.locale,
                currency=self.merchant.get('outletCurrency', 'AED'),
            )
            self.merchant['menus'] = self.menu_details
        else:
            # we will not normal delivery menu items on dubai and abu dhabi location
            if self.location_id in get_delivery_enabled_location_ids_against_company(self.company):
                self.merchant_menu_items = {}
            else:
                super().get_delivery_menu_item(**kwargs)

    def get_outlets_present_in_offer_list(self):
        """
        Filter the outlets if they contains offers
        :return:
        """
        for outlet in self.outlets:
            outlet['tripadvisor_id'] = int(outlet['tripadvisor_id'])
            if outlet['id'] in self.outlet_ids_having_offers:
                self.outlets_filtered.append(outlet)

    def sort_offers_list(self):
        """
        Sort offers list using multi_key_sort method.
        Add sorting key ismember to get monthly offers on top always.
        """
        self.offers = multi_key_sort(
            self.offers,
            columns=[
                '-is_redeemable',
                '-product_sequence',
                '-is_purchased',
                '-is_ent',
                '-is_birthday_offer',
                '-is_bonus_offers',
                '-ismember',
                '-is_monthly',
                '-is_monthly_cheers',
                '-is_core_product',
                '-is_new',
                '-is_delivery',
                '-is_cheers',
                'product_id'
            ]
        )

    def check_pinged_offers(self):
        """
        Sets is_pingable flags for merchant in case ping feature is enabled and is valid.
        """
        if self.ping_feature_enabled:
            if not self.ping_details or not self.ping_details['can_user_ping']:
                self.merchant['is_pingable'] = False

    def create_top_up_offers_hash(self):
        """
        Creates hashes for top up offers.
        """
        self.hashed_top_up_offers = {}
        self.offer_array_product_names = []

        if self.top_up_offers_enabled:
            for top_up_offer in self.top_up_offers:
                self.hashed_top_up_offers[top_up_offer.product_id] = True

    def process_offers(self):

        product_ids = []
        product_sku = []
        for offer in self.offers:
            product_ids.append(offer['product_id'])
            product_sku.append(offer['product_sku'])
            # if product has old delivery then we mark this flag True to send cashless_delivery Flag True.
            if offer.get('is_delivery', False):
                self.show_old_delivery = True
            if not self.merchant['is_pingable']:
                offer['is_pingable'] = False
            if offer.get('shared_received_count') > 0 and offer['is_delivery']:
                self.show_pinged_offers_delivery_section = True
            elif offer.get('shared_received_count') > 0 and not offer['is_delivery']:
                self.show_pinged_offers_non_delivery_section = True
            if offer.get('personal_shared_received_count', 0) > 0 and offer['is_delivery']:
                self.show_personal_pinged_offers_delivery_section = True
            elif offer.get('personal_shared_received_count', 0) > 0 and not offer['is_delivery']:
                self.show_personal_pinged_offers_non_delivery_section = True

            # Top Up Offers Related changes
            if self.top_up_offers_enabled:
                offer['offer_pay_back_app_action_id'] = SMILES_ACTION_BURN_OFFERS_TOP_UP_ID
                self.top_up_offer_against_product = False
                if self.hashed_top_up_offers.get(offer['product_id']):
                    self.top_up_offer_against_product = True
                offer['smiles_burn_value'] = TOP_UP_OFFER_BURN_VALUE
                offer['top_up_offer_allowed'] = False

                if offer['is_freemium'] == 0:
                    # Logic to allow/disallow offer pay back
                    offer['top_up_offer_allowed'] = allowed_offer_buy_back(
                        self.top_up_offer_against_product,
                        offer['type'],
                        offer['quantity_redeemed'],
                        self.customer.get('member_type_id', 0),
                        offer['is_ent'],
                        is_active_family_member=self.is_active_family_member,
                        member_ship_sub_group=self.customer.get('membership_sub_group')
                    )

            show_smile_earn_values(offer, self.is_active_family_member, self.customer, self.merchant)

            offer['savings_estimate_aed'] = round(int(offer['savings_estimate']))
            self.set_offer_currency(offer)
            handle_deliverable_offer(
                company=self.company,
                offer=offer,
                location_id=self.location_id,
                delivery_offers_count=self.delivery_offers_count,
                redeemability_for_delivery=self.redeemability_for_delivery
            )
            if offer['product_name'] not in self.offer_array_product_names:
                self.offers_array.append({
                    'section_name': offer['product_name'],
                    'show_pinged_offers_delivery_section': False,
                    'show_pinged_offers_non_delivery_section': False
                })
                self.offer_array_product_names.append(offer['product_name'])

            if self.cinema_enabled:
                populate_cinema_offers(offer=offer, instance=self)

        if product_ids and self.merchant.get('delivery_cart_params'):
            self.merchant['delivery_cart_params']['product_ids'] = list(set(product_ids))
            self.merchant['delivery_cart_params']['product_sku'] = list(set(product_sku))

    def show_pinged_offer_delivery_section(self):

        if self.ping_feature_enabled:
            if self.show_pinged_offers_delivery_section:
                self.offers_array.append({
                    'section_name': 'Offers Pinged to Family',
                    'show_pinged_offers_delivery_section': True,
                    'show_pinged_offers_non_delivery_section': False,
                    'show_personal_pinged_offers_delivery_section': False,
                    'show_personal_pinged_offers_non_delivery_section': False
                })
            if self.show_personal_pinged_offers_delivery_section:
                self.offers_array.append({
                    'section_name': TranslationManager.get_translation(
                        TranslationManager.offers_pinged_to_me,
                        self.message_locale
                    ),
                    'show_pinged_offers_delivery_section': False,
                    'show_pinged_offers_non_delivery_section': False,
                    'show_personal_pinged_offers_delivery_section': True,
                    'show_personal_pinged_offers_non_delivery_section': False
                })

    def add_pinged_offers_non_delivery_section(self):

        if self.ping_feature_enabled:
            if self.show_personal_pinged_offers_non_delivery_section:
                self.offers_array.append({
                    'section_name': TranslationManager.get_translation(
                        TranslationManager.offers_pinged_to_me,
                        self.message_locale
                    ),
                    'show_pinged_offers_delivery_section': False,
                    'show_pinged_offers_non_delivery_section': False,
                    'show_personal_pinged_offers_delivery_section': False,
                    'show_personal_pinged_offers_non_delivery_section': True
                })
            if self.show_pinged_offers_non_delivery_section:
                self.offers_array.append({
                    'section_name': 'Offers Pinged to Family',
                    'show_pinged_offers_delivery_section': False,
                    'show_pinged_offers_non_delivery_section': True,
                    'show_personal_pinged_offers_delivery_section': False,
                    'show_personal_pinged_offers_non_delivery_section': False
                })
            self.replace_241_type_with_141 = self.location_id in LOCATION_IDS_1_FOR_1

    def get_list_of_offers_array(self):
        """
        Formulate and process offers
        """
        self.offers_array, self.is_any_offer_pingable, to_be_removed_live_offers = formulate_offer_details_array_v3(
            self.offers,
            self.offers_array,
            self.message_locale,
            self.is_user_account_frozen,
            self.is_any_offer_pingable,
            self.has_birthday_month,
            self.birthday_skus,
            self.birthday_offers_validity,
            self.customer_id == 0,
            True,
            self.replace_241_type_with_141,
            is_on_trial=self.is_on_trial,
            merchant_pin=self.merchant['merchant_pin'],
            family_identifier=self.family_identifier,
            personal_family_pinged_received=self.personal_family_pinged_received,
            company_configs=self.configs,
            is_live_offers_enabled=self.live_offers_enabled,
            location_id=self.location_id,
        )
        if to_be_removed_live_offers:
            temp_offers_array = []
            removed_live_offers = []
            show_offers = []

            for remove_offer in to_be_removed_live_offers:
                removed_live_offers.append(remove_offer.get('offer_id'))

            for offer_array in self.offers_array:
                for offer__data in offer_array.get('offers_to_display'):
                    if offer__data.get('offer_id') not in removed_live_offers:
                        show_offers.append(offer__data)
                offer_array['offers_to_display'] = []

                if show_offers:
                    # If offers are available then adding it in temporary offers array
                    temp_offers_array.append(offer_array)
                    offer_array['offers_to_display'] = show_offers
                    show_offers = []

            self.offers_array = temp_offers_array

    def mark_if_any_offer_is_pingable(self):
        """
        If cashless delivery is enabled and it's a cashless offer then we set pingable to False for that merchant.
        """

        if not self.is_any_offer_pingable or self.cashless_delivery_enabled:
            self.merchant['is_pingable'] = False

    def set_sponsor_message_and_urls(self):
        """
        Set sponsor messages and URLs details.

        > For Oman, we have specific messages and URLs but for the rest it's a generic message.
        """
        if self.location_id == OMAN_LOCATION_ID:
            self.sponsor_title = SPONSOR_TITLE_OMAN
            self.sponsor_image = SPONSOR_IMAGE_OMAN
            if self.platform == "ios":
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_IOS_OMAN
            elif self.platform == "wp":
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_WINDOWS_OMAN
            else:
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_ANDROID_OMAN

        else:
            self.sponsor_title = SPONSOR_TITLE_DEFAULT
            self.sponsor_image = SPONSOR_IMAGE_DEFAULT
            if self.platform == "ios":
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_IOS_DEFAULT
            elif self.platform == "wp":
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_WINDOWS_DEFAULT
            else:
                self.sponsor_image_target_link = SPONSOR_IMAGE_TARGET_LINK_ANDROID_DEFAULT

    def set_offer_currency(self, offer):
        """
        Sets currency and check whether product_name already exist in the offers array
        """
        if self.currency.lower() == offer['local_currency'].lower() and offer.get('savings_estimate_local_currency'):
            offer['savings_estimate'] = offer['savings_estimate_local_currency']
        else:
            offer['savings_estimate'] = ExchangeRate.get_conversion_rate(
                offer.get('savings_estimate'),
                'AED',
                self.currency
            )

    def check_favorite_merchant(self):
        """
        Checks if merchant is favorite.
        """

        self.is_merchant_favorite = False
        try:
            is_merchant_favorite = self.user_favourite_model.get_favourite_merchants_by_id(
                self.merchant.get('id', 0),
                self.customer_id,
                company=self.company
            )
        except SQLAlchemyError:
            self.user_favourite_model.query.session.rollback()
            is_merchant_favorite = self.user_favourite_model.get_favourite_merchants_by_id(
                self.merchant.get('id', 0),
                self.customer_id,
                company=self.company
            )

        if is_merchant_favorite:
            self.is_merchant_favorite = True

    def prepare_merchant_object(self):
        """
        Prepare merchant object for final response data
        """
        self.merchant['is_favourite'] = self.is_merchant_favorite
        self.merchant['sponsor_title'] = self.sponsor_title
        self.merchant['sponsor_image'] = self.sponsor_image
        self.merchant['sponsor_image_target_link'] = self.sponsor_image_target_link
        self.merchant['has_delivery_offers'] = self.delivery_offers_count > 0

        self.merchant_menu_items['offers_remaining'] = "{total_offers} {messsage}".format(
            total_offers=int(self.redeemability_for_delivery.get('total_offers', 0)),
            messsage=TranslationManager.get_translation(
                TranslationManager.delivery_offers_remaining,
                self.message_locale
            )
        )
        self.merchant_menu_items['offers_remaining'] = self.merchant_menu_items.get('offers_remaining', 0)
        self.merchant['merchant_attributes'] = self.merchant_attributes
        self.merchant['outlets'] = self.outlets_filtered
        self.merchant['offers'] = self.offers_array
        self.merchant['delivery_section'] = self.merchant_menu_items
        self.merchant['booking_request'] = str(self.merchant.get('booking_request', 0))
        self.merchant['ping_section'] = self.ping_details
        self.merchant['customer'] = []

        if self.customer_info:
            if self.customer_info.get('membership_expiration_date'):
                self.customer_info['membership_expiration_date'] = self.customer_info['membership_expiration_date'].strftime("%Y-%m-%d %H:%M:%S")       # NOQA
            self.merchant['customer'] = self.customer_info

        if self.merchant.get('website', ''):
            merchant_website_or_name = "<a>{website}</a>".format(website=self.merchant.get('website', ''))
        else:
            merchant_website_or_name = self.merchant.get('name', '')

        self.merchant['offer_instruction_message'] = TranslationManager.get_translation(
            TranslationManager.OFFER_INSTRUCTION_MESSAGE,
            self.locale
        ).format(website_or_name=merchant_website_or_name)

        self.merchant['promo_code_instruction_message'] = TranslationManager.get_translation(
            TranslationManager.PROMO_CODE_INSTRUCTION_MESSAGE,
            self.locale
        ).format(website_or_name=merchant_website_or_name)

        if self.merchant.get('has_promo_code_offers', 0):
            self.merchant['promo_code_history'] = {
                "title": TranslationManager.get_translation(
                    TranslationManager.PROMO_CODE_HISTORY_TITLE,
                    self.locale
                ),
                "sub_title": TranslationManager.get_translation(
                    TranslationManager.PROMO_CODE_HISTORY_SUB_TITLE,
                    self.locale
                )
            }

    def add_merchant_buttons(self):
        """
        Add merchant buttons

         1. Added some new buttons for top menu buttons.
         2. Dine_in and delivery rules section added required by apps team.
        """
        telephone = ''
        buttons_list = []
        top_menu_buttons_list = []

        if self.merchant.get('outlets', []):
            telephone = self.merchant.get('outlets', [])[0].get('telephone', '')

        if not self.cashless_delivery_enabled:
            if self.merchant['is_pingable']:
                ping_button = {
                    'type': BUTTON_TYPE_PING,
                    'value': True,
                    'title': BUTTON_TITLE_PING,
                }
                buttons_list.append(ping_button)

            if self.merchant['pdf_url']:
                menu_button = {
                    'type': BUTTON_TYPE_MENU,
                    'value': self.merchant['pdf_url'],
                    'title': BUTTON_TITLE_MENU,
                }

                if CATEGORY_NAME_RESTAURANTS_AND_BARS in self.merchant.get('categories', []):
                    # In case of Category Restaurants & Bars category menu button is added.
                    buttons_list.append(menu_button)

                elif CATEGORY_NAME_BODY in self.merchant.get('categories', []):
                    # In case of Body it will be updated with title catalogue.
                    menu_button['title'] = BUTTON_TITLE_CATALOGUE
                    menu_button['type'] = BUTTON_TYPE_CATALOGUE
                    buttons_list.append(menu_button)

        favourite_button = {
            'type': BUTTON_TYPE_FAVOURITES,
            'value': BUTTON_VALUE_FAVORITES,
            'title': BUTTON_TITLE_FAVOURITES,
            'is_favourite': self.merchant['is_favourite'],
            'image_url': UN_FAVOURITE_IMAGE_URL,
            'image_selected_url': FAVOURITE_IMAGE_URL
        }
        buttons_list.append(favourite_button)

        if not self.hide_delivery_phone_button:
            top_menu_call_button = {
                'type': BUTTON_TYPE_CALL,
                'value': telephone,
                'title': BUTTON_TITLE_CALL,
            }

            top_menu_buttons_list.append(top_menu_call_button)

        share_outlet_button = {
            "value": BUTTON_VALUE_SHARE,
            "type": BUTTON_TYPE_SHARE,
            "title": BUTTON_TITLE_SHARE
        }
        top_menu_buttons_list.append(share_outlet_button)

        if self.enable_cashless_delivery:
            if not self.cashless_delivery_enabled:
                if self.merchant['email']:
                    top_menu_buttons_list.append({
                        'type': BUTTON_TYPE_EMAIL,
                        'value': self.merchant['email'],
                        'title': BUTTON_TITLE_FAVOURITES,
                    })
                # Handling delivery buttons for each outlet of merchant.
                for outlet in self.outlets:
                    # check if old_delivery is enabled then we will send has_delivery_offers True
                    if self.show_old_delivery:
                        outlet['has_delivery_offers'] = 1
                    # If outlet has own_delivery then we will show delivery button.
                    elif outlet.get('own_delivery', False) or outlet.get('last_mile_delivery', False):
                        outlet['has_delivery_offers'] = int(self.delivery_offers_count > 0)
                    else:
                        outlet['has_delivery_offers'] = 0
                    # If outlet has take_away_enabled then we will show take_away button.
                    if self.takeaways_enabled and outlet.get('take_away_enabled', False):
                        outlet['has_take_away_offers'] = bool(self.has_take_away_offers > 0)

        update_action_buttons_list_for_merchant(buttons_list)
        update_action_buttons_list_for_merchant(top_menu_buttons_list)

        self.merchant['top_menu_button'] = top_menu_buttons_list

        menu_buttons = {
            "expandable_button_text": "",
            "identifier": "menu_buttons",
            "is_expandable": False,
            "menu_buttons": buttons_list,
            "section_name": ""
        }
        self.sections.append(menu_buttons)

        if self.cashless_delivery_enabled:
            view_dine_in_section = {
                "is_expandable": False,
                "expandable_button_text": "",
                "identifier": "view_dine_in",
                "section_name": "View Dine In"
            }
            self.sections.append(view_dine_in_section)

            delivery_rules_section = {
                "is_expandable": False,
                "expandable_button_text": "",
                "identifier": "delivery_rules",
                "section_name": "",
                "delivery_rules": self.merchant.get('offersDetail', [])
            }
            self.sections.append(delivery_rules_section)

            del self.merchant['offersDetail']

            re_order_section = {
                "is_expandable": False,
                "expandable_button_text": "",
                "identifier": "reorder",
                "section_name": "",
                "items_to_reorder": []
            }
            self.sections.append(re_order_section)

        self.merchant['sections'] = self.sections

    def populate_offers_section_v7(self):
        """
         Populate offers section

         1. Separate locked and un-locked offers to show them in their own sections
         2. In case of member unlocked section will be created and added to sections
         3. In case of non-member locked offers will be in 2 sections 1 for all offers and 2nd for single offer.
        """
        # Here will separate locked and un_locked offers. If purchased_product_id exists in customer products.
        locked_offers = []
        un_locked_offers = []
        for offer in self.merchant.get('offers', []):
            if offer.get('purchase_product_id', 0) in self.customer.get('product_ids', []):
                un_locked_offers.append(offer)
            else:
                locked_offers.append(offer)
        del self.merchant['offers']
        if (
            (
                self.customer.get('member_type_id', 0) == EntCustomerProfile.MEMBERSTATUS_MEMBER or
                self.customer.get('is_user_in_family') or self.is_dc_prospect
            ) and un_locked_offers
        ):
            my_offers_section = {
                "is_expandable": True,
                "expandable_button_text": "",
                "identifier": "offers",
                "section_name": "My offers",
                'offers': un_locked_offers
            }
            self.merchant['sections'].append(my_offers_section)
        elif locked_offers:
            # locked offers section if particular product is not purchased.
            single_locked_offer_section = {
                "is_expandable": False,
                "expandable_button_text": "",
                "identifier": "preview_offers",
                "section_name": "Preview Offers",
                "section_subtitle": "",
                "section_icon": "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/voucher_type_food_1.png",  # noqa: E501
                "offers": []
            }
            preview_offers = locked_offers
            offer_list = []
            for offer in preview_offers:
                if offer.get('offers_to_display', []):
                    offer['offers_to_display'] = [offer['offers_to_display'][0]]
                offer_list.append(offer)
            single_locked_offer_section['offers'] = offer_list
            self.merchant['sections'].append(single_locked_offer_section)

            locked_offers_section = {
                "is_expandable": False,
                "expandable_button_text": "",
                "identifier": "locked_offers",
                "section_name": "Locked Offers",
                "section_subtitle": "Click here to view the locked offers",
                "section_icon": "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/offer_locked_section_img_md.png",  # noqa: E501
                "offers": locked_offers
            }
            self.merchant['sections'].append(locked_offers_section)

    def add_merchant_new_sections_v7(self):
        """
        Add merchant new sections for V7
        """
        if not self.cashless_delivery_enabled:
            outlet_selection_section = {
                "expandable_button_text": "",
                "identifier": "outlet_selection",
                "is_expandable": False,
                "section_name": ""
            }
            modules_section = {
                "expandable_button_text": "",
                "identifier": "modules",
                "is_expandable": False,
                "modules_navigations": [],
                "section_name": ""
            }
            self.merchant['sections'].append(outlet_selection_section)
            self.merchant['sections'].append(modules_section)

        self.populate_offers_section_v7()

        if self.cashless_delivery_enabled:
            full_menu_section = {
                "is_expandable": False,
                "is_expended": True,
                "expandable_button_text": "",
                "identifier": "delivery_menus",
                "section_name": "Full Menu"
            }
            self.merchant['sections'].append(full_menu_section)

        if self.merchant.get('has_promo_code_offers', 0) and not self.cashless_delivery_enabled:
            promo_code_section = {
                "is_expandable": False,
                "expandable_button_text": "See All",
                "identifier": "online_offers_history",
                "section_name": "Online offer history",
                "promo_code_instruction_message": "Copy & paste this code at \n<a>https://www.fairmont.com/fujairah/dining/arena-sports-bar-and-kitchen/</a>"  # noqa: E501
            }
            self.merchant['sections'].append(promo_code_section)

        products_section = {
            "is_expandable": False,
            "expandable_button_text": "",
            "identifier": "products",
            "section_name": "More products to buy",
            "products": []
        }
        self.merchant['sections'].append(products_section)

        if not self.cashless_delivery_enabled:
            outlet_details_section_v7 = {
                "is_expandable": True,
                "expandable_button_text": "Read More",
                "identifier": "detail",
                "section_name": "Outlet Details",
                "description": "",
                "detail_attributes": []
            }
            self.merchant['sections'].append(outlet_details_section_v7)
        if not self.cashless_delivery_enabled and self.merchant.get('merchant_attributes', []):
            amenities_new_section = {
                "is_expandable": True,
                "expandable_button_text": "See All",
                "identifier": "merchant_attributes",
                "section_name": "Amenities",
                "attributes": []
            }
            if self.merchant.get('merchant_attributes', []):
                amenities_new_section['attributes'] = self.merchant['merchant_attributes'][0].get('attributes', [])
            self.merchant['sections'].append(amenities_new_section)
        self.merchant['cuisines_sub_categories'] = []
        for cuisine in self.merchant.get('cuisines', []):
            self.merchant['cuisines_sub_categories'].append(cuisine)
        for sub_category in self.merchant.get('sub_categories', []):
            self.merchant['cuisines_sub_categories'].append(sub_category)

    def add_modules_navigation_section_in_outlets(self):
        """
        Add modules navigation on outlet level.

         1. Cashless delivery params will work as module navigation like table button, delivery button and others.
        """
        for outlet in self.merchant.get('outlets', []):
            outlet['modules_navigations'] = []
            if outlet.get('table_reservation_enabled') and outlet.get("bat_section"):
                table_reservation_secction = {
                    "title": "Book a Table",
                    "image_url": "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/bookatable.png",
                    "identifier": "book_a_table",
                    "has_accessory_icon": 0,
                    "web_url": outlet['bat_section'].get('bat_url', ''),
                    "extra_params": {}
                }
                outlet['modules_navigations'].append(table_reservation_secction)

            if outlet.get('own_delivery', False) or outlet.get('last_mile_delivery'):
                delivery_section = {
                    "title": "Delivery",
                    "image_url": "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/delivery_icon_md.png",
                    "identifier": "cashless_delivery",
                    "has_accessory_icon": 1,
                    "web_url": "",
                    "extra_params": {
                        "cashless_delivery": True,
                        "outlet_id": outlet.get('id', 0),
                        "is_take_away": False
                    }
                }
                outlet['modules_navigations'].append(delivery_section)

            if self.show_old_delivery:
                old_delivery_section = {
                    "title": "Delivery",
                    "image_url": "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/delivery_icon_md.png",
                    "identifier": "delivery",
                    "has_accessory_icon": 0,
                    "web_url": "",
                    "extra_params": {}
                }
                outlet['modules_navigations'].append(old_delivery_section)
            if self.takeaways_enabled and outlet.get('take_away_enabled', False):
                takeaways_section = {
                    "title": "Takeaway",
                    "image_url": "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/takeaway_md.png",
                    "identifier": "cashless_takeaway",
                    "has_accessory_icon": 1,
                    "web_url": "",
                    "extra_params": {
                        "cashless_delivery": True,
                        "outlet_id": outlet.get('id', 0),
                        "is_take_away": True
                    }
                }
                outlet['modules_navigations'].append(takeaways_section)

    def prepare_response(self):
        """
        Sets final response for merchant api
        :rtype: dict
        """

        del self.merchant['merchant_attributes']

        if not self.merchant['pdf_url']:
            del self.merchant['pdf_url']

        if self.merchant.get('is_for_members_only') is None:
            del self.merchant['is_for_members_only']

        if self.cashless_delivery_enabled:
            extra_params = {
                'allergyDetail': self.merchant.get('allergyDetail', ''),
                'merchant_name': self.merchant['name']
            }
            if self.merchant.get('delivery_cart_params'):
                self.merchant['delivery_cart_params'].update(extra_params)
            else:
                self.merchant['delivery_cart_params'] = extra_params

        self.merchant['is_take_away_enabled'] = self.takeaways_enabled
        self.send_response_flag = True
        self.response = {
            'success': True,
            'message': 'success',
            'data': {"merchant": self.merchant},
            'code': 0
        }
        self.status_code = codes.OK

        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Control the flow of merchant api
        """
        self.initialize_local_variables(*args, **kwargs)
        self.get_company_configs()
        self.initialize_class_attributes()
        self.set_current_customer_data()
        self.get_merchant(**kwargs)
        if self.is_send_response_flag_on():
            return
        self.get_customer_profile()
        self.set_customer_features()
        self.set_is_on_trial()
        self.get_smiles_balance_and_update_merchant()
        self.set_order_addresses()
        self.get_delivery_details(**kwargs)
        self.get_active_outlets(**kwargs)
        self.get_buy_back_offers_array()
        self.load_customer_object()
        self.get_all_active_offers()
        self.get_delivery_menu_item(**kwargs)
        self.get_outlets_present_in_offer_list()
        self.sort_offers_list()
        if not self.cashless_delivery_enabled:
            self.check_pinged_offers()
        self.create_top_up_offers_hash()
        self.process_offers()
        self.show_pinged_offer_delivery_section()
        self.add_pinged_offers_non_delivery_section()
        self.get_list_of_offers_array()
        self.mark_if_any_offer_is_pingable()
        self.set_sponsor_message_and_urls()
        self.get_merchant_attributes(**kwargs)
        self.check_favorite_merchant()
        self.prepare_merchant_object()
        self.add_merchant_buttons()
        self.add_merchant_new_sections_v7()
        self.add_modules_navigation_section_in_outlets()
        self.prepare_response()
