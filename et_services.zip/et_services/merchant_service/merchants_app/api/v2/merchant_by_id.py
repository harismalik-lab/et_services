"""
This module contains API V2 endpoint to get merchant by id.
    In this version 2, followings have been changed.
        - logger file_path has been updated in logger_info
        - Class `MerchantByIdApi` -> `get_location_categories()` method has been updated:
            - configs has been added.
            - On the basis of these configs, replace_241_type_with_141 flag value is set.
        - `redeemability_api_urls` is set as RedemptionServiceAPIUrlsV2 to communicate redemption-service
"""
from flask import current_app

from app_configurations.settings import ET_SERVICES_LOG_PATH
from merchant_service.common.models.api_configuration import ApiConfiguration
from merchant_service.common.models.wl_company import WlCompany
from merchant_service.common.models.wl_location_category import WlLocationCategory
from merchant_service.common.rest_urls import RedemptionServiceAPIUrlsV2
from merchant_service.common.utils.api_utils import get_api_configurations
from merchant_service.merchants_app.api.v1.merchant_by_id import MerchantByIdApi
from merchant_service.modules.api_modules import formulate_offer_details_array


class MerchantByIdApiV2(MerchantByIdApi):
    """
    @api {get} /v2/merchants/{merchant_id} Get merchant id
    @apiSampleRequest /v2/merchants/{merchant_id}
    @apiVersion 1.0.0
    @apiName MerchantName
    @apiGroup Merchants
    @apiParam {String}                                  [app_version]           App_version
    @apiParam {Float}                                   [lat]                   Latitude
    @apiParam {Float}                                   [lng]                   Longitude
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}     [currency]    Currency  # noqa:E501
    @apiParam {Boolean}                                 [is_cuckoo]             Is_cuckoo flag
    @apiParam {Boolean}                                 [user_include_cheers]   User_include_cheers flag
    """

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='merchants_service/merchants_by_id_v2.log',
        ),
        'name': 'merchants_api_v2'
    }
    # url to communicate redemption service
    redeemability_api_urls = RedemptionServiceAPIUrlsV2

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        super().initialize_local_variables()
        self.api_configs = get_api_configurations(company=self.company, environment=current_app.config['ENV'].lower())

    def get_location_categories(self):
        """
        Gets location categories
        """
        if self.offers_array:
            self.categories = WlLocationCategory.get_location_categories(
                self.company,
                self.location_id,
                [self.user_group],
            )
            if self.categories:
                for index, category in enumerate(self.categories):
                    category = category._asdict()
                    self.categories[index] = category
                    category['tile_id'] = 1
            replace_241_type_with_141 = False

            if self.api_configs.get('replace_241_type_with_141'):
                replace_241_type_with_141 = self.api_configs['replace_241_type_with_141']
            if self.api_configs.get('replace_241_type_with_141_locations'):
                # typecasting of locations_to_replace values from str to int for comparison
                locations_to_replace = list(
                    map(lambda x: int(x), self.api_configs['replace_241_type_with_141_locations'].split(',')))
                if self.location_id in locations_to_replace:
                    replace_241_type_with_141 = True

            if(
                self.company.lower() == WlCompany.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER and
                self.location_id == WlLocationCategory.SINGAPORE
            ):
                replace_241_type_with_141 = True
            show_and_go_product_skus = self.api_configs.get(ApiConfiguration.BLUE_PRODUCTS)
            if show_and_go_product_skus:
                show_and_go_product_skus = show_and_go_product_skus.split(',')
            self.offers_array = formulate_offer_details_array(
                offers=self.offers,
                offers_array=self.offers_array,
                message_locale=self.message_locale,
                is_skip_mode=not self.customer.get('is_user_logged_in'),
                categories=self.categories,
                company=self.company,
                replace_241_type_with_141=replace_241_type_with_141,
                show_and_go_product_skus=show_and_go_product_skus
            )
