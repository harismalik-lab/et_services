"""
Validates Merchant PIN API
"""
from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from merchant_service.common.base_resource import BasePostResource
from merchant_service.common.models.api_configuration import ApiConfiguration
from merchant_service.common.models.outlet import Outlet
from merchant_service.common.utils.api_utils import get_api_configurations
from merchant_service.common.utils.authentication import get_company
from merchant_service.common.utils.translation_manager import TranslationManager
from merchant_service.merchants_app.api.v2.validations.validate_merchant_pin import merchant_pin_validator_parser


class ValidatesMerchantPinAPI(BasePostResource):
    required_token = False
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='merchants_service/validates_merchant_pin_api.log',
        ),
        'name': 'validates_merchant_pin'
    }
    request_parser = merchant_pin_validator_parser

    def populate_request_arguments(self):
        """
        Populates request args
        """
        self.merchant_id = self.request_args.get('merchant_id')
        self.outlet_id = self.request_args.get('outlet_id')
        self.pin = self.request_args.get('pin')
        self.locale = self.request_args.get('language')
        self.verified_merchant_id = None
        self.verified_merchant_name = None
        self.company = get_company()

    def set_invalid_response(self):
        """
        Sets invalid response
        """
        self.send_response_flag = True
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.response = self.generate_response_dict(
            message=TranslationManager.get_translation(
                TranslationManager.merchant_details_not_found,
                self.locale
            )
        )
        return self.send_response(self.response, self.status_code)

    def get_api_configuration(self):
        """
        get api configuration by company and env
        """
        self.api_config = get_api_configurations(self.company, current_app.config['ENV'].lower())

    def validate_merchant(self):
        """
        Validates if merchant id is valid
        """
        if self.merchant_id and self.outlet_id:
            merchant = Outlet.get_by_outlet_id_and_merchant_id(self.outlet_id, self.merchant_id)
            if not merchant:
                return self.set_invalid_response()
            if merchant.pin != self.pin:
                return self.set_invalid_response()
        elif self.api_config.get(ApiConfiguration.MERCHANT_PIN_VALIDATION, False):
            merchant = Outlet.get_by_merchant_pin_af(
                self.pin
            )
            if not merchant:
                return self.set_invalid_response()
            self.verified_merchant_id = merchant.id
            self.verified_merchant_name = merchant.name
            return
        self.set_invalid_response()

    def set_final_response(self):
        """
        Sets final response
        """
        self.send_response_flag = True
        self.response = self.generate_response_dict(data={
            'merchant_id': self.verified_merchant_id,
            'merchant_name': self.verified_merchant_name
        })
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.get_api_configuration()
        self.validate_merchant()
        if self.send_response_flag:
            return
        self.set_final_response()
