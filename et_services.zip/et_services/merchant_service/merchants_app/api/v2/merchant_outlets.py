"""
Merchant Outlets API
"""
from collections import OrderedDict
from operator import itemgetter

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from merchant_service.common.models.offer_wl_active import OfferWlActive
from merchant_service.common.models.outlet import Outlet
from merchant_service.merchants_app.api.v1.merchants import MerchantsApi
from merchant_service.modules.constants import MAX_MERCHANTS


class MerchantOutlets(MerchantsApi):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='merchants_service/merchant_outlets_api.log',
        ),
        'name': 'merchant_outlets_api'
    }

    def set_current_customer(self):
        """
        Gets the bundled skus against the purchasable product
        """
        product_skus = self.product_sku.split(',') if self.product_sku else []
        # TODO: cache
        merchants_base_query_object = OfferWlActive.get_merchant_offers(
            self.locale,
            product_skus,
            location_id=self.location_id,
            return_query_object=True
        )
        self.total_records = merchants_base_query_object.count()
        self.merchants = merchants_base_query_object.all()
        self.merchant_ids = []

    def set_merchants(self):
        """
        Set merchants data
        """
        self.outlet_ids = []
        self.hashed_merchants = OrderedDict()
        for _index, merchant in enumerate(self.merchants):
            merchant_dict = {
                'id': merchant.id,
                'name': merchant.name,
                'distance': 0,  # it is set to handle sorting if any merchant has no outlet which is not possible.
                'logo_offer_retina_url': merchant.logo_url,
                'outlet_ids': merchant.outlet_ids
            }
            self.hashed_merchants[merchant.id] = merchant_dict
            self.outlet_ids.extend(list(map(int, list(filter(None, merchant.outlet_ids.split(','))))))
            self.merchant_ids.append(merchant.id)
        self.product_price_details = {}

    def get_outlets(self):
        """
        Gets outlets from db
        """
        self.lat_lng = {
            'lat': self.lat,
            'lng': self.lng
        }
        self.outlets = []
        if self.outlet_ids:
            self.outlets = Outlet.get_by_ids(self.outlet_ids, criteria=self.lat_lng, merchant_ids=self.merchant_ids)
        for outlet in self.outlets:
            outlet_dict = {
                'id': outlet.id,
                'name': outlet.name,
                'human_location': outlet.human_location,
                'neighborhood': outlet.neighborhood,
                'mall': outlet.mall,
                'hotel': outlet.hotel,
                'distance': outlet.distance
            }
            if self.hashed_merchants[outlet.merchant_id].get('outlets'):
                self.hashed_merchants[outlet.merchant_id]['outlets'].append(outlet_dict)
            else:
                self.hashed_merchants[outlet.merchant_id]['distance'] = outlet_dict['distance']
                self.hashed_merchants[outlet.merchant_id]['outlets'] = [outlet_dict]

    def sort_merchants(self):
        """
        sort merchants on the basis of distance key
        """
        if all([self.lat_lng['lat'], self.lat_lng['lat'] != '0,0', self.lat_lng['lng'], self.lat_lng['lng'] != ',']):
            self.merchants = list(
                sorted(
                    self.hashed_merchants.values(),
                    key=itemgetter('distance')
                )
            )
        else:
            self.merchants = list(self.hashed_merchants.values())

        self.merchants = self.merchants[self.offset: self.offset + self.limit]

    def prepare_response(self):
        """
        Set final response for MerchantApiAction api
        """
        self.response = {
            'success': True,
            'message': 'success',
            'data': {
                'merchants': self.merchants,
                'total_records': self.total_records,
                'limit': MAX_MERCHANTS,
                'payment_info': self.product_price_details
            },
            'code': 0
        }
        self.send_response_flag = True
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Controls the flow of merchant_api_action
        """
        self.check_limit()
        if self.send_response_flag:
            return
        self.initialize_local_variables()
        self.set_current_customer()
        self.set_merchants()
        self.get_outlets()
        self.sort_merchants()
        self.prepare_response()
