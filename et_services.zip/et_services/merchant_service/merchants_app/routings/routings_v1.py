"""
This module contains routing for merchant app
"""
from flask import current_app

from merchant_service.common.base_routing import BaseRouting
from merchant_service.merchants_app.api.v1.merchant_by_id import MerchantByIdApi
from merchant_service.merchants_app.api.v1.merchants import MerchantsApi


class MerchantsAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['MERCHANT_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['merchant'] = {
            'url': '/merchants',
            'view': MerchantsApi
        }

        self.routing_collection['merchant-id'] = {
            'url': '/merchants/<int:merchant_id>',
            'view': MerchantByIdApi
        }
