"""
This module contains V3 routing for merchant app
"""
from merchant_service.merchants_app.api.v4.prio.product_availability import PrioProductAvailability
from merchant_service.merchants_app.api.v4.prio.product_detail import PrioProductDetail
from merchant_service.merchants_app.api.v4.ent_tours.tour_availability import EntTourAvailability
from merchant_service.merchants_app.routings.routings_v3 import MerchantsAPIV3


class MerchantsRoutingV4(MerchantsAPIV3):
    api_version = '4'

    def set_routing_collection(self):
        super().set_routing_collection()

        self.routing_collection['prio_product_detail'] = {
            'url': '/merchants/prio/product_detail',
            'view': PrioProductDetail
        }
        self.routing_collection['prio_product_availability'] = {
            'url': '/merchants/prio/product_availability',
            'view': PrioProductAvailability
        }
        self.routing_collection['ent_tour_availability'] = {
            'url': '/merchants/ent_tours/availability',
            'view': EntTourAvailability
        }
