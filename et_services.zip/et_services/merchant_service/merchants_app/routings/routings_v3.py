"""
This module contains V3 routing for merchant app
"""
from merchant_service.merchants_app.api.v3.merchant_by_id import MerchantByIdApiV3
from merchant_service.merchants_app.routings.routings_v2 import MerchantsAPIV2


class MerchantsAPIV3(MerchantsAPIV2):
    api_version = '3'

    def set_routing_collection(self):
        super().set_routing_collection()

        self.routing_collection['merchant-id'] = {
            'url': '/merchants/<int:merchant_id>',
            'view': MerchantByIdApiV3
        }
