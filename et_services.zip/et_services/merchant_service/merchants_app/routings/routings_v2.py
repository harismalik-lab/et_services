"""
This module contains V2 routing for merchant app
"""
from merchant_service.merchants_app.api.v2.merchant_by_id import MerchantByIdApiV2
from merchant_service.merchants_app.api.v2.merchant_outlets import MerchantOutlets
from merchant_service.merchants_app.api.v2.validate_merchant_pin_api import ValidatesMerchantPinAPI
from merchant_service.merchants_app.routings.routings_v1 import MerchantsAPIV1


class MerchantsAPIV2(MerchantsAPIV1):
    api_version = '2'

    def set_routing_collection(self):
        super().set_routing_collection()

        self.routing_collection['merchant-id'] = {
            'url': '/merchants/<int:merchant_id>',
            'view': MerchantByIdApiV2
        }
        self.routing_collection['pin-validate'] = {
            'url': '/merchants/validates/pin',
            'view': ValidatesMerchantPinAPI
        }
        self.routing_collection['merchants-outlets'] = {
            'url': '/merchants/outlets',
            'view': MerchantOutlets
        }
