"""
This modules loads APIs for merchant service
"""
from flask import g

from merchant_service.merchants_app.routings.routings_v1 import MerchantsAPIV1
from merchant_service.merchants_app.routings.routings_v2 import MerchantsAPIV2
from merchant_service.merchants_app.routings.routings_v3 import MerchantsAPIV3
from merchant_service.merchants_app.routings.routings_v4 import MerchantsRoutingV4


def api_urls():
    MerchantsAPIV1(app=g.app, name=MerchantsAPIV1.__name__).map_urls()
    MerchantsAPIV2(app=g.app, name=MerchantsAPIV2.__name__).map_urls()
    MerchantsAPIV3(app=g.app, name=MerchantsAPIV3.__name__).map_urls()
    MerchantsRoutingV4(app=g.app, name=MerchantsRoutingV4.__name__).map_urls()
