import datetime
import json

from common.utils.api_utils import calculate_distance
from flask import current_app
from merchant_service.common.exceptions import PrioException
from merchant_service.common.models.mongo_models.prio_product import \
    PrioProduct
from merchant_service.modules.v_1.prio_api_client import PrioAPIClient


class PrioDetailModule(object):
    """
    A helper class for ProductDetails API for all static variables and helper methods.
    """

    @staticmethod
    def _get_details_sections(prio_product):

        details_section = {}

        if prio_product.get('product_content'):
            product_content = prio_product['product_content']
            product_title = product_content['product_title']
            product_imgs = [img['image_url'] for img in product_content.get('product_images', [])]
            product_desc = (product_content.get('product_short_description') or product_content.get('product_long_description'))  # noqa
            details_section = {
                'product_title': product_title,
                'product_images': product_imgs,
                'description': product_desc,
                'product_admission_type': prio_product['product_admission_type'] or '',
                'product_pickup_point': prio_product['product_pickup_point'] or '',
                'product_cluster': prio_product['product_cluster'],
                'product_combi': prio_product['product_combi']
            }
            if 'product_pickup_point_details' in prio_product:
                details_section.update({'product_pickup_point_details': prio_product['product_pickup_point_details']})
            if 'product_options' in prio_product:
                details_section.update({'product_options': prio_product['product_options']})
            if 'product_addon_details' in prio_product:
                details_section.update({'product_addon_details': prio_product['product_addon_details']})
            if 'product_booking_quantity_min' in prio_product:
                details_section.update({
                    'product_booking_quantity_min': prio_product['product_booking_quantity_min'],
                    'product_booking_quantity_max': prio_product['product_booking_quantity_max']
                })
            if prio_product.get('product_combi'):
                details_section.update({'product_combi_details': prio_product['product_combi_details']})
            if prio_product.get('product_cluster'):
                details_section.update({'product_cluster_details': prio_product['product_cluster_details']})

        return details_section

    @staticmethod
    def _get_individual_capacities(prio_product):

        return prio_product.get('product_type_seasons') or []

    @staticmethod
    def _get_pickup_section(prio_product):

        if prio_product.get('product_pickup_point_details'):
            pick_up_points = []
            for point in prio_product['product_pickup_point_details']:
                pick_up_place = point["pickup_point_name"]
                pick_up_time = datetime.datetime.strptime(point["pickup_point_time"], "%H:%M").strftime("%I:%M %p")
                pick_up_points.append("Pick up available from {} at {}".format(pick_up_place, pick_up_time))
        else:
            pick_up_points = ['Call for pick up and drop off locations.']

        return pick_up_points

    @staticmethod
    def _get_location_section(prio_product, user_lat, user_lng):

        address_section = {}
        if prio_product.get('product_locations'):
            # TODO: What to do in case of multiple locations?
            # Would we get a location ID in params? For now it's the first one.
            product_addr = prio_product['product_locations'][0]['location_address']
            addr = ', '.join(filter(None, [
                product_addr.get('name'),
                product_addr.get('city'),
                product_addr.get('country'),
            ]))

            address_section['address'] = addr

            lat, lng = product_addr.get('latitude'), product_addr.get('longitude')
            # TODO: Is it distance between two points or a product property?
            if lat and lng and user_lat and user_lng:
                distance = "{}m".format(calculate_distance(lat, lng, user_lat, user_lng, "M"))
                if distance:
                    address_section['distance'] = distance

        return address_section

    @staticmethod
    def _get_opening_time_section(prio_product):

        opening_time_str = ''
        if prio_product.get('product_opening_times'):
            timings = prio_product['product_opening_times'][0]
            if timings.get("opening_time_valid_from") and timings.get("opening_time_valid_till"):
                opening_time_str = "Open from: {} to {}.".format(
                    timings["opening_time_valid_from"],
                    timings["opening_time_valid_till"]
                )
            elif timings.get("opening_time_valid_from"):
                opening_time_str = "Open from: {}.".format(timings["opening_time_valid_from"])

        return opening_time_str

    @staticmethod
    def _get_currency_section(prio_product):

        if prio_product.get('product_payment_detail'):
            currency_detail = prio_product['product_payment_detail']
            return currency_detail['product_payment_currency']['currency_code']

    @staticmethod
    def _get_cancellation_details(prio_product):

        cancellation_details = {
            'is_cancellable': prio_product.get('product_cancellation_allowed', False),
            'cancellation_policy': '',
        }
        if prio_product.get('product_cancellation_policies'):
            cancel_policy = prio_product['product_cancellation_policies'][0]
            if cancel_policy.get('cancellation_description'):
                cancellation_details['cancellation_policy'] = cancel_policy['cancellation_description']

        return cancellation_details

    def format_prio_product_json(self, prio_product, user_lat, user_lng):
        """
        Formats PRIO product JSON as required in ProductDetails API response.

        :rtype: dict
        """
        formatted_product = {
            'product_id': prio_product['product_id'],
        }
        details_section = self._get_details_sections(prio_product)
        if details_section:
            formatted_product.update(details_section)

        location_section = self._get_location_section(prio_product, user_lat, user_lng)
        if location_section:
            formatted_product.update(location_section)

        pickup_section = self._get_pickup_section(prio_product)
        if pickup_section:
            formatted_product['location'] = pickup_section

        opening_time_section = self._get_opening_time_section(prio_product)
        if opening_time_section:
            formatted_product['opening_time'] = opening_time_section

        currency_section = self._get_currency_section(prio_product)
        if currency_section:
            formatted_product['currency'] = currency_section

        capacity_section = self._get_individual_capacities(prio_product)
        formatted_product['capacity'] = capacity_section

        cancellation_section = self._get_cancellation_details(prio_product)
        formatted_product.update(cancellation_section)

        return formatted_product

    @staticmethod
    def format_product_availabilities(availability_slots):
        """
        Formats product availabilities into readable slots.

        ..Prio avialabilities overrides:
            [1] Only send availabilities for which the spots are open. Check requested by Web: Muneeb.
        """
        formatted_availabilities = {}
        for slot in availability_slots:
            start_time = datetime.datetime.fromisoformat(slot['availability_from_date_time'])
            end_time = datetime.datetime.fromisoformat(slot['availability_to_date_time'])
            slot_date = start_time.strftime('%Y-%m-%d')
            availability_obj = {
                'availability_id': slot['availability_id'],
                'start_time': start_time.strftime("%I:%M %p"),
                'end_time': end_time.strftime("%I:%M %p"),
            }
            if slot['availability_active']:
                if slot.get('availability_duration'):
                    availability_obj['duration'] = slot['availability_duration']
                if slot.get('availability_spots', {}).get('availability_spots_open'):
                    availability_obj['spots'] = slot['availability_spots']
                if slot_date in formatted_availabilities:
                    formatted_availabilities[slot_date].append(availability_obj)
                else:
                    formatted_availabilities[slot_date] = [availability_obj]

        return formatted_availabilities

    @staticmethod
    def get_product_from_mongo(**kwargs):
        """
        Gets a product JSON response stored in MongoDB.

        :rtype: dict
        """
        product_info = {}

        mongo_product = PrioProduct.get_products(get_one=True, **kwargs)
        if mongo_product:
            return json.loads(mongo_product.prio_json)

        return product_info

    @staticmethod
    def get_product_from_api(**kwargs):
        """
        Gets a product JSON response from PrioHub Products API.

        :rtype: dict
        """
        prio_client = PrioAPIClient(**current_app.config.get("PRIO_API_CREDENTIALS", {}))

        try:
            product_api_response = prio_client.get_product(**kwargs)
        except Exception as e:
            return PrioException(e)

        if product_api_response:
            return product_api_response.get('data', {}).get('product')
