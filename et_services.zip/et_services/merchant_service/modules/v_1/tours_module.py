import datetime

from merchant_service.common.models.tour import Tour
from merchant_service.common.utils.api_utils import get_formatted_date


class EntToursModule(object):
    """
    A helper class for TE Tours for all static variables and helper methods.
    """

    @staticmethod
    def get_available_slots_for_tour(**kwargs):
        """
        Gets tours all valid availabilities from DB based on kwargs.

        Valid tour:
            is_active = 1
            is_published = 1
            validity_date has not passed.
            Available spots > 0
        """
        tours = []
        tour_availabilities = Tour.get_availabilities(**kwargs)
        for tour in tour_availabilities:
            valid_booking_time = (tour.start_time - datetime.timedelta(hours=tour.booking_lead_time))
            if datetime.datetime.now() < valid_booking_time:
                tour_avl = {
                    'tour_id': tour.tour_id,
                    'slot_id': tour.slot_id,
                    'booking_date': get_formatted_date(tour.booking_date),
                    'start_time': get_formatted_date(tour.start_time, "%I:%M %p"),
                    'end_time': get_formatted_date(tour.end_time, "%I:%M %p"),
                    'slots': {
                        'total_spots': tour.total_spots,
                        'available_spots': tour.available_spots,
                        'booked_spots': tour.total_spots - tour.available_spots
                    }
                }
                tours.append(tour_avl)

        return tours

    @staticmethod
    def format_tour_availabilities(tour_slots):
        """
        Formats each tour slot against its corresponding date.
        """
        formatted_availabilities = {}
        for slot in tour_slots:
            slot_date = slot.pop('booking_date')
            if slot_date in formatted_availabilities:
                formatted_availabilities[slot_date].append(slot)
            else:
                formatted_availabilities[slot_date] = [slot]

        return formatted_availabilities
