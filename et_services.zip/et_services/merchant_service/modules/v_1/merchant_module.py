"""

"""


class MerchantModule(object):
    """

    """

    def calculate_outlet_availability(self, **kwargs):
        """

        """
    pass
