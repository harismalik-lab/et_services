import time

from merchant_service.common.utils.http_helpers import get_auth_headers, make_get_request, make_post_request


class PrioAPIClient(object):
    """
    Contains wrappers of Prio API HTTP requests.
    """
    access_token = None

    def __init__(self, user, password, env, version, distributor):

        self.usr = user
        self.pwd = password
        self.env = env
        self.version = version
        self.distributor = distributor

    def get_access_token(self):
        """
        Gets an expiring access token from oauth2 API of PrioHUB.
        If the token is about to expire, we wait and request for another token.
        """
        api_url = "https://{env}.prioticket.com/v{ver}/distributor/oauth2/token".format(
            env=self.env,
            ver=self.version
        )

        auth_headers = get_auth_headers(usr=self.usr, pwd=self.pwd)

        api_body = {
            "grant_type": "client_credentials",
            "scope": "https://{env}.booking".format(env=self.env)
        }

        api_response = make_post_request(api_url, auth_headers, api_body)

        if api_response['status_code'] == 200:
            if api_response['response']['expires_in'] < 5:
                time.sleep(6)
                self.get_access_token()

            self.access_token = api_response['response']['access_token']
        else:
            raise Exception("Error while getting authentication token: {} | {}".format(
                api_response['status_code'],
                api_response['response']
            ))

    def get_base_headers(self):
        """
        Returns base headers to be used in every request. These can be updated as required or used as is.
        """
        return {
            'distributor_id': self.distributor
        }

    def get_auth_headers(self):
        """
        Creates authentication headers from Priohub API request with bearer access token.
        """
        self.get_access_token()

        if not self.access_token:
            raise Exception("No bearer token for Prio API call.")

        self.auth_headers = get_auth_headers(bearer=self.access_token)

    def get_product(self, **kwargs):
        """
        Gets a product information based on passed keyword arguments.

        :param kwargs:
            > product_id = ID of the product we need to get information of.
        :rtype: dict
        """

        product_id = kwargs.get('product_id')

        api_url = "https://{env}.prioticket.com/v{ver}/distributor/products/{product_id}".format(
            env=self.env,
            ver=self.version,
            product_id=product_id
        )

        self.get_auth_headers()

        api_response = make_get_request(api_url, self.auth_headers, self.get_base_headers())

        if api_response['status_code'] == 200:
            return api_response['response']
        else:
            raise Exception("Error while getting product: {} | {}".format(
                api_response['status_code'],
                api_response['response']
            ))

    def get_product_availability(self, product_id, from_date, to_date):
        """
        Gets availability of a product between the passed dates.
        """
        from_date = from_date.strftime('%Y-%m-%d')
        to_date = to_date.strftime('%Y-%m-%d')

        api_url = "https://{env}.prioticket.com/v{ver}/distributor/products/{product_id}/availability".format(
            env=self.env,
            ver=self.version,
            product_id=product_id
        )

        self.get_auth_headers()
        request_params = self.get_base_headers()
        request_params.update({
            'from_date': from_date,
            'to_date': to_date
        })

        api_response = make_get_request(api_url, self.auth_headers, request_params)

        if api_response['status_code'] == 200:
            return api_response['response']
        else:
            raise Exception("Error while getting product availability: {} | {}".format(
                api_response['status_code'],
                api_response['response']['error']
            ))
