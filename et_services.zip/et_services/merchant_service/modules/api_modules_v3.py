"""
contains api v3 specific modules and featured methods
"""
import datetime
import json
import math
from collections import OrderedDict
from json import JSONDecodeError
from operator import itemgetter

import requests
from dateutil import tz
from dateutil.parser import parse
from flask import current_app
from geopy import distance
from merchant_service.common.constants import (AED, CATEGORY_API_NAME_BODY,
                                               CATEGORY_API_NAME_LEISURE,
                                               CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                                               CATEGORY_API_NAME_RETAIL,
                                               CATEGORY_API_NAME_SERVICES,
                                               CATEGORY_API_NAME_TRAVEL,
                                               COLOR_BODY, COLOR_LEISURE,
                                               COLOR_RESTAURANTS_AND_BARS,
                                               COLOR_RETAIL, COLOR_SERVICES,
                                               COLOR_TRAVEL, EN,
                                               GREY_BACKGROUND_COLOR,
                                               LIVE_OFFERS_IMAGE,
                                               LOCATION_TIME_ZONE_MAP,
                                               OFFER_TEXT_COLOR,
                                               TAG_TITLE_COLOR,
                                               V7_ADDITIONAL_DETAIL_COLOR)
from merchant_service.common.models.api_messages import APIMessages
from merchant_service.common.models.category import Category
from merchant_service.common.models.dm_menu_item import DmMenuItem
from merchant_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from merchant_service.common.models.extended_trial_rules import \
    ExtendedTrialRule
from merchant_service.common.models.offer import Offer
from merchant_service.common.models.outlet import Outlet
from merchant_service.common.models.product import Product
from merchant_service.common.models.purchased_offer_pings import \
    PurchasedOfferPing
from merchant_service.common.models.redemption import Redemption
from merchant_service.common.models.share_offer import ShareOffer
from merchant_service.common.models.user_info import UserInfo
from merchant_service.common.rest_urls import RedemptionServiceAPIUrlsV3
from merchant_service.common.utils.api_utils import (encode_params,
                                                     get_api_configurations,
                                                     get_delivery_enabled_location_ids_against_company,
                                                     multi_key_sort)
from merchant_service.common.utils.cummunicator import communicator
from merchant_service.common.utils.translation_manager import \
    TranslationManager
from merchant_service.modules.api_modules import (assign_sort_order_to_offers,
                                                  format_merchant_attributes,
                                                  get_analytics_codes_against_categories,
                                                  get_image_url,
                                                  get_message_for_offer_type,
                                                  get_offer_sub_detail_object,
                                                  get_voucher_restriction_details,
                                                  get_voucher_type_details,
                                                  initialize_offers_array)
from merchant_service.modules.constants import (BODY_ATT,
                                                COLOR_CODE_ALREADY_REDEEMED,
                                                DUBAI_LOCATION_ID,
                                                FASHION_AND_RETAIL_ATT,
                                                ICON_URL_BASE_V7,
                                                IMAGE_TYPE_PARTY_SIZE,
                                                IMAGE_TYPE_VOUCHER_TYPE,
                                                LEISURE_ATT,
                                                PING_TIME_LIMIT_SECONDS,
                                                RESTAURANTS_AND_BARS_ATT,
                                                SECTION_NOT_REDEEMABLE,
                                                SECTION_PINGED,
                                                SECTION_REDEEMABLE,
                                                SECTION_REDEEMED, SERVICES_ATT,
                                                SMILES_COLOR_CODE,
                                                SMILES_ICON_URL, SORT_EXPIRED,
                                                SORT_NOT_REDEEMABLE,
                                                SORT_PINGED,
                                                SORT_PURCHASED_AVAILABLE_IN_FUTURE,
                                                SORT_REDEEMABLE, SORT_REDEEMED,
                                                TRAVEL_ATT)
from shapely.geometry import Point


def get_birthday_offer_validity_in_days(birth_date):
    """
    calculate and validate customer birth date
    :param birth_date:
    :return number_of_birthday_validity_days:
    """
    current_date = datetime.datetime.now().date()
    try:
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=birth_date.day
        )
    except ValueError:  # For 29th Feb on non leap year
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=28
        )
    birthday_start_period = birthday_period + datetime.timedelta(
        days=EntCustomerProfile.HAPPY_BIRTHDAY_START_RANGE_DAYS)
    birthday_end_period = birthday_period + datetime.timedelta(days=EntCustomerProfile.HAPPY_BIRTHDAY_END_RANGE_DAYS)
    if birthday_start_period <= current_date <= birthday_end_period:
        return (birthday_end_period - current_date).days
    return -1


def get_birthday_offer_validity():
    """
    Returns date of validity in case of birthday offer.
    """
    offer_validity_date = datetime.datetime.now().date()
    offer_validity_date = offer_validity_date + datetime.timedelta(
        days=EntCustomerProfile.HAPPY_BIRTHDAY_END_RANGE_DAYS)
    offer_validity_date = datetime.datetime.strptime(
        offer_validity_date.strftime("%Y-%m-%dT12:00:00"),
        "%Y-%m-%dT%H:%M:%S"
    )
    return offer_validity_date


def get_ping_section():
    """
    Returns ping section dict
    :rtype: dict
    """
    return {
        'is_sender_info': False,
        'is_recipient_info': False,
        'can_user_ping': False,
        'can_user_receive_ping': False,
        'total_quota_to_send_pings': 0,
        'total_quota_to_receive_pings': 0,
        'total_pings_sent': 0,
        'total_pings_received': 0,
        'message': '',
        'background_color': ''
    }


def get_number_of_allowed_pings(**kwargs):
    """
    This returns number of allowed pings
    - get customer ping limit
    - get customer purchased pings
    :returns number_of_allowed_pings:
    """
    user_id = kwargs['user_id']
    customer_ping_offer_limit = UserInfo.get_ping_offer_limit(user_id)

    # Get the Number of Purchased Pings through Smiles
    purchased_pings = PurchasedOfferPing.get_purchased_pings(user_id, datetime.datetime.now().year)
    # If older pings available
    if customer_ping_offer_limit:
        if purchased_pings:
            # add the purchased pings
            return purchased_pings + customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES
        return customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES

    number_of_allowed_pings = ShareOffer.MAX_ALLOWED_SHARES
    if purchased_pings:
        number_of_allowed_pings += purchased_pings
    return number_of_allowed_pings


def get_ping_details(user_id, membership_status, product_id_owned, is_sender, is_family_member=False,
                     primary_user_id=None):
    """
    - get/set dummy ping data
    - get number of allowed pings
    - get number of shared pings
    - get shared offer pings count
    - update ping dict
    - Returns ping details

    :param primary_user_id:
    :param is_family_member:
    :param user_id:
    :param membership_status:
    :param product_id_owned:
    :param is_sender:
    :rtype: dict
    """
    ping_details = get_ping_section()
    if user_id:
        user_quota_to_send_pings = 0
        if membership_status == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_family_member:
            user_quota_to_send_pings = get_number_of_allowed_pings(
                user_id=user_id,
                product_id_owned=product_id_owned
            )
        total_offers_pinged = ShareOffer.get_shared_offers_by_sender_count(
            sender_id=user_id, primary_sender_user_id=primary_user_id
        )
        ping_details['is_sender_info'] = is_sender
        ping_details['is_recipient_info'] = not is_sender
        ping_details['can_user_ping'] = user_quota_to_send_pings > total_offers_pinged
        ping_details['total_quota_to_send_pings'] = user_quota_to_send_pings
        ping_details['total_pings_sent'] = total_offers_pinged
    return ping_details


def get_geo_point_from_lat_lng(company, lat, lng, location_id):
    """
    Get shapely geo point from latitude and longitude.

    :param company:
    :param lat:
    :param lng:
    :param location_id:
    :return: geo point
    """
    lat_lng_point = None
    try:
        if lat and lng:
            lat_lng_point = Point(float(lng), float(lat))
        elif (
            not lat_lng_point and
            location_id in get_delivery_enabled_location_ids_against_company(company)
        ):
            if location_id == 1:  # dubai center location
                lat_lng_point = Point(55.307709, 25.300579)
            if location_id == 2:  # abu dhabhi center location
                lat_lng_point = Point(54.362671, 24.534632)
            if location_id == 9:  # qatar location
                lat_lng_point = Point(51.521652, 25.296234)
    except Exception:
        pass
    return lat_lng_point


def convert_timedelta_to_datetime(timedelta, location_current_time):
    """
    Convert timedelta object to datetime obj w.r.t user selected location.

    Problem:
        dateutil.parser.parse convert time string to datetime obj. date will be server/dubai date.
        qatar merchant delivery time in dm_delivery_timings is 10pm - 11:59pm.
        it means merchant will be online at 10pm - 11:59pm qatar time and 11pm-12:59am server/dubai time.
        Let assume that current date is 25 November 2019.
        logically time slot will be ===> 2019-11-25 23:00:00 -  2019-11-26 00:59:00
        but dateutil.parser.parse gives following time slot
            1. 2019-11-25 23:00:00 -  2019-11-26 00:59:00 (before dubai next day, qatar and dubai date are same)
            2. 2019-11-26 23:00:00 -  2019-11-26 00:59:00 (after dubai next day, qatar and dubai date are different)
        second case is the issue in which parse add date of next day in start time.

    Solution:
        convert time string to datetime obj via dateutil.parser.parse
        after that replace day,month and year with day,month and year of :param location_current_time


    :param datetime.timedelta,str timedelta: datetime timedelta obj or time string
    :param datetime location_current_time: current time of user selected location
    :return datetime: native datetime obj as per user location
    """
    user_location_time = parse(str(timedelta)).replace(
        day=location_current_time.day, month=location_current_time.month, year=location_current_time.year
    )
    return user_location_time


def calculate_outlet_availability(
        last_ping, is_device_online, delivery_start_time, delivery_end_time, total_minutes, location_id
):
    """
    calculate and process outlet availability
    :param last_ping:
    :param is_device_online:
    :param delivery_start_time:
    :param delivery_end_time:
    :param total_minutes:
    :return int i_open, str delivery_hours:
    """
    is_open = bool(is_device_online)
    now = get_current_time_of_location(location_id)
    from_time_am_pm = ''
    to_time_am_pm = ''
    try:
        from_time = convert_timedelta_to_datetime(delivery_start_time, now)
        from_time = parse(from_time)
        from_time_am_pm = from_time.strftime("%I:%M%p")
    except (TypeError, ValueError):
        from_time = ''
    try:
        to_time = str(delivery_end_time)
        to_time = parse(to_time)
        to_time_am_pm = to_time.strftime("%I:%M%p")
    except (TypeError, ValueError):
        to_time = ''
    if is_open and from_time:
        is_open = False
        try:
            to_time = from_time + datetime.timedelta(minutes=total_minutes)
            if from_time < now < to_time:
                is_open = True
        except (TypeError, ValueError):
            pass
    else:
        is_open = False
    if last_ping and is_open:
        last_ping_seconds = (get_current_time_of_location(DUBAI_LOCATION_ID) - last_ping).total_seconds()
        if last_ping_seconds > PING_TIME_LIMIT_SECONDS:
            is_open = False
    else:
        is_open = False
    delivery_hours = '{from_time} - {to_time}'.format(from_time=from_time_am_pm, to_time=to_time_am_pm)
    return int(is_open), delivery_hours


def find_distance(lat, lng, outlet_lat, outlet_lng):
    """
    Returns outlet's distance in KM from target lat long

    :param float lat: Person latitude
    :param float lng: Person longitude
    :param float outlet_lat: Outlet latitude
    :param float outlet_lng: Outlet longitude
    :rtype: float
    :returns: outlet_distance in Km's
    """
    outlet_distance = 0
    if lat is not None and lng is not None and outlet_lat is not None and outlet_lng is not None:
        lat_lng = (lat, lng)
        outlet_lat_lng = (outlet_lat, outlet_lng)
        outlet_distance = distance.distance(lat_lng, outlet_lat_lng).km

    return outlet_distance


def inject_distances_and_sort_v3(outlets, target_lat_long='0,0', return_ids=False, do_extra_work=False,
                                 platform="", device_key="", merchant_contact_number=""):
    """
    This method does some calculations on latitude and longitude and sort result on basis of that calculation
    :param merchant_contact_number:
    :param device_key:
    :param platform:
    :param do_extra_work:
    :param list outlets: List of outlet dicts
    :param str target_lat_long: String of latitude and longitude appended by coma
    :param bool return_ids: Flag to get list of ids as well
    """
    ids = []
    if target_lat_long and target_lat_long not in ['0,0', '0.0,0.0']:
        target_lat_long = list(map(float, target_lat_long.split(',')))
        for _index, outlet in enumerate(outlets):
            outlet = outlet._asdict()
            outlets[_index] = outlet
            if do_extra_work:
                # For IOS
                if outlet['tripadvisor_id'] == 0 and platform in ['', 'ios'] and 'wp' in device_key.lower():
                    outlet['tripadvisor_id'] = 9999
                if not outlet['delivery_telephone']:
                    outlet['delivery_telephone'] = merchant_contact_number

            if 'Ritz-Carlton' not in outlet.get('name', ''):
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

            outlet['lat'], outlet['lng'] = (float(outlet['lat'] if outlet['lat'] is not None else 0),
                                            float(outlet['lng'] if outlet['lng'] is not None else 0))

            outlet['distance'] = round(
                math.acos(
                    math.cos(math.radians(90.0 - target_lat_long[0])) *
                    math.cos(math.radians(90.0 - outlet['lat'])) +
                    math.sin(math.radians(90.0 - target_lat_long[0])) *
                    math.sin(math.radians(90.0 - outlet['lat'])) *
                    math.cos(math.radians((target_lat_long[1] - outlet['lng'])))
                ) * 6371.0 * 1000.0
            )
            if return_ids:
                ids.append(outlet['id'])
    else:
        for _index, outlet in enumerate(outlets):
            outlet = outlet._asdict()
            outlets[_index] = outlet
            if do_extra_work:
                # For IOS
                if outlet['tripadvisor_id'] == 0 and platform in ['', 'ios'] and 'wp' in device_key.lower():
                    outlet['tripadvisor_id'] = 9999
                if not outlet['delivery_telephone']:
                    outlet['delivery_telephone'] = merchant_contact_number

            if 'Ritz-Carlton' not in outlet['name']:
                outlet_name_parts = outlet['name'].split('-')
                outlet['name'] = outlet_name_parts[-1].strip()

            if return_ids:
                ids.append(outlet['id'])

    if outlets:
        sorted(outlets, key=itemgetter('distance'))

    return ids


def get_bat_section(session_token, merchant_id, merchant_name, outlet_id, message_locale=EN):
    """
    Returns bat section.
    """

    button_title = TranslationManager.get_translation(TranslationManager.BOOK_A_TABLE, message_locale)

    key = current_app.config['PARAM_ENCRYPTION_KEY']
    salt = current_app.config['PARAM_ENCRYPTION_SALT']
    mode = current_app.config['PARAM_ENCRYPTION_MODE']

    data_encode = {
        'token': session_token,
        'merchant_id': merchant_id,
        'outlet_id': outlet_id
    }
    encoded_data = encode_params(key, salt, mode, json.dumps(data_encode).encode()).decode(errors='ignore')

    return {
        "bat_url": current_app.config['BAT_URL'].format(params=encoded_data),
        "bat_webview_title": merchant_name,
        "bat_button_bg_color": "4d97d0",
        "bat_button_title": button_title
    }


def process_extended_trial_rules(extended_trail_rules_sql, location_id):
    """
    :param extended_trail_rules_sql:
    :return:
    """
    extended_trail_rules = []
    for rule in extended_trail_rules_sql:
        if rule.location_id == location_id:
            try:
                extended_trail_rules.append(rule._asdict())
            except:
                extended_trail_rules.append(rule.__dict__)
        # as travel dont hai location id
        elif str(rule.get('category', '')).lower() == 'travel' and not rule.get('location_id'):
            extended_trail_rules.append(rule)
    rules = dict()
    rules['categories'] = []
    rules['category_info'] = {}
    rules['getaways_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_travel_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_cheers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_delivery_info'] = {'enabled': False, 'saving_estimates': []}
    rules['cashless_delivery_enabled_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_monthly_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_more_sa_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_merlin_offer_info'] = {'enabled': False, 'saving_estimates': []}
    rules['has_cinema_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_bonus_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_johor_bahru_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_product_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fine_dining_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_family_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fitness_product'] = {'enabled': False, 'saving_estimates': []}
    for rule in extended_trail_rules:
        category = ''
        if rule.get('category'):
            category = rule.get('category')

        rules['categories'].append(category)
        try:
            rules['category_info'][category]
        except KeyError:
            rules['category_info'][category] = dict()
            rules['category_info'][category]['saving_estimates'] = []
            rules['category_info'][category]['sub_rules'] = False
            rules['category_info'][category]['rules'] = dict()
            rules['category_info'][category]['rules']['is_more_sa'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_travel'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_cheers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_delivery'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['cashless_delivery_enabled'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_merlin_offer'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_monthly'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_bonus_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['has_cinema_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fine_dining_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_family_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fitness_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_johor_bahru'] = {
                'enabled': False, 'saving_estimates': []
            }
        rules['category_info'][category]['saving_estimates'].append(
            rule.get('max_savings_estimate_cap', 0)
        )

        if rule.get('enabled_getaways'):
            rules['getaways_info']['enabled'] = True
        if rule.get('enabled_travel_offers'):
            rules['is_travel_info']['enabled'] = True
            rules['is_travel_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_travel']['enabled'] = True
            rules['category_info'][category]['rules']['is_travel']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cheer_offers'):
            rules['is_cheers_info']['enabled'] = True
            rules['is_cheers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_cheers']['enabled'] = True
            rules['category_info'][category]['rules']['is_cheers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_delivery_offers'):
            rules['is_delivery_info']['enabled'] = True
            rules['is_delivery_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_delivery']['enabled'] = True
            rules['category_info'][category]['rules']['is_delivery']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cashless_offers'):
            rules['cashless_delivery_enabled_info']['enabled'] = True
            rules['cashless_delivery_enabled_info']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['cashless_delivery_enabled']['enabled'] = True
            rules['category_info'][category]['rules']['cashless_delivery_enabled']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_monthly_offers'):
            rules['is_monthly_info']['enabled'] = True
            rules['is_monthly_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_monthly']['enabled'] = True
            rules['category_info'][category]['rules']['is_monthly']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('more_offers'):
            rules['is_more_sa_info']['enabled'] = True
            rules['is_more_sa_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_more_sa']['enabled'] = True
            rules['category_info'][category]['rules']['is_more_sa']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_merlin_offers'):
            rules['is_merlin_offer_info']['enabled'] = True
            rules['is_merlin_offer_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['enabled'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cinema_offers'):
            rules['has_cinema_offers_info']['enabled'] = True
            rules['has_cinema_offers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['enabled'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_bonus_offers'):
            rules['is_bonus_offers_info']['enabled'] = True
            rules['is_bonus_offers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['enabled'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_johor_baru_offers'):
            rules['is_johor_bahru_info']['enabled'] = True
            rules['is_johor_bahru_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['enabled'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_fine_dining_offers'):
            rules['is_core_fine_dining_product']['enabled'] = True
            rules['is_core_fine_dining_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_family_offers'):
            rules['is_core_family_product']['enabled'] = True
            rules['is_core_family_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_fitness_offers'):
            rules['is_core_fitness_product']['enabled'] = True
            rules['is_core_fitness_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
    return rules


def get_extended_trial_rules_current_customer(customer, location_id=0):
    """
    Fetch trial rules of current request user.
    :param int location_id: location id
    :rtype: dict
    """
    rules = {}

    if customer.get('is_member_on_trial') and customer.get('is_using_extended_trial'):
        rules = ExtendedTrialRule.user_trial_extended_rules(
            extended_trail_group_ids=customer.get('extended_trial_ids', []),
            location_id=location_id
        )

    return process_extended_trial_rules(extended_trail_rules_sql=rules, location_id=location_id)


def parse_voucher_restrictions(json_encoded_voucher_restriction):
    """
    parses a json encoded string
    :param json_encoded_voucher_restriction: json encoded string
    :return: decoded json
    """
    if json_encoded_voucher_restriction:
        return json.loads(json_encoded_voucher_restriction)
    return {}


def _set_hours(date, hours=14):
    """
    :param date:
    :param hours:
    :return:
    """
    if hours > 9:
        return date.strftime("%Y-%m-%dT{}:00:00+0400".format(hours))
    return date.strftime("%Y-%m-%dT0{}:00:00+0400".format(hours))


def is_offer_allowed_to_ping(is_ent, offer_type, category, is_freemium, membership_sub_group=0, is_merlin_offer=False):
    """
    Checks whether or not the offer is allowed to be pinged
    :param is_ent:
    :param offer_type:
    :param category:
    :param is_freemium:
    :param is_merlin_offer
    :param membership_sub_group:
    :return: bool
    """
    if membership_sub_group == EntCustomerProfile.ACTIVE_MEMBERSHIP_SUB_GROUP:
        return False
    return (
        is_ent == 1 and offer_type != Offer.TYPE_MEMBER and
        category.lower() != Category.TRAVEL.lower() and is_freemium == 0 and
        not is_merlin_offer
    )


def get_and_process_offers_v3(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    """

    delivery_offers_count = 0
    take_away_offers_count = 0
    is_customer_logged_in = kwargs.get('customer', {}).get('is_user_logged_in')

    outlet_exclude_from_offers = kwargs.get('all_offers_active', True)
    is_take_away_enabled = kwargs.get('is_take_away', False)
    only_delivery = kwargs.get('only_delivery', False)

    if only_delivery:
        outlet_exclude_from_offers = False

    primary_user_id = kwargs['primary_user_id']
    show_cheer_offers = kwargs['show_cheer_offers']
    personal_cheer_offers = kwargs.get('personal_cheer_offers', [])
    company = kwargs.get('company')
    pings_received_offer_ids = []

    redeemability_api_url_cls = RedemptionServiceAPIUrlsV3
    redeemability_api_url = redeemability_api_url_cls.CALCULATE_REDEEMABILITY

    for offer_received in kwargs['shared_offers_received']:
        if offer_received.offer_id not in pings_received_offer_ids:
            pings_received_offer_ids.append(offer_received.offer_id)

    if kwargs.get('offers_es'):
        offers_es = kwargs['offers_es']
        offer_id = 0
        if kwargs.get('offer_id', 0):
            offer_id = kwargs.get('offer_id', 0)
        category = None

        from merchant_service.common.constants import VALID_CATEGORIES

        if kwargs.get('selected_category') in VALID_CATEGORIES:
            category = kwargs['selected_category']

        if kwargs.get('customer'):
            product_ids = kwargs['customer'].get('product_ids', [])
            filtered = []
            for offer in offers_es:
                if category and offer['category'] != category:
                    continue
                if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                    continue
                if offer_id and offer['id'] != kwargs['offer_id']:
                    continue
                if not (
                    (
                        offer['is_ent'] == 1 and offer['is_dummy_product'] != 1 and
                        offer['show_offers_if_purchased'] != 1 and offer['is_freemium'] != 1
                    ) or
                    (
                        offer['product_id'] in product_ids or offer['id'] in pings_received_offer_ids
                    )
                ):
                    continue
                filtered.append(offer)
            offers_es = filtered
        else:
            filtered = []
            for offer in offers_es:
                if category and offer['category'] != category:
                    continue
                if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                    continue
                if offer_id and offer['id'] != kwargs['offer_id']:
                    continue
                if not (offer['is_ent'] == 1 and
                        offer['is_dummy_product'] != 1 and
                        offer['show_offers_if_purchased'] != 1 and
                        offer['is_cheers'] != 1 and
                        offer['is_freemium'] != 1):
                    continue
                filtered.append(offer)
            offers_es = filtered
        offers = offers_es
    else:
        offers = Offer.find_by_outlets_v3(
            company=kwargs.get('company'),
            is_ent=kwargs.get('is_ent'),
            pings_received_offer_ids=pings_received_offer_ids,
            customer=kwargs.get('customer', {}),
            merchant_id=kwargs.get('merchant_id', None),
            outlet_ids=kwargs.get('outlet_ids'),
            offer_id=kwargs.get('offer_id'),
            only_delivery=kwargs.get('only_delivery', False),
            outlet_exclude_from_offers=kwargs.get('all_offers_active', True),
            show_cheer_offers=show_cheer_offers,
            personal_cheer_offers=personal_cheer_offers,
            location_id=kwargs.get('location_id', 0),
            is_merlin_offers_to_show=kwargs.get('is_merlin_offers_to_show'),
            selected_category=kwargs.get('selected_category'),
            is_take_away_enabled=is_take_away_enabled,
            outlet_id=kwargs.get('outlet_id'),
            enable_delivery_cashless=kwargs.get('enable_delivery_cashless')
        )

    offer_ids = []
    offers_to_delete = []
    customer = kwargs.get('customer', {})
    cashless_delivery_enabled = kwargs.get('enable_delivery_cashless')

    for offer_index, offer in enumerate(offers):
        try:
            offer = offer._asdict()
            offers[offer_index] = offer
        except Exception:
            pass

        offer_ids.append(offer['id'])
        if offer.get('cashless_delivery_enabled', False) and outlet_exclude_from_offers:
            outlet_exclude_from_offers = False

    redemption_quantities = {}

    if is_customer_logged_in:
        if customer.get('family_is_active') and customer.get('is_user_in_family'):
            redemption_results = Redemption.get_redeemed_quantities_for_customer(
                customer_id=customer.get('customer_id', 0),
                family_id=customer['family_info'].id,
                primary_user_id=primary_user_id,
                offer_id=offer_ids,
                company=company,
                is_onboarding=customer.get('is_using_trial', 0)
            )
            for redemption in redemption_results:
                redemption_quantities[redemption['offer_id']] = int(redemption.qty)
            if primary_user_id != customer['customer_id']:
                secondary_birthday_redemptions = Redemption.get_birthday_redeemed_quantities_for_secondary_customer(
                    customer_id=customer.get('customer_id', 0),
                    is_onboarding=customer.get('is_using_trial', 0),
                    offer_id=offer_ids,
                    company=company
                )
                redemption_quantities.update(secondary_birthday_redemptions)
        else:
            redemption_results = Redemption.get_redeemed_quantities_for_customer(
                customer_id=customer.get('customer_id', 0),
                family_id=customer.get('family_info', {}).get('id'),
                primary_user_id=primary_user_id,
                offer_id=offer_ids,
                company=company,
                is_onboarding=customer.get('is_using_trial', 0),
            )
            for redemption in redemption_results:
                redemption_quantities[redemption.offer_id] = int(redemption.qty)

    offer_categories = kwargs['offer_categories']
    offer_sub_categories = kwargs['offer_sub_categories']
    ids = []
    has_dinner_offers = True

    for offer_index, offer in enumerate(offers):
        # for normal merchant and dubai location
        if isinstance(offer.get('outlet_ids'), list):
            outlet_ids = offer['outlet_ids']

        elif isinstance(offer.get('outlet_ids'), str):
            outlet_ids = list(set(map(int, filter(None, offer.get('outlet_ids').split(',')))))

        else:
            outlet_ids = []

        if (
            not only_delivery and
            kwargs.get('location_id', 0) in get_delivery_enabled_location_ids_against_company(company)
        ):
            if offer.get('is_take_away_offer', False):
                take_away_offers_count += 1

        if (
            not only_delivery and
            kwargs.get('location_id', 0) in get_delivery_enabled_location_ids_against_company(company) and
            not outlet_exclude_from_offers
        ):
            if kwargs.get('outlet_id'):
                # for cashless location we will exclude the offers for merchant details screen to show view
                # delivery offers button this will be instantiated from delivery cashless merchant details screen
                # https://entertainerproducts.atlassian.net/browse/DC-34
                if cashless_delivery_enabled:
                    if offer.get('cashless_delivery_enabled', False) and offer('is_delivery_cashless_offer'):
                        if kwargs.get('outlet_id', 0) in outlet_ids:
                            delivery_offers_count += 1
                        offers_to_delete.append(offer_index)
                        ids.extend(outlet_ids)
                        continue
                    elif offer.get('is_delivery', False):
                        offers_to_delete.append(offer_index)
                        ids.extend(outlet_ids)
                        continue

                if kwargs.get('outlet_id', 0) and kwargs.get('outlet_id', 0) not in outlet_ids:
                    offers_to_delete.append(offer_index)
                    ids.extend(outlet_ids)
                    continue
            else:
                # for global search and cashless location if outlet is not part of delivery_cashless then exclude
                # cashless_delivery_enabled and is_delivery offers
                if (
                    offer.get('cashless_delivery_enabled', False) or
                    offer.get('is_delivery', False)
                ):
                    offers_to_delete.append(offer_index)
                    ids.extend(outlet_ids)
                    continue

        if kwargs.get('is_merlin_offers_to_show'):
            offer['merlin_title'] = kwargs.get('merchant_name')

        if offer.get('category', '') not in offer_categories:
            offer_categories.append(offer.get('category'))

        if offer.get('sub_category', '') and offer.get('sub_category', '') not in offer_sub_categories:
            offer_sub_categories.append(offer.get('sub_category'))

        offer.update({
            'conditions': parse_voucher_restrictions(offer.get('conditions', {})),
            'redeemability': 0,
            'is_purchased': False,
            'allowed_onboarding': False,
            'is_offer_valid_in_future': False,
            'is_offer_expired': False,
            'quantity_redeemable': 0,
            'quantity_redeemed': 0,
            'quantity_not_redeemable': offer.get('quantity', 0),
            'shared_sent_count': 0,
            'shared_received_count': 0,
            'shared_redemptions_count': 0,
            'is_show_purchase_button': False,
            'is_new': offer['type'] == Offer.TYPE_NEW_OFFER,
            "is_pingable": is_offer_allowed_to_ping(
                is_ent=offer['is_ent'],
                offer_type=offer['type'],
                category=offer['category'],
                is_freemium=offer['is_freemium'],
                is_merlin_offer=offer['is_merlin_offer'],
                membership_sub_group=customer.get('membership_sub_group',
                                                  EntCustomerProfile.INACTIVE_MEMBERSHIP_SUB_GROUP)
            ),
            'outlet_ids': outlet_ids,
            'merlin_title': offer['merlin_title'],
            'is_merlin_offer': bool(offer['is_merlin_offer']),
            'valid_from_date': _set_hours(offer['valid_from_date'], 4),
            'expiration_date': _set_hours(offer['expiration_date'], 14),
            'has_cinema_offers': offer.get('has_cinema_offers', 0),
            'cinema_venue_id': offer.get('cinema_venue_id', 0),
            'is_bonus_offers': offer.get('is_bonus_offers', 0),
            'is_core_product': offer.get('is_core_product', 0),
            'is_core_fine_dining_product': offer.get('is_core_fine_dining_product', 0),
            "is_core_family_product": offer.get('is_core_family_product', 0),
            "is_core_fitness_product": offer.get('is_core_fitness_product', 0),
            'is_monthly_cheers': 0,
            'is_redeemable': 0
        })

        # Monthly offer check on base of ismember flag and offer_type if show_monthly_offers_on_product is True.
        if kwargs.get('show_monthly_offers_on_product', True):
            if offer['type'] == Offer.TYPE_MEMBER:
                offer['is_monthly'] = offer['type'] == Offer.TYPE_MEMBER
            else:
                offer['is_monthly'] = bool(offer.get('ismember'))
        else:
            offer['is_monthly'] = offer['type'] == Offer.TYPE_MEMBER

        if offer.get('is_merlin_offer'):
            offer['outlet_merlin_urls'] = kwargs['outlet_merlin_urls']
        else:
            offer['outlet_merlin_urls'] = []

        if offer.get('is_monthly_offer') and offer.get('is_cheers'):
            offer['is_monthly_cheers'] = 1

        if is_customer_logged_in:
            is_top_up_offer = False
            top_up_offer_count = 0

            for top_up_offer in kwargs.get('top_up_offers', []):
                if top_up_offer.offer_id == offer.get('id'):
                    is_top_up_offer = True
                    top_up_offer_count = top_up_offer_count + 1

            redeemability_params = {
                'offer_ids': offer.get('id'),
                'is_birthday_offer': offer.get('is_birthday_offer'),
                'location_id': kwargs.get('location_id'),
            }
            offer_redeemability = communicator.communicate(
                redeemability_api_url,
                'GET',
                payload=redeemability_params
            ).json().get('data', {})

            offer_product_id = "{}_{}".format(offer.get('id'), offer.get('product_id'))
            redeemability = offer_redeemability.get(offer_product_id, {})

            offer.update({
                'redeemability': redeemability.get('redeemability', 2),
                'is_purchased': redeemability.get('is_purchased'),
                'allowed_onboarding': redeemability.get('allowed_onboarding'),
                'is_offer_valid_in_future': redeemability.get('is_offer_valid_in_future'),
                'is_offer_expired': redeemability.get('is_offer_expired'),
                'quantity_redeemable': redeemability.get('quantity_redeemable', 1),
                'quantity_redeemed': redeemability.get('quantity_redeemed', 0),
                'quantity_not_redeemable': redeemability.get('quantity_not_redeemable', 0),
                'shared_sent_count': redeemability.get('shared_sent_count', 0),
                'shared_received_count': redeemability.get('shared_received_count', 0),
                'shared_redemptions_count': redeemability.get('shared_redemptions_count', 0),
                'is_show_purchase_button': redeemability.get('is_show_purchase_button'),
                'personal_shared_received_count': redeemability.get('personal_shared_received_count', 0),
                'personal_shared_redemptions_count': redeemability.get('personal_shared_redemptions_count', 0),
                'is_top_up_offer': is_top_up_offer
            })

        if offer.get('redeemability') in (Redemption.REDEEMABLE, Redemption.REUSABLE):
            offer['is_redeemable'] = 1

        if kwargs.get('return_outlet_ids'):
            ids.extend(offer['outlet_ids'])

    if ids:
        ids = list(set(ids))

    for offer_index in sorted(offers_to_delete, reverse=True):
        try:
            del offers[offer_index]
        except IndexError:
            pass

    if kwargs.get('return_outlet_ids'):
        return (
            offers,
            ids,
            offer_categories,
            offer_sub_categories,
            offer_ids,
            delivery_offers_count,
            has_dinner_offers,
            take_away_offers_count
        )

    return (
        offers,
        [],
        offer_categories,
        offer_sub_categories,
        offer_ids,
        delivery_offers_count,
        has_dinner_offers,
        take_away_offers_count
    )


def process_menu_details_v3(menus_details, offer_ids, locale=EN, currency=AED):
    """
    process delivery menu items for merchant
    :param menus_details:
    :param offer_ids:
    :param locale:
    :param currency:
    :return processed_menu:
    """
    category_items_hash = OrderedDict()
    category_id_to_names = {}
    menu_item_ids = []
    all_customisations = {}
    menu_items_after_removing_duplicate = list()
    offers_hash_to_remove_duplicate = dict()
    # offer_ent_active_repo = OfferEntActiveRepositoryV65()
    for result_item in menus_details:  # Getting menu item ids to save multiple queries
        # we will make a hash of results with their name as key.
        # We will check if key already exists in hash and assigned a voucher we will skip to add again.
        # Otherwise we will add this to finalize menu items list if not duplicated
        result = result_item._asdict()
        try:
            if offers_hash_to_remove_duplicate.get(result.get('product_name', '')) and not result.get('voucherId', 0):
                duplicated_menu_item = offers_hash_to_remove_duplicate.get(result.get('product_name', '').lower())
                if duplicated_menu_item.get('menuName', '').lower() == result.get('menuName', '').lower():
                    continue
                else:
                    menu_items_after_removing_duplicate.append(result)
            else:
                menu_items_after_removing_duplicate.append(result)
            offers_hash_to_remove_duplicate[result.get('product_name', '')] = result
        except Exception:
            offers_hash_to_remove_duplicate[result.get('product_name', '')] = result
            menu_items_after_removing_duplicate.append(result)

        menu_item_ids.append(result.get('product_id'))
    #  we will get all values from hash in finalize_result list for further calculations and sort them as in query.
    finalize_result = multi_key_sort(menu_items_after_removing_duplicate, columns=['menuId', 'product_id'])
    if menu_item_ids:
        customisations = DmMenuItem.get_outlet_items_customisations(menu_item_ids, locale, currency)
        all_customisations = process_outlet_items_customisations(customisations, currency)
    for result in finalize_result:
        voucher_id = result.voucherId
        if voucher_id in offer_ids:
            image_url = get_image_url(
                image_type=IMAGE_TYPE_VOUCHER_TYPE,
                category=result.category if result.category else result.m_category,
                voucher_type_id=result.voucher_type,
                replace_241_type_with_141=False,
                is_monthly=True if result.offer_type == 2 else False,
            )
        else:
            image_url = ''
        customisations = all_customisations.get(result['product_id'], {})
        temp = {
            "maximumOrderNumber": 1000,
            "name": result.product_name,
            "is_customisable": bool(customisations),
            "description": result.product_description,
            "price": result.item_price,
            "productId": result.product_id,
            "imageURL": image_url
        }
        if customisations:
            temp['customizations'] = []
        if voucher_id in offer_ids:
            temp.update({'voucherId': voucher_id})
        # sorted(customisations) will return sorted customisations keys
        for customisation_key in sorted(customisations):
            temp['customizations'].append(customisations[customisation_key])
        try:
            int(result.sort_order)
        except (TypeError, ValueError):
            result.sort_order = 9999999
        menu_key = "{}_{}".format(result.sort_order, result.menuId)
        if category_items_hash.get(menu_key):
            category_items_hash[menu_key].append(temp)
        else:
            category_items_hash[menu_key] = [temp]
            category_id_to_names[menu_key] = result.menuName
    menus = []
    for menu_key in sorted(category_items_hash, key=lambda obj: int(obj.split("_")[0])):
        try:
            menu_name = category_id_to_names[menu_key]
        except KeyError:
            menu_name = ''
        try:
            menu_id = str(menu_key).split("_")[1]
        except IndexError:
            menu_id = ''
        menus.append({
            "menuId": menu_id, "menuName": menu_name, "products": category_items_hash[menu_key]
        })
    return menus


def process_outlet_items_customisations(menu_items, currency=AED):
    """
    process outlet items customisations
    :param menu_items:
    :param currency:
    :return final_hierarchy:
    """
    final_hierarchy = OrderedDict()
    menu_hierarchy = OrderedDict()
    option_section_id_to_option_items = OrderedDict()

    current = menu_items[0].menu_item_id if menu_items else 0
    customization_item_ids = []
    for _index, row in enumerate(menu_items):
        row = row._asdict()
        menu_items[_index] = row
        make_it_meal_validation = False
        row['title'] = 'Customise' if row['group_identifier'] == 'custom_options' else 'Make it a meal'
        attribute_group = row['attribute_group_id']
        if row['menu_item_id'] != current:
            final_hierarchy[current] = menu_hierarchy
            menu_hierarchy = {}
            current = row['menu_item_id']
        if not menu_hierarchy.get(row['title']):
            menu_hierarchy[row['title']] = {}
        if row['group_identifier'] == 'custom_options':
            menu_hierarchy[row['title']]['section_title'] = 'Customise'
        else:
            menu_hierarchy[row['title']]['section_title'] = 'Make it a meal'
            menu_hierarchy[row['title']]['minimum_option_selection'] = 1
            menu_hierarchy[row['title']]['validation_message'] = '1 items required'
            make_it_meal_validation = True
        if row['group_identifier'] == 'custom_options':
            menu_hierarchy[row['title']]['show_selection'] = False
        else:
            menu_hierarchy[row['title']]['show_selection'] = bool(row['min_choices'] < 1)
        menu_hierarchy[row['title']]['section_id'] = row['attribute_group_id']
        if row['min_choices']:
            menu_hierarchy[row['title']]['minimum_option_selection'] = int(row['min_choices'])
            menu_hierarchy[row['title']]['validation_message'] = '{} items required'.format(row['min_choices'])
        menu_hierarchy[row['title']]['is_selected'] = bool(row['min_choices'] >= 1)
        if not menu_hierarchy.get(row['title'], {}).get('options'):
            menu_hierarchy[row['title']]['options'] = []
        if not option_section_id_to_option_items.get(attribute_group):
            option_section_id_to_option_items[attribute_group] = {}
            if make_it_meal_validation:
                option_section_id_to_option_items[attribute_group]['minimum_option_selection'] = 1
                validation_message_make_it_meal = 'Please select at least {min} option(s) from {title}'.format(
                    min=option_section_id_to_option_items[attribute_group]['minimum_option_selection'],
                    title=row.get('group_name', 'Make it a meal')
                )
                option_section_id_to_option_items[attribute_group][
                    'validation_message'] = validation_message_make_it_meal  # noqa: E501

        # Options
        option_section_id_to_option_items[attribute_group]['title'] = row['group_name']
        option_section_id_to_option_items[attribute_group]['allow_multiple_selection'] = bool(row['max_choices'] > 1)
        if row['min_choices'] and row['max_choices']:
            if row['min_choices'] < row['max_choices']:
                option_section_id_to_option_items[attribute_group]['sub_title'] = "Choose at least {min} " \
                                                                                  "option(s), upto {max}".format(
                    min=row['min_choices'], max=row['max_choices']
                )
            elif row['min_choices'] == row['max_choices']:
                option_section_id_to_option_items[attribute_group]['sub_title'] = 'Choose {max} option(s)'.format(
                    max=row['max_choices']
                )

        if row['max_choices']:
            option_section_id_to_option_items[attribute_group]['maximum_option_selection'] = int(row['max_choices'])
            if not option_section_id_to_option_items[attribute_group].get('sub_title'):
                option_section_id_to_option_items[attribute_group]['sub_title'] = "Choose any option(s)," \
                                                                                  " upto {max}".format(
                    max=row['max_choices']
                )
            option_section_id_to_option_items[attribute_group]['maximum_validation_message'] = \
                "Please adjust your selection to include a maximum of {} customizations.".format(row['max_choices'])
        option_section_id_to_option_items[attribute_group]['option_section_id'] = attribute_group
        option_section_id_to_option_items[attribute_group]['is_selected'] = bool(row['min_choices'] >= 1)
        if row['min_choices']:
            option_section_id_to_option_items[attribute_group]['minimum_option_selection'] = int(row['min_choices'])
            if not option_section_id_to_option_items[attribute_group].get('sub_title'):
                option_section_id_to_option_items[attribute_group]['sub_title'] = 'Choose {min} option(s)'.format(
                    min=row['min_choices']
                )
            option_section_id_to_option_items[attribute_group]['validation_message'] = "Please select at least {}" \
                                                                                       " customization from {}".format(
                row['min_choices'], str(option_section_id_to_option_items[attribute_group].get('title'))
            )
        if option_section_id_to_option_items[attribute_group].get('options_items'):
            is_selected = False
            option_data = {
                "title": row['option_title'],
                "item_id": row['item_id'],
                "is_selected": is_selected,
                "price": row['attribute_price_field'],
                "sub_title": 'Free' if not row['attribute_price_field'] else
                "{0} {1:.2f}".format(currency, row['attribute_price_field'])
            }
            option_section_id_to_option_items[attribute_group]['options_items'].append(option_data)
        else:
            # option_section_id_to_option_items[attribute_group]['minimum_option_selected'] = 1
            option_data = {
                "title": row['option_title'],
                "item_id": row['item_id'],
                "is_selected": False,  # bool(row['min_choices'] >= 1),
                "price": row['attribute_price_field'],
                "sub_title": 'Free' if not row['attribute_price_field'] else
                "{0} {1:.2f}".format(currency, row['attribute_price_field'])
            }
            option_section_id_to_option_items[attribute_group]['options_items'] = [option_data]
        if attribute_group not in customization_item_ids:
            if not menu_hierarchy[row['title']]['options']:
                menu_hierarchy[row['title']]['options'] = [option_section_id_to_option_items[attribute_group]]
            else:
                menu_hierarchy[row['title']]['options'].append(option_section_id_to_option_items[attribute_group])
            customization_item_ids.append(attribute_group)
    final_hierarchy[current] = menu_hierarchy
    return final_hierarchy


def allowed_offer_buy_back(
        top_up_offer_against_product,
        offer_type,
        offer_quantity_redeemed,
        membership_type,
        offer_is_ent,
        is_active_family_member=False,
        member_ship_sub_group=0
):
    """
    :param is_active_family_member:
    :param top_up_offer_against_product:
    :param offer_type:
    :param offer_quantity_redeemed:
    :param membership_type:
    :param offer_is_ent:
    :param member_ship_sub_group:
    :return:
    """
    if (
        not top_up_offer_against_product and offer_type != Offer.TYPE_MEMBER and
        offer_quantity_redeemed and offer_is_ent and
        (membership_type == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_active_family_member) and
        member_ship_sub_group != EntCustomerProfile.ACTIVE_MEMBERSHIP_SUB_GROUP
    ):
        return True
    return False


def show_smiles_earn_value(membership_type, offer_is_ent, is_tutorial, product_type, is_merlin_offer=False):
    """
    Checks if we need to show smiles earned value.
    :rtype: bool
    """

    return (
        membership_type == EntCustomerProfile.MEMBERSTATUS_MEMBER and
        (offer_is_ent or product_type == Product.PRODUCT_TYPE_BIRTHDAY) and
        not is_tutorial and
        not is_merlin_offer
    )


def show_smile_earn_values(offer, is_active_family_member, customer, merchant):

    # Logic to show smiles earn value at offer level

    membership_type = customer.get('member_type_id', 0)
    if is_active_family_member:
        membership_type = EntCustomerProfile.MEMBERSTATUS_MEMBER

    if show_smiles_earn_value(
        membership_type,
        offer['is_ent'],
        merchant['is_tutorial'],
        offer['product_type'],
        offer.get('is_merlin_offer', False)
    ):
        offer['show_smiles_earn_value'] = True
        try:
            offer['smiles_earn_value'] = round(offer['savings_estimate'])
        except (TypeError, ValueError):
            offer['smiles_earn_value'] = 0
    else:
        offer['show_smiles_earn_value'] = False
        offer['smiles_earn_value'] = 0


def handle_deliverable_offer(company, offer, location_id, delivery_offers_count, redeemability_for_delivery):
    """

    :param company:
    :param offer:
    :param location_id:
    :param delivery_offers_count:
    :param redeemability_for_delivery:
    :return:
    """
    # if location is dubai then we calculate delivery_offers_count on the basis of cashless_delivery_enabled param
    # and on other locations use is_delivery param
    if (
        (
            location_id in get_delivery_enabled_location_ids_against_company(company) and
            offer.get('cashless_delivery_enabled', False)
        ) or
        (
            location_id not in get_delivery_enabled_location_ids_against_company(company) and
            offer.get('is_delivery', False)
        )
    ):
        delivery_offers_count += 1
        redeemability_for_delivery['total_offers'] = redeemability_for_delivery.get('total_offers', 0)
        redeemability_for_delivery['total_offers'] += offer.get('quantity_redeemable', 0)
        redeemability_for_delivery['total_offers'] += offer.get('quantity_redeemed', 0)
        redeemability_for_delivery['total_offers'] += offer.get('quantity_not_redeemable', 0)
        redeemability_for_delivery['total_offers'] += offer.get('shared_received_count', 0)
        redeemability_for_delivery['total_offers'] += offer.get('personal_shared_received_count', 0)
        redeemability_for_delivery['total_offers'] -= offer.get('quantity_redeemed', 0)
        redeemability_for_delivery['total_offers'] -= offer.get('shared_redemptions_count', 0)
        redeemability_for_delivery['total_offers'] -= offer.get('personal_shared_redemptions_count', 0)


def populate_cinema_offers(offer, instance):
    if offer.get('has_cinema_offers', False):
        key = current_app.config['PARAM_ENCRYPTION_KEY']
        salt = current_app.config['PARAM_ENCRYPTION_SALT']
        mode = current_app.config['PARAM_ENCRYPTION_MODE']
        offer['outlet_merlin_urls'] = []
        cinema_outlets = Outlet.get_outlets_having_cinema_venue_ids(
            offer.get('outlet_ids', [])
        )
        outlets_with_cinema_venue_ids = {}
        for outlet in cinema_outlets:
            outlets_with_cinema_venue_ids[outlet.outlet_id] = outlet.cinema_venue_id
        if outlets_with_cinema_venue_ids:
            offer['outlet_merlin_urls'] = dict()
            for outlet_id in offer.get('outlet_ids', []):
                venue_id = outlets_with_cinema_venue_ids.get(outlet_id, 0)
                if venue_id:
                    data_encode = {
                        'venue_id': venue_id,
                        'user_id': getattr(instance, 'user_id', ''),
                        'merchant_id': instance.merchant.get('id', ''),
                        'platform': getattr(instance, 'platform', ''),
                        'session_token': instance.customer.get('session_token', ''),
                        'outlet_id': outlet_id
                    }
                    encoded_data = encode_params(key, salt, mode, json.dumps(data_encode).encode()).decode(errors='ignore')  # noqa: #E501
                    offer['outlet_merlin_urls'][str(outlet_id)] = current_app.config['CINEMA_URL'].format(
                        params=encoded_data
                    )
        offer['is_merlin_offer'] = True
        offer['is_pingable'] = False
        offer['merlin_title'] = offer.get('merlin_title', '')
        offer['sub_detail_label'] = ''


def get_category_color_code_v3(category):
    """
    Returns color code for category
    :param category:
    :return:
    """
    if not category:
        return ""
    elif category == CATEGORY_API_NAME_BODY:
        return COLOR_BODY
    elif category == CATEGORY_API_NAME_LEISURE:
        return COLOR_LEISURE
    elif category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
        return COLOR_RESTAURANTS_AND_BARS
    elif category == CATEGORY_API_NAME_RETAIL:
        return COLOR_RETAIL
    elif category == CATEGORY_API_NAME_SERVICES:
        return COLOR_SERVICES
    elif category == CATEGORY_API_NAME_TRAVEL:
        return COLOR_TRAVEL
    return ""


def get_formatted_date(date):
    if isinstance(date, datetime.datetime):
        date = datetime.datetime.strftime(date, '%Y-%m-%dT%H:%M:%S+0400')
    return date


def set_offer_label_v3(offer_section, offer, offer_to_display, messages_locale, is_skip_mode=False):
    """
    :param offer_section:
    :param offer:
    :param offer_to_display:
    :param messages_locale:
    :param is_skip_mode:
    :return:
    """
    offer_to_display['product_sku'] = offer['product_sku']
    if offer['is_offer_expired']:
        offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
            TranslationManager.expired_offer, messages_locale
        )
        return offer_to_display
    if offer_section == SECTION_REDEEMABLE:
        if offer['is_offer_valid_in_future']:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.purchased_available_from, messages_locale
            )
            offer_to_display['validity_date'] = get_formatted_date(offer['valid_from_date'])
        else:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.valid_to, messages_locale
            )
    elif offer_section == SECTION_REDEEMED:
        offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
            TranslationManager.already_redeemed, messages_locale
        )
    elif offer_section == SECTION_PINGED:
        offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
            TranslationManager.pinged, messages_locale
        )
    elif offer_section == SECTION_NOT_REDEEMABLE:
        if offer['is_show_purchase_button'] or is_skip_mode:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.included_in_mobile_product_not_yet_purchased, messages_locale
            )
        elif offer.get('is_purchaseable'):
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.this_product_is_no_more_purchasable, messages_locale
            )
        elif offer.get('category') == 'Travel':
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.THIS_IS_A_BUNDLED_PRODUCT,
                locale=messages_locale
            )
        else:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.NOT_YET_PURCHASED, locale=messages_locale
            )
    if offer.get('has_cinema_offers', False):
        offer_to_display['sub_detail_label'] = ''


def freeze_offers(offers_array, message_locale):
    """
    :param offers_array:
    :param message_locale:
    :return:
    """
    for offer_array in offers_array:
        for offer_to_display in offer_array['offers_to_display']:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.user_account_frozen,
                message_locale
            )
            offer_to_display['redeemability'] = Redemption.NOT_REDEEMABLE
            offer_to_display['is_pingable'] = False


def get_offer_deal_details(offer, category_color):
    """
    Get data dict containing deal_details & hours_validation_text keys of offer.
    deals details dict containing day wise data list will be in same order as displaying on redemption screen
    :param dict offer: offer data
    :return dict: data dict containing deal_details & hours_validation_text keys
    """
    data = []
    if offer.get('is_deals_product', False):
        deal_details = []
        # if offer deal_validity_all_week flag is on then offer is valid on all days
        if offer['deal_validity_all_week']:
            deals_validity = {
                'Sun': {'id': 1, 'title': 'S', 'status': True},
                'Mon': {'id': 2, 'title': 'M', 'status': True},
                'Tue': {'id': 3, 'title': 'T', 'status': True},
                'Wed': {'id': 4, 'title': 'W', 'status': True},
                'Thu': {'id': 5, 'title': 'T', 'status': True},
                'Fri': {'id': 6, 'title': 'F', 'status': True},
                'Sat': {'id': 7, 'title': 'S', 'status': True}
            }
        else:
            deals_validity = {
                'Sun': {'id': 1, 'title': 'S', 'status': offer['deal_valid_on_sunday']},
                'Mon': {'id': 2, 'title': 'M', 'status': offer['deal_valid_on_monday']},
                'Tue': {'id': 3, 'title': 'T', 'status': offer['deal_valid_on_tuesday']},
                'Wed': {'id': 4, 'title': 'W', 'status': offer['deal_valid_on_wednesday']},
                'Thu': {'id': 5, 'title': 'T', 'status': offer['deal_valid_on_thursday']},
                'Fri': {'id': 6, 'title': 'F', 'status': offer['deal_valid_on_friday']},
                'Sat': {'id': 7, 'title': 'S', 'status': offer['deal_valid_on_saturday']}
            }
        if any([
            deals_validity['Sun'].get('status'),
            deals_validity['Mon'].get('status'),
            deals_validity['Tue'].get('status'),
            deals_validity['Wed'].get('status'),
            deals_validity['Thu'].get('status'),
            deals_validity['Fri'].get('status'),
            deals_validity['Sat'].get('status')
        ]):
            for deal in deals_validity.values():
                if deal.get('status'):
                    day_background_color = category_color
                else:
                    day_background_color = GREY_BACKGROUND_COLOR
                deal_details.append({
                    'title': deal['title'],
                    'is_offer_valid': bool(deal['status']),
                    'id': deal['id'],
                    'day_text_color': OFFER_TEXT_COLOR,
                    'day_background_color': day_background_color
                })
            data = multi_key_sort(deal_details, ['id'])
        return data


def get_current_time_of_location(location_id):
    """
    Return current native datetime as per location.

    :param int location_id: user selected location id
    :return datetime: native datetime obj
    """
    location_utc_offset = LOCATION_TIME_ZONE_MAP.get(location_id, 1)
    utc_offset = 'UTC{offset}'.format(offset=location_utc_offset)
    location_current_time = datetime.datetime.now(tz.gettz(utc_offset))
    # convert timezone aware datetime to native datetime because in our app
    # we are using native datetime at all places
    location_current_time = location_current_time.replace(tzinfo=None)
    return location_current_time


def get_deal_validity_data(self, offer, locale, location_id):
    """
    Verifies offer time and days

    1. verify is offer valid for whole week or not
    2. verify on which day offer is valid
    3. verify offer valid for whole day or for some time span

    :param dict offer: offer
    :param str locale: language to get error message in selected language
    :param int location_id: location id to calculate time in current location
    :returns dict of offer redeemability flag, offer redeemability value, error message title and error_message
    :rtype dict
    """
    try:
        # extract data from offer
        offer_valid_to_time = offer.get('valid_to_time', 0)
        offer_valid_from_time = offer.get('valid_from_time', 0)

        # get utc_time and convert into user timezone. and then convert it into timedelta object for comparison
        current_location_time = get_current_time_of_location(location_id)
        current_day = current_location_time.strftime('%A')
        utc_time = datetime.timedelta(
            hours=current_location_time.hour, minutes=current_location_time.minute,
            seconds=current_location_time.second
        )
        is_deal_valid_on_day = False

        # check offer settings updated or not w.r.t deals columns
        # check deal valid on that day
        if (
            offer.get('deal_validity_all_week', 0) or
            offer.get('deal_valid_on_{current_day}'.format(current_day=current_day.lower()))
        ):
            is_deal_valid_on_day = True

        # check deal validity on that hours
        if is_deal_valid_on_day and (
            offer.get('deal_validity_all_day', 0) or
            (offer_valid_from_time < utc_time < offer_valid_to_time)
        ):
            return {
                'is_redeemable': True,
                'redeemability': Redemption.REDEEMABLE,
                'restriction_title': '',
                'restriction_message': ''
            }
        # generating error message

        error_message = TranslationManager.get_translation(
            TranslationManager.OFFER_RESTRICTION_MESSAGE,
            locale
        )
        offer_restriction_title = TranslationManager.get_translation(TranslationManager.OOPS_TEXT, locale)
        return {
            'is_redeemable': False,
            'redeemability': Redemption.NOT_REDEEMABLE,
            'restriction_title': offer_restriction_title,
            'restriction_message': error_message
        }

    except Exception:
        return {
            'is_redeemable': False,
            'redeemability': Redemption.NOT_REDEEMABLE,
            'restriction_title': '',
            'restriction_message': ''
        }


def initialize_offers_to_display_v592(
        offer,
        locale,
        offer_section_by_redeemability,
        redeemability,
        is_skip_mode=False,
        replace_241_type_with_141=False,
        merchant_pin="",
        is_family_offer=False,
        family_identifier=None,
        is_birthday_offer=False,
        percentage_off=0,
        company='entertainer',
        is_live_offers_enabled=False,
        location_id=1,
):
    """
    :param offer:
    :param locale:
    :param offer_section_by_redeemability:
    :param redeemability:
    :param is_skip_mode:
    :param replace_241_type_with_141:
    :param merchant_pin:
    :param is_family_offer:
    :param family_identifier:
    :param is_birthday_offer:
    :param percentage_off:
    :param str company: company
    :param bool is_live_offers_enabled: is_live_offers_enabled
    :return:
    """

    environment = current_app.config.get('ENV', 'prod')
    # environment = current_app.config.get("API_CONFIGURATION_ENVIRONMENT", 'prod')
    offer_tags_labels = APIMessages.get_offer_labels(locale)
    offer_tags_colors = get_api_configurations(company, environment, config_group='offer_tag_color')
    offer_to_display = {}
    category_color = get_category_color_code_v3(offer['category'])
    categories_list = []
    if offer['category']:
        categories_list = [offer['category']]
    offer_to_display['categories_analytics'] = get_analytics_codes_against_categories(
        categories_list
    )
    offer_to_display['hhs'] = merchant_pin
    offer_to_display['offer_sequence'] = offer['offer_sequence']
    offer_to_display['offer_id'] = offer['id']
    offer_to_display['category'] = offer['category']
    offer_to_display['category_color'] = category_color
    offer_to_display['name'] = offer['name']
    offer_to_display['offer_detail'] = offer.get('description', '')
    offer_to_display['voucher_type'] = offer['voucher_type']
    offer_to_display['voucher_type_image'] = ""
    offer_to_display['conditions'] = offer['conditions']
    offer_to_display['voucher_restriction1'] = offer['voucher_restriction1']
    offer_to_display['voucher_restriction2'] = offer['voucher_restriction2']
    offer_to_display['voucher_restrictions'] = offer['voucher_restrictions']
    offer_to_display['details'] = offer['details']
    offer_to_display['is_cheers'] = bool(offer['is_cheers'])
    offer_to_display['savings_estimate'] = offer['savings_estimate']
    offer_to_display['savings_estimate_aed'] = offer['savings_estimate_aed']
    offer_to_display['savings_estimate_local_currency'] = offer['savings_estimate_local_currency']
    offer_to_display['redeemability'] = redeemability
    offer_to_display['is_topup_offer_allowed'] = False
    offer_to_display['is_pingable'] = False
    offer_to_display['is_pinged'] = False
    offer_to_display['is_show_smiles'] = offer.get('show_smiles_earn_value', 0)
    offer_to_display['smiles_earn_value'] = offer.get('smiles_earn_value', 0)
    offer_to_display['smiles_burn_value'] = offer.get('smiles_burn_value', 0)
    offer_to_display['offer_pay_back_app_action_id'] = offer.get('offer_pay_back_app_action_id')
    offer_to_display['dcp_license'] = offer.get('dcp_license')
    offer_to_display['valid_from_date'] = offer['valid_from_date']
    offer_to_display['expiration_date'] = offer['expiration_date']
    offer_to_display['validity_date'] = offer['expiration_date']
    offer_to_display['outlet_ids'] = offer['outlet_ids']
    offer_to_display['merlin_title'] = offer['merlin_title']
    offer_to_display['is_merlin_offer'] = offer['is_merlin_offer']
    offer_to_display['outlet_merlin_urls'] = offer['outlet_merlin_urls']
    offer_to_display['message'] = get_message_for_offer_type(
        locale,
        offer['voucher_type'],
        offer['spend'],
        offer['reward'],
        offer['percentage_off']
    )
    offer_to_display['is_family_offer'] = is_family_offer
    offer_to_display['additional_details'] = []
    offer_to_display['voucher_details'] = []
    offer_to_display['voucher_rules_of_use'] = []
    offer_to_display['family_identifier'] = family_identifier
    offer_to_display['is_birthday_offer'] = is_birthday_offer
    offer_to_display['sub_detail_label'] = ""
    if percentage_off:
        offer_to_display['percentage_off'] = offer.get('percentage_off', 0)
    set_offer_label_v3(offer_section_by_redeemability, offer, offer_to_display, locale, is_skip_mode)

    # Need to be discussed
    offer['voucher_type'] = offer['voucher_type'] if offer['voucher_type'] else 1
    if offer['voucher_type']:
        voucher_type_details = get_voucher_type_details(
            offer['voucher_type'],
            offer['category'],
            locale,
            replace_241_type_with_141,
            offer['is_monthly'],
            company,
        )
        if voucher_type_details:
            voucher_type_details['title'] = offer_to_display['message']
            offer_to_display['voucher_details'].append(voucher_type_details)
            offer_to_display['voucher_type_image'] = voucher_type_details['image']

    if offer.get('voucher_restriction1'):
        voucher_restriction1_details = get_voucher_restriction_details(
            offer['voucher_restriction1'],
            offer['category'],
            locale,
        )
        if voucher_restriction1_details:
            offer_to_display['voucher_details'].append(voucher_restriction1_details)
            voucher_restriction1_details['title'] = voucher_restriction1_details['title']
            offer_to_display['additional_details'].append(voucher_restriction1_details)

    if offer.get('no_of_people'):
        if offer['no_of_people'] == 1:
            _no_of_people_message = "1 {msg}".format(
                msg=TranslationManager.get_translation(TranslationManager.Person, locale)
            )
        else:
            _no_of_people_message = "{number_of_people} {msg}".format(
                number_of_people=offer['no_of_people'],
                msg=TranslationManager.get_translation(TranslationManager.People, locale)
            )
        offer_to_display['additional_details'].append(
            get_offer_sub_detail_object(
                '0',
                get_image_url(
                    IMAGE_TYPE_PARTY_SIZE,
                    offer['category'],
                ),
                _no_of_people_message,
                category_color
            )
        )
    if offer.get('voucher_restriction2'):
        voucher_restriction2_details = get_voucher_restriction_details(
            offer['voucher_restriction2'],
            offer['category'],
            locale,
        )
        if voucher_restriction2_details:
            offer_to_display['voucher_details'].append(voucher_restriction2_details)

    if offer.get('smiles_earn_value'):
        offer_to_display['additional_details'].append(
            get_offer_sub_detail_object(
                offer['smiles_earn_value'],
                SMILES_ICON_URL,
                "+{smiles} SMILES".format(smiles=offer['smiles_earn_value']),
                SMILES_COLOR_CODE
            )
        )

    if offer.get('voucher_restrictions'):
        offer_to_display['voucher_rules_of_use'].append(offer["voucher_restrictions"])

    if (
        offer_section_by_redeemability != SECTION_REDEEMABLE or
        redeemability == Redemption.NOT_REDEEMABLE
    ):
        offer_to_display['additional_details'] = []
        offer_to_display['additional_details'].append(
            get_offer_sub_detail_object(
                offer.get("smiles_earn_value", ""),
                "",
                offer_to_display.get('sub_detail_label', '').upper(),
                COLOR_CODE_ALREADY_REDEEMED
            )
        )

    # Set Offer Sort Order - START
    if offer.get('is_offer_expired'):
        offer_to_display['sort_order'] = SORT_EXPIRED

    if offer_section_by_redeemability == SECTION_REDEEMABLE:
        if offer['is_offer_valid_in_future']:
            offer_to_display['sort_order'] = SORT_PURCHASED_AVAILABLE_IN_FUTURE
        else:
            offer_to_display['sort_order'] = SORT_REDEEMABLE
    elif offer_section_by_redeemability == SECTION_REDEEMED:
        offer_to_display['sort_order'] = SORT_REDEEMED
    elif offer_section_by_redeemability == SECTION_PINGED:
        offer_to_display['sort_order'] = SORT_PINGED
    elif offer_section_by_redeemability == SECTION_NOT_REDEEMABLE:
        offer_to_display['sort_order'] = SORT_NOT_REDEEMABLE

    # In case of v7_api call we will update additional details color according to design.
    if offer_to_display.get('additional_details', []):
        for additional_detail in offer_to_display.get('additional_details', []):
            additional_detail['color'] = V7_ADDITIONAL_DETAIL_COLOR

    if is_live_offers_enabled:
        category_color = get_category_color_code_v3(offer['category'])
        offer_day_validity = get_offer_deal_details(offer, category_color)
        redeemability_data = get_deal_validity_data(offer, locale, location_id)

        is_live_offer = False
        if offer_day_validity:
            is_live_offer = True

        offer_to_display.update({
            'show_smiles': offer.get('show_smiles', True),
            'show_savings': offer.get('show_savings', True),
            'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
            'is_promo_code_offer': offer.get('is_promo_code_offer', False),
            'offer_day_validity': offer_day_validity,
            'is_live_offer': is_live_offer,
            'restriction_message': redeemability_data.get('restriction_message'),
            'restriction_title': redeemability_data.get('restriction_title')
        })
    else:
        offer_to_display.update({
            'show_smiles': offer.get('show_smiles', True),
            'show_savings': offer.get('show_savings', True),
            'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
            'is_promo_code_offer': offer.get('is_promo_code_offer', False)
        })
    if offer:
        if offer.get('is_promo_code_offer'):
            offer_to_display['tag_info'] = {
                'tag_title': offer_tags_labels.get('offer_tag_promo_code'),
                'tag_bg_color': offer_tags_colors.get('promo'),
                'tag_title_color': TAG_TITLE_COLOR
            }
        elif offer.get('is_deals_product'):
            offer_to_display['tag_info'] = {
                'tag_title': offer_tags_labels.get('offer_tag_live'),
                'tag_bg_color': offer_tags_colors.get('live'),
                'tag_title_color': TAG_TITLE_COLOR
            }
            try:
                if (
                    offer_to_display['additional_details'] and
                    offer_to_display['additional_details'][0]
                ):
                    # In case of Live Offer then remove person message and image from additional_details
                    del offer_to_display['additional_details'][0]
            except IndexError:
                pass
        elif offer.get('is_monthly'):
            offer_to_display['tag_info'] = {
                'tag_title': offer_tags_labels.get('offer_tag_resuable'),
                'tag_bg_color': offer_tags_colors.get('re_usable'),
                'tag_title_color': TAG_TITLE_COLOR
            }
        elif offer.get('offer_replenishment_enabled'):
            offer_to_display['tag_info'] = {
                'tag_title': offer_tags_labels.get('offer_tag_express'),
                'tag_bg_color': offer_tags_colors.get('express'),
                'tag_title_color': TAG_TITLE_COLOR
            }
    return offer_to_display


def initialize_offer_to_display_array_v3(
    offer, redeemability, locale=EN, merchant_pin="", is_family_offer=False, family_identifier=None,
    is_birthday_offer=False, percentage_off=0, is_live_offers_enabled=False, location_id=1
):
    """
    :param merchant_pin:
    :param is_birthday_offer:
    :param family_identifier:
    :param is_family_offer:
    :param locale:
    :param redeemability:
    :param offer:
    :return:
    """
    offer_to_display = dict()
    categories_list = []
    if offer['category']:
        categories_list = list(offer['category'])

    offer_to_display['categories_analytics'] = get_analytics_codes_against_categories(categories_list)
    offer_to_display['hhs'] = merchant_pin
    offer_to_display['offer_sequence'] = offer['offer_sequence']
    offer_to_display['offer_id'] = offer['id']
    offer_to_display['name'] = offer['name']
    offer_to_display['category'] = "Services" if offer['category'] == "Retail" else offer['category']
    offer_to_display['details'] = offer['details']
    offer_to_display['is_cheers'] = bool(offer['is_cheers'])  # Offer belongs to cheers
    offer_to_display['voucher_restrictions'] = offer['voucher_restrictions']  # Offer Voucher Restriction
    offer_to_display['savings_estimate'] = round(offer['savings_estimate'])
    offer_to_display['savings_estimate_aed'] = offer['savings_estimate_aed']
    offer_to_display['savings_estimate_local_currency'] = offer['savings_estimate_local_currency']
    offer_to_display['redeemability'] = redeemability
    offer_to_display['is_topup_offer_allowed'] = False  # Offer Buy Back Allowed
    offer_to_display['is_pingable'] = False  # Is offer Pingable?
    offer_to_display['is_pinged'] = False  # Customer Already Pinged This offer to other customer ?
    offer_to_display['is_show_smiles'] = offer['show_smiles_earn_value']
    offer_to_display['smiles_earn_value'] = offer['smiles_earn_value']
    offer_to_display['smiles_burn_value'] = offer['smiles_burn_value']
    offer_to_display['offer_pay_back_app_action_id'] = offer['offer_pay_back_app_action_id']
    offer_to_display['dcp_license'] = offer['dcp_license']
    offer_to_display['valid_from_date'] = offer['valid_from_date']
    offer_to_display['expiration_date'] = offer['expiration_date']
    offer_to_display['validity_date'] = offer['expiration_date']
    offer_to_display['outlet_ids'] = offer['outlet_ids']
    offer_to_display['family_identifier'] = family_identifier
    offer_to_display['is_birthday_offer'] = is_birthday_offer
    offer_to_display['is_family_offer'] = is_family_offer
    if percentage_off:
        offer_to_display['percentage_off'] = offer.get('percentage_off', 0)
    if is_live_offers_enabled:
        category_color = get_category_color_code_v3(offer['category'])
        offer_day_validity = get_offer_deal_details(offer, category_color)
        redeemability_data = get_deal_validity_data(offer, locale, location_id)

        is_live_offer = False
        if offer_day_validity:
            is_live_offer = True

        offer_to_display.update({
            'show_smiles': offer.get('show_smiles', True),
            'show_savings': offer.get('show_savings', True),
            'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
            'is_promo_code_offer': offer.get('is_promo_code_offer', False),
            'offer_day_validity': offer_day_validity,
            'is_live_offer': is_live_offer,
            'restriction_message': redeemability_data.get('restriction_message'),
            'restriction_title': redeemability_data.get('restriction_title')
        })
    else:
        offer_to_display.update({
            'show_smiles': offer.get('show_smiles', True),
            'show_savings': offer.get('show_savings', True),
            'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
            'is_promo_code_offer': offer.get('is_promo_code_offer', False),
        })
    return offer_to_display


def formulate_offer_details_array_v3(
        offers, offers_array, message_locale, is_user_account_frozen, is_any_offer_pingable, has_birthday_month,
        birthday_skus, birthday_offers_validity, is_skip_mode, is_offer_type_attributes_to_add=False,
        replace_241_type_with_141=False, is_on_trial=False, merchant_pin="", family_identifier=None,
        personal_family_pinged_received=[], company_configs={}, is_live_offers_enabled=False, location_id=1):
    """
    :param list personal_family_pinged_received:
    :param family_identifier:
    :param merchant_pin:
    :param is_on_trial:
    :param replace_241_type_with_141:
    :param is_offer_type_attributes_to_add:
    :param offers:
    :param offers_array:
    :param message_locale:
    :param is_user_account_frozen:
    :param is_any_offer_pingable:
    :param has_birthday_month:
    :param birthday_skus:
    :param birthday_offers_validity:
    :param is_skip_mode:
    :return:
    """
    # replace_retail_to_services - its for supporting retail to be treated as services
    # for apps before v5.92 (Till Jan 31, 2017)

    ping_feature = company_configs.get('enable_ping_feature')
    cashless_delivery = company_configs.get('enable_cashless_delivery')
    to_be_removed_offers = []
    redeemability = Redemption.NOT_REDEEMABLE
    for offer in offers:
        is_birthday_offer = offer['is_birthday_offer']
        for offer_array in offers_array:
            # Logic for Pinged Offers Delivery
            if ping_feature and cashless_delivery:
                if (
                    offer['shared_received_count'] and
                    offer_array['show_pinged_offers_delivery_section'] and
                    offer['is_delivery']
                ):
                    if not offer_array.get('offers_to_display'):
                        initialize_offers_array(offer_array, offer, True)
                    pinged_offers_redeemable = offer['shared_received_count'] - offer['shared_redemptions_count']

                    # Show the Offers which are redeemable
                    for _ in range(pinged_offers_redeemable):
                        if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                            redeemability = Redemption.REDEEMABLE
                        if is_offer_type_attributes_to_add:
                            offer_to_display = initialize_offers_to_display_v592(
                                offer,
                                message_locale,
                                SECTION_REDEEMABLE,
                                redeemability,
                                is_skip_mode,
                                replace_241_type_with_141,
                                merchant_pin=merchant_pin,
                                is_family_offer=True,
                                family_identifier=family_identifier,
                                is_birthday_offer=is_birthday_offer,
                                is_live_offers_enabled=is_live_offers_enabled,
                                location_id=location_id,
                            )
                            if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                                to_be_removed_offers.append(offer_to_display)
                            elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                                offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                                offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE

                        else:
                            offer_to_display = initialize_offer_to_display_array_v3(
                                offer=offer,
                                redeemability=redeemability,
                                locale=message_locale,
                                merchant_pin=merchant_pin,
                                is_family_offer=True,
                                family_identifier=family_identifier,
                                is_birthday_offer=is_birthday_offer,
                                is_live_offers_enabled=is_live_offers_enabled,
                                location_id=location_id
                            )
                            if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                                to_be_removed_offers.append(offer_to_display)
                            elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                                offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                                offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                            set_offer_label_v3(
                                SECTION_REDEEMABLE,
                                offer,
                                offer_to_display,
                                message_locale
                            )
                            offer_to_display = assign_sort_order_to_offers(
                                SECTION_REDEEMABLE, offer, offer_to_display
                            )

                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

                    for _ in range(offer['shared_redemptions_count']):
                        redeemability = Redemption.REDEEMED
                        if is_offer_type_attributes_to_add:
                            offer_to_display = initialize_offers_to_display_v592(
                                offer,
                                message_locale,
                                SECTION_REDEEMED,
                                redeemability,
                                is_skip_mode,
                                replace_241_type_with_141,
                                merchant_pin=merchant_pin,
                                family_identifier=family_identifier,
                                is_birthday_offer=is_birthday_offer,
                                is_live_offers_enabled=is_live_offers_enabled,
                                location_id=location_id,
                            )
                            if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                                to_be_removed_offers.append(offer_to_display)
                            elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                                offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                                offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        else:
                            offer_to_display = initialize_offer_to_display_array_v3(
                                offer,
                                redeemability,
                                message_locale,
                                merchant_pin=merchant_pin,
                                family_identifier=family_identifier,
                                is_birthday_offer=is_birthday_offer,
                                is_live_offers_enabled=is_live_offers_enabled,
                                location_id=location_id
                            )
                            if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                                to_be_removed_offers.append(offer_to_display)
                            elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                                offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                                offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                            set_offer_label_v3(
                                SECTION_REDEEMED,
                                offer,
                                offer_to_display,
                                message_locale
                            )
                            offer_to_display = assign_sort_order_to_offers(
                                SECTION_REDEEMED, offer, offer_to_display
                            )
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]
            # Logic for Pinged Offers NoN Delivery
            if (
                offer['shared_received_count'] and
                offer_array['show_pinged_offers_non_delivery_section'] and
                not offer['is_delivery']
            ):
                if not offer_array.get('offers_to_display'):
                    initialize_offers_array(offer_array, offer, True)

                pinged_offers_redeemable = offer['shared_received_count'] - offer['shared_redemptions_count']

                # Show the Offers which are redeemable
                for _ in range(pinged_offers_redeemable):
                    if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                        redeemability = Redemption.REDEEMABLE

                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMABLE,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            is_family_offer=True,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer,
                            redeemability,
                            message_locale,
                            merchant_pin=merchant_pin,
                            is_family_offer=True,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMABLE, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

                # Show the Offers which are already redeemed
                for _ in range(offer['shared_redemptions_count']):
                    redeemability = Redemption.REDEEMED

                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMED,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMED, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]
            # Logic for Personal Pinged Offers Delivery
            if (
                offer.get('personal_shared_received_count') and
                offer_array.get('show_personal_pinged_offers_delivery_section') and
                offer['is_delivery']
            ):
                if not offer_array.get('offers_to_display'):
                    initialize_offers_array(offer_array, offer, True)
                pinged_offers_redeemable = offer['personal_shared_received_count'] - offer[
                    'personal_shared_redemptions_count']

                # Show the Offers which are redeemable
                for _ in range(pinged_offers_redeemable):
                    if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                        redeemability = Redemption.REDEEMABLE
                    family_flag = False
                    if offer['id'] in personal_family_pinged_received:
                        family_flag = True
                        personal_family_pinged_received.remove(offer['id'])
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMABLE,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_family_offer=family_flag,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_family_offer=family_flag,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMABLE, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

                for _ in range(offer['personal_shared_redemptions_count']):
                    redeemability = Redemption.REDEEMED
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMED,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMED, offer, offer_to_display
                        )
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]
            # Logic for Personal Pinged Offers NoN Delivery
            if (
                offer.get('personal_shared_received_count') and
                offer_array.get('show_personal_pinged_offers_non_delivery_section') and
                not offer['is_delivery']
            ):
                if not offer_array.get('offers_to_display'):
                    initialize_offers_array(offer_array, offer, True)

                pinged_offers_redeemable = (offer['personal_shared_received_count'] -
                                            offer['personal_shared_redemptions_count'])

                # Show the Offers which are redeemable
                for _ in range(pinged_offers_redeemable):
                    if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                        redeemability = Redemption.REDEEMABLE
                    family_flag = False
                    if offer['id'] in personal_family_pinged_received:
                        family_flag = True
                        personal_family_pinged_received.remove(offer['id'])
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMABLE,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_family_offer=family_flag,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_family_offer=family_flag,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMABLE, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

                # Show the Offers which are already redeemed
                for _ in range(offer['personal_shared_redemptions_count']):
                    redeemability = Redemption.REDEEMED
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMED,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMED, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

            # Logic for Product Offers
            elif offer_array['section_name'] == offer['product_name']:
                if not offer_array.get('offers_to_display'):
                    initialize_offers_array(offer_array, offer, False)

                # Show the Offers which are either redeemable or reusable
                for _ in range(int(offer.get('quantity_redeemable', 0))):
                    redeemability = offer['redeemability']

                    # TODO: This change is not required. Need to discuss with Imtiaz Durrani
                    if redeemability == Redemption.REUSABLE:
                        redeemability = Redemption.REDEEMABLE

                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMABLE,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(SECTION_REDEEMABLE, offer, offer_to_display)

                    if offer['redeemability'] == Redemption.REDEEMABLE and not offer['allowed_onboarding']:
                        offer_to_display['is_pingable'] = offer['is_pingable']

                    # If the Offer is redeemable and belongs to the Birthday SKU, change the validity date of
                    # the offer to the last date of the current month.
                    if (
                        has_birthday_month and
                        offer['product_sku'] in birthday_skus and
                        redeemability == Redemption.REDEEMABLE and
                        birthday_offers_validity
                    ):
                        offer_to_display['validity_date'] = offer['expiration_date']
                        if birthday_offers_validity < offer['expiration_date']:
                            offer_to_display['validity_date'] = birthday_offers_validity

                    if offer_to_display['is_pingable']:
                        is_any_offer_pingable = True

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

                # Show the Offers which are already redeemed
                for _ in range(int(offer.get('quantity_redeemed', 0))):
                    redeemability = Redemption.REDEEMED
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_REDEEMED,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_REDEEMED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_REDEEMED, offer, offer_to_display
                        )

                    offer_to_display['is_topup_offer_allowed'] = False
                    # Offer Buy Back Allowed
                    if offer.get('is_purchased', False):
                        offer_to_display['is_topup_offer_allowed'] = offer.get('top_up_offer_allowed', False)
                    # if offer is purchased
                    if any([is_on_trial, offer.get('is_purchased', False)]):
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

                # Show the offers which are pinged
                for _ in range(offer['shared_sent_count']):
                    redeemability = Redemption.NOT_REDEEMABLE
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_PINGED,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_PINGED,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_PINGED, offer, offer_to_display
                        )

                    # Offer Pinged to other customer
                    offer_to_display['is_pinged'] = True
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

                # Show the Offers which are not redeemable
                for _ in range(int(offer.get('quantity_not_redeemable', 0))):
                    redeemability = Redemption.NOT_REDEEMABLE
                    if is_offer_type_attributes_to_add:
                        offer_to_display = initialize_offers_to_display_v592(
                            offer,
                            message_locale,
                            SECTION_NOT_REDEEMABLE,
                            redeemability,
                            is_skip_mode,
                            replace_241_type_with_141,
                            merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id,
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                    else:
                        offer_to_display = initialize_offer_to_display_array_v3(
                            offer, redeemability, message_locale, merchant_pin=merchant_pin,
                            family_identifier=family_identifier,
                            is_birthday_offer=is_birthday_offer,
                            is_live_offers_enabled=is_live_offers_enabled,
                            location_id=location_id
                        )
                        if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                            to_be_removed_offers.append(offer_to_display)
                        elif offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                            offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                            offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE
                        set_offer_label_v3(
                            SECTION_NOT_REDEEMABLE,
                            offer,
                            offer_to_display,
                            message_locale
                        )
                        offer_to_display = assign_sort_order_to_offers(
                            SECTION_NOT_REDEEMABLE, offer, offer_to_display
                        )

                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]
    _filtered_product_offers = []
    # remove sections where there is no offer available to redeem
    for product_section in offers_array:
        if product_section['offers_to_display']:
            product_section['offers_to_display'] = multi_key_sort(
                product_section['offers_to_display'],
                ['sort_order', 'offer_sequence', 'offer_id']
            )
        _filtered_product_offers.append(product_section)
    offers_array = _filtered_product_offers
    if is_user_account_frozen:
        freeze_offers(offers_array, message_locale)
        is_any_offer_pingable = False
    return offers_array, is_any_offer_pingable, to_be_removed_offers


def get_merchant_attributes_by_merchant_id_from_es(merchant_id, merchant_categories, locale=EN, attributes={}):
    """
    Returns merchant attributes from es against provided merchant ids
    :param str locale: Locale
    :param int merchant_id: Merchant Id
    :param list merchant_categories: Merchant Categories
    :param dict attributes: Merchant attributes
    """
    __merchant_attributes = []

    body_att = BODY_ATT
    fashion_and_retail_att = FASHION_AND_RETAIL_ATT
    leisure_att = LEISURE_ATT
    services_att = SERVICES_ATT
    travel_att = TRAVEL_ATT
    restaurants_and_bars_att = RESTAURANTS_AND_BARS_ATT

    merchant_attribute = {}
    attributes_names = None
    for merchant_category in merchant_categories:
        if merchant_category.lower() == CATEGORY_API_NAME_BODY.lower():
            attributes_names = body_att

        elif merchant_category.lower() == CATEGORY_API_NAME_RETAIL.lower():
            attributes_names = fashion_and_retail_att

        elif merchant_category.lower() == CATEGORY_API_NAME_LEISURE.lower():
            attributes_names = leisure_att

        elif merchant_category.lower() == CATEGORY_API_NAME_RESTAURANTS_AND_BARS.lower():
            attributes_names = restaurants_and_bars_att

        elif merchant_category.lower() == CATEGORY_API_NAME_SERVICES.lower():
            attributes_names = services_att

        elif merchant_category.lower() == CATEGORY_API_NAME_TRAVEL.lower():
            attributes_names = travel_att

        if attributes_names:
            for attr in attributes_names:
                '''
                If there is a case that merchant_attribute name is different in ES Schema from our expected response,
                I am adding alias with ':'
                e.g:
                    wi_fi:wifi
                '''
                if ':' in attr:
                    merchant_attribute[attr.split(':')[0]] = attributes[attr.split(':')[1]]
                else:
                    merchant_attribute[attr] = attributes[attr]
            merchant_attributes_for_category = format_merchant_attributes(
                merchant_id,
                merchant_attribute,
                merchant_category,
                locale
            )
            if __merchant_attributes:
                __merchant_attributes = merchant_attributes_for_category
            else:
                for merchant_attributes_for_category_section in merchant_attributes_for_category:
                    is_section_already_exists = False
                    for __merchant_attributes_section in __merchant_attributes:
                        if __merchant_attributes_section['section_name'] == \
                                merchant_attributes_for_category_section['section_name']:
                            is_section_already_exists = True
                            __merchant_attributes_section['attributes'].extend(
                                merchant_attributes_for_category_section['attributes'])
                    if not is_section_already_exists:
                        __merchant_attributes.append(merchant_attributes_for_category_section)
    return __merchant_attributes


def update_action_buttons_list_for_merchant(buttons_list):
    """
    Update buttons list for merchant with image url
    :param list buttons_list: Buttons list
    """
    for button in buttons_list:
        button.update({
            'image_url': '{base}{type}.png'.format(
                base=ICON_URL_BASE_V7,
                type=button['type']
            )
        })


def get_quip_up_service_availability():
    """
    Gets the Quiqup service availability
    :rtype: dict
    """
    auth_token = generate_bearer_token_quiqup()
    if auth_token:
        complete_url = current_app.config.get('GET_QUIQUP_JOB_SERVICE_NOTIFICATION_URL')
        data = {
            "grant_type": 'client_credentials',
            "client_id": current_app.config.get('QUIQUP_API_CLIENT_ID'),
            "client_secret": current_app.config.get('QUIQUP_API_KEY')
        }
        bearer_token = '{} {}'.format('Bearer', auth_token)
        headers = {'Authorization': bearer_token}
        request_details = requests.get(url=complete_url, data=json.dumps(data), headers=headers)
        delivery_info = {'delay_message': ''}
        try:
            if request_details.ok:
                request_details = request_details.json()
                if request_details.get('segmentation'):
                    if request_details['segmentation'].get('order_placement_allowed'):
                        delivery_info['delay_message'] = request_details['segmentation'].get('message_body')
                        return delivery_info
                    return {}
                return delivery_info
        except JSONDecodeError:
            pass
    return {}


def generate_bearer_token_quiqup():
    """
    Generates bearer token for quiqup API
    :rtype: str
    """
    auth_token = ''
    url = current_app.config.get('GENERATE_BEREAR_QUIQUP_URL')
    data = {
        "grant_type": 'client_credentials',
        "client_id": current_app.config.get('QUIQUP_API_CLIENT_ID'),
        "client_secret": current_app.config.get('QUIQUP_API_KEY')
    }
    headers = {'content-type': 'application/json'}
    try:
        bearer_token_response = requests.post(url=url, data=json.dumps(data), headers=headers)
        if bearer_token_response.ok:
            bearer_token_response = bearer_token_response.json()
            auth_token = bearer_token_response.get('access_token')
        return auth_token
    except Exception:
        return auth_token
