"""
Constants for Merchants service
"""
ANDROID = 'and'
LOG_SUB_FOLDERS = []
MAX_MERCHANTS = 50
FINE_DINING_DRESS_CODE_TRANSLATION = {
    'dress_code': {
        'formal_ar': 'لباس رسمي',
        'formal_el': 'Επίσημο',
        'formal_cn': '正式',
        'formal_en': 'Formal',
        'informal_ar': 'لباس غير رسمي ',
        'informal_el': 'Ανεπίσημο',
        'informal_cn': '非正式',
        'informal_en': 'Informal',
        'smart casual_ar': ' لباس أنيق وغير رسمي',
        'smart casual_el': 'Καθημερινό',
        'smart casual_cn': '商務休閒',
        'smart casual_en': 'Smart Casual'
    },
    'fine_dining': {
        'no_en': 'No',
        'no_ar': 'لا',
        'no_el': 'ΟΧΙ',
        'no_cn': '不是',
        'gold_en': 'Gold',
        'gold_ar': 'فئة ذهبية',
        'gold_el': 'Χρυσό',
        'gold_cn': '金',
        'silver_en': 'Silver',
        'silver_ar': 'فئة فضية',
        'silver_el': 'Ασήμι',
        'silver_cn': '銀'
    }
}

ATTRIBUTE_VALUE_NO = 0
ATTRIBUTE_VALUE_YES = 1
ATTRIBUTE_VALUE_OUTLET_SPECIFIC = 2
ATTRIBUTE_TYPE_MERCHANT = 1
ATTRIBUTE_VALUE_TYPE_TERNARY = 1
ATTRIBUTE_VALUE_TYPE_VALUE = 2

CUISINE = 'cuisine'
DRESS_CODE = 'dress_code'
FINE_DINING = 'fine_dining'

HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM = 4
HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO = -18

TYPE_DEFAULT = 0
TYPE_TRIAL = 1
TYPE_MEMBER = 2
TYPE_BOTH = 3
TYPE_NEW_OFFER = 4
TYPE_FEATURED_OFFER = 5  # Both New and Monthly

OFFER_TYPE_VALUE_DEFAULT = 0
OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
OFFER_TYPE_VALUE_GIFT = 3
OFFER_TYPE_VALUE_PACKAGE = 4
OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

OFFER_TYPE_TEXT_BUY_ONE_GET_ONE_FREE = "Buy One Get One Free"
OFFER_TYPE_TEXT_SPEND_THIS_GET_THIS = "Spend This Get That"
OFFER_TYPE_TEXT_PERCENTAGE_OFF = "% Off"
OFFER_TYPE_TEXT_GIFT = "Gift"
OFFER_TYPE_TEXT_PACKAGE = "Package"
OFFER_TYPE_TEXT_FIX_PRICE_OFF = "Fixed Price Off"

VOUCHER_TYPE_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/voucher_type_"
VOUCHER_RESTRICTION_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/voucher_restriction_"  # noqa: E501
PARTY_SIZE_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/"
VOUCHER_TYPE_IMAGE_URL_PREFIX_HS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/hs/voucher_type_"  # noqa: E501
VOUCHER_TYPE_IMAGE_URL_PREFIX_GEM = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/gem/voucher_type_"  # noqa: E501
VOUCHER_RESTRICTION_IMAGE_URL_PREFIX_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/gems/voucher_restriction_"  # noqa: E501
PARTY_SIZE_IMAGE_URL_PREFIX_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/gems/"
VOUCHER_TYPE_IMAGE_URL_PREFIX_V7_V7 = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types_v7/voucher_type_"  # noqa

IMAGE_TYPE_VOUCHER_TYPE = 1
IMAGE_TYPE_VOUCHER_RESTRICTION = 2
IMAGE_TYPE_PARTY_SIZE = 3

ICON_URL_BASE_V7 = "https://entertainer-app-assets.s3.amazonaws.com/icons/md_v7/"
SMILES_ICON_URL = "https://s3.amazonaws.com/entertainer-app-assets/icons/smiles_icon.png"
FREEMIUM_DUMMY_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/freemium_dummy_image.jpg'
SMILES_COLOR_CODE = "e2bb55"
COLOR_CODE_ALREADY_REDEEMED = "de595b"

VOUCHER_RESTRICTIONS = {
    1: "Valid for Dine-in and Take-away",
    2: "Excluding Friday Brunch",
    3: "Advance Booking is required",
    4: "Delivery only",
    5: "Dine-in only",
    6: "Excluding Brunch",
    7: "Food only",
    8: "No corkage allowed",
    9: "Not Valid on Delivery",
    10: "Not valid on Public Holidays",
    11: "Rack rate applies",
    12: "To redeem, you must be of legal drinking age and non-Muslim",  # Must comply with applicable local laws
    13: "Valid on all packages",
    14: "Valid on Delivery",
    15: "Must comply with applicable local laws",
    16: "Rate includes breakfast",
    17: "Rate Room only",
    18: "Based on Best Available Rates",
    19: "All Inclusive",
    20: "Consume on premises only",
    21: "Drink Responsibly",
    22: "Valid on soft beverages",
    23: "Valid on house beverages",
    24: "Valid on bubbly package",
    25: "Min. order & delivery charges apply",
    26: "Half board",
    27: "Best available rate",
    28: "Best flexible rate",
    29: "Fixed rate per night",
    30: "Online offer",
    31: "Takeaway"
}

SORT_EXPIRED = 6

SECTION_REDEEMABLE = 1
SECTION_REDEEMED = 2
SECTION_PINGED = 3
SECTION_NOT_REDEEMABLE = 4
SORT_REDEEMABLE = 1
SORT_PURCHASED_AVAILABLE_IN_FUTURE = 2
SORT_REDEEMED = 3
SORT_PINGED = 4
SORT_NOT_REDEEMABLE = 5

ALLERGY_INFORMATION = "Allergy Information"

RADIUS_CONVERSION_UNIT = 100000
PING_TIME_LIMIT_SECONDS = 300
DUBAI_LOCATION_ID = 1

ALLERGY_INFORMATION_TITLE = "Allergy Information"

DELIVERY_TIMINGS_KEY = "delivery_duration"
DELIVERY_TIMINGS_NAME = "Avg.Delivery Time"
DELIVERY_TIMINGS_IMAGE_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUZv9mnFiJxrbgc812KmuUEfnOzZar4z8WkUXo3yuIoA9Z-ST2" # noqa: 327
DELIVERY_HOURS_KEY = "delivery_hours"
DELIVERY_HOURS_NAME = "Delivery hours"
DELIVERY_HOURS_IMAGE_URL = ""

DELIVERY_TIMINGS = {
    "type": 2,
    "key": DELIVERY_TIMINGS_KEY,
    "name": DELIVERY_TIMINGS_NAME,
    "image_url": DELIVERY_TIMINGS_IMAGE_URL,
    "value": ""
}
DELIVERY_HOURS = {
    "type": 1,
    "key": DELIVERY_HOURS_KEY,
    "name": DELIVERY_HOURS_NAME,
    "image_url": DELIVERY_HOURS_IMAGE_URL,
    "value": ""
}

SMILES_ACTION_BURN_OFFERS_TOP_UP_ID = 137
TOP_UP_OFFER_BURN_VALUE = 1000

SPONSOR_TITLE_DEFAULT = 'Holiday savings & fun, all 2-4-1!'
SPONSOR_IMAGE_DEFAULT = 'https://s3.amazonaws.com/entertainer-app-assets/sponsor_default.png'
SPONSOR_IMAGE_TARGET_LINK_IOS_DEFAULT = 'https://itunes.apple.com/us/app/241passport/id1015294255?mt=8'
SPONSOR_IMAGE_TARGET_LINK_ANDROID_DEFAULT = 'https://play.google.com/store/apps/details?id=com.theentertainerme.passport'
SPONSOR_IMAGE_TARGET_LINK_WINDOWS_DEFAULT = 'https://www.241passport.com/'

SPONSOR_TITLE_OMAN = ''
SPONSOR_IMAGE_OMAN = 'https://s3.amazonaws.com/entertainer-app-assets/sponsor_oman.jpg'
SPONSOR_IMAGE_TARGET_LINK_IOS_OMAN = 'http://mazdaoman.com/mazda-cx-9/'
SPONSOR_IMAGE_TARGET_LINK_ANDROID_OMAN = 'http://mazdaoman.com/mazda-cx-9/'
SPONSOR_IMAGE_TARGET_LINK_WINDOWS_OMAN = 'http://mazdaoman.com/mazda-cx-9/'

MoreSA_Locations = [4, 14, 20]
OMAN_LOCATION_ID = 8

BODY_ATT = [
    'by_appointment_only', 'couples_friendly', 'indoor_facilities', 'outdoor_facilities', 'refreshments',
    'certified', 'female_only', 'supervised_play_area', 'parking', 'valet_parking', 'male_only', 'jacuzzi',
    'kids_play_area', 'moroccan_bath', 'personal_trainer', 'sauna', 'steam_room', 'pool',
    'wheelchair_accessible', 'wi_fi:wifi'
]

LEISURE_ATT = [
    'age_restrictions', 'aviation', 'desert_safari', 'fishing', 'height_restrictions',
    'indoor_activities', 'kids_welcome', 'motor_sports', 'outdoor_activities', 'parking',
    'team_sports', 'valet_parking', 'alcohol', 'boating', 'extreme_sports', 'golf',
    'holiday_programmes', 'indoor_play_area', 'live_entertainment', 'outdoor_cooling',
    'outdoor_play_area', 'racquet_sports', 'theme_park', 'water_park', 'water_sports',
    'rooftop_bars', 'wineries'
]

SERVICES_ATT = ['by_appointment_only', 'delivery', 'pick_up_drop_off', 'pharmacy', 'beauty_products']

TRAVEL_ATT = [
    'x24_hour_reception', 'x24_hour_room_service', 'adaptor', 'air_conditioning',
    'airport_pick_up_drop_off', 'alcohol', 'balcony', 'beach', 'beach_club', 'beauty_centre',
    'bed_breakfast', 'boutique', 'butler_service', 'car_park', 'chauffeur_service', 'city',
    'closest_airport_name', 'club_lounge', 'concierge', 'couples_only', 'day_spa', 'family',
    'golf', 'gym_fitness', 'hair_salon', 'health_programmes', 'health_spa_resort', 'heating',
    'home_safety', 'housekeeping', 'hotel_apartment', 'inhouse_movies', 'in_room_spa_bath',
    'kids_club', 'kids_friendly', 'kitchen_facilities', 'laundry_service', 'lodge_safari',
    'lodge_ski', 'luggage_storage', 'mini_bar', 'mountain_country', 'night_club', 'no_of_bars',
    'no_of_cafes', 'no_of_restaurants', 'plunge_pool', 'prayer_room', 'proximity_to_airport_kms',
    'proximity_to_city_centre_kms', 'resort', 'safe_deposit_box', 'seaside', 'shopping_mall',
    'sightseeing', 'smoking_rooms', 'sound_system', 'sports_club', 'swimming_pool', 'toiletries',
    'total_no_of_rooms', 'tv_in_room', 'valet_parking', 'villas', 'water_sports', 'wheelchair_accessible',
    'wi_fi:wifi'
]

RESTAURANTS_AND_BARS_ATT = [
    'alcohol', 'brunch', 'buffet', 'cuisine', 'cuisines', 'dress_code', 'fine_dining',
    'groups_welcome', 'halal', 'kids_welcome', 'live_entertainment', 'outdoor_cooling',
    'outdoor_heating', 'outdoor_seating', 'parking', 'pets_allowed', 'pork_products',
    'smoking_indoor', 'smoking_outdoor', 'smoking_shisha', 'sports_screens',
    'supervised_play_area', 'takeaway', 'valet_parking', 'wheelchair_accessible',
    'wi_fi:wifi', 'rooftop_bars', 'wineries', 'delivery', 'hubbly_bubbly', 'kids_play_area',
    'open_late', 'with_a_view', 'price_range'
]

FASHION_AND_RETAIL_ATT = [
    'children_baby_only', 'fashion_accessories', 'footwear', 'ladieswear', 'menswear',
    'opticians', 'sportswear'
]

BUTTON_TYPE_CALL = "call"
BUTTON_TYPE_EMAIL = "email"
BUTTON_TYPE_MAP = "map"
BUTTON_TYPE_INVITE = "invite"
BUTTON_TYPE_CATALOGUE = "catalogue"
BUTTON_TYPE_REORDER = "reorder"
BUTTON_TYPE_FAVOURITES = "favourites"
BUTTON_TYPE_MENU = "menu"
BUTTON_TYPE_PING = "ping"
BUTTON_TYPE_SHARE = "share"

BUTTON_TITLE_CALL = "Call the outlet"
BUTTON_TITLE_SHARE = "Share the Outlet"
BUTTON_TITLE_EMAIL = "Send an Email"
BUTTON_TITLE_PING = "Ping"
BUTTON_TITLE_MENU = "Menu"
BUTTON_TITLE_CATALOGUE = "Catalogue"
BUTTON_TITLE_FAVOURITES = "Favourites"

BUTTON_VALUE_SHARE = "share text"
BUTTON_VALUE_FAVORITES = "https://s3.amazonaws.com/offer-engine/arena-sports-bar--kitchen-x23871148/merchant_fine_dining_menu_%28pdf%29201907071150.pdf"    # NOQA

FAVOURITE_IMAGE_URL = 'https://entertainer-app-assets.s3.amazonaws.com/v7/icFavouriteFilled%403x.png'
UN_FAVOURITE_IMAGE_URL = 'https://entertainer-app-assets.s3.amazonaws.com/v7/icFavourite%403x.png'

ICON_URL_BASE = "https://s3.amazonaws.com/entertainer-app-assets/icons/"
BUTTONS_IMAGES_BASE_URL = "{icon_base}merchant_menu_buttons/".format(icon_base=ICON_URL_BASE)

LOCATION_IDS_1_FOR_1 = [11, 15, 5]
