import multiprocessing
import os
import sys

from common.routes import TEAPIs

service_path = '/home/entutebizapi/theentertainer-python/api_ft_merchant'
sys.path.append(service_path)

parent_directory = os.getcwd()
chdir = parent_directory
pythonpath = '{path}/env'.format(path=parent_directory)
accesslog = '{path}/logs/merchant-service-access.log'.format(path=parent_directory)
errorlog = '{path}/logs/merchant-service-error.log'.format(path=parent_directory)
capture_output = True
raw_env = 'APPLICATION_SETTINGS={path}/et_instance_settings/uat_settings.py'.format(path=service_path)

bind = '127.0.0.1:{port}'.format(port=TEAPIs.MERCHANT_SERVICE_PORT)
timeout = 120
workers = multiprocessing.cpu_count() * 2 + 1
preload_app = True
proc_name = 'merchant_service'

files_to_create = [accesslog, errorlog]
for log_file in files_to_create:
    open(log_file, "wb").close()
