from merchant_service.merchants_app import create_app

app = create_app()['app']

if __name__ == "__main__":
    app.run()
