import base64
import datetime
from collections import OrderedDict, defaultdict
from operator import itemgetter

from flask import g
from geopy import distance

from outlet_service.common import constants as common_constants
from outlet_service.common.models.ent_customer_profile import EntCustomerProfile
from outlet_service.common.models.outlet import Outlet
from outlet_service.common.models.product import Product
from outlet_service.common.models.quiq_up_settings import QuiqUpSetting
from outlet_service.common.models.share_offer import ShareOffer
from outlet_service.common.models.wl_company import WlCompany
from outlet_service.common.models.wl_tabs import WlTab
from outlet_service.common.utils.api_utils import bool_validator, get_current_time_of_location, row2dict
from outlet_service.common.utils.translation_manager import TranslationManager
from outlet_service.modules.api_constants import (
    HSBC_LOVE_DINING_SKUS, OUTLET_ATTRIBUTE_DEFAULT_ICONS, TAB_ORDER_ALL_OFFERS, TAB_SECTION_TYPE_ALL_OFFERS,
    TAB_UID_ALL_OFFERS, TAB_UID_BUY_MORE, TAB_UID_CHEERS, TAB_UID_DELIVERY, TAB_UID_MONTHLY, TAB_UID_MORESA,
    VALID_OFFER_TYPES
)

cache = g.cache


def get_tabs_info(customer_id, company, offset, filter_by_type, category,
                  is_cuckoo, message_locale, location_id, product_ids):
    """
    Gets tabs info

    :param customer_id:
    :param company:
    :param offset:
    :param filter_by_type:
    :param category:
    :param is_cuckoo:
    :param message_locale:
    :param location_id:
    :param product_ids:
    :return:
    """
    tabs = []
    tabs_list = []
    # comented company code
    # hsbc_black_card_holder = False
    # if customer_id and company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
    #     user_group = Wlvalidation().get_user_group(company, customer_id)
    #     if user_group == SECOND_GROUP:
    #         hsbc_black_card_holder = True
    if offset == 0 and not filter_by_type:
        show_buy_more_tab = False

        # Same as commented in Php
        # self.show_buy_more_tab = len(self.customer['purchased_product_ids']) > 0
        # if self.show_buy_more_tab:
        #     purchasable_product = self.product_wl_active_repo.get_purchasable_products(
        #         self.company,
        #         self.location_id
        #     )
        #     show_buy_more_tab = len(self.purchasable_product['purchasable_products_this_location']) > 0

        tab_names = WlTab.get_tab_names(company, message_locale)
        if tab_names:
            if category == common_constants.CATEGORY_API_NAME_TRAVEL:
                show_buy_more_tab = False
            product_types = Product.get_product_types(company, category, location_id, is_cuckoo, product_ids)
            for tab_name in tab_names:
                tab_name = row2dict(tab_name)
                if product_types:
                    if (
                            bool_validator(product_types.is_member) and
                            tab_name.get('type') == TAB_UID_MONTHLY
                    ):
                        tabs_list.append(tab_name)
                    if (
                            bool_validator(product_types.is_cheers) and
                            tab_name.get('type') == TAB_UID_CHEERS
                    ):
                        tabs_list.append(tab_name)
                    if (
                            bool_validator(product_types.is_delivery) and
                            tab_name.get('type') == TAB_UID_DELIVERY
                    ):
                        tabs_list.append(tab_name)
                    if (
                            bool_validator(product_types.is_more_sa) and
                            tab_name.get('type') == TAB_UID_MORESA
                    ):
                        tabs_list.append(tab_name)
                    if (
                            show_buy_more_tab and
                            tab_name.get('type') == TAB_UID_BUY_MORE
                    ):
                        tabs_list.append(tab_name)

                if tab_name.get('type') not in [
                    TAB_UID_MONTHLY, TAB_UID_CHEERS, TAB_UID_DELIVERY,
                    TAB_UID_MORESA, TAB_UID_BUY_MORE
                ]:
                    tabs_list.append(tab_name)

        if not tabs_list:
            tab_list = OrderedDict()
            tab_list['locale'] = message_locale
            tab_list['name'] = TranslationManager.get_translation(TranslationManager.tab_name_all_offers)
            tab_list['order'] = TAB_ORDER_ALL_OFFERS
            tab_list['params'] = 'redeemability=redeemable_reusable'
            tab_list['type'] = TAB_UID_ALL_OFFERS
            tab_list['type_id'] = TAB_SECTION_TYPE_ALL_OFFERS
            tabs_list.append(tab_list)

        tabs_list = sorted(tabs_list, key=itemgetter('order'))

        for tab_list in tabs_list:
            params = dict()
            params_array = tab_list['params'].split(',')
            for param_array in params_array:
                param = param_array.split("=")
                if len(param):
                    param[1] = tabs_param_parser(param[1])
                    params[param[0]] = param[1]
            tabs.append({
                'section_type': tab_list.get('type_id'),
                'order': tab_list.get('order'),
                'uid': tab_list.get('type'),
                'name': tab_list.get('name'),
                'params': params
            })
    return tabs


def tabs_param_parser(param):
    """
    Checks if param is in bool params list then return bool value otherwise returns the param
    :param param:
    :return:
    """
    if param in ('True', 'true', True, 1, '1'):
        return True
    if param in ('False', 'false', False, 0, '0'):
        return False
    return param


def is_search_string_found(search_in, search_string, is_search_words=False):
    """
    Search the presence of word in string.
    :param str search_in: string in which need to search
    :param str search_string: string to find
    :param bool is_search_words: let us know that search string is single word or combination of words
    :rtype: bool
    """
    search_string = search_string.strip().lower()
    if not is_search_words:
        return search_string in search_in
    else:
        search_words = search_string.split()
        # if search_in i.e offer_name is None then set it to empty string so that code doesn't break
        if not search_in:
            search_in = ''
        for word in search_words:
            if word.strip() and word.strip() not in search_in.lower():
                return False
        return True


def parse_list(__categories, cuisine=False):
    _categories_processed = []
    try:
        _categories = __categories.split(';')
        for _category in _categories:
            if _category:
                _categories_processed.append(_category)
    except Exception:
        return []
    if cuisine:
        return _categories_processed
    _categories_processed = sort_categories(_categories_processed)
    return _categories_processed


def sort_categories(categories):
    categories_array = []

    if common_constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS)

    if common_constants.CATEGORY_API_NAME_BODY in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_BODY)

    if common_constants.CATEGORY_API_NAME_LEISURE in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_LEISURE)

    if common_constants.CATEGORY_API_NAME_RETAIL in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_RETAIL)

    if common_constants.CATEGORY_API_NAME_SERVICES in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_SERVICES)

    if common_constants.CATEGORY_API_NAME_TRAVEL in categories:
        categories_array.append(common_constants.CATEGORY_API_NAME_TRAVEL)

    return categories_array


def set_images_and_attributes(company, outlet, categories, selected_category=''):
    """
    Sets images and attributes
    """
    outlet['attributes'] = []
    is_love_dining_outlet = False
    if company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
        get_love_dining_skus = HSBC_LOVE_DINING_SKUS

        for sku in outlet['product_sku']:
            if sku in get_love_dining_skus:
                is_love_dining_outlet = True

    if is_love_dining_outlet:
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/ios_63x63.png'
        })

    if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
        if outlet['is_point_based_offer'] == 1:
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/gem_point_offer_icon.png'
            })

        if outlet['is_company_specific'] and not outlet['is_monthly']:
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
            })

    if outlet.get('is_new'):
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_new.png'
        })

    if outlet.get('is_monthly'):
        if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
            })

        else:
            outlet['attributes'].append({
                'type': 'image',
                'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_monthly.png'
            })

    if outlet.get('is_cheers'):
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_cheers.png'
        })

    if outlet.get('is_delivery'):
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_delivery.png'
        })

    if outlet.get('is_more_sa'):
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_more_sa.png'
        })

    if outlet.get('is_shared'):
        outlet['attributes'].append({
            'type': 'image',
            'value': 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_pinged.png'
        })

    if not outlet.get('is_featured'):
        for category in outlet['categories']:
            if category != selected_category:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': get_category_badge(category, categories, selected_category)
                })
            if category == common_constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
                for cuisine in outlet['merchant']['cuisines']:
                    outlet['attributes'].append({
                        'type': 'text',
                        'value': cuisine
                    })

            if category == common_constants.CATEGORY_API_NAME_TRAVEL:
                category_val = None
                for sub_category in outlet['sub_categories']:
                    if sub_category == category:
                        category_val = sub_category
                        break
                if category_val:
                    outlet['attributes'].append({
                        'type': 'image',
                        'value': outlet['sub_categories'][category_val]
                    })

    if outlet.get('is_featured'):
        outlet['attributes'].append({
            'type': 'image',
            'value': get_featured_ribbon_image(outlet['category']),
            'is_featured': True
        })

    if not outlet.get('is_redeemable'):
        if outlet.get('is_purchased'):
            outlet[
                'locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_golden.png'  # noqa: E501
        else:
            if company == WlCompany.COMPANY_CODE_MASTER_CARDS:
                outlet[
                    'locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey_gems.png'  # noqa: E501
            else:
                outlet[
                    'locked_image_url'] = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey.png'  # noqa: E501


def set_images_and_attributes_dynamically(
        company, outlet, categories,
        selected_category='', api_configs=None, tab=None
):
    """
    Sets images and attributes
    """
    if api_configs is None:
        api_configs = {}
    outlet_attribute_icons = {}
    for key, value in OUTLET_ATTRIBUTE_DEFAULT_ICONS.items():
        if api_configs.get(key):
            outlet_attribute_icons[key] = api_configs[key]
        else:
            outlet_attribute_icons[key] = value

    outlet['attributes'] = []
    if tab and tab.icon_url:
        outlet['attributes'].append(
            {
                "type": "image",
                "value": tab.icon_url
            }
        )

    if outlet.get('is_new'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_new']
        })

    if outlet.get('is_monthly'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_monthly']
        })

    if outlet.get('is_cheers'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_cheers']
        })

    if outlet.get('is_delivery'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_delivery']
        })

    if outlet.get('is_more_sa'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_more_sa']
        })

    if outlet.get('is_shared'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['is_shared']
        })

    # TODO Check
    if not outlet.get('is_featured'):
        for category in outlet['categories']:
            if category != selected_category:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': get_category_badge(category, categories, selected_category)
                })
            if category == common_constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
                if outlet.get('cuisines'):
                    for cuisine in outlet['cuisines']:
                        outlet['attributes'].append({
                            "type": "text",
                            "value": cuisine  # get translation
                        })
                else:
                    for cuisine in outlet['merchant'].get('cuisines', []):
                        outlet['attributes'].append({
                            "type": "text",
                            "value": cuisine  # get translation
                        })

            if category == common_constants.CATEGORY_API_NAME_TRAVEL:
                # we have list in outlet['sub_categories'] and we need to get index against specific category
                if outlet['sub_categories'].get(category):
                    outlet['attributes'].append({
                        "type": "text",
                        "value": outlet['sub_categories'][category][0]
                    })

    if outlet.get('is_featured'):
        outlet['attributes'].append({
            'type': 'image',
            'value': outlet_attribute_icons['Featured_Merchant_Icon_URL_{}'.format(outlet['category'].strip())],
            'is_featured': True
        })

    if not outlet.get('is_redeemable'):
        if outlet.get('is_purchased'):
            outlet['locked_image_url'] = outlet_attribute_icons['locked_image_url_purchased']
        else:
            outlet['locked_image_url'] = outlet_attribute_icons['locked_image_url_non_purchased']


def get_category_badge(category, categories, selected_category):
    """
    Gets category badge
    """
    for cat in categories:
        if category == cat['api_name'] and selected_category != cat['api_name']:
            return cat['image']
    return ''


def get_featured_ribbon_image(category):
    """
    Gets featured ribbon image
    """
    if category:
        if category == common_constants.CATEGORY_API_NAME_BODY:
            return common_constants.FEATURED_MERCHANT_ICON_URL_BODY
        elif category == common_constants.CATEGORY_API_NAME_LEISURE:
            return common_constants.FEATURED_MERCHANT_ICON_URL_LEISURE
        elif category == common_constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
            return common_constants.FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS
        elif category == common_constants.CATEGORY_API_NAME_RETAIL:
            return common_constants.FEATURED_MERCHANT_ICON_URL_RETAIL
        elif category == common_constants.CATEGORY_API_NAME_SERVICES:
            return common_constants.FEATURED_MERCHANT_ICON_URL_SERVICES
        elif category == common_constants.CATEGORY_API_NAME_TRAVEL:
            return common_constants.FEATURED_MERCHANT_ICON_URL_TRAVEL
    else:
        return ''


def convert_merchant_name_lower(final_outlets):
    """
    Convert merchant name into lower in final outlets
    :return:
    """
    for outlet in final_outlets:
        outlet.update({'merchant_name': outlet['merchant_name'].lower()})


def get_allowed_ping_limit(user_group, is_active_family_member):
    """
    Returns max number of allowed pings according to member status
    :param bool is_active_family_member: Is user part of an active family
    :param int user_group: Member group
    :rtype: int
    """
    if user_group == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_active_family_member:
        return ShareOffer.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_MEMBER
    return ShareOffer.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_NON_MEMBER


def get_location_ids_from_product_ids(product_ids, company):
    """
    Returns list of location ids against product ids
    :param str company: Company name.
    :param list product_ids: Product Ids
    :rtype: list
    """
    if product_ids:
        results = Product.get_location_ids_by_product_ids(product_ids, company)
        return [result.location_id for result in results]
    return []


def filter_positive_number(number):
    """
    Filters the number, is number positive or not.

    :param number: int
    :rtype: bool
    :returns: true or false if number is greater than 0 or not respectively.
    """
    if number and number > 0:
        return True
    return False


def get_outlet_nearest_time_slot_index(slots_delevery_end_time):
    """
    Gets index of picked slot from dict of diff between end time of slot with current time.

                    Sample Input                      ==>    Sample Output
    -------------------------------------------------------------------------
    {'1000': 0, '3000': 1, '6000': 2, '8000': 3}      ==>   0 (All Future)
    {'-8000': 0, '-6000': 1, '-3000': 2, '-1000': 3}  ==>   3 (All Past)
    {'-1000': 0, '-3000': 1, '2000': 2, '4000': 3}    ==>   2 (Some Future, some Past)

    :param slots_delevery_end_time: dict
    :rtype: int
    :return: index of picked slot
    """
    slots_delievery_end_time_keys = slots_delevery_end_time.keys()
    min_value = min(slots_delevery_end_time)
    # For all future time slots case
    if min_value > 0:
        return slots_delevery_end_time[min_value]
    max_value = max(slots_delevery_end_time)
    # For all past or present time slots case
    if max_value <= 0:
        return slots_delevery_end_time[max_value]
    # For some future and some past time slots
    if min_value <= 0 < max_value:
        get_positive_slot = list(filter(filter_positive_number, slots_delievery_end_time_keys))
        min_positive = min(get_positive_slot)
        return slots_delevery_end_time[min_positive]


def find_time_difference_in_seconds(outlet_delivery_end_time, current_time):
    """
    Converts outlet delivery slot end time and current time to seconds and then returns difference of both

    :param outlet_delivery_end_time: end time of outlet time slot
    :param current_time: current time
    :return difference between current time and outlet delivery ending time in seconds
    :rtype: float
    """
    outlet_delivery_end_time_in_secs = outlet_delivery_end_time.seconds
    current_time_in_secs = datetime.timedelta(
        hours=current_time.hour,
        minutes=current_time.minute,
        seconds=current_time.second
    ).total_seconds()
    diff_from_current_time = outlet_delivery_end_time_in_secs - current_time_in_secs
    return diff_from_current_time


def filter_outlet_time_slots(outlets, current_time):
    """
    Filters outlets on basis of nearest possible time slot

    :param outlets: outlets
    :param current_time: current time
    :return return outlet with selected time slot
    :rtype: dict
    """
    outlets_time_diff = {}
    for index, outlet in enumerate(outlets):
        outlet_slot_total_minutes = outlet.get('total_minutes', 0)
        outlet_delivery_end_time = outlet.get('delivery_start_time') + datetime.timedelta(
            minutes=outlet_slot_total_minutes
        )
        time_diff_in_secs = find_time_difference_in_seconds(outlet_delivery_end_time, current_time)
        outlets_time_diff[time_diff_in_secs] = index
    index_of_selected_outlet = 0
    if len(outlets_time_diff) > 1:
        index_of_selected_outlet = get_outlet_nearest_time_slot_index(outlets_time_diff)
    return outlets[index_of_selected_outlet]


def pick_outlets_with_best_time_slot(outlets, location_id):
    """
    Picks if delivery outlet should be visible at a current time
    :param outlets:
    :param location_id:
    :return:
    """
    outlets_data = defaultdict(list)
    outlet_bands = defaultdict(set)
    current_time = get_current_time_of_location(location_id)
    # It will append outlets data in outlets_data and bands in outlet_bands by the key of outlet id.
    for outlet in outlets:
        outlet['delivery_end_time'] = outlet['delivery_start_time'] + datetime.timedelta(
            minutes=outlet.get('total_minutes', 0)
        )
        outlet_id = outlet['id']
        outlet_band_id = outlet['bands']
        outlets_data[outlet_id].append(outlet)
        if outlet_band_id:
            outlet_bands[outlet_id].add(outlet_band_id)
    outlets_dm = []
    # It will append outlet with the best time slot and bands from each list item.
    for outlet_id, outlet_time_slots in outlets_data.items():
        if len(outlet_time_slots) > 1:
            outlet_with_best_time_slot = filter_outlet_time_slots(
                outlet_time_slots, current_time
            )
        else:
            outlet_with_best_time_slot = outlet_time_slots[0]
        outlet_with_best_time_slot['bands'] = list(outlet_bands[outlet_id])
        outlets_dm.append(outlet_with_best_time_slot)
    return outlets_dm


def find_distance(lat, lng, outlet_lat, outlet_lng):
    """
    Returns outlet's distance in KM from target lat long
    :param float lat: Person latitude
    :param float lat: Person longitude
    :param float outlet_lat: Outlet latitude
    :param float outlet_lng: Outlet longitude
    :rtype: float
    :returns: outlet_distance in Km's
    """
    lat_lng = (lat, lng)
    outlet_lat_lng = (outlet_lat, outlet_lng)
    if lat is not None and lng is not None and outlet_lat is not None and outlet_lng is not None:
        outlet_distance = distance.distance(lat_lng, outlet_lat_lng).km
    else:
        outlet_distance = 0
    return outlet_distance


@cache.memoize(timeout=1800)
def get_band_info_cached(location_id):
    """
    Returns bands info against location id and caches result
    :param int location_id: Location Id
    """
    return QuiqUpSetting.get_band_range_info(location_id)


@cache.memoize(timeout=900)
def get_cashless_delivery_outlets(outlet_ids, company):
    """
    Cached method to get which outlets have cashless delivery enabled based on outlets_ids.

    :param list outlet_ids: ids of outlets.
    :param str company: name of company to get outlets for.
    :rtype dict
    """
    if outlet_ids:
        return {
            row.outlet_id: row.cashless_delivery_enabled
            for row in Outlet.cashless_delivery_outlets(outlet_ids, company)
        }
    return {}


def get_outlet_monthly_status(offer, outlet=None):
    """
    Return outlet monthly status.

    If outlet is already marked as monthly then it stays monthly.
    Otherwise if offer coming in this outlet is monthly then outlet will be monthly.

    is_monthly status is setting in offer data in following function:

    INFO::If any offer in outlet is monthly then outlet is monthly.

    :param dict offer: offer data
    :param dict, None outlet: outlet data
    :return: outlet monthly flag
    :rtype: bool
    """
    if not outlet:
        outlet = {}
    if offer.get('is_monthly', False) or outlet.get('is_monthly', False):
        return True
    return False


def get_outlet_fourth_offer_status(offer, outlet=None):
    """
    Return outlet fourth offer status.

    If outlet is already marked as has_fourth_offers then remain it as has_fourth_offers.
    otherwise if offer coming in this outlet has type 2 offer but not monthly then outlet will be has_fourth_offers.

    INFO::If any offer in outlet has offer type 2 but not belongs to monthly product
    then outlet is has_fourth_offers.

    :param dict offer: offer data
    :param dict, None outlet: outlet data
    :return: outlet fourth offer status
    :rtype: bool
    """
    if not outlet:
        outlet = {}
    if (offer.get('type', 0) == 2 and offer.get('ismember', 0) != 1) or outlet.get('has_fourth_offers', False):
        return True
    return False


def validate_offer_types(offer_types):
    """
    Returns valid subset of offer_types.
    :param list offer_types: types of offers.
    :rtype: list
    """
    if isinstance(offer_types, list):
        return [int(offer_type) for offer_type in offer_types if int(offer_type) in VALID_OFFER_TYPES]
    return []


def get_cache_key(cache_type, language, search_type, billing_area, category, attributes):

    cache_key = "{language}-{cache_type}-{search_type}-{billing_area}-{category}-{attrs}".format(
        language=language,
        cache_type=cache_type,
        search_type=search_type,
        billing_area=billing_area,
        category=category,
        attrs=attributes
    )
    return base64.b64encode(cache_key.encode()).decode()
