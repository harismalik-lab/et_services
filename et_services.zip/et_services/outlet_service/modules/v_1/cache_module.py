"""
Contains helper functions specific to cache.
"""
import base64

from flask import current_app
from flask_caching import Cache


class CacheModule(object):
    """

    """

    @staticmethod
    def get_context_cache():
        return Cache(current_app, config=current_app.config)

    @staticmethod
    def get_cache_key(**kwargs):

        additional_text = kwargs.get('text')

        cache_key = "{cache_type}-{search_type}-{billing_area}-{category}-{attrs}".format(
            cache_type=kwargs['cache_type'],
            search_type=kwargs['search_type'],
            billing_area=kwargs['billing_area'],
            category=kwargs['category'],
            attrs=kwargs['attributes']
        )
        if additional_text:
            cache_key = "{key}-{add_text}".format(key=cache_key, add_text=additional_text)

        return base64.b64encode(cache_key.encode()).decode()
