"""
Contains helper functions specific to outlets service.
"""

from flask import g

from common.models.v_2.offer import OfferV2
from common.models.v_2.outlet import OutletV2
from outlet_service.common.constants import (
    CATEGORY_NAME_BODY, CATEGORY_NAME_LEISURE, CATEGORY_NAME_RESTAURANTS_AND_BARS, CATEGORY_NAME_RETAIL,
    CATEGORY_NAME_SERVICES, CATEGORY_NAME_TRAVEL, FEATURED_RIBBON_IMAGE, IMAGE_BODY, IMAGE_LEISURE,
    IMAGE_RESTAURANTS_AND_BARS, IMAGE_RETAIL, IMAGE_SERVICES
)
from outlet_service.common.models.offer import Offer
from outlet_service.common.models.share_offer import ShareOffer
from outlet_service.common.models.v_2.merchant import MerchantV2
from outlet_service.common.models.v_2.product import ProductV2
from outlet_service.common.models.wl_company import WlCompany
from outlet_service.common.utils.translation_manager import TranslationManager
from outlet_service.modules.api_constants import (
    CHEERS_OFFER_ICON, DELIVERY_OFFER_ICON, GEMS_LOGO, GEMS_POINT_OFFER_ICON, HSBC_LOVE_DINING_SKUS,
    I_LOVE_DINING_OFFER_ICON, MONTHLY_OFFER_ICON, MORE_SA_OFFER_ICON, NEW_OFFER_ICON, SHARED_OFFER_ICON,
    LOCKED_IMG_GOLD, LOCKED_IMG_GEMS, LOCKED_IMG_GREY)

cache = g.cache


class OutletsModule(object):
    """
    Outlets module holds all the helper methods and their constants to be used in outlets service.
    """
    MAX_OUTLETS = 60
    MAP_ZOOM_LEVEL = 12.5
    VALID_OFFER_TYPES = (
        Offer.OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE,
        Offer.OFFER_TYPE_VALUE_PERCENTAGE_OFF,
        Offer.OFFER_TYPE_VALUE_GIFT,
        Offer.OFFER_TYPE_VALUE_PACKAGE,
        Offer.OFFER_TYPE_VALUE_FIX_PRICE_OFF,
        Offer.OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS
    )

    def validate_offer_types(self, offer_types):
        """
        Returns valid subset of offer_types.
        :rtype: list
        """
        if isinstance(offer_types, list):
            return [int(offer_type) for offer_type in offer_types if int(offer_type) in self.VALID_OFFER_TYPES]
        return []

    @staticmethod
    def is_valid_subcategory(sub_category):

        return sub_category and sub_category.lower() != 'all'

    def validate_subcategories(self, sub_categories):
        """
        Returns valid subset of sub_categories.
        """
        return list(filter(self.is_valid_subcategory, [subcategory.strip() for subcategory in sub_categories]))

    @staticmethod
    def get_allowed_ping_limit(is_member, is_active_family_member):
        """
        Returns max number of allowed pings according to member status
        :rtype: int
        """
        if is_member or is_active_family_member:
            return ShareOffer.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_MEMBER

        return ShareOffer.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_NON_MEMBER

    def get_ping_section_data_for_user(self, **kwargs):
        """

        """
        is_member = kwargs.get('is_member')
        is_family_member = kwargs.get('is_family_member')
        customer_id = kwargs.get('customer_id')
        locale = kwargs.get('locale')

        max_pings_allowed_to_receive = self.get_allowed_ping_limit(is_member, is_family_member)
        if is_family_member:
            pings_count_received_by_recipient = 0
        else:
            pings_count_received_by_recipient = ShareOffer.get_pings_count_accepted_or_pending_by_user_id(customer_id)

        pings_recipient_can_receive = max(0, max_pings_allowed_to_receive - pings_count_received_by_recipient)

        if pings_recipient_can_receive:
            ping_color_code = ShareOffer.COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND
            if pings_recipient_can_receive == 1:
                ping_message = TranslationManager.get_translation(
                    TranslationManager.PING_COUNT_LEFT_TO_RECEIVE_SINGLE,
                    locale
                )
                ping_message = ping_message.format(offer_count=pings_recipient_can_receive)
            elif is_member or is_family_member:
                ping_message = ''
            else:
                ping_message = TranslationManager.get_translation(
                    TranslationManager.PING_COUNT_LEFT_TO_RECEIVE_MULTIPLE,
                    locale
                )
                ping_message = ping_message.format(offer_count=pings_recipient_can_receive)
        else:
            ping_color_code = ShareOffer.COLOR_CODE_WHEN_USER_HAS_NO_PING_QUOTA_LEFT_TO_RECEIVE_OR_SEND
            ping_message = TranslationManager.get_translation(
                TranslationManager.PING_QUOTA_FINISHED_TO_RECEIVE,
                locale
            )

        return {
            'message': ping_message,
            'color_code': ping_color_code,
            'can_user_receive_ping': bool(pings_recipient_can_receive),
            'total_quota_to_receive_pings': max_pings_allowed_to_receive,
            'total_pings_received': pings_count_received_by_recipient,
        }

    @staticmethod
    def get_promotional_section_for_category(category, locale):
        """
        Static JSON for promotional section on the base of passed category.
        """
        title = None
        description = None
        image = None
        promotional_json = {
            'title': '',
            'description': '',
            'image': '',
            'bottom_button_title': ''
        }
        if category == CATEGORY_NAME_BODY:
            title = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_BODY_TITLE, locale=locale
            )
            description = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_BODY_DESCRIPTION, locale=locale
            )
            image = IMAGE_BODY

        elif category == CATEGORY_NAME_LEISURE:
            title = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_LEISURE_TITLE, locale=locale
            )
            description = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_LEISURE_DESCRIPTION, locale=locale
            )
            image = IMAGE_LEISURE

        elif category == CATEGORY_NAME_RESTAURANTS_AND_BARS:
            title = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_FOOD_TITLE, locale=locale
            )
            description = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_FOOD_DESCRIPTION, locale=locale
            )
            image = IMAGE_RESTAURANTS_AND_BARS

        elif category == CATEGORY_NAME_RETAIL:
            title = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_RETAIL_TITLE, locale=locale
            )
            description = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_RETAIL_DESCRIPTION, locale=locale
            )
            image = IMAGE_RETAIL

        elif category == CATEGORY_NAME_SERVICES:
            title = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_SERVICES_TITLE, locale=locale
            )
            description = TranslationManager.get_translation(
                TranslationManager.PROMOTIONAL_SECTION_SERVICES_DESCRIPTION, locale=locale
            )
            image = IMAGE_SERVICES

        if image and title and description:
            promotional_json = {
                'title': TranslationManager.get_message_by_string(title, locale),
                'description': TranslationManager.get_message_by_string(description, locale),
                'image': image,
                'bottom_button_title': TranslationManager.get_message_by_string(
                    TranslationManager.PROMOTIONAL_SECTION_BOTTOM_BUTTON_TITLE,
                    locale=locale
                )
            }
        return promotional_json

    @staticmethod
    def get_customer_cheer_products_for_location(product_ids, location_id, is_ent, company):

        return bool(
            ProductV2.get_products(
                product_ids=product_ids,
                location_id=location_id,
                company=company,
                is_ent=is_ent,
                is_cheers=1,
                get_count=1
            )
        )

    @staticmethod
    @cache.memoize(1800)
    def get_product_locations(product_ids, is_ent, company):
        """
        Returns list of location ids against product ids.
        :rtype: list
        """
        if product_ids:
            results = ProductV2.get_products(
                product_ids=product_ids,
                is_ent=is_ent,
                company=company,
                is_distinct=True
            )
            return [result.location_id for result in results]
        return []

    @staticmethod
    def get_hotel_rating(sub_categories):
        """
        Extracts hotel rating from subcategories of offer.
        """

        if sub_categories:
            if '3 Star' in sub_categories:
                return 3
            if '4 Star' in sub_categories:
                return 4
            if '5 Star' in sub_categories:
                return 5

        return ''

    @staticmethod
    def get_offer_monthly_status(offer, show_monthly):
        """
        Return offer is_monthly status.

        If show_monthly flag is ON then set offer monthly status on the basis of ismember key value.
        If show_monthly flag is OFF then set offer monthly status on the basis of type key value.

        :rtype: bool
        """
        if show_monthly:
            is_monthly = bool(offer.get('ismember', False))
        else:
            is_monthly = offer.get('type') == OfferV2.OFFER_TYPE_MONTHLY
        return is_monthly

    def find_offers(self, **kwargs):

        offers = []

        records = OfferV2.get_offers(**kwargs)
        if records:
            is_ent = kwargs['is_ent']
            is_show_monthly = kwargs.get('show_monthly_offers_product_wise', False)
            for record in records:
                offer = record._asdict()
                if is_ent:
                    offer['is_monthly'] = self.get_offer_monthly_status(offer, show_monthly=is_show_monthly)
                offers.append(offer)
        return offers

    @staticmethod
    def get_category_badge(category, categories, selected_category):
        """
        Gets category badge
        """
        for cat in categories:
            if category == cat['api_name'] and selected_category != cat['api_name']:
                return cat['image']
        return ''

    @staticmethod
    def get_featured_ribbon_image(category):
        """
        Gets featured ribbon image for category.
        """
        if category:
            return FEATURED_RIBBON_IMAGE.get(category, '')
        return ''

    def set_images_and_attributes(self, company, outlet, categories, selected_category):
        """
        Sets images and attributes for outlets.
        """
        outlet['attributes'] = []
        is_love_dining_outlet = False
        if company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
            for sku in outlet['product_sku']:
                if sku in HSBC_LOVE_DINING_SKUS:
                    is_love_dining_outlet = True

        elif company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            if outlet['is_point_based_offer'] == 1:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': GEMS_POINT_OFFER_ICON
                })

            if outlet['is_company_specific'] and not outlet['is_monthly']:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': GEMS_LOGO
                })

        if is_love_dining_outlet:
            outlet['attributes'].append({
                'type': 'image',
                'value': I_LOVE_DINING_OFFER_ICON
            })

        if outlet.get('is_new'):
            outlet['attributes'].append({
                'type': 'image',
                'value': NEW_OFFER_ICON
            })

        if outlet.get('is_monthly'):
            if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': GEMS_LOGO
                })

            else:
                outlet['attributes'].append({
                    'type': 'image',
                    'value': MONTHLY_OFFER_ICON
                })

        if outlet.get('is_cheers'):
            outlet['attributes'].append({
                'type': 'image',
                'value': CHEERS_OFFER_ICON
            })

        if outlet.get('is_delivery'):
            outlet['attributes'].append({
                'type': 'image',
                'value': DELIVERY_OFFER_ICON
            })

        if outlet.get('is_more_sa'):
            outlet['attributes'].append({
                'type': 'image',
                'value': MORE_SA_OFFER_ICON
            })

        if outlet.get('is_shared'):
            outlet['attributes'].append({
                'type': 'image',
                'value': SHARED_OFFER_ICON
            })

        if not outlet.get('is_featured'):
            for category in outlet['categories']:
                if category != selected_category:
                    outlet['attributes'].append({
                        'type': 'image',
                        'value': self.get_category_badge(category, categories, selected_category)
                    })
                if category == CATEGORY_NAME_RESTAURANTS_AND_BARS:
                    for cuisine in outlet['merchant']['cuisines']:
                        outlet['attributes'].append({
                            'type': 'text',
                            'value': cuisine
                        })

                if category == CATEGORY_NAME_TRAVEL:
                    category_val = None
                    for sub_category in outlet['sub_categories']:
                        if sub_category == category:
                            category_val = sub_category
                            break
                    if category_val:
                        outlet['attributes'].append({
                            'type': 'image',
                            'value': outlet['sub_categories'][category_val]
                        })

        if outlet.get('is_featured'):
            outlet['attributes'].append({
                'type': 'image',
                'value': self.get_featured_ribbon_image(outlet['category']),
                'is_featured': True
            })

        if not outlet.get('is_redeemable'):
            if outlet.get('is_purchased'):
                outlet['locked_image_url'] = LOCKED_IMG_GOLD
            else:
                if company == WlCompany.COMPANY_CODE_MASTER_CARDS:
                    outlet['locked_image_url'] = LOCKED_IMG_GEMS
                else:
                    outlet['locked_image_url'] = LOCKED_IMG_GREY

    @staticmethod
    def get_featured_merchants_with_params(**kwargs):
        """
        Gets all featured merchants of a certain category for a location id.
        :rtype: list
        """
        category = kwargs['category']
        locale = kwargs['locale']

        outlet_label_plural = ''
        featured_merchants = []

        records = MerchantV2.get_featured_merchants(**kwargs)

        if category == CATEGORY_NAME_TRAVEL:
            outlet_label_singular = TranslationManager.get_translation(TranslationManager.TRAVEL_LOCATION, locale)
        else:
            outlet_label_singular = TranslationManager.get_translation(
                TranslationManager.OUTLET_COUNT_SINGULAR,
                locale
            )
            outlet_label_plural = TranslationManager.get_translation(
                TranslationManager.OUTLET_COUNT_PLURAL,
                locale
            )
        for record in records:
            if record:
                if record.category == CATEGORY_NAME_TRAVEL:
                    record.outlets_info = outlet_label_singular
                elif record.outlets_count > 0:
                    record.outlets_info = '{outlets_count} {label}'.format(
                        outlets_count=record.outlets_count,
                        label=outlet_label_singular if record.outlets_count == 1 else outlet_label_plural
                    )
                featured_merchants.append(record)
        return featured_merchants

    @staticmethod
    @cache.memoize(timeout=900)
    def get_cashless_delivery_outlets(**kwargs):
        """
        Cached method to get which outlets have cashless delivery enabled based on outlet_ids.

        :rtype dict
        """
        if kwargs['outlet_ids']:
            filtered_outlets = OutletV2.cashless_delivery_outlets(**kwargs)
            return {otl.outlet_id: otl.cashless_delivery_enabled for otl in filtered_outlets}
        return {}
