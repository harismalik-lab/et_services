"""
API Related constants reside here
"""
from outlet_service.common.constants import (
    FEATURED_MERCHANT_ICON_URL_BODY, FEATURED_MERCHANT_ICON_URL_LEISURE,
    FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS, FEATURED_MERCHANT_ICON_URL_RETAIL,
    FEATURED_MERCHANT_ICON_URL_SERVICES, FEATURED_MERCHANT_ICON_URL_TRAVEL
)

MAP_ZOOM_LEVEL = 12.5
PING_TIME_LIMIT_SECONDS = 300
LOG_SUB_FOLDERS = []
HSBC_FINE_DINING_SKUS = ('L19DBFHSC', 'L19DBHSFD')
MERCHANT_CRITERIA = {
    'lat': 0,
    'lng': 0,
    'radius': 5000,
    'category': 'All',
    'cuisine': 'All',
    'sort': 'default',
    'query': False,
    'query_type': 'name',
    'neighborhood': False,
    'mall': False,
    'hotel': False,
    'billing_country': False,
    'outlet_ids': False
}
REDEEMABILITY_NOT_REDEEMABLE = 'not_redeemable'
REDEEMABILITY_REDEEMABLE = 'redeemable'
REDEEMABILITY_REDEEMED = 'redeemed'
REDEEMABILITY_REDEEMABLE_REUSABLE = 'redeemable_reusable'
REDEEMABILITY_REUSABLE = 'reusable'
REDEEMABILITY_ALL = "all"
SECOND_GROUP = 2
TAB_ORDER_ALL_OFFERS = 1
TAB_SECTION_TYPE_ALL_OFFERS = 1
TAB_UID_ALL_OFFERS = 'all_offers'
TAB_UID_BUY_MORE = 'buy_more'
TAB_UID_CHEERS = 'cheers'
TAB_UID_DELIVERY = 'delivery'
TAB_UID_MONTHLY = 'monthly'
TAB_UID_MORESA = 'more_sa'
TYPE_MEMBER = 2
QUERY_TYPE_NAME = 'name'
EID_OFFERS = ('eid', 'eid offers')
EID_OFFER = 'eid offer'
DISABLE_FUZZY_FOR_QUERIES = ('yay', 'yay!', 'eid offer', 'ramadan')
HSBC_LOVE_DINING_SKUS = (
    'L18DBHSDC', 'L19DBHSDC', 'L18ADHSDC', 'L19ADHSDC',
    'L18DBHSDB', 'L19DBHSDB', 'L18ADHSDB', 'L19ADHSDB'
)
OUTLET_ATTRIBUTE_DEFAULT_ICONS = {
    'is_new': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_new.png",
    'is_monthly': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_monthly.png",
    'is_cheers': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_cheers.png",
    'is_delivery': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_delivery.png",
    'is_more_sa': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_more_sa.png",
    'is_shared': "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_pinged.png",
    'locked_image_url_purchased': "https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_golden.png",
    'locked_image_url_non_purchased': "https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey.png",
    'is_point_based_offer': "",
    'FEATURED_MERCHANT_ICON_URL_BODY': FEATURED_MERCHANT_ICON_URL_BODY,
    'FEATURED_MERCHANT_ICON_URL_LEISURE': FEATURED_MERCHANT_ICON_URL_LEISURE,
    'FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS': FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS,
    'FEATURED_MERCHANT_ICON_URL_RETAIL': FEATURED_MERCHANT_ICON_URL_RETAIL,
    'FEATURED_MERCHANT_ICON_URL_SERVICES': FEATURED_MERCHANT_ICON_URL_SERVICES,
    'FEATURED_MERCHANT_ICON_URL_TRAVEL': FEATURED_MERCHANT_ICON_URL_TRAVEL,
}
DEEP_LINK_PRODUCT_TYPE = 'product'
DEEP_LINK_BONUS_OFFERS = 'bonusoffers'
DISABLE_FUZZY = '_disablefuzzy'
HAPPY_BIRTHDAY_KEYWORD = 'happy_birthday'
CATEGORY_ALL = 'All'
PINGS_SECTION = {
    'is_sender_info': False,
    'is_recipient_info': False,
    'can_user_ping': False,
    'can_user_receive_ping': False,
    'total_quota_to_send_pings': 0,
    'total_quota_to_receive_pings': 0,
    'total_pings_sent': 0,
    'total_pings_received': 0,
    'message': '',
    'background_color': ''
}

RAMADAN_KEYWORD = 'ramadan'
RAMADAN_OFFER_ATTRIBUTES = ["iftar", "suhour", "futour", "ramadan", "eid"]


FEATURED_CATEGORY_RETAIL = "Retail"
FEATURED_CATEGORY_SERVICES = "Services"
DEEP_LINK_MALL_TYPE = 'mall'
DEEP_LINK_HOTEL_TYPE = 'hotel'
DEEP_LINK_NEIGHBOUR_HOOD_TYPE = 'neighbourhood'
DEEP_LINK_TABLE_RESERVATION = 'tablereservation'

NON_INTEGRATED_ASSET = 'non-integrated asset'
CALL_CENTRE = 'call centre'


LAST_MILE_LIVE_TRACKING = 'Live Tracking'
LAST_MILE_TITLE_COLOR = '000000'
LAST_MILE_IMAGE_URL = 'https://entertainer-app-assets.s3.amazonaws.com/delivery/en/image_2019_08_19T08_04_40_502Z.png'

CLOCK_CASHLESS_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/icons/clock2.png'

ATTRIBUTES_TO_DELETE_FOR_CASHLESS = (
    'can_delivery_at_address',
    'delivery_start_time',
    'delivery_end_time',
    'last_ping',
    'polygon_coordinates',
    'online_status',
    'oz_default_delivery_time',
    'outlet_zones',
    'zone_default_delivery_time'
)

OFFER_TYPE_VALUE_DEFAULT = 0
OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
OFFER_TYPE_VALUE_GIFT = 3
OFFER_TYPE_VALUE_PACKAGE = 4
OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

VALID_OFFER_TYPES = [
    OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE,
    OFFER_TYPE_VALUE_PERCENTAGE_OFF,
    OFFER_TYPE_VALUE_GIFT,
    OFFER_TYPE_VALUE_PACKAGE,
    OFFER_TYPE_VALUE_FIX_PRICE_OFF,
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS
]

SELECTED_OFFER_TYPE_NEW = 'new'
SELECTED_OFFER_TYPE_MONTHLY = 'monthly'
SELECTED_OFFER_TYPE_FOURTH = 'fourth_offers'
SELECTED_OFFER_TYPE_FOURTH_AND_MONTHLY = 'show_fourth_and_monthly_offers'

GEMS_LOGO = 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'


I_LOVE_DINING_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/ios_63x63.png'
SHARED_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_pinged.png'
NEW_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_new.png'
MONTHLY_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_monthly.png'
CHEERS_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_cheers.png'
DELIVERY_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_delivery.png'
MORE_SA_OFFER_ICON = 'https://s3.amazonaws.com/entertainer-app-assets/icons/badge_more_sa.png'
GEMS_POINT_OFFER_ICON = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/gem_point_offer_icon.png'

LOCKED_IMG_GOLD = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_golden.png'
LOCKED_IMG_GEMS = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey_gems.png'
LOCKED_IMG_GREY = 'https://s3.amazonaws.com/entertainer-app-assets/icons/locked_outlet_grey.png'
