"""
This module contains routing for an app
"""
from flask import current_app

from outlet_service.app.api.v1.hotels import HotelsApi
from outlet_service.app.api.v1.malls import MallsApi
from outlet_service.app.api.v1.neighborhood import NeighborhoodApi
from outlet_service.app.api.v1.outlets import OutletsApi
from outlet_service.common.base_routing import BaseRouting


class OutletsAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['OUTLET_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['outlets'] = {
            'url': '/outlets',
            'view': OutletsApi
        }

        self.routing_collection['hotels'] = {
            'url': '/hotels',
            'view': HotelsApi
        }

        self.routing_collection['malls'] = {
            'url': '/malls',
            'view': MallsApi
        }

        self.routing_collection['neighborhood'] = {
            'url': '/neighborhood',
            'view': NeighborhoodApi
        }
