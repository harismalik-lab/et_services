"""
This module contains routing for an app
"""
from outlet_service.app.api.v4.outlets import OutletsAPIV4
from outlet_service.app.routings.routings_v3 import OutletsAPIRoutesV3


class OutletsAPIRoutesV4(OutletsAPIRoutesV3):
    api_version = '4'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['outlets'] = {
            'url': '/outlets',
            'view': OutletsAPIV4
        }
