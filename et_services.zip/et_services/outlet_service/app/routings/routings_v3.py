"""
This module contains routing for an app
"""
from outlet_service.app.api.v3.outlets import OutletsAPIV3
from outlet_service.app.routings.routings_v2 import OutletsAPIV2


class OutletsAPIRoutesV3(OutletsAPIV2):
    api_version = '3'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['outlets'] = {
            'url': '/outlets',
            'view': OutletsAPIV3
        }
