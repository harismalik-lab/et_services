"""
This module contains routing for an app
"""
from outlet_service.app.api.v2.external_outlets import ExternalOutletsApi
from outlet_service.app.api.v2.outlets import OutletsApiV2
from outlet_service.app.routings.routings_v1 import OutletsAPIV1


class OutletsAPIV2(OutletsAPIV1):
    api_version = '2'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['outlets'] = {
            'url': '/outlets',
            'view': OutletsApiV2
        }
        self.routing_collection['external_outlets'] = {
            'url': '/external/outlets',
            'view': ExternalOutletsApi
        }
