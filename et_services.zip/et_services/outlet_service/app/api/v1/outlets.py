"""
Outlet Api
"""
import datetime
from datetime import timedelta
from operator import itemgetter

from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from outlet_service.app.api.v1.validations.outlets_validator import \
    outlet_validation_parser
from outlet_service.common.base_resource import BaseGetResource
from outlet_service.common.constants import (ALPHA, CATEGORY_API_NAME_RETAIL,
                                             CATEGORY_API_NAME_SERVICES,
                                             CUSTOM_ERROR_CODE, DEFAULT, EN,
                                             MAX_OUTLETS, VALID_CATEGORIES)
from outlet_service.common.models.home_screen_configurations import \
    HomeScreenConfiguration
from outlet_service.common.models.offer_wl_active import OfferWlActive
from outlet_service.common.models.outlet import Outlet
from outlet_service.common.models.redemption import Redemption
from outlet_service.common.models.wl_company import WlCompany
from outlet_service.common.models.wl_product import WlProduct
from outlet_service.common.models.wl_user_group import WlUserGroup
from outlet_service.common.rest_urls import RedemptionServiceAPIUrls
from outlet_service.common.utils.api_utils import (get_analytics_codes_against_categories,
                                                   get_category_codes_for_analytics,
                                                   get_configured_sku_by_company,
                                                   get_locale, multi_key_sort)
from outlet_service.common.utils.authentication import (get_company,
                                                        get_current_customer)
from outlet_service.common.utils.cummunicator import communicator
from outlet_service.modules.api_constants import (QUERY_TYPE_NAME,
                                                  REDEEMABILITY_NOT_REDEEMABLE,
                                                  REDEEMABILITY_REDEEMABLE,
                                                  REDEEMABILITY_REDEEMABLE_REUSABLE,
                                                  REDEEMABILITY_REDEEMED,
                                                  REDEEMABILITY_REUSABLE,
                                                  TYPE_MEMBER)
from outlet_service.modules.api_utils import (get_tabs_info,
                                              is_search_string_found,
                                              parse_list,
                                              set_images_and_attributes,
                                              sort_categories)
from outlet_service.modules.fuzzy_search_manager import fuzzy_search_manager


class OutletsApi(BaseGetResource):
    """
    @api {get} /v1/outlets Outlets
    @apiSampleRequest /v1/outlets
    @apiVersion 1.0.0
    @apiName OutletsApi
    @apiGroup Outlets
    @apiParam {String="android", "ios", "web"}            [platform]                 Mobile Platform
    @apiParam {Boolean}                                   [is_cuckoo]                Checks flag is_cuckoo
    @apiParam {Boolean}                                   [is_cheers]                Checks flag is_cheers
    @apiParam {Boolean}                                   [is_company_specific]      Checks flag is_company_specific
    @apiParam {Boolean}                                   [is_more_sa]               Checks flag is_more_sa
    @apiParam {Integer}                                   [location_id]              Location_id
    @apiParam {String}                                    [product_sku]              Product_sku
    @apiParam {Integer}                                   [outlet_id]                Outlet_id
    @apiParam {String}                                    [sub_category_filter]      Sub_category_filter
    @apiParam {String}                                    [redeemability]            Redeemability value
    @apiParam {String}                                    [filter_by_type]           Filter_by_type
    @apiParam {String}                                    [query_type]               Query_type
    @apiParam {String}                                    [category]                 Name category to filter outlets by
    @apiParam {String}                                    [user_include_cheers]      User include cheers
    @apiParam {String}                                    [location_id]              ID of location to filter outlets by
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'} [language]                 Response language
    """
    request_parser = outlet_validation_parser
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/outlets_api.log',
        ),
        'name': 'outlets_api'
    }

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = get_locale(self.request_args.get('language'))
        self.offer_redeemability = self.request_args.get('redeemability').lower().strip()
        self.filter_by_type = self.request_args.get('filter_by_type')
        self.query = self.request_args.get('query')
        self.outlet_id = self.request_args.get('outlet_id')
        self.offset = self.request_args.get('offset')
        self.is_more_sa = self.request_args.get('is_more_sa')
        self.is_cuckoo = self.request_args.get('is_cuckoo')
        self.is_cheers = self.request_args.get('is_cheers')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')
        self.radius = self.request_args.get('radius')
        self.cuisine = self.request_args.get('cuisine')
        self.user_include_cheers = self.request_args.get('user_include_cheers')
        self.is_delivery = self.request_args.get('is_delivery')
        self.category = self.request_args.get('category')
        self.query_type = self.request_args.get('query_type')
        self.neighborhood = self.request_args.get('neighborhood')
        self.mall = self.request_args.get('mall')
        self.hotel = self.request_args.get('hotel')
        self.sub_category_filter = self.request_args.get('sub_category_filter')
        self.cuisine_filter = self.request_args.get('cuisine_filter') or self.request_args.get('cuisine_filter[]')
        self.filters_selected_for_yes = (
            self.request_args.get('filters_selected_for_yes') or
            self.request_args.get('filters_selected_for_yes[]')
        )
        self.filters_selected_for_no = (
            self.request_args.get('filters_selected_for_no') or
            self.request_args.get('filters_selected_for_no[]')
        )
        self.billing_country = self.request_args.get('billing_country')
        self.billing_city = self.request_args.get('billing_city')
        self.search_by_dest_type = self.request_args.get('search_by_dest_type')
        self.fuzzy = self.request_args.get('fuzzy')
        self.redeemability_first = self.request_args.get('first_sort_by_redeemability')
        self.is_company_specific = self.request_args.get('is_company_specific')
        self.show_monthly_offers = self.request_args.get('show_monthly_offers')
        self.show_new_offers = self.request_args.get('show_new_offers')
        self.app_version = self.request_args.get('app_version')
        self.show_only_core_product_offers = self.request_args.get('show_only_core_product_offers')
        self.product_sku = self.request_args.get('product_sku')
        self.sort = self.request_args.get('sort')
        self.is_company_specific = self.request_args.get('is_company_specific')
        self.limit = self.request_args.get('limit', MAX_OUTLETS)

    def check_limit(self):

        if self.limit > MAX_OUTLETS or self.limit < 0:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Limit should be > 0 and <= {}".format(MAX_OUTLETS),
                custom_code=CUSTOM_ERROR_CODE
            )
            return self.send_response(self.response, self.status_code)

        if self.offset < 0:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Offset should not be a negative number",
                custom_code=CUSTOM_ERROR_CODE
            )
            return self.send_response(self.response, self.status_code)

    def initialize_local_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.redemption_api_urls = RedemptionServiceAPIUrls
        self.total_records = 0

    def initialize_class_attributes(self):
        """
        Initialize class attributes
        """
        self.outlet_ids = []
        self.featured_merchants = []
        self._fuzzy_search_outlet_ids = []
        self._fuzzy_search_outlet_id_score = []
        self.is_fuzzy_server_down = False
        self.elastic_search_is_on = current_app.config["ELASTIC_SEARCH_IS_ON"]
        self.elastic_search_min_string_length_for_search = current_app.config[
            "ELASTIC_SEARCH_MIN_STRING_LENGTH_FOR_SEARCH"
        ]

    def load_customer_profile_and_session_data(self):
        """
        Load the customer-profile and customer session_data
        """
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id', 0)

    def is_show_monthly_offers(self):
        """
        Checks Monthly offers in outlet
        """
        if not self.show_monthly_offers:
            if (
                self.filter_by_type == str(TYPE_MEMBER) and
                self.offer_redeemability == REDEEMABILITY_REUSABLE
            ):
                self.show_monthly_offers = True

        self.offer_valid_from_start_date = datetime.datetime.now().replace(month=1, day=31)  # Offers Cut off date
        self.offer_valid_from_cut_off_date = datetime.datetime.now()
        self.offer_valid_from_cut_off_date = self.offer_valid_from_cut_off_date.replace(hour=0, minute=0, second=0)
        self.offer_valid_from_cut_off_date = self.offer_valid_from_cut_off_date - timedelta(days=30)
        self._is_fuzzy_search_on = (
            (self.elastic_search_is_on or self.fuzzy) and
            self.query and
            self.query_type == QUERY_TYPE_NAME and
            self.locale == EN
        )
        # query_lower = (self.query or '').lower()
        # if query_lower in EID_OFFERS:
        #     self.query = 'eid offer'
        # if query_lower == EID_OFFER:
        #     self._is_fuzzy_search_on = False

    def get_tabs_info(self):
        """
        Gets tabs info
        """
        self.tabs = get_tabs_info(
            self.customer_id,
            self.company,
            self.offset,
            self.filter_by_type,
            self.category,
            self.is_cuckoo,
            self.locale,
            self.location_id,
            self.customer.get('product_ids', [])
        )

    def skip_mode(self):
        """
        Skip mode
        """
        if not self.customer.get('session_token'):
            self.user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
            self.customer['product_ids'] = WlProduct.get_configured_product_ids(
                self.company,
                self.user_groups
            )

    def set_categories(self):
        """
        Sets categories to be shown in response of outlets.
        """

        self.categories = HomeScreenConfiguration.get_categories(
            is_user_logged_in=self.customer.get('is_user_logged_in'),
            company=self.company,
            user_id=self.customer_id,
            location_id=self.location_id,
            purchased_product_ids=[],
            purchasable_product_ids=[],
            locale=self.locale
        )
        self.search_results = []
        self.final_outlets = []

    def is_fuzzy_search_on(self):
        if self._is_fuzzy_search_on:
            fuzzy_search_result = fuzzy_search_manager.get_fuzzy_results(
                self.query,
                self.category,
                self.sub_category_filter
            )
            if fuzzy_search_result.is_timeout_or_server_down:
                self._is_fuzzy_search_on = False
                self.is_fuzzy_server_down = True
            elif (
                fuzzy_search_result.is_succeeded and
                fuzzy_search_result.total_unique_results_found > 0
            ):
                self._fuzzy_search_outlet_ids = fuzzy_search_result.outlet_ids
                self._fuzzy_search_outlet_id_score = fuzzy_search_result.outlet_id_score

    def get_offers_from_db(self):
        self.offers = Outlet.find_offers(
            locale=self.locale,
            company=self.company,
            product_ids=self.customer.get('product_ids'),
            product_sku=self.product_sku,
            offer_redeemability=self.offer_redeemability,
            show_only_core_product_offers=self.show_only_core_product_offers,
            is_cuckoo=self.is_cuckoo,
            is_cheers=self.is_cheers,
            is_delivery=self.is_delivery,
            show_monthly_offers=self.show_monthly_offers,
            show_new_offers=self.show_new_offers,
            is_more_sa=self.is_more_sa,
            user_include_cheers=self.user_include_cheers,
            category=self.category,
            _is_fuzzy_search_on=self._is_fuzzy_search_on,
            _fuzzy_search_outlet_ids=self._fuzzy_search_outlet_ids,
            sub_category_filter=self.sub_category_filter,
            outlet_id=self.outlet_id,
            location_id=self.location_id,
            is_company_specific=self.is_company_specific,
            offer_valid_from_start_date=self.offer_valid_from_start_date,
            offer_valid_from_cut_off_date=self.offer_valid_from_cut_off_date
        )

    def set_offer_related_defaults(self):
        self.product_offers = []

    def process_offers(self):
        if self.offers:
            self.set_offer_related_defaults()
            self.offer_ids = [offer.id for offer in self.offers]
            self.query_matched_offers_outlets = []  # outlet id's of the offers that match search query
            self.outlet_offer_info = {}
            # Getting offers redeemability
            redeemabilities = {}
            if self.customer_id:
                response = communicator.communicate(
                    self.redemption_api_urls.CALCULATE_REDEEMABILITY,
                    'GET',
                    payload={'offer_ids': self.offer_ids}

                )
                redeemabilities = response.json()['data']
            for offer in self.offers:
                # Code
                offer = dict((zip(offer._fields, offer)))
                offer['outlet_ids'] = list(map(int, offer['outlet_ids'].split(',')))
                this_outlet_ids = offer['outlet_ids']
                if not self._is_fuzzy_search_on:
                    if (
                            self.query and
                            self.query_type == 'name'
                    ):
                        if is_search_string_found(offer['offer_name'], self.query, True):
                            for ids in this_outlet_ids:
                                self.query_matched_offers_outlets.append(ids)
                redeemability = redeemabilities.get('{}_{}'.format(offer['id'], offer['product_id']), {})
                offer['is_redeemable'] = redeemability.get('is_redeemable', False)
                offer['redeemability'] = redeemability.get('redeemability', Redemption.NOT_REDEEMABLE)
                offer['is_purchased'] = redeemability.get('is_purchased', False)

                for outlet_id in offer['outlet_ids']:
                    self.outlet_ids.append(outlet_id)

                    if not self.outlet_offer_info.get(outlet_id):
                        self.outlet_offer_info[outlet_id] = {'offer_ids': [offer['id']]}
                        changes = {
                            'product_id': [offer['product_id']],
                            'product_sku': [offer['product_sku']],
                            'is_redeemable': offer['is_redeemable'],
                            'redeemability': offer['redeemability'],
                            'is_purchased': offer['is_purchased'],
                            'is_cheers': True if offer['is_cheers'] else False,
                            'is_delivery': True if offer['is_delivery'] else False,
                            'is_more_sa': True if offer['is_more_sa'] else False,
                            'type': offer['type'],
                            'is_point_based_offer': offer['is_point_based_offer']
                        }
                        self.outlet_offer_info[outlet_id].update(changes)

                        if self.show_monthly_offers or offer['type'] == OfferWlActive.TYPE_MEMBER:
                            self.outlet_offer_info[outlet_id].update({'is_monthly': True})
                        else:
                            self.outlet_offer_info[outlet_id].update({'is_monthly': False})

                        if (self.show_new_offers or (
                                offer['type'] != OfferWlActive.TYPE_MEMBER and
                                offer['valid_from_date'] > self.offer_valid_from_start_date and
                                offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                        )):
                            self.outlet_offer_info[outlet_id]['is_new'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_new'] = False
                        if not self.outlet_offer_info[outlet_id].get('categories'):
                            self.outlet_offer_info[outlet_id]['categories'] = []

                        self.outlet_offer_info[outlet_id]['categories'].append(offer['merchant_category'])
                        if not self.outlet_offer_info[outlet_id].get('sub_categories'):
                            self.outlet_offer_info[outlet_id]['sub_categories'] = []
                        if (
                                offer['sub_category'] and
                                offer['sub_category'] not in self.outlet_offer_info[outlet_id].get('sub_categories')
                        ):
                            self.outlet_offer_info[outlet_id]['sub_categories'].append(offer['sub_category'])
                    else:
                        if offer['id'] not in self.outlet_offer_info[outlet_id].get('offer_ids'):
                            self.outlet_offer_info[outlet_id]['offer_ids'].append(offer['id'])
                        if offer['product_id'] not in self.outlet_offer_info[outlet_id].get('product_id'):
                            self.outlet_offer_info[outlet_id]['product_id'].append(offer['product_id'])
                        if offer['product_sku'] not in self.outlet_offer_info[outlet_id].get('product_sku'):
                            self.outlet_offer_info[outlet_id]['product_sku'].append(offer['product_sku'])
                        if offer['is_redeemable']:
                            self.outlet_offer_info[outlet_id]['is_redeemable'] = True
                        if offer['redeemability'] > self.outlet_offer_info[outlet_id]['redeemability']:
                            self.outlet_offer_info[outlet_id]['redeemability'] = offer['redeemability']
                        if offer['is_purchased']:
                            self.outlet_offer_info[outlet_id]['is_purchased'] = offer['is_purchased']
                        if offer['is_cheers']:
                            self.outlet_offer_info[outlet_id]['is_cheers'] = offer['is_cheers']
                        if offer['is_delivery']:
                            self.outlet_offer_info[outlet_id]['is_delivery'] = offer['is_delivery']
                        self.outlet_offer_info[outlet_id]['is_more_sa'] = (
                            True if offer['is_more_sa'] else self.outlet_offer_info[outlet_id]['is_more_sa']
                        )
                        self.outlet_offer_info[outlet_id]['type'] = (
                            offer['type']
                            if offer['type'] > self.outlet_offer_info[outlet_id]['type']
                            else self.outlet_offer_info[outlet_id]['type']
                        )
                        self.outlet_offer_info[outlet_id]['is_point_based_offer'] = (
                            True
                            if offer['is_point_based_offer']
                            else self.outlet_offer_info[outlet_id]['is_point_based_offer']
                        )
                        if not self.outlet_offer_info[outlet_id].get('categories'):
                            self.outlet_offer_info[outlet_id]['categories'] = []
                        if offer['merchant_category'] not in self.outlet_offer_info[outlet_id]['categories']:
                            self.outlet_offer_info[outlet_id]['categories'].append(offer['merchant_category'])
                        if (
                                self.show_monthly_offers or
                                offer['type'] == OfferWlActive.TYPE_MEMBER or
                                self.outlet_offer_info[outlet_id]['is_monthly']
                        ):
                            self.outlet_offer_info[outlet_id]['is_monthly'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_monthly'] = False
                        if (self.show_new_offers or self.outlet_offer_info[outlet_id]['is_new'] or (
                                offer['type'] != OfferWlActive.TYPE_MEMBER and
                                offer['valid_from_date'] > self.offer_valid_from_start_date and
                                offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                        )):
                            self.outlet_offer_info[outlet_id]['is_new'] = True
                        else:
                            self.outlet_offer_info[outlet_id]['is_new'] = False

                    if not self.outlet_offer_info[outlet_id].get('sub_categories'):
                        self.outlet_offer_info[outlet_id]['sub_categories'] = []

                    if (
                            offer['sub_category'] and
                            offer['sub_category'] not in self.outlet_offer_info[outlet_id].get('sub_categories')
                    ):
                        self.outlet_offer_info[outlet_id]['sub_categories'].append(offer['sub_category'])
                # Code
            self.update_outlets()
            self.process_outlets()
            self.process_fuzzy_search()
        filter_limit = self.limit + self.offset
        self.total_records = len(self.final_outlets)
        self.filtered_outlets = self.final_outlets[self.offset:filter_limit]
        if self.featured_merchants:
            for featured_merchant in self.featured_merchants:
                featured_merchant['locked_image_url'] = ""
                set_images_and_attributes(
                    company=self.company,
                    outlet=featured_merchant,
                    categories=self.categories,
                    selected_category=self.category
                )

    def update_outlets(self):
        self.outlet_ids = list(set(list(filter(None, self.outlet_ids))))
        self.merchant_criteria = {
            'lat': self.lat,
            'lng': self.lng,
            'radius': self.radius,
            'category': self.category,
            'cuisine': self.cuisine,
            'sort': self.sort,
            'query': self.query,
            'query_type': self.query_type,
            'neighborhood': self.neighborhood,
            'mall': self.mall,
            'hotel': self.hotel,
            'billing_country': self.billing_country,
            'outlet_ids': self.outlet_ids,
            'sub_category_filter': self.sub_category_filter,
            'cuisine_filter': self.cuisine_filter,
            'filters_selected_for_yes': self.filters_selected_for_yes,
            'filters_selected_for_no': self.filters_selected_for_no,
            'fuzzy_search_outlet_id_score': self._fuzzy_search_outlet_id_score,
        }
        # Grab current, active Outlets that match criteria
        self.outlets = Outlet.find_by_criteria_merchant_attributes(
            criteria=self.merchant_criteria,
            locale=self.locale
        )
        self.redeemabilities = []
        self.distances = []
        self.merchant_names = []
        self.final_outlets = []
        self.outlet_ids = []
        self.offers = []

    def update_outlet(self, outlet):
        outlet['merchant_ad_travel_country'] = ''
        outlet['merchant_ad_active_status'] = True
        outlet['merchant_categories'] = parse_list(outlet.get('merchant_categories', []))
        outlet['merchant_cuisines'] = parse_list(outlet.get('merchant_cuisines', []), cuisine=True)
        outlet['merchant_categories_analytics'] = get_analytics_codes_against_categories(
            outlet['merchant_categories']
        )
        outlet['tripadvisor_id'] = str(outlet.get('tripadvisor_id'))
        merchant = {}
        outlet['description'] = ""
        outlet['merchant_description'] = ""

        merchant_fields = [
            'id', 'name', 'name_for_outlet', 'description', 'category', 'categories', 'cuisine', 'cuisines',
            'categories_analytics', 'ad_travel_country', 'ad_active_status', 'logo_url', 'logo_small_url', 'photo_url',
            'photo_small_url'
        ]

        for field in merchant_fields:
            merchant[field] = outlet['merchant_{}'.format(field)]
            if field == 'ad_active_status':
                merchant[field] = merchant.get(field, 0) > 0
            del outlet['merchant_{}'.format(field)]
        if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
            outlet_name_parts = outlet['name'].split('-')
            outlet['name'] = outlet_name_parts[-1].strip()

        if self.category:
            if all([self.category in merchant['categories'],
                    self.category in VALID_CATEGORIES]):
                merchant['category'] = self.category

        merchant['name_for_outlet'] = merchant['name']
        outlet['merchant_name'] = merchant['name']
        outlet['merchant'] = merchant
        if outlet.get('distance'):
            # implicit cast to int, as value is in meters
            outlet['distance'] = round(int(outlet.get('distance', 0)))
        else:
            outlet['distance'] = 0
        if outlet['id'] in self.merchant_criteria['fuzzy_search_outlet_id_score']:
            outlet['fuzzy_relevance'] = self.merchant_criteria['fuzzy_search_outlet_id_score'][outlet['id']]
        else:
            outlet['fuzzy_relevance'] = 0

        # updated cuisine filter to merchant level
        if self.cuisine_filter and self.cuisine_filter[0]:
            is_cuisine_matched = False
            for cuisine in self.cuisine_filter:
                # change merchant_cuisines to lower case
                if cuisine.strip().lower() in map(lambda x: x.lower(), outlet['merchant']['cuisines']):
                    is_cuisine_matched = True
                    break
            if not is_cuisine_matched:
                return False
        return outlet

    def process_outlets(self):
        for outlet in self.outlets:
            outlet = dict((zip(outlet._fields, outlet)))
            if not self.update_outlet(outlet):
                continue
            outlet['product_id'] = self.outlet_offer_info[outlet['id']]['product_id']
            outlet['product_sku'] = self.outlet_offer_info[outlet['id']]['product_sku']
            outlet['top_offer_redeemability'] = self.outlet_offer_info[outlet['id']]['redeemability']
            outlet['top_offer_type'] = self.outlet_offer_info[outlet['id']]['type']
            outlet['is_redeemable'] = self.outlet_offer_info[outlet['id']]['is_redeemable']
            outlet['is_purchased'] = self.outlet_offer_info[outlet['id']]['is_purchased']
            outlet['is_monthly'] = self.outlet_offer_info[outlet['id']]['is_monthly']
            outlet['is_new'] = self.outlet_offer_info[outlet['id']]['is_new']
            outlet['is_cheers'] = self.outlet_offer_info[outlet['id']]['is_cheers']
            outlet['is_delivery'] = self.outlet_offer_info[outlet['id']]['is_delivery']
            outlet['is_more_sa'] = self.outlet_offer_info[outlet['id']]['is_more_sa']
            outlet['is_point_based_offer'] = self.outlet_offer_info[outlet['id']]['is_point_based_offer']
            outlet['locked_image_url'] = ""
            outlet['categories'] = self.outlet_offer_info[outlet['id']]['categories']
            outlet['sub_categories'] = self.outlet_offer_info[outlet['id']]['sub_categories']

            if outlet['categories']:
                outlet['categories'] = sort_categories(outlet['categories'])

            outlet['merchant_categories'] = outlet['categories']
            outlet['merchant_categories_analytics'] = get_category_codes_for_analytics(
                outlet['merchant_categories'])

            outlet['merchant']['categories'] = outlet['merchant_categories']
            outlet['merchant']['categories_analytics'] = outlet['merchant_categories_analytics']

            if self.outlet_offer_info[outlet['id']]['sub_categories']:
                outlet['merchant']['digital_section'] = ", ".join(
                    self.outlet_offer_info[outlet['id']]['sub_categories'])
            else:
                outlet['merchant']['digital_section'] = ""
            if (
                self.category and
                self.category in VALID_CATEGORIES
            ):
                outlet['merchant']['category'] = self.category
            elif outlet['categories']:
                outlet['merchant']['category'] = outlet['categories'][0]
            else:
                outlet['merchant']['category'] = ""

            if self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                if outlet['merchant']['category'] == CATEGORY_API_NAME_RETAIL:
                    outlet['merchant']['category'] = CATEGORY_API_NAME_SERVICES
                company_skus = get_configured_sku_by_company(self.company)
                outlet['is_company_specific'] = self.is_company_specific
                if not outlet['is_company_specific']:
                    for skus in outlet['product_sku']:
                        if skus in company_skus:
                            outlet['is_company_specific'] = True
                            break
            set_images_and_attributes(
                self.company,
                outlet,
                self.categories,
                self.category
            )
            if not self._is_fuzzy_search_on:
                if self.query and self.query_type == 'name':
                    if (
                            not is_search_string_found(outlet['merchant_name'], self.query, True) and
                            outlet['id'] not in self.query_matched_offers_outlets
                    ):
                        continue

            if self.featured_merchants:
                for featured_merchant in self.featured_merchants:

                    if featured_merchant['id'] == outlet['merchant']['id']:

                        featured_merchant['is_featured'] = True
                        featured_merchant['category'] = self.category
                        featured_merchant['categories'] = [self.category]

                        if not featured_merchant['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet.get('is_redeemable')

                        if not featured_merchant['is_purchased']:
                            featured_merchant['is_purchased'] = outlet.get('is_purchased')

                        if not featured_merchant['is_monthly']:
                            featured_merchant['is_monthly'] = outlet.get('is_monthly')

                        if not featured_merchant['is_new']:
                            featured_merchant['is_new'] = outlet.get('is_new')

                        if not featured_merchant['is_cheers']:
                            featured_merchant['is_cheers'] = outlet.get('is_cheers')

                        if not featured_merchant['is_delivery']:
                            featured_merchant['is_delivery'] = outlet.get('is_delivery')

                        if outlet['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet['is_redeemable']
                        if outlet['is_purchased']:
                            featured_merchant['is_purchased'] = outlet['is_purchased']
                        if outlet['is_monthly']:
                            featured_merchant['is_monthly'] = outlet['is_monthly']
                        if outlet['is_new']:
                            featured_merchant['is_new'] = outlet['is_new']
                        if outlet['is_cheers']:
                            featured_merchant['is_cheers'] = outlet['is_cheers']
                        if outlet['is_delivery']:
                            featured_merchant['is_delivery'] = outlet['is_delivery']

            if (
                self.offer_redeemability != REDEEMABILITY_NOT_REDEEMABLE and
                self.offer_redeemability.lower() != 'all'
            ):
                if (
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMABLE_REUSABLE and
                            not (outlet['top_offer_redeemability'] == OfferWlActive.REDEEMABLE or
                                 outlet['top_offer_redeemability'] == OfferWlActive.REUSABLE)
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REUSABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.REUSABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_NOT_REDEEMABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.NOT_REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMED and
                            outlet['top_offer_redeemability'] != OfferWlActive.REDEEMED
                        )
                ):
                    continue
            outlet['merchant_name'] = (outlet['merchant_name'] or '').lower()
            self.final_outlets.append(outlet)
            self.redeemabilities.append(outlet['top_offer_redeemability'])
            self.merchant_names.append((outlet['merchant_name'] or '').lower())
            self.distances.append(outlet['distance'])

    def convert_merchant_name_lower(self):
        """
        Convert merchant name into lower in final outlets
        :return:
        """
        for outlet in self.final_outlets:
            outlet.update({'merchant_name': outlet['merchant_name'].lower()})

    def process_fuzzy_search(self):
        """
        Process the fuzzy search
        """

        if self._is_fuzzy_search_on:
            self.__wildcard_outlets = []
            self.__fuzzy_search_outlets = []
            self.fuzzy_search_result = fuzzy_search_manager.get_fuzzy_results(
                self.query,
                self.category,
                self.sub_category_filter
            )
            if self.fuzzy_search_result.is_timeout_or_server_down:
                self._is_fuzzy_search_on = False
                self.is_fuzzy_server_down = True
            elif self.fuzzy_search_result.is_succeeded and self.fuzzy_search_result.total_unique_results_found:
                self._fuzzy_search_outlet_ids = self.fuzzy_search_result.outlet_ids
                self._fuzzy_search_outlet_id_score = self.fuzzy_search_result.outlet_id_score

            for __outlet in self.final_outlets:
                if __outlet['fuzzy_relevance'] == fuzzy_search_manager.score_for_wildcard_search:
                    self.__wildcard_outlets.append(__outlet)
                else:
                    self.__fuzzy_search_outlets.append(__outlet)
            self.__wildcard_outlets = sorted(self.__wildcard_outlets, key=itemgetter('distance'))
            self.__fuzzy_search_outlets = sorted(self.__fuzzy_search_outlets, key=itemgetter('fuzzy_relevance'))
            self.final_outlets = self.__wildcard_outlets + self.__fuzzy_search_outlets
        else:
            if self.sort == DEFAULT:
                if self.redeemability_first:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['-top_offer_redeemability', 'distance', 'merchant_name']
                    )
                else:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['distance', 'merchant_name', '-top_offer_redeemability']
                    )
            if self.sort == ALPHA:
                if self.redeemability_first:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['-top_offer_redeemability', 'merchant_name']
                    )
                else:
                    self.final_outlets = multi_key_sort(
                        self.final_outlets,
                        ['merchant_name', '-top_offer_redeemability']
                    )
        self.merchant_names = []
        # if int(self.offset) == 0:
        #     if self.query and len(self.query.strip()) > 0:
        #         neighborhoods = OfferWlActive.get_country_areas(
        #             self.location_id,
        #             self.locale,
        #             self.query,
        #             self.category,
        #             self.customer.get('product_ids')
        #         )
        #         for neighborhood in neighborhoods:
        #             self.search_results.append({
        #                 "type": NEIGHBORHOOD,
        #                 "name": neighborhood["name"],
        #                 "value": neighborhood["value"],
        #                 "icon": NEIGHBORHOOD_IMAGE
        #             })
        #     if self.category and self.category != ANALYTICS_CATEGORY_CODE_TRAVEL:
        #         if self.query and len(self.query.strip()) > 0:
        #             hotels = OfferWlActive.get_country_hotels(
        #                 self.customer[PRODUCT_IDS],
        #                 self.locale,
        #                 self.query
        #             )
        #             for hotel in hotels:
        #                 self.search_results.append({
        #                     "type": HOTEL,
        #                     "name": hotel["name"],
        #                     "value": hotel["value"],
        #                     "icon": HOTEL_IMAGE
        #                 })
        #         if self.query and len(self.query.strip()) > 0:
        #             mall_list = OfferWlActive.get_attribute_values(
        #                 'mall',
        #                 self.customer.get('product_ids'),
        #                 self.location_id,
        #                 self.locale,
        #                 self.query,
        #                 self.category
        #             )
        #             for mall in mall_list:
        #                 self.search_results.append({
        #                     "type": MALL,
        #                     "name": mall,
        #                     "value": mall,
        #                     "icon": MALL_IMAGE
        #                 })

    def prepare_final_response(self):
        self.outlet_response = {
            'is_fuzzy_search_results': self._is_fuzzy_search_on,
            'is_fuzzy_server_down': self.is_fuzzy_server_down,
            'limit': str(MAX_OUTLETS),
            'total_records': self.total_records,
            'tabs': self.tabs,
            'search_results': self.search_results,
            'featured_merchants': self.featured_merchants,
            'outlets': self.filtered_outlets
        }
        self.set_response({
            'success': True,
            'message': 'success',
            'data': self.outlet_response
        })

    def process_request(self, *args, **kwargs):
        self.check_limit()
        if self.send_response_flag:
            return
        self.initialize_local_variables()
        self.initialize_class_attributes()
        self.is_show_monthly_offers()
        self.load_customer_profile_and_session_data()
        self.get_tabs_info()
        self.skip_mode()
        if self.is_send_response_flag_on():
            return
        self.set_categories()
        self.is_fuzzy_search_on()
        self.get_offers_from_db()
        self.process_offers()
        self.prepare_final_response()
