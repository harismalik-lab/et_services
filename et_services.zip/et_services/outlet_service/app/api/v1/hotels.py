"""
hotels screen api
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BaseGetResource
from common.utils.api_utils import get_locale
from common.utils.authentication import get_company
from outlet_service.app.api.v1.validations.hotels_validator import hotels_api_parser
from outlet_service.common.models.offer_wl_active import OfferWlActive


class HotelsApi(BaseGetResource):
    """
    @api {get} /v1/hotels
    @apiSampleRequest /v1/hotels
    @apiVersion 1.0.0
    @apiName hotels
    @apiGroup hotels
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/hotels_api.log',
        ),
        'name': 'hotels_api'
    }
    request_parser = hotels_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('locale')
        self.category = self.request_args.get('category')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = get_locale(self.locale)
        self.company = get_company()

    def get_hotels(self):
        """
        Gets categories
        """
        hotels_attributes = OfferWlActive.get_outlet_attribute_values(
            company=self.company,
            attribute='hotel',
            location_id=self.location_id,
            locale=self.locale,
            category=self.category
        )
        self.hotels = []
        for hotel in hotels_attributes:
            if hotel.hotel:
                self.hotels.append(hotel.hotel)

    def generate_final_response(self):
        """
        Generates final response
        """
        data = {
            'hotels': self.hotels
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.setting_variables()
        self.get_hotels()
        self.generate_final_response()
