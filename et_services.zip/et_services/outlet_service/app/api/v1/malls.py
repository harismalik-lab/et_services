"""
Malls screen api
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BaseGetResource
from common.models.offer_wl_active import OfferWlActive
from common.utils.api_utils import get_locale
from common.utils.authentication import get_company
from outlet_service.app.api.v1.validations.malls_validator import malls_api_parser


class MallsApi(BaseGetResource):
    """
    @api {get} /v1/malls
    @apiSampleRequest /v1/malls
    @apiVersion 1.0.0
    @apiName Malls
    @apiGroup Malls
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {Integer}                                     [location_id]    User Location Id.
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/malls_api.log',
        ),
        'name': 'malls_api'
    }
    request_parser = malls_api_parser
    required_token = True

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('language')
        self.category = self.request_args.get('category')

    def setting_variables(self):
        """
        Sets variables for api
        """
        self.locale = get_locale(self.locale)
        self.company = get_company()

    def get_malls(self):
        """
        Gets categories
        """
        malls_attributes = OfferWlActive.get_outlet_attribute_values(
            company=self.company,
            attribute='mall',
            location_id=self.location_id,
            locale=self.locale,
            category=self.category
        )
        self.malls = []
        for mall in malls_attributes:
            if mall.mall:
                self.malls.append(mall.mall)

    def generate_final_response(self):
        """
        Generates final response
        """
        data = {
            'malls': self.malls
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.setting_variables()
        self.get_malls()
        self.generate_final_response()
