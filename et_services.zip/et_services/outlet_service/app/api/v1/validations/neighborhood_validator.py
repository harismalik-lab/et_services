"""
Validation params of neighborhood api
"""
from flask_restful import reqparse

from common.utils.custom_request_fields_parser import language
from outlet_service.common.constants import EN

neighborhood_api_parser = reqparse.RequestParser(bundle_errors=True)

neighborhood_api_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location='args'
)
neighborhood_api_parser.add_argument(
    name="language",
    required=False,
    default=EN,
    type=language,
    location='args'
)
neighborhood_api_parser.add_argument(
    'category',
    type=str,
    required=False,
    default='',
    location='args'
)
