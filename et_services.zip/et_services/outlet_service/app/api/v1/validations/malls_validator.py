"""
Validation params of malls api
"""
from flask_restful import reqparse

from outlet_service.common.constants import EN
from outlet_service.common.utils.custom_request_fields_parser import language

malls_api_parser = reqparse.RequestParser(bundle_errors=True)

malls_api_parser.add_argument(
    name="location_id",
    required=False,
    type=int,
    location='args'
)
malls_api_parser.add_argument(
    name="language",
    required=False,
    default=EN,
    type=language,
    location='args'
)
malls_api_parser.add_argument(
    'category',
    type=str,
    required=False,
    default='',
    location='args'
)
