"""
Outlets API Params validator
"""
from outlet_service.app.api.v3.validations.outlets_validator import outlet_validation_parser_v3

outlets_parser_v4 = outlet_validation_parser_v3.copy()
