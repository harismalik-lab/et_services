"""
OutletsAPI V4
"""
import ast
import datetime
import json
from copy import deepcopy
from urllib.parse import unquote

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.utils.authentication import get_company, get_current_customer
from flask import current_app
from outlet_service.app.api.v3.outlets import OutletsAPIV3
from outlet_service.app.api.v4.validations.outlets_validator import \
    outlets_parser_v4
from outlet_service.common.constants import (BEST_REVIEWED,
                                             CATEGORY_API_NAME_LEISURE,
                                             CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                                             CATEGORY_API_NAME_RETAIL,
                                             CATEGORY_API_NAME_SERVICES,
                                             CATEGORY_API_NAME_TRAVEL, DEFAULT,
                                             DUBAI_LOCATION_ID,
                                             ENT_COMPANY_TYPE,
                                             FEATURED_CATEGORY_TRAVEL,
                                             HOTEL_IMAGE, MALL_IMAGE,
                                             MOST_REVIEWED, NEAREST,
                                             NEIGHBORHOOD_IMAGE,
                                             RADIUS_CONVERSION_UNIT,
                                             REDEEMABILITY_REDEEMABLE_REUSABLE,
                                             RETAIL, TRAVEL_INQUIRE_FOR_RATES,
                                             TRAVEL_INSTANT_BOOKING,
                                             TRAVEL_INSTANT_BOOKING_FLAG,
                                             TYPE_MEMBER, VALID_CATEGORIES)
from outlet_service.common.models.api_configuration import ApiConfiguration
from outlet_service.common.models.dm_devices import DmDevice
from outlet_service.common.models.ent_customer_profile import \
    EntCustomerProfile
from outlet_service.common.models.exchange_rate import ExchangeRate
from outlet_service.common.models.home_screen_configurations import \
    HomeScreenConfiguration
from outlet_service.common.models.offer import Offer
from outlet_service.common.models.outlet import Outlet
from outlet_service.common.models.package import Package
from outlet_service.common.models.product import Product
from outlet_service.common.models.redemption import Redemption
from outlet_service.common.models.share_offer import ShareOffer
from outlet_service.common.models.top_up_offer import TopUpOffer
from outlet_service.common.models.wl_company import WlCompany
from outlet_service.common.models.wl_tabs import WlTab
from outlet_service.common.rest_urls import RedemptionServiceAPIUrlsV4
from outlet_service.common.utils.api_utils import (calculate_offer_redeemability_for_customer_details,
                                                   convert_timedelta_to_datetime,
                                                   count_offer_redemptions_by_customer_shared_offers,
                                                   fix_expiration_date,
                                                   format_company,
                                                   get_analytics_codes_against_categories,
                                                   get_birthday_offer_validity_in_days,
                                                   get_category_codes_for_analytics,
                                                   get_configured_sku_by_company,
                                                   get_current_time_of_location,
                                                   get_extended_trial_rules,
                                                   get_geo_point_from_lat_lng,
                                                   get_hotel_rating,
                                                   get_locale,
                                                   get_outlet_attr_status,
                                                   multi_key_sort)
from outlet_service.common.utils.authentication import token_decorator_v3
from outlet_service.common.utils.v_1.shared_util import SharedUtil
from outlet_service.modules.api_constants import (ATTRIBUTES_TO_DELETE_FOR_CASHLESS,
                                                  CALL_CENTRE, CATEGORY_ALL,
                                                  CLOCK_CASHLESS_IMAGE,
                                                  DEEP_LINK_BONUS_OFFERS,
                                                  DEEP_LINK_HOTEL_TYPE,
                                                  DEEP_LINK_MALL_TYPE,
                                                  DEEP_LINK_NEIGHBOUR_HOOD_TYPE,
                                                  DEEP_LINK_PRODUCT_TYPE,
                                                  DEEP_LINK_TABLE_RESERVATION,
                                                  DISABLE_FUZZY,
                                                  DISABLE_FUZZY_FOR_QUERIES,
                                                  EID_OFFER, EID_OFFERS,
                                                  HAPPY_BIRTHDAY_KEYWORD,
                                                  LAST_MILE_IMAGE_URL,
                                                  LAST_MILE_LIVE_TRACKING,
                                                  LAST_MILE_TITLE_COLOR,
                                                  MAP_ZOOM_LEVEL,
                                                  NON_INTEGRATED_ASSET,
                                                  PING_TIME_LIMIT_SECONDS,
                                                  PINGS_SECTION,
                                                  RAMADAN_KEYWORD,
                                                  RAMADAN_OFFER_ATTRIBUTES,
                                                  SELECTED_OFFER_TYPE_FOURTH,
                                                  SELECTED_OFFER_TYPE_FOURTH_AND_MONTHLY,
                                                  SELECTED_OFFER_TYPE_MONTHLY,
                                                  SELECTED_OFFER_TYPE_NEW)
from outlet_service.modules.api_utils import (find_distance,
                                              get_band_info_cached,
                                              get_outlet_fourth_offer_status,
                                              get_outlet_monthly_status,
                                              is_search_string_found,
                                              parse_list,
                                              pick_outlets_with_best_time_slot,
                                              set_images_and_attributes_dynamically,
                                              sort_categories)
from outlet_service.modules.fuzzy_search_manager import fuzzy_search_manager
from outlet_service.modules.v_1.cache_module import CacheModule
from outlet_service.modules.v_1.outlets_module import OutletsModule
from shapely import speedups
from shapely.geometry import Point, Polygon


class OutletsAPIV4(OutletsAPIV3):

    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/outlets_api_v4.log',
        ),
        'name': 'outlets_api_v4'
    }
    validators = [token_decorator_v3]
    request_parser = outlets_parser_v4

    def set_api_configurations(self):
        """
        Sets api configuration variables
        """
        self.enable_family_feature = self.api_configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE)
        self.enable_ping_feature = self.api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE)
        self.enable_delivery_cashless = self.api_configs.get(ApiConfiguration.ENABLE_DELIVERY_CASHLESS)
        self.enable_birthday_feature = self.api_configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE)
        self.enable_last_mile = self.api_configs.get(ApiConfiguration.ENABLE_LAST_MILE)
        self.enable_takeaways = self.api_configs.get(ApiConfiguration.ENABLE_TAKEAWAYS)
        self.enable_cheers = self.api_configs.get(ApiConfiguration.ENABLE_CHEERS)
        self.enable_new_offers = self.api_configs.get(ApiConfiguration.ENABLE_NEW_OFFERS)
        self.enable_monthly_offers = self.api_configs.get(ApiConfiguration.ENABLE_MONTHLY_OFFERS)
        self.enable_fourth_offers = self.api_configs.get(ApiConfiguration.ENABLE_FOURTH_OFFERS)
        self.enable_top_up_offers = self.api_configs.get(ApiConfiguration.ENABLE_TOP_UP_OFFERS)

        self.company_type = self.api_configs.get(ApiConfiguration.COMPANY_TYPE)
        self.is_ent = self.company_type == ENT_COMPANY_TYPE

    def populate_request_arguments(self):
        """
        Populates request parameters.
        """
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('language')
        self.offer_redeemability = self.request_args.get('redeemability').lower().strip()
        self.filter_by_type = self.request_args.get('filter_by_type')
        self.query = self.request_args.get('query')
        self.outlet_id = self.request_args.get('outlet_id')
        self.offset = self.request_args.get('offset')
        self.is_more_sa = self.request_args.get('is_more_sa')
        self.is_cuckoo = self.request_args.get('is_cuckoo')
        self.is_cheers = self.request_args.get('is_cheers')
        self.lat = self.request_args.get('lat')
        self.lng = self.request_args.get('lng')
        self.radius = self.request_args.get('radius')
        self.cuisine = self.request_args.get('cuisine')
        self.user_include_cheers = self.request_args.get('user_include_cheers')
        self.is_delivery = self.request_args.get('is_delivery')
        self.category = self.request_args.get('category')
        self.query_type = self.request_args.get('query_type')
        self.neighborhood = self.request_args.get('neighborhood')
        self.mall = self.request_args.get('mall')
        self.hotel = self.request_args.get('hotel')
        self.sub_category_filter = self.request_args.get('sub_category_filter')
        self.cuisine_filter = self.request_args.get('cuisine_filter') or self.request_args.get('cuisine_filter[]')
        self.filters_selected_for_yes = (
            self.request_args.get('filters_selected_for_yes') or
            self.request_args.get('filters_selected_for_yes[]')
        )
        self.filters_selected_for_no = (
            self.request_args.get('filters_selected_for_no') or
            self.request_args.get('filters_selected_for_no[]')
        )
        self.billing_country = self.request_args.get('billing_country')
        self.billing_city = self.request_args.get('billing_city')
        self.search_by_dest_type = self.request_args.get('search_by_dest_type')
        self.fuzzy = self.request_args.get('fuzzy')
        self.redeemability_first = self.request_args.get('first_sort_by_redeemability')
        self.is_company_specific = self.request_args.get('is_company_specific')
        self.show_monthly_offers = self.request_args.get('show_monthly_offers')
        self.show_new_offers = self.request_args.get('show_new_offers')
        self.app_version = self.request_args.get('app_version')
        self.show_only_core_product_offers = self.request_args.get('show_only_core_product_offers')
        self.product_sku = self.request_args.get('product_sku')
        self.sort = self.request_args.get('sort')
        self.is_company_specific = self.request_args.get('is_company_specific')
        self.limit = self.request_args.get('limit')
        self.tab_id = self.request_args.get('tid')
        self.is_birthday = self.request_args.get('is_birthday')
        self.platform = self.request_args.get('__platform')

        self.isshared = self.request_args.get('isshared')
        self.elastic_search_status = self.request_args.get('__es')
        self.cuisines_selected = self.request_args.get('cuisines[]') or self.request_args.get('cuisines')
        self.cuisine_filter = self.cuisine_filter or self.cuisines_selected

        self.sub_categories_selected = self.request_args.get('sub_categories')
        self.merchant_attributes_selected = self.request_args.get('merchant_attributes')
        self.offer_attributes_selected = self.request_args.get('offer_attributes')
        self.offer_types_selected = self.request_args.get('offer_types')

        if isinstance(self.offer_types_selected, list):
            self.offer_types_selected = filter(None, self.offer_types_selected)

        self.show_offers_of_type_selected = self.request_args.get('show_offers_of_type')

        self.cashless_delivery_enabled = self.request_args.get('cashless_delivery_enabled', False)
        if self.cashless_delivery_enabled:
            self.locale = 'en'
        self.is_hot_summer_nights = self.request_args.get('is_hot_summer_nights')
        self.deep_link_search_type = self.request_args.get('search_type', '')
        self.deep_link_keyword = self.request_args.get('keyword', '')
        self.deep_link_search_sub_category = self.request_args.get('search_sub_category', '')
        self.specific_outlet_ids_encoded = self.request_args.get('o_ids')
        self.merchant_ids_encode = self.request_args.get('m_ids')
        self.filter_search = self.request_args.get('filter_search')
        self.price_range_encoded = self.request_args.get('price_range')
        self.distance_latitude = self.request_args.get('d_lat')
        self.distance_longitude = self.request_args.get('d_lng')
        self.distance_radius = self.request_args.get('d_radius')
        self.show_monthly_product_offers_selected = (
            self.request_args.get('show_monthly_product_offers') or
            self.request_args.get('show_monthly_product_offers[]')
        )
        self.last_mile_enabled = self.request_args.get('is_last_mile_enabled')

        self.takeaways_enabled = self.request_args.get('is_take_away')
        self.show_instant_booking_hotels = self.request_args.get('show_instant_booking_hotels')
        self.is_travel = self.request_args.get('is_travel')
        self.currency = self.request_args.get('currency')
        self.limit = self.request_args.get('limit', 10)

    def process_request_params(self):
        """
        Processes request parameters.
        """

        if self.monthly_offers_enabled and self.show_monthly_product_offers_selected:
            self.show_offers_of_type_selected = self.show_monthly_product_offers_selected
            self.filter_monthly_offers_product_wise = True

        elif self.show_offers_of_type_selected:
            self.filter_monthly_offers_product_wise = False

        else:
            self.show_offers_of_type_selected = self.show_monthly_product_offers_selected
            self.filter_monthly_offers_product_wise = True

        if self.deep_link_search_type.lower() == DEEP_LINK_PRODUCT_TYPE:
            self.product_filter_enabled = True
            if self.deep_link_search_sub_category == DEEP_LINK_BONUS_OFFERS:
                self.filter_bonus_products = True

        self.offer_types_selected = self.outlets_module.validate_offer_types(self.offer_types_selected)

        self.sub_categories_selected = self.outlets_module.validate_subcategories(self.sub_categories_selected)

        self.show_new_offers = (
            self.new_offers_enabled and
            SELECTED_OFFER_TYPE_NEW in self.show_offers_of_type_selected
        )

        self.show_monthly_offers = (
            self.monthly_offers_enabled and
            SELECTED_OFFER_TYPE_MONTHLY in self.show_offers_of_type_selected
        )

        self.show_fourth_offers = (
            self.fourth_offers_enabled and
            SELECTED_OFFER_TYPE_FOURTH in self.show_offers_of_type_selected
        )

        self.show_fourth_and_monthly_offers = (
            self.fourth_offers_enabled and
            self.monthly_offers_enabled and
            SELECTED_OFFER_TYPE_FOURTH_AND_MONTHLY in self.show_offers_of_type_selected
        )

    def initialize_local_variables(self):
        """
        Initializes local variable used per request.
        """
        self.customer = get_current_customer()
        self.company = format_company(get_company())
        self.api_configs = self.customer.get('api_configs')
        self.redemption_api_urls = RedemptionServiceAPIUrlsV4

    def initialize_modules(self):
        """
        Initializes helper modules to be used in request.
        """
        self.outlets_module = OutletsModule()
        self.cache_module = CacheModule()
        self.util_module = SharedUtil()

    def initialize_class_attributes(self):
        """
        Initializes class attributes.
        """
        self.is_source_es = True
        self.lat_lng_exists = False
        self.disable_fuzzy = False
        self.is_fuzzy_server_down = False
        self.is_load_featured_merchants = False
        self.shared_offers_received = False
        self.redemptions_quantities_present = False
        self.offer_redeemability_check = False
        self.is_fuzzy_server_down = False
        self._is_fuzzy_search_on = False
        self.is_active_family_member = False
        self.own_cheer_products = False
        self.include_cheer_offers = False
        self.filter_bonus_products = False
        self.product_filter_enabled = False
        self.show_new_offers = False
        self.show_monthly_offers = False
        self.show_fourth_and_monthly_offers = False
        self.show_fourth_offers = False
        self.show_monthly_offers = (
            int(self.filter_by_type) == Offer.TYPE_MEMBER and
            self.offer_redeemability == Redemption.REDEEMABILITY_REUSABLE
        )

        if not self.is_travel:
            self.limit = self.outlets_module.MAX_OUTLETS

        self.elastic_search_is_on = current_app.config["ELASTIC_SEARCH_IS_ON"]
        self.__fuzzy_host = current_app.config['ELASTIC_SEARCH_URL']

        self.top_up_offers = []
        self._fuzzy_search_outlet_ids = []
        self._fuzzy_search_outlet_id_score = []
        self.featured_category = ""
        self.featured_merchants = []
        self.search_results = []
        self.final_outlets = []
        self.shared_offers_receive = []
        self.shared_offers_sent = []
        self.merchants_ids = []
        self.filtered_outlets = []
        self.featured_merchant_ids = []
        self.redeemabilities = []
        self.merchant_names = []
        self.distances = []
        self.shared_offers_receive_personal = []
        self.merchant_ids = []
        self.specific_outlet_ids = []
        self.price_ranges = []
        self.offers = []
        self.outlet_ids = []
        self.outlets = []
        self.merchant_attributes_selected = []
        self.merchants_ids_cashless = []
        self.pings_offers_received_ids = []
        self.redemption_quantities = []
        self.ping_section = {}
        self.promote_user_to_buy_product = {}

        self.locale = get_locale(self.locale)
        self.message_locale = get_locale(self.request_args.get('language'))

    def set_up_api_features(self):
        """
        Enables/disables the feature flags based on api configurations.

        A feature is enabled only when it's enabled for that specific company AND comes in the request
        arguments.
        """
        self.last_mile_enabled = self.last_mile_enabled and self.enable_last_mile
        self.cashless_delivery_enabled = self.cashless_delivery_enabled and self.enable_delivery_cashless
        self.takeaways_enabled = self.takeaways_enabled and self.enable_takeaways
        self.ping_enabled = self.isshared and self.enable_ping_feature
        self.cheers_enabled = self.enable_cheers

        self.new_offers_enabled = self.enable_new_offers
        self.monthly_offers_enabled = self.enable_monthly_offers
        self.fourth_offers_enabled = self.enable_fourth_offers
        self.top_up_offers_enabled = self.enable_top_up_offers

        self.family_enabled = self.enable_family_feature
        self.birthday_feature_enabled = self.enable_birthday_feature

    def set_fuzzy_search_status(self):
        """
        Sets fuzzy search status.
        """
        if self.elastic_search_status > 0:
            self._is_fuzzy_search_on = True

        elif not self.elastic_search_status:
            self._is_fuzzy_search_on = False

        else:
            self._is_fuzzy_search_on = (
                current_app.config.get('ELASTIC_SEARCH_IS_ON', False) and
                not self.disable_fuzzy
            )

        # Patch to disable fuzzy search on certain key words, as per marketing request.
        if self.query.lower() in EID_OFFERS:
            self.query = EID_OFFER

        if self.query and self.query.lower() in DISABLE_FUZZY_FOR_QUERIES:
            self.is_fuzzy_search_on = False

        if self.merchant_ids:
            self.is_fuzzy_search_on = False

        if self.price_ranges:
            self.is_fuzzy_search_on = False

        if self.specific_outlet_ids:
            self.is_fuzzy_search_on = False

    def set_customer_related_data(self):
        """
        Set customer related information in instance.
        """

        self.customer_id = self.customer.get('customer_id', 0) or self.customer.get('user_id', 0)
        self.member_group = 0
        self.birth_date = False
        self.is_customer_member = False
        self.is_active_family_member = False
        self.primary_user_id = None
        self.is_customer_own_cheers_for_location = False

        self.is_customer_logged_in = self.customer['is_user_logged_in']

        if self.is_customer_logged_in:
            self.member_group = self.customer.get('new_member_group')
            self.is_customer_member = self.member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER
            self.customer_product_ids = self.customer.get('product_ids') or []
            self.is_customer_using_trial = bool(self.customer.get('is_using_trial'))
            self.is_customer_using_extended_trial = bool(self.customer.get('is_using_extended_trial'))

            if self.birthday_feature_enabled:
                self.add_birthday_product_ids()

            if not self.is_ent:
                if self.cashless_delivery_enabled:
                    self.offer_redeemability = Redemption.REDEEMABILITY_ALL

            if self.family_enabled:
                self.is_active_family_member = self.customer['family_is_active'] and self.customer['is_user_in_family']
                if self.is_active_family_member:
                    if self.customer['is_primary']:
                        self.primary_user_id = self.customer_id
                    else:
                        self.primary_user_id = self.customer['primary_member_info'].user_id

            if self.cheers_enabled:
                if self.is_active_family_member:
                    self.include_cheer_offers = self.customer['family_member_info'].is_cheers_to_include

                self.own_cheer_products = self.customer['owns_cheer_products']

                if self.is_customer_member and self.category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
                    self.is_customer_own_cheers_for_location = (
                        self.outlets_module.get_customer_cheer_products_for_location(
                            product_ids=self.customer_product_ids,
                            location_id=self.location_id,
                            company=self.company,
                            is_ent=self.is_ent
                        )
                    )

    def get_tabs_info(self):
        """
        Gets tabs info against passed tab id and company.
        """
        self.tab = None
        if not self.is_ent:
            self.tab = WlTab.get_by_id_and_company(self.tab_id, self.company)
            if self.tab:
                if self.tab.is_sku_specific and self.tab.sku_list:
                    self.product_sku = self.tab.sku_list

    def add_birthday_product_ids(self):
        """
        Add birthday products to customer's products.
        Logic:
        If birthday feature is enabled, then show birthday offers for 8 days before and 21 days after his birthday.
        """
        if self.enable_birthday_feature:
            if self.is_customer_logged_in:
                self.birth_date = self.customer.get('birth_date')
                if (self.is_customer_member or self.is_active_family_member) and self.birth_date:
                    number_of_birthday_validity_days = get_birthday_offer_validity_in_days(self.birth_date)
                    if number_of_birthday_validity_days > -1:
                        birthday_product_ids = Product.get_birthday_products(
                            location_id=self.location_id,
                            company=self.company,
                            column_to_get='id'
                        )
                        self.customer['product_ids'] += birthday_product_ids

    def get_top_up_offers(self):
        """
        Gets top offers for a customer.
        """
        self.top_up_offers = []
        if self.top_up_offers_enabled and self.self.is_customer_logged_in:
            self.top_up_offers = TopUpOffer.get_top_up_offers(
                self.customer_id,
                self.location_id,
                merchant_id=0,
                offer_type=TopUpOffer.TYPE_VIRTUAL_CURRENCY,
                primary_user_id=self.primary_user_id
            )

    def set_ping_section(self):
        """
        Set up ping section in response if ping feature is enabled.
        """
        if self.ping_enabled:
            self.ping_section = deepcopy(PINGS_SECTION)
            if self.isshared and self.is_customer_logged_in:
                ping_data = self.outlets_module.get_ping_section_data_for_user(
                    is_member=self.is_customer_member,
                    is_family_member=self.is_active_family_member,
                    customer_id=self.customer_id,
                    locale=self.locale
                )
                self.ping_section['is_recipient_info'] = True
                self.ping_section['can_user_receive_ping'] = ping_data['can_user_receive_ping']
                self.ping_section['total_quota_to_receive_pings'] = ping_data['total_quota_to_receive_pings']
                self.ping_section['total_pings_received'] = ping_data['total_pings_received']
                self.ping_section['message'] = ping_data['message']
                self.ping_section['background_color'] = ping_data['color_code']

    def get_skip_mode_response(self):
        """
        Skips offers that require customer's details.

        Sets up response in case the user isn't logged in and not outlet id is sent.
        """

        if not self.is_customer_logged_in and not self.outlet_id:
            if self.is_cheers or self.is_delivery or self.isshared or self.is_more_sa:
                self.set_response(
                    response={
                        'data': {
                            'ping_section': self.ping_section,
                            'is_elastic_search_results': self.is_fuzzy_search_on,
                            'is_elastic_search_server_down': self.is_fuzzy_server_down,
                            'search_results': [],
                            'featured_merchants': [],
                            'outlets': [],
                        },
                        'success': True,
                        'message': 'success'
                    },
                    code=0
                )

            # IN SKIP MODE, don't show cheers, monthly, shared, more_sa and delivery offers.
            elif (
                    self.offer_redeemability == Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE or
                    (
                        self.offer_redeemability == Redemption.REDEEMABILITY_ALL and
                        not self.neighborhood and
                        not self.mall and
                        not self.hotel
                    )
            ) and not self.is_travel and not self.query:
                # IN SKIP MODE, show promotional section under Your Offers tab.
                self.promote_user_to_buy_product = self.outlets_module.get_promotional_section_for_category(
                    category=self.category,
                    locale=self.message_locale
                )
                self.set_response(
                    response={
                        'data': {
                            'is_elastic_search_results': self.is_fuzzy_search_on,
                            'is_elastic_search_server_down': self.is_fuzzy_server_down,
                            'ping_section': self.ping_section,
                            'search_results': [],
                            'featured_merchants': [],
                            'outlets': [],
                            'promote_user_to_buy_product': self.promote_user_to_buy_product
                        },
                        'success': True,
                        'message': 'success'
                    },
                    code=0
                )

    def set_shared_offers(self):
        """
        Set shared_offers_receive, shared_offers_sent, shared_offers_received
        """
        if self.ping_enabled and self.is_customer_logged_in:
            if self.primary_user_id:
                self.shared_offers_receive = ShareOffer.get_accepted_received_offers(
                    recipient_id=self.customer_id,
                    primary_user_id=self.primary_user_id
                )

            if self.primary_user_id != self.customer_id:
                self.shared_offers_receive_personal = ShareOffer.get_accepted_received_offers(self.customer_id)

            self.shared_offers_sent = ShareOffer.get_sent_offers(
                self.primary_user_id or self.customer_id
            )
            self.shared_offers_received = bool(
                len(self.shared_offers_receive) or len(self.shared_offers_receive_personal)
            )
            self.pings_offers_received_ids = [offer.offer_id for offer in self.shared_offers_receive]
            self.pings_offers_received_ids.extend([offer.offer_id for offer in self.shared_offers_receive_personal])

            self.pings_offers_received_ids = list(set(self.pings_offers_received_ids))
            self.shared_offers_sent_ids = list(set([offer.offer_id for offer in self.shared_offers_sent]))

    def initialize_offers_criteria(self):
        """
        Set offers data to find offers.
        """
        self.offers_criteria = {
            'locale': self.locale,
            'is_customer_logged_in': self.is_customer_logged_in,
            'is_using_trial': self.is_customer_using_trial,
            'is_using_extended_trial': self.is_customer_using_extended_trial,
            'customer_product_ids': self.customer_product_ids,
            'is_ent': self.is_ent,
            'company': self.company,
            'product_sku': self.product_sku,
            'offer_redeemability': self.offer_redeemability,
            'is_cheers': self.is_cheers,
            'is_delivery': self.is_delivery,
            'show_monthly_offers': self.show_monthly_offers,
            'show_new_offers': self.show_new_offers,
            'is_more_sa': self.is_more_sa,
            'category': self.category,
            'is_fuzzy_search_on': self.is_fuzzy_search_on,
            'fuzzy_search_outlet_ids': self._fuzzy_search_outlet_ids,
            'sub_category_filter': self.sub_category_filter,
            'outlet_id': self.outlet_id,
            'location_id': self.location_id,
            'offer_valid_from_start_date': self.offer_valid_from_start_date,
            'offer_valid_from_cut_off_date': self.offer_valid_from_cut_off_date,
            'shared_offers_receive': self.shared_offers_receive,
            'is_birthday': self.is_birthday and self.birthday_feature_enabled,
            'category_lower_case': self.category_lower_case,
            'filter_by_type': self.filter_by_type,
            'received_offer_ids': self.pings_offers_received_ids,
            'offer_types_selected': self.offer_types_selected,
            'sub_categories_selected': self.sub_categories_selected,
            'offer_attributes_selected': self.offer_attributes_selected,
            'is_hot_summer_nights': self.is_hot_summer_nights,
            'show_monthly_offers_product_wise': self.filter_monthly_offers_product_wise,
            'ping_enabled': self.ping_enabled,
            'cashless_delivery_enabled': self.cashless_delivery_enabled,
            'takeaways_enabled': self.takeaways_enabled,
            'cheers_enabled': self.cheers_enabled,
            'is_travel': self.is_travel
        }

        if self.query.lower() == RAMADAN_KEYWORD:
            self.offers_criteria['query_string'] = RAMADAN_OFFER_ATTRIBUTES

        self.offers_criteria['deep_link_search_type'] = self.deep_link_search_type
        self.offers_criteria['deep_link_keyword'] = self.deep_link_keyword
        self.offers_criteria['deep_link_search_sub_category'] = self.deep_link_search_sub_category

        self.deep_link_search_type_lower_case = self.deep_link_search_type.lower()

        if self.deep_link_keyword.lower() != 'all' and self.deep_link_search_type_lower_case in (
            DEEP_LINK_NEIGHBOUR_HOOD_TYPE,
            DEEP_LINK_HOTEL_TYPE,
            DEEP_LINK_MALL_TYPE
        ):
            if self.deep_link_search_sub_category:
                self.category = self.deep_link_search_sub_category
            self.offers_criteria['category'] = self.category

            if self.deep_link_search_type_lower_case == DEEP_LINK_MALL_TYPE:
                self.mall = self.deep_link_keyword

            elif self.deep_link_search_type_lower_case == DEEP_LINK_HOTEL_TYPE:
                self.hotel = self.deep_link_keyword

            elif self.deep_link_search_type_lower_case == DEEP_LINK_NEIGHBOUR_HOOD_TYPE:
                self.neighborhood = self.deep_link_keyword

    def get_offers_from_db(self):
        """
        Get offers from db.
        """

        self.load_search_results = False
        location_has_products = self.location_id in self.outlets_module.get_product_locations(
            product_ids=self.customer_product_ids,
            is_ent=self.is_ent,
            company=self.company
        )
        if self.cashless_delivery_enabled and self.is_customer_logged_in:
            self.offers = self.outlets_module.find_offers(**self.offers_criteria)

        elif self.outlet_id:
            self.offers = self.outlets_module.find_offers(**self.offers_criteria)

        elif (
            self.is_customer_using_trial and
            self.category == CATEGORY_API_NAME_LEISURE and
            (self.neighborhood or self.mall or self.hotel)
        ):
            self.offers = self.outlets_module.find_offers(**self.offers_criteria)

        elif (
            self.is_customer_using_trial and
            self.category == CATEGORY_API_NAME_LEISURE and
            self.offer_redeemability != Redemption.REDEEMABILITY_NOT_REDEEMABLE and
            not self.query and
            not self.neighborhood and
            not self.mall and
            not self.hotel
        ):
            self.offers = []

        elif (
            self.is_customer_using_trial and
            self.category not in (CATEGORY_API_NAME_TRAVEL, CATEGORY_API_NAME_LEISURE) and
            self.offer_redeemability != Redemption.REDEEMABILITY_NOT_REDEEMABLE
        ):
            self.offers = self.outlets_module.find_offers(**self.offers_criteria)

        elif (
            self.is_customer_logged_in and
            not self.is_customer_member and
            not self.is_active_family_member and
            self.offer_redeemability == Redemption.REDEEMABILITY_ALL and
            self.category != CATEGORY_API_NAME_TRAVEL and
            not self.is_delivery and
            not self.is_cheers and
            not self.isshared and
            not self.is_more_sa and
            not self.query and
            not self.deep_link_search_type_lower_case and
            not self.filter_search
        ):
            self.offers = []

        elif self.deep_link_keyword.lower() == 'all':

            self.offers = []
            self.load_search_results = True

            if self.deep_link_search_type.lower() == DEEP_LINK_MALL_TYPE:
                self.load_malls_only = True
                self.mall_category = ''
                self.mall_keyword = ''

            elif self.deep_link_search_type.lower() == DEEP_LINK_HOTEL_TYPE:
                self.load_hotels_only = True
                self.hotel_category = ''
                self.hotel_keyword = ''

            elif self.deep_link_search_type.lower() == DEEP_LINK_NEIGHBOUR_HOOD_TYPE:
                self.load_neighbourhood_only = True
                self.neighbourhood_category = ''
                self.neighbourhood_keyword = ''

        elif (
            self.is_customer_logged_in and
            self.is_customer_member and
            self.offer_redeemability == Redemption.REDEEMABILITY_ALL and
            not self.filter_search and
            self.category != CATEGORY_API_NAME_TRAVEL and
            not self.is_delivery and
            not self.is_cheers and
            not self.isshared and
            not self.is_more_sa and
            not self.query and
            not self.deep_link_search_type_lower_case and
            not location_has_products
        ):
            self.offers = []

        else:
            self.offers = self.outlets_module.find_offers(**self.offers_criteria)

    def get_featured_merchants_from_db(self):
        """
        Get merchant based on featured category.
        """

        self.featured_merchants = self.outlets_module.get_featured_merchants_with_params(
            location_id=self.location_id,
            category=self.category,
            featured_category=self.featured_category,
            company=self.company,
            billing_country=self.billing_country,
            locale=self.locale,
            is_cheers=self.is_cheers,
            is_customer_own_cheers_for_location=self.is_customer_own_cheers_for_location
        )

    def load_featured_merchants(self):
        """
        Loads featured merchants in the case offers are present.
        """
        if self.is_load_featured_merchants and self.offers:
            self.get_featured_merchants_from_db()

    def set_query_type_is_name(self):
        """
        Set query_type_is_name on when query_type is name.
        """
        self.query_type_is_name = False
        if self.query:
            self.query_type_is_name = True

    def set_offer_related_defaults(self):
        """
        Set offer-related defaults.
        """
        self.outlet_offer_info = {}
        self.query_matched_offers_outlets = []
        self.shared_offer_ids = []
        self.offer_ids_for_customer_redemptions = []
        self.shared_redemptions_count_records = {}
        self.personal_shared_redemptions_count_records = {}
        self.customer_redemptions_records = {}
        self.product_offers = []

    def get_outlets_from_db(self):
        """
        Fetches outlets from db
        """
        self.outlets = Outlet.find_by_criteria_merchant_attributes_v3(**self.merchant_criteria)

    def update_outlets(self):
        """
        Set up outlet criteria to get outlets from DB.
        """
        self.outlet_ids = list(set(filter(None, self.outlet_ids)))
        self.merchant_criteria = {
            'company': self.company,
            'cashless_delivery': self.cashless_delivery_enabled,
            'is_last_mile_enabled': self.last_mile_enabled,
            'takeaways_enabled': self.takeaways_enabled,
            'lat': self.lat,
            'lng': self.lng,
            'radius': self.radius,
            'category': self.category,
            'cuisine': None,
            'cuisines': self.cuisines_selected,
            'sort': self.sort,
            'query': self.query,
            'query_type': self.query_type,
            'neighborhood': self.neighborhood,
            'mall': self.mall,
            'hotel': self.hotel,
            'billing_country': self.billing_country,
            'billing_city': self.billing_city,
            'search_by_dest_type': self.search_by_dest_type,
            'merchant_attributes': self.merchant_attributes_selected,
            'fuzzy_search_outlet_id_score': self._fuzzy_search_outlet_id_score,
            'outlet_ids': self.outlet_ids,
            'sub_category_filter': self.sub_category_filter,
            'filters_selected_for_yes': [],
            'filters_selected_for_no': [],
            'is_elastic_search_on': self.is_fuzzy_search_on,
            'is_monthly': self.show_monthly_offers,
            'table_reservation_enabled': False,
            'location_id': self.location_id,
            'locale': self.locale,
            'price_ranges': None,
            'merchant_ids': None,
            'show_instant_booking_hotels': self.show_instant_booking_hotels,
            'offer_attributes_selected': self.offer_attributes_selected,
            'is_travel': self.is_travel
        }
        if self.cashless_delivery_enabled:
            self.merchant_criteria.update({
                'price_ranges': self.price_ranges,
                'merchant_ids': self.merchant_ids
            })
        if self.specific_outlet_ids:
            self.merchant_criteria['outlet_ids'] = self.specific_outlet_ids
        if self.deep_link_search_sub_category.lower() == DEEP_LINK_TABLE_RESERVATION:
            self.merchant_criteria['table_reservation_enabled'] = True

        # TODO: Get outlets from ElasticSearch when ready.

        self.get_outlets_from_cache()
        if not self.outlets:
            self.get_outlets_from_db()
            self.set_outlets_in_cache()

        self.redeemabilities = []
        self.distances = []
        self.merchant_names = []
        self.final_outlets = []
        self.outlet_ids = []
        self.offers = []

    def get_outlets_from_cache(self):
        """
        Create outlets cache key and look up if outlets have been cached.

        Currently caching for TRAVEL category.
        """
        if self.is_travel and not self.specific_outlet_ids:
            otl_ids = ''
            hww_cache = self.cache_module.get_context_cache()
            billing_area = self.billing_city if self.search_by_dest_type == "city" else self.billing_country
            attrs = "-".join(sorted(filter(None, (self.sub_categories_selected + self.offer_attributes_selected))))
            if self.specific_outlet_ids:
                otl_ids = "-".join(sorted(self.specific_outlet_ids))
            self.outlets_cache_key = self.cache_module.get_cache_key(
                cache_type='outlets',
                search_type=self.search_by_dest_type,
                billing_area=billing_area,
                category=self.category,
                attributes=attrs,
                text=otl_ids
            )
            if hww_cache.get(self.outlets_cache_key):
                self.outlets = hww_cache.get(self.outlets_cache_key)

    def set_outlets_in_cache(self):
        """
        Cache the outlets that we get from DB to improve performance.

        Currently only caching for TRAVEL category.
        """
        if self.outlets:
            hww_cache = self.cache_module.get_context_cache()
            hww_cache.add(
                self.outlets_cache_key,
                self.outlets,
                timeout=current_app.config.get('HWW_CACHE_DEFAULT_TIMEOUT')
            )

    def get_offers_from_cache(self):
        """
        Get offers from cache if exists against cache key.
        """
        if self.is_travel:
            otl_ids = ''
            hww_cache = self.cache_module.get_context_cache()
            billing_area = self.billing_city if self.search_by_dest_type == "city" else self.billing_country
            attrs = "-".join(sorted(filter(None, (self.sub_categories_selected + self.offer_attributes_selected))))
            if self.specific_outlet_ids:
                otl_ids = "-".join(sorted(self.specific_outlet_ids))
            self.offers_cache_key = self.cache_module.get_cache_key(
                cache_type='offers',
                search_type=self.search_by_dest_type,
                billing_area=billing_area,
                category=self.category,
                attributes=attrs,
                text=otl_ids
            )
            if hww_cache.get(self.offers_cache_key):
                self.offers = hww_cache.get(self.offers_cache_key)

    def set_offers_in_cache(self):
        """
        Set offers in cache if does not exist in cache already.
        """
        if self.offers:
            hww_cache = self.cache_module.get_context_cache()
            hww_cache.add(
                self.offers_cache_key,
                self.offers,
                timeout=current_app.config.get('HWW_CACHE_DEFAULT_TIMEOUT')
            )

    def update_query_matched_offers_outlets(self, offer={}):
        """
        Update query_matched_offers_outlets based on fuzzy_search.
        """
        if not self.is_fuzzy_search_on and self.query_type_is_name:
            if self.query.lower() == RAMADAN_KEYWORD:
                search_attributes = RAMADAN_OFFER_ATTRIBUTES
                for attribute in search_attributes:
                    if is_search_string_found(offer.get('offer_name'), attribute, True):
                        try:
                            self.query_matched_offers_outlets += map(int, offer.get('outlet_ids').split(','))
                        except AttributeError:
                            self.query_matched_offers_outlets.append(int(offer.get('outlet_ids')))
            else:
                if is_search_string_found(offer.get('offer_name'), self.query, True):
                    try:
                        self.query_matched_offers_outlets += map(int, offer.get('outlet_ids').split(','))
                    except AttributeError:
                        self.query_matched_offers_outlets.append(int(offer.get('outlet_ids')))

    def update_offer_attributes(self):
        """
        Updates different offer-attributes.
        """
        self.rules = dict()
        for offer_index, offer in enumerate(self.offers):
            shared_count_receive = 0
            personal_shared_count_receive = 0
            shared_count_sent = 0
            top_up_count = 0

            # Adding time part as 12:00:00 (mid-day) and make sure not end of the day like 23:59:59.
            # Time difference is taken care of while calculating the redeemability of an offer.
            offer['expiration_date'] = fix_expiration_date(offer['expiration_date'])
            self.update_query_matched_offers_outlets(offer=offer)
            offer['isshared'] = False
            offer['top_up_offer'] = False

            if self.is_customer_logged_in:
                for shared_offer in self.shared_offers_receive:
                    if shared_offer.offer_id == offer['id']:
                        offer['isshared'] = True
                        shared_count_receive += 1

                for shared_offer in self.shared_offers_receive_personal:
                    if shared_offer.offer_id == offer['id']:
                        offer['isshared'] = True
                        personal_shared_count_receive += 1

                for shared_offer in self.shared_offers_sent:
                    if shared_offer.offer_id == offer['id']:
                        shared_count_sent += 1

                for top_up_offer in self.top_up_offers:
                    if top_up_offer.offer_id == offer['id']:
                        offer['top_up_offer'] = True
                        top_up_count += 1

            if not self.cashless_delivery_enabled and self.is_customer_logged_in:
                if (
                    not self.rules and
                    self.customer.get('is_member_on_trial') and
                    self.customer.get('is_using_extended_trial')
                ):
                    self.rules = get_extended_trial_rules(location_id=self.location_id)

                redeemability = calculate_offer_redeemability_for_customer_details(
                    offer,
                    offer['savings_estimate'],
                    self.category,
                    self.customer,
                    self.location_id,
                    shared_count_sent,
                    redemptions_quantities=self.redemptions_quantities,
                    shared_offer_receive=self.shared_offers_receive_personal,
                    shared_offers_received_family=self.shared_offers_receive,
                    shared_count_receive=shared_count_receive,
                    top_up_offer=offer['top_up_offer'],
                    top_up_count=top_up_count,
                    is_user_onboard=self.is_user_onboard,
                    offer_redeemability=self.offer_redeemability,
                    customer_redemptions_records=self.customer_redemptions_records,
                    shared_redemptions_count_records=self.shared_redemptions_count_records,
                    personal_shared_redemptions_count_records=self.personal_shared_redemptions_count_records,
                    member_group=self.member_group,
                    is_active_family_member=self.is_active_family_member,
                    personal_shared_count_receive=personal_shared_count_receive,
                    rules=self.rules
                )
                offer['is_redeemable'] = redeemability['redeemability'] in [Redemption.REDEEMABLE, Redemption.REUSABLE]
                offer['redeemability'] = redeemability['redeemability']
                offer['times_redeemed'] = redeemability['times_redeemed']
                offer['is_purchased'] = redeemability['is_purchased']
            else:
                offer['is_purchased'] = True
                offer['is_redeemable'] = True
                offer['times_redeemed'] = 0
                offer['redeemability'] = Redemption.REDEEMABLE
            try:
                outlet_ids = map(int, filter(None, offer.get('outlet_ids').split(',')))
            except AttributeError:
                outlet_ids = [offer['outlet_ids']]

            for outlet_id in outlet_ids:
                self.outlet_ids.append(outlet_id)
                if not self.outlet_offer_info.get(outlet_id):
                    self.outlet_offer_info[outlet_id] = {'offer_ids': [offer['id']]}
                    changes = {
                        'product_id': [offer['product_id']],
                        'product_sku': [offer['product_sku']],
                        'is_redeemable': offer['is_redeemable'],
                        'redeemability': offer['redeemability'],
                        'is_purchased': offer['is_purchased'],
                        'type': offer['type'],
                        'is_delivery_cashless_offer': offer.get('is_delivery_cashless_offer', False)
                    }
                    self.outlet_offer_info[outlet_id].update(changes)
                    # set different flags in outlet obj for outlets filtration
                    self.outlet_offer_info[outlet_id]['is_monthly'] = get_outlet_monthly_status(offer)
                    self.outlet_offer_info[outlet_id]['has_type_2_offers'] = get_outlet_attr_status(
                        offer=offer,
                        offer_level_attr_name='type',
                        outlet_level_attr_name='has_type_2_offers',
                        offer_level_attr_value=TYPE_MEMBER
                    )
                    self.outlet_offer_info[outlet_id]['has_fourth_offers'] = get_outlet_fourth_offer_status(
                        offer=offer
                    )
                    self.outlet_offer_info[outlet_id]['has_bonus_offers'] = get_outlet_attr_status(
                        offer=offer,
                        offer_level_attr_name='is_bonus_offers',
                        outlet_level_attr_name='has_bonus_offers',
                        offer_level_attr_value=True
                    )
                    self.outlet_offer_info[outlet_id].update({'is_new': False})
                    if (
                            offer['is_entertainer'] and
                            offer['type'] != TYPE_MEMBER and
                            offer['valid_from_date'] > self.offer_valid_from_start_date and
                            offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                    ):
                        self.outlet_offer_info[outlet_id].update({'is_new': True})

                    self.outlet_offer_info[outlet_id].update({
                        'is_cheers': bool(offer['is_cheers']),
                        'is_delivery': bool(offer['is_delivery']),
                        'is_shared': offer['isshared'],
                        'top_up_offer': offer['top_up_offer'],
                        'categories': [offer['merchant_category']],
                        'is_more_sa': bool(offer['is_more_sa']),
                        'is_birthday': False
                    })

                    if offer['product_type'] == Product.PRODUCT_TYPE_BIRTHDAY:
                        self.outlet_offer_info[outlet_id].update({'is_birthday': True})

                else:
                    if offer['id'] not in self.outlet_offer_info[outlet_id].get('offer_ids'):
                        self.outlet_offer_info[outlet_id]['offer_ids'].append(offer['id'])
                    if offer['product_id'] not in self.outlet_offer_info[outlet_id].get('product_id'):
                        self.outlet_offer_info[outlet_id]['product_id'].append(offer['product_id'])
                    if offer['product_sku'] not in self.outlet_offer_info[outlet_id].get('product_sku'):
                        self.outlet_offer_info[outlet_id]['product_sku'].append(offer['product_sku'])
                    if offer['is_redeemable']:
                        self.outlet_offer_info[outlet_id]['is_redeemable'] = True
                    if offer['redeemability'] > self.outlet_offer_info[outlet_id]['redeemability']:
                        self.outlet_offer_info[outlet_id]['redeemability'] = offer['redeemability']
                    if offer['is_purchased']:
                        self.outlet_offer_info[outlet_id]['is_purchased'] = offer['is_purchased']
                    if offer['type'] > self.outlet_offer_info[outlet_id]['type']:
                        self.outlet_offer_info[outlet_id]['type'] = offer['type']
                    self.outlet_offer_info[outlet_id]['is_monthly'] = get_outlet_monthly_status(
                        offer, outlet=self.outlet_offer_info[outlet_id]
                    )
                    # set outlet attribute for offer type 2 filter
                    self.outlet_offer_info[outlet_id]['has_type_2_offers'] = get_outlet_attr_status(
                        offer=offer,
                        offer_level_attr_name='type',
                        outlet_level_attr_name='has_type_2_offers',
                        offer_level_attr_value=TYPE_MEMBER,
                        outlet=self.outlet_offer_info[outlet_id]
                    )
                    # set outlet attribute for fourth offers filtration
                    self.outlet_offer_info[outlet_id]['has_fourth_offers'] = get_outlet_fourth_offer_status(
                        offer=offer, outlet=self.outlet_offer_info[outlet_id]
                    )
                    self.outlet_offer_info[outlet_id]['has_bonus_offers'] = get_outlet_attr_status(
                        offer=offer,
                        offer_level_attr_name='is_bonus_offers',
                        outlet_level_attr_name='has_bonus_offers',
                        offer_level_attr_value=True,
                        outlet=self.outlet_offer_info[outlet_id]
                    )
                    if (
                        self.outlet_offer_info[outlet_id]['is_new'] or
                        (
                            offer['is_entertainer'] and
                            offer['type'] != TYPE_MEMBER and
                            offer['valid_from_date'] > self.offer_valid_from_start_date and
                            offer['valid_from_date'] > self.offer_valid_from_cut_off_date
                        )
                    ):
                        self.outlet_offer_info[outlet_id]['is_new'] = True

                    if offer['is_cheers']:
                        self.outlet_offer_info[outlet_id]['is_cheers'] = offer['is_cheers']
                    if offer['is_delivery']:
                        self.outlet_offer_info[outlet_id]['is_delivery'] = offer['is_delivery']
                    self.outlet_offer_info[outlet_id]['is_more_sa'] = self.outlet_offer_info[outlet_id]['is_more_sa']
                    if offer['is_more_sa']:
                        self.outlet_offer_info[outlet_id]['is_more_sa'] = offer['is_more_sa']
                    if offer['product_type'] == Product.PRODUCT_TYPE_BIRTHDAY:
                        self.outlet_offer_info[outlet_id]['is_birthday'] = True
                    if offer['isshared']:
                        self.outlet_offer_info[outlet_id]['is_shared'] = True
                    if offer['top_up_offer']:
                        self.outlet_offer_info[outlet_id]['top_up_offer'] = True

                    if offer['merchant_category'] not in self.outlet_offer_info[outlet_id]['categories']:
                        self.outlet_offer_info[outlet_id]['categories'].append(offer['merchant_category'])

                if not self.outlet_offer_info[outlet_id].get('sub_categories'):
                    self.outlet_offer_info[outlet_id]['sub_categories'] = {}

                if not self.outlet_offer_info[outlet_id]['sub_categories'].get(offer['merchant_category']):
                    self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']] = []

                if (
                        offer['sub_category'] and
                        offer['sub_category'] not in
                        self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']]
                ):
                    self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']].append(
                        offer['sub_category']
                    )
                if not self.outlet_offer_info[outlet_id].get('cashless_delivery_enabled', False):
                    self.outlet_offer_info[outlet_id]['cashless_delivery_enabled'] = offer.get(
                        'cashless_delivery_enabled', 0
                    )

    def update_outlet(self, outlet):
        """
        Adds custom information to outlets as required.
        """
        # Common
        merchant = {}
        outlet['merchant_categories'] = parse_list(outlet.get('merchant_categories', []))
        outlet['merchant_cuisines'] = parse_list(outlet.get('merchant_cuisines', []), cuisine=True)
        outlet['merchant_categories_analytics'] = get_analytics_codes_against_categories(outlet['merchant_categories'])
        outlet['description'] = ""
        outlet['merchant_description'] = ""
        outlet['tripadvisor_id'] = str(outlet.get('tripadvisor_id'))

        # B2C
        outlet_lat = outlet['lat']
        outlet_lng = outlet['lng']
        if not outlet['distance']:
            outlet_distance = find_distance(self.lat, self.lng, outlet_lat, outlet_lng)
            if outlet_distance:
                outlet['distance'] = outlet_distance
            else:
                outlet['distance'] = 0

        outlet['distance'] = round(int(outlet['distance']))

        # B2B
        outlet['merchant_ad_travel_country'] = ''
        outlet['merchant_ad_active_status'] = True

        merchant_fields = [
            'id',
            'name',
            'name_for_outlet',
            'description',
            'category',
            'categories',
            'cuisine',
            'cuisines',
            'categories_analytics',
            'ad_travel_country',
            'ad_active_status',
            'logo_url',
            'logo_small_url',
            'photo_url',
            'photo_small_url',
            'digital_section'
        ]
        if TRAVEL_INSTANT_BOOKING_FLAG in outlet:
            outlet['2-for-1-icon'] = True
            outlet['hww_title'] = TRAVEL_INQUIRE_FOR_RATES

            outlet['package_price'], outlet['no_of_nights'] = 0, ''

            if outlet['is_hww_instant_booking']:
                outlet['package_price'], outlet['no_of_nights'] = Package.get_cheapest_package(
                    merchant_id=outlet['merchant_id'],
                    outlet_id=outlet['id'],
                    offer_ids=self.outlet_offer_info[outlet['id']]['offer_ids']
                )
                if outlet['package_price'] and outlet['no_of_nights']:
                    outlet['2-for-1-icon'] = False
                    outlet['hww_title'] = TRAVEL_INSTANT_BOOKING

            if not outlet['package_price'] and not outlet['no_of_nights']:
                outlet['package_price'] = Offer.get_max_saving_estimate(
                    self.outlet_offer_info[outlet['id']]['offer_ids']
                )
                outlet['no_of_nights'] = ''

            outlet['package_price'] = round(ExchangeRate.get_conversion_rate(
                outlet['package_price'],
                'AED',
                self.currency
            ))
            outlet['hotel_rating'] = get_hotel_rating(
                self.outlet_offer_info[outlet['id']]['sub_categories'][self.category]
            )
            try:
                images_url = ast.literal_eval(outlet['hero_non_retina_urls'])
                outlet["images_url"] = [img.replace('\\', '') for img in images_url]
            except ValueError:
                outlet["images_url"] = []

        if self.is_ent:
            if outlet['merchant_category'].lower() == RETAIL:
                outlet['merchant_category'] = CATEGORY_API_NAME_SERVICES

        for field in merchant_fields:
            merchant[field] = outlet['merchant_{}'.format(field)]
            if field == 'ad_active_status':
                merchant[field] = merchant[field] > 0
            del outlet['merchant_{}'.format(field)]
        if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
            outlet_name_parts = outlet['name'].split('-')
            outlet['name'] = outlet_name_parts[-1].strip()
        merchant['name_for_outlet'] = merchant['name']
        outlet['merchant_name'] = merchant['name']
        outlet['merchant'] = merchant

        if (
                self.category and
                self.category in VALID_CATEGORIES
        ):
            outlet['merchant']['category'] = self.category
        elif outlet['categories']:
            outlet['merchant']['category'] = outlet['categories'][0]
        else:
            outlet['merchant']['category'] = ""

        if outlet['id'] in self.merchant_criteria['fuzzy_search_outlet_id_score']:
            outlet['fuzzy_relevance'] = self.merchant_criteria['fuzzy_search_outlet_id_score'][outlet['id']]
        else:
            outlet['fuzzy_relevance'] = 0

        if self.cuisine_filter and self.cuisine_filter[0]:
            is_cuisine_matched = False
            for cuisine in self.cuisine_filter:
                # change merchant_cuisines to lower case
                if cuisine.strip().lower() in map(lambda x: x.lower(), outlet['merchant']['cuisines']):
                    is_cuisine_matched = True
                    break
            if not is_cuisine_matched:
                return False

        outlet_bands = outlet.get('bands')

        if self.last_mile_enabled:
            if outlet.get('last_mile_delivery') and outlet_bands:
                outlet_band_info = get_band_info_cached(self.location_id)
                user_within_distance = False
                for band in outlet_band_info:
                    if band.id in outlet_bands:
                        band_start_range = band.start_range
                        band_end_range = band.end_range
                        if (
                                outlet['distance'] and
                                (band_start_range <= outlet['distance'] <= band_end_range)
                        ):
                            user_within_distance = True
                            outlet['tracking_info'] = {
                                'title': LAST_MILE_LIVE_TRACKING,
                                'image_url': LAST_MILE_IMAGE_URL,
                                'title_color': LAST_MILE_TITLE_COLOR,
                                'is_live_tracking_enabled': True
                            }
                if not user_within_distance:
                    return False

        # Set default outlet keys.
        outlet.update({
            'opening_hours': '',
            'api_params': {
                'show_monthly_product': True
            }
        })

        if self.takeaways_enabled and self.cashless_delivery_enabled and outlet.get('take_away_enabled'):
            outlet['api_params']['is_take_away'] = True

        return outlet

    def filter_outlet_by_query(self, outlet={}):
        """
        Filter outlets based on merchant_name using query.
        :param outlet: outlet instance
        :return: bool
        """
        if (not self.is_fuzzy_search_on or self.is_fuzzy_server_down) and self.query_type_is_name:
            if (
                    not is_search_string_found(outlet.get('merchant_name'), self.query, True) and
                    outlet.get('id') not in self.query_matched_offers_outlets
            ):
                return True
        return False

    def update_featured_merchant(self, featured_merchant, outlet):
        """
        Add respective flags to featured merchant in response.
        """

        if not featured_merchant.get('merchant'):
            featured_merchant['merchant'] = {}

        if self.category == self.category_repo.category_name_Restaurants_and_Bars:
            if not featured_merchant.get('merchant', {}).get('cuisines'):
                featured_merchant['merchant'] = {'cuisines': []}
            for cuisine in outlet['cuisines']:
                if cuisine not in featured_merchant['merchant']['cuisines']:
                    featured_merchant['merchant']['cuisines'].append(cuisine)

        featured_merchant['merchant']['cuisine'] = outlet['merchant']['cuisine']

        featured_merchant['category'] = self.category
        featured_merchant['categories'] = [self.category]
        featured_merchant['category_image'] = outlet['category_image']
        featured_merchant['categories_analytics'] = outlet['categories_analytics']
        featured_merchant['category_color'] = outlet['category_color']

        merchant_attributes = (
            'is_redeemable',
            'is_purchased',
            'is_monthly',
            'is_new',
            'is_cheers',
            'is_delivery'
        )

        featured_merchant_keys = featured_merchant.keys()

        for attribute in merchant_attributes:
            if attribute not in featured_merchant_keys:
                featured_merchant[attribute] = outlet[attribute]
            elif outlet[attribute]:
                featured_merchant[attribute] = outlet[attribute]

        featured_merchant['is_cheers'] = bool(featured_merchant['is_cheers'])
        featured_merchant['is_delivery'] = bool(featured_merchant['is_delivery'])

    @staticmethod
    def process_outlet_attributes(outlet, outlet_offer_info):
        """
        Update outlet features based on offer attributes.
        """

        outlet['product_id'] = outlet_offer_info['product_id']
        outlet['product_sku'] = outlet_offer_info['product_sku']
        outlet['top_offer_redeemability'] = outlet_offer_info['redeemability']
        outlet['top_offer_type'] = outlet_offer_info['type']
        outlet['has_type_2_offers'] = outlet_offer_info.get('has_type_2_offers', False)
        outlet['has_fourth_offers'] = outlet_offer_info.get('has_fourth_offers', False)
        outlet['has_bonus_offers'] = outlet_offer_info.get('has_bonus_offers', False)
        outlet['is_redeemable'] = outlet_offer_info['is_redeemable']
        outlet['is_purchased'] = outlet_offer_info['is_purchased']
        outlet['is_monthly'] = outlet_offer_info['is_monthly']
        outlet['is_new'] = outlet_offer_info['is_new']
        outlet['is_cheers'] = outlet_offer_info['is_cheers']
        outlet['is_delivery'] = outlet_offer_info['is_delivery']
        outlet['is_more_sa'] = outlet_offer_info['is_more_sa']
        outlet['is_birthday'] = outlet_offer_info.get('is_birthday', False)
        outlet['is_shared'] = outlet_offer_info.get('is_shared', False)
        outlet['top_up_offer'] = outlet_offer_info.get('top_up_offer', False)
        outlet['is_point_based_offer'] = outlet_offer_info.get('is_point_based_offer')
        outlet['locked_image_url'] = ""
        outlet['categories'] = outlet_offer_info['categories']
        outlet['sub_categories'] = outlet_offer_info['sub_categories']

        if outlet['categories']:
            outlet['categories'] = sort_categories(outlet['categories'])

        outlet['merchant_categories'] = outlet['categories']
        outlet['merchant_categories_analytics'] = get_category_codes_for_analytics(
            outlet['merchant_categories'])

        outlet['merchant']['categories'] = outlet['merchant_categories']
        outlet['merchant']['categories_analytics'] = outlet['merchant_categories_analytics']

        if outlet_offer_info['sub_categories']:
            outlet['merchant']['digital_section'] = ", ".join(outlet_offer_info['sub_categories'])
        else:
            outlet['merchant']['digital_section'] = ""

    def process_outlets(self):
        """
        Process each outlet gotten from DB as required in response.
        """

        outlet_index_mapping = {}
        final_outlets_index_counter = 0

        self.hashed_featured_merchants = dict(
            [(featured_merchant['id'], featured_merchant) for featured_merchant in self.featured_merchants]
        )
        dm_devices_hash = dict()
        lat_lng_point = None

        if self.cashless_delivery_enabled:

            if self.lat and self.lng and self.lat != '0,0' and self.lng != ',':
                self.lat_lng_exists = True

            if self.merchants_ids:
                dm_devices = DmDevice.find_device_by_filter(
                    in_filters=[{'merchant_id': self.merchants_ids}],
                    filters={'is_active': 1, 'is_device_online': 1},
                    multiple_devices=True,
                    order_field='last_ping',
                    order_desc=True,
                )
                for dm_device in dm_devices:
                    dm_devices_hash_key = '{merchant_id}_{outlet_id}'.format(
                        merchant_id=dm_device.get('merchant_id'),
                        outlet_id=dm_device.get('outlet_id')
                    )
                    try:
                        dm_devices_hash[dm_devices_hash_key]
                    except KeyError:
                        dm_devices_hash[dm_devices_hash_key] = dm_device

            if self.lat_lng_exists:
                lat_lng_point = get_geo_point_from_lat_lng(
                    lat=self.lat,
                    lng=self.lng,
                    location_id=self.location_id,
                    company=self.company
                )

            if speedups.available:
                speedups.enable()

        for outlet in self.outlets:
            outlet = dict((zip(outlet._fields, outlet)))
            if not self.update_outlet(outlet):
                continue

            try:
                outlet_offer_info = self.outlet_offer_info[outlet['id']]
            except KeyError:
                continue

            if self.cashless_delivery_enabled and outlet_offer_info.get('is_delivery_cashless_offer'):
                if outlet_index_mapping.get(outlet['id']) is not None:
                    outlet_index_mapping[outlet_index_mapping[outlet['id']]]['outlet_zones'].append({
                        'polygon_coordinates': outlet.get('polygon_coordinates'),
                        'map_type': outlet.get('map_type'),
                        'default_delivery_time': outlet.get('oz_default_delivery_time')
                    })
                    continue
                else:
                    outlet['outlet_zones'] = [
                        {
                            'polygon_coordinates': outlet['polygon_coordinates'],
                            'map_type': outlet['map_type'],
                            'default_delivery_time': outlet.get('oz_default_delivery_time')
                        }
                    ]

                outlet_offer_info['is_delivery'] = True
                outlet['is_delivery'] = True
                outlet['cashless_delivery_params'] = {
                    'outlet_id': outlet.get('id'),
                    'cashless_delivery': True,
                    'is_take_away': self.takeaways_enabled
                }
                outlet_exists_in_zones = []

                if not lat_lng_point:
                    continue

                outlet_zones = outlet.get('outlet_zones', [])
                if not outlet_zones:
                    continue

                for zone_index, zone in enumerate(outlet_zones):
                    shape = None
                    outlet_exists_in_zones.append(False)
                    if not zone.get('polygon_coordinates') and not outlet.get('bands'):
                        continue
                    map_type = zone.get('map_type', DmDevice.POLYGON_SHAPE_CONSTANT)
                    if map_type == DmDevice.POLYGON_SHAPE_CONSTANT and not outlet.get('bands'):
                        try:
                            shape_coordinates = json.loads(zone.get('polygon_coordinates').replace('"', ''))
                            shape = Polygon(shape_coordinates[0])
                        except IndexError:
                            continue
                    elif map_type == DmDevice.CIRCLE_SHAPE_CONSTANT and not outlet.get('bands'):
                        try:
                            shape_coordinates = json.loads(zone.get('polygon_coordinates'))
                            shape = Point(
                                shape_coordinates.get('lng'),
                                shape_coordinates.get('lat')
                            ).buffer(shape_coordinates.get('radius') / RADIUS_CONVERSION_UNIT)
                        except Exception:
                            continue
                    try:
                        if shape:
                            if not shape.contains(lat_lng_point):
                                outlet['can_delivery_at_address'] = False
                                # In case of mall search, don't skip the outlet.
                                if not self.mall:
                                    continue
                                outlet_exists_in_zones[zone_index] = True
                            else:
                                outlet['can_delivery_at_address'] = True
                                outlet_exists_in_zones[zone_index] = True
                                outlet['zone_default_delivery_time'] = zone.get('default_delivery_time')
                                break
                        elif outlet.get('bands'):
                            outlet_distance = find_distance(self.lat, self.lng, outlet.get('lat'), outlet.get('lng'))
                            outlet_bands = outlet.get('bands')
                            if self.last_mile_enabled and outlet.get('last_mile_delivery') and outlet_bands:
                                outlet_band_info = get_band_info_cached(self.location_id)
                                user_within_distance = False
                                for band in outlet_band_info:
                                    if band.get('id') in outlet_bands:
                                        band_start_range = band.get('start_range')
                                        band_end_range = band.get('end_range')
                                        if (
                                                outlet_distance >= 0 and
                                                (band_start_range <= outlet_distance <= band_end_range)
                                        ):
                                            user_within_distance = True
                                            outlet['tracking_info'] = {
                                                'title': LAST_MILE_LIVE_TRACKING,
                                                'image_url': LAST_MILE_IMAGE_URL,
                                                'title_color': LAST_MILE_TITLE_COLOR,
                                                'is_live_tracking_enabled': True
                                            }
                                if user_within_distance:
                                    outlet['can_delivery_at_address'] = True
                                    outlet_exists_in_zones[zone_index] = True
                                    outlet['zone_default_delivery_time'] = zone.get('default_delivery_time')
                            break
                        else:
                            outlet['can_delivery_at_address'] = False
                            # in case of mall search dont skip the outlet
                            if not self.mall:
                                continue
                            outlet_exists_in_zones[zone_index] = True
                    except Exception:
                        continue

                if not any(outlet_exists_in_zones):
                    continue

                outlet_device_key = None
                if str(outlet.get('integration_type', '')).lower() == NON_INTEGRATED_ASSET:
                    outlet_device_key = '{merchant_id}_{outlet_id}'.format(
                        merchant_id=outlet.get('merchant', {}).get('id', None),
                        outlet_id=outlet.get('id', None)
                    )
                elif str(outlet.get('integration_type', '')).lower() == CALL_CENTRE:
                    outlet_device_key = '{merchant_id}_{outlet_id}'.format(
                        merchant_id=outlet.get('merchant', {}).get('id', None),
                        outlet_id=None
                    )
                if outlet_device_key:
                    try:
                        outlet['is_device_online'] = dm_devices_hash[outlet_device_key].get('is_device_online', False)
                        outlet['last_ping'] = dm_devices_hash[outlet_device_key].get('last_ping', None)
                    except KeyError:
                        pass
                outlet['default_delivery_time'] = (
                    outlet.get('zone_default_delivery_time') or
                    outlet.get('default_delivery_time') or
                    99999
                )
                now = get_current_time_of_location(self.location_id)
                from_time_am_pm = ''
                to_time_am_pm = ''
                try:
                    from_time = convert_timedelta_to_datetime(outlet.get('delivery_start_time', ''), now)
                    from_time_am_pm = from_time.strftime("%I:%M%p")
                except (TypeError, ValueError):
                    from_time = ''
                try:
                    to_time = from_time + datetime.timedelta(minutes=outlet.get('total_minutes', 0))
                    to_time_am_pm = to_time.strftime("%I:%M%p")
                except (TypeError, ValueError):
                    to_time = ''
                if from_time_am_pm and to_time_am_pm:
                    outlet['opening_hours'] = '{from_time} - {to_time}'.format(
                        from_time=from_time_am_pm, to_time=to_time_am_pm
                    )
                outlet['cuisine_distance'] = ''
                if isinstance(outlet.get('merchant', {}).get('cuisines'), list):
                    outlet['cuisine_distance'] = ",".join(outlet.get('merchant', {}).get('cuisines'))
                if self.lat_lng_exists:
                    if outlet['cuisine_distance'] and outlet.get('distance'):
                        outlet['cuisine_distance'] += ' | '
                    if outlet.get('distance', 0) > 999:
                        outlet['cuisine_distance'] += '{distance}{units}'.format(
                            distance=round(outlet.get('distance', 0) / 1000),
                            units='km'
                        )
                    else:
                        outlet['cuisine_distance'] += '{distance}{units}'.format(
                            distance=outlet.get('distance', 0),
                            units='m'
                        )
                outlet['attributes'] = []
                if outlet.get('default_delivery_time') and outlet.get('default_delivery_time') < 9999:
                    outlet['attributes'].append({
                        "type": "image",
                        'value': CLOCK_CASHLESS_IMAGE
                    })
                    outlet['attributes'].append({
                        "type": "text",
                        'value': '{mins} mins'.format(
                            mins=outlet.get('default_delivery_time', '-')
                        )
                    })
                outlet['cashless_delivery_params'] = {'outlet_id': outlet.get('id'), 'cashless_delivery': True}
                outlet['is_open'] = (
                    bool(outlet.get('is_device_online', False)) and
                    outlet.get('online_status', 'offline') == 'Online'
                )

                if outlet['is_open'] and outlet.get('last_ping'):
                    try:
                        last_ping_seconds = (
                            get_current_time_of_location(DUBAI_LOCATION_ID) - outlet.get('last_ping')
                        ).total_seconds()
                        if last_ping_seconds > PING_TIME_LIMIT_SECONDS:
                            outlet['is_open'] = False
                    except Exception:
                        outlet['is_open'] = False
                else:
                    outlet['is_open'] = False

                if outlet['is_open'] and from_time:
                    outlet['is_open'] = False
                    try:
                        to_time = from_time + datetime.timedelta(minutes=outlet.get('total_minutes', 0))
                        if from_time < now < to_time:
                            outlet['is_open'] = True
                    except (ValueError, TypeError):
                        pass

                elif not from_time or not to_time:
                    outlet['is_open'] = False

                if self.mall and not outlet['can_delivery_at_address']:
                    outlet['is_open'] = False

                for attribute in ATTRIBUTES_TO_DELETE_FOR_CASHLESS:
                    try:
                        del outlet[attribute]
                    except KeyError:
                        pass

            if self.filter_outlet_by_query(outlet):
                continue

            self.process_outlet_attributes(outlet, outlet_offer_info)

            if self.hashed_featured_merchants.get(outlet['merchant'].get('id', 0)):
                self.update_featured_merchant(
                    self.hashed_featured_merchants[outlet['merchant']['id']],
                    outlet
                )

            if self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                if outlet['merchant']['category'] == CATEGORY_API_NAME_RETAIL:
                    outlet['merchant']['category'] = CATEGORY_API_NAME_SERVICES
                company_skus = get_configured_sku_by_company(self.company)
                outlet['is_company_specific'] = self.is_company_specific
                if not outlet['is_company_specific']:
                    for skus in outlet['product_sku']:
                        if skus in company_skus:
                            outlet['is_company_specific'] = True
                            break

            set_images_and_attributes_dynamically(
                self.company,
                outlet,
                self.categories,
                self.category,
                self.api_configs,
                self.tab
            )
            if not self.is_fuzzy_search_on:
                if self.query and self.query_type == 'name':
                    if (
                            not is_search_string_found(outlet['merchant_name'], self.query, True) and
                            outlet['id'] not in self.query_matched_offers_outlets
                    ):
                        continue

            if self.featured_merchants:
                for featured_merchant in self.featured_merchants:

                    if featured_merchant['id'] == outlet['merchant']['id']:

                        featured_merchant['is_featured'] = True
                        featured_merchant['category'] = self.category
                        featured_merchant['categories'] = [self.category]

                        if not featured_merchant['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet.get('is_redeemable')

                        if not featured_merchant['is_purchased']:
                            featured_merchant['is_purchased'] = outlet.get('is_purchased')

                        if not featured_merchant['is_monthly']:
                            featured_merchant['is_monthly'] = outlet.get('is_monthly')

                        if not featured_merchant['is_new']:
                            featured_merchant['is_new'] = outlet.get('is_new')

                        if not featured_merchant['is_cheers']:
                            featured_merchant['is_cheers'] = outlet.get('is_cheers')

                        if not featured_merchant['is_delivery']:
                            featured_merchant['is_delivery'] = outlet.get('is_delivery')

                        if outlet['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet['is_redeemable']
                        if outlet['is_purchased']:
                            featured_merchant['is_purchased'] = outlet['is_purchased']
                        if outlet['is_monthly']:
                            featured_merchant['is_monthly'] = outlet['is_monthly']
                        if outlet['is_new']:
                            featured_merchant['is_new'] = outlet['is_new']
                        if outlet['is_cheers']:
                            featured_merchant['is_cheers'] = outlet['is_cheers']
                        if outlet['is_delivery']:
                            featured_merchant['is_delivery'] = outlet['is_delivery']

            if self.is_customer_logged_in:
                if self.offer_redeemability != Redemption.REDEEMABILITY_ALL:
                    if (
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMABLE_REUSABLE and
                            outlet['top_offer_redeemability'] not in (Redemption.REDEEMABLE, Redemption.REUSABLE)
                        ) or
                        (
                            self.offer_redeemability == Redemption.REDEEMABILITY_REUSABLE and
                            outlet['top_offer_redeemability'] != Redemption.REUSABLE
                        ) or
                        (
                            self.offer_redeemability == Redemption.REDEEMABILITY_NOT_REDEEMABLE and
                            outlet['top_offer_redeemability'] != Redemption.NOT_REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == Redemption.RedemptionREDEEMABILITY_REDEEMABLE and
                            outlet['top_offer_redeemability'] != Redemption.REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == Redemption.REDEEMABILITY_REDEEMED and
                            outlet['top_offer_redeemability'] != Redemption.REDEEMED
                        )
                    ):
                        continue

            if self.show_monthly_offers and not outlet.get('is_monthly', False):
                continue

            # Filter fourth or monthly offers.
            if self.show_fourth_and_monthly_offers and not outlet.get('has_type_2_offers', False):
                continue

            # Filter fourth offers.
            if self.show_fourth_offers and not outlet.get('has_fourth_offers', False):
                continue

            if self.is_birthday and not outlet.get('is_birthday', False):
                continue

            if self.is_cheers and not outlet.get('is_cheers', False):
                continue

            if self.show_new_offers and not outlet.get('is_new', False):
                continue

            # Fix for IOS. In case of trip advisor id 0, change it to 9999.
            if outlet['tripadvisor_id'] == "0" and self.platform in ["", "ios"]:
                outlet['tripadvisor_id'] = "9999"

            outlet['merchant_name'] = outlet['merchant_name'].lower()
            self.final_outlets.append(outlet)
            outlet_index_mapping[outlet['id']] = final_outlets_index_counter
            final_outlets_index_counter += 1
            self.redeemabilities.append(outlet['top_offer_redeemability'])
            self.merchant_names.append(outlet['merchant_name'])
            self.distances.append(outlet['distance'])

        if self.cashless_delivery_enabled:
            self.final_outlets = pick_outlets_with_best_time_slot(self.final_outlets, self.location_id)

    def set_shared_redemptions_count_records(self):
        """
        Set shared_redemptions_count_records.
        """
        self.shared_offers_received = True
        if self.shared_offers_received:
            self.shared_redemptions_count_records = count_offer_redemptions_by_customer_shared_offers(
                self.customer_id,
                offer_id=self.shared_offer_ids,
                group_by=True,
                is_active_family_member=self.is_active_family_member,
                primary_user_id=self.primary_user_id,
                company=self.company
            )
            self.personal_shared_redemptions_count_records = count_offer_redemptions_by_customer_shared_offers(
                self.customer_id,
                offer_id=self.shared_offer_ids,
                group_by=True,
                company=self.company
            )

    def get_redemptions_quantities(self):
        """
        Set redemptions quantities.
        """
        self.redemption_quantities = {}
        if self.is_customer_logged_in:
            self.redemptions_quantities = self.util_module.redeemed_quantities_for_customer(
                customer_id=self.customer_id,
                primary_user_id=self.primary_user_id,
                is_onboarding=self.is_customer_using_trial,
                company=self.company,
                is_secondary_customer=False
            )
            if self.is_active_family_member and self.primary_user_id != self.customer_id:
                secondary_birthday_redemptions = self.util_module.redeemed_quantities_for_customer(
                    customer_id=self.customer_id,
                    primary_user_id=self.primary_user_id,
                    is_onboarding=self.is_customer_using_trial,
                    company=self.company,
                    is_secondary_customer=True
                )
                self.redemptions_quantities.update(secondary_birthday_redemptions)
            self.redemptions_quantities_present = True if self.redemption_quantities else False

    def set_customer_redemptions(self):
        """
        Set customer-redemptions records it will be used in redeemability calculations.
        """
        if self.is_customer_logged_in:
            self.set_shared_redemptions_count_records()

    def update_search_results_neighborhoods(self):
        """
        Update the search results with country areas.
        """
        self.neighborhoods = []
        if self.query:
            self.neighborhoods = Offer.get_country_areas(
                location_id=self.location_id,
                locale=self.locale,
                search_keyword=self.query,
                category=self.category,
                company=self.company
            )
        elif getattr(self, 'load_neighbourhood_only', False):
            self.neighborhoods = Offer.get_country_areas(
                location_id=self.location_id,
                locale=self.locale,
                search_keyword=self.neighbourhood_keyword,
                category=self.neighbourhood_category,
                company=self.company
            )

        for neighborhood in self.neighborhoods:
            self.search_results.append({
                'type': 'neighborhood',
                'name': neighborhood['name'],
                'value': neighborhood['value'],
                'icon': NEIGHBORHOOD_IMAGE
            })

    def update_search_results_hotel_and_malls(self):
        """
        Update the search results with country hotels and malls.
        """
        self.hotels = []
        self.malls_list = []
        self.load_malls_only = True
        self.mall_category = ''
        self.mall_keyword = ''

        if getattr(self, 'load_malls_only', False):
            self.malls_list = Offer.get_attribute_values_malls(
                DEEP_LINK_MALL_TYPE,
                location_id=self.location_id,
                locale=self.locale,
                search_keyword=self.mall_keyword,
                category=self.mall_category,
                company=self.company
            )
        if getattr(self, 'load_hotels_only', False):
            self.hotels = Offer.get_country_hotels(
                location_id=self.location_id,
                locale=self.locale,
                search_keyword=self.hotel_keyword,
                category=self.hotel_category,
                company=self.company
            )
        elif self.category_lower_case != 'travel':
            if self.query:
                self.hotels = Offer.get_country_hotels(
                    location_id=self.location_id,
                    locale=self.locale,
                    search_keyword=self.query,
                    category=self.category,
                    company=self.company
                )
                self.malls_list = Offer.get_attribute_values_malls(
                    'mall',
                    location_id=self.location_id,
                    locale=self.locale,
                    search_keyword=self.query,
                    category=self.category,
                    company=self.company
                )

        for mall in self.malls_list:
            self.search_results.append({
                'type': 'mall',
                'name': mall,
                'value': mall,
                'icon': MALL_IMAGE
            })

        for hotel in self.hotels:
            self.search_results.append({
                'type': 'hotel',
                'name': hotel['name'],
                'value': hotel['value'],
                'icon': HOTEL_IMAGE
            })

    def update_search_results(self):
        """
        Update the search-results.
        """
        if self.offset == 0:
            self.update_search_results_neighborhoods()
            self.update_search_results_hotel_and_malls()

    def process_offers(self):
        """
        Process offers.
        """
        if self.offers:
            self.set_query_type_is_name()
            self.get_redemptions_quantities()
            self.set_offer_related_defaults()
            self.set_customer_redemptions()
            self.update_offer_attributes()
            self.update_outlets()
            self.process_outlets()
            self.sort_outlets()
            self.update_search_results()
        elif self.load_search_results:
            self.update_search_results()

    def sort_outlets(self):
        """
        Sort Final outlets
        """
        sort_order = []
        if self.is_fuzzy_search_on and self.query:
            if self.cashless_delivery_enabled:
                if self.lat_lng_exists:
                    sort_order = ['-is_open', '-fuzzy_relevance', 'merchant_name', 'default_delivery_time', 'distance']
                else:
                    sort_order = ['-is_open', '-fuzzy_relevance', 'merchant_name']
            else:
                sort_order = ['-fuzzy_relevance', 'distance', 'merchant_name', '-top_offer_redeemability']
        else:
            self.sort_type = self.sort
            if self.cashless_delivery_enabled:
                if self.lat_lng_exists:
                    sort_order = ['-is_open', 'default_delivery_time', 'distance', 'merchant_name']

                else:
                    sort_order = ['-is_open', 'merchant_name']

            elif self.sort_type == DEFAULT:
                if self.redeemability_first:
                    sort_order = ['-top_offer_redeemability', 'distance', 'merchant_name']
                else:
                    sort_order = ['distance', 'merchant_name', '-top_offer_redeemability']
            elif self.sort_type == 'alpha':
                if self.redeemability_first:
                    sort_order = ['-top_offer_redeemability', 'merchant_name']
                else:
                    sort_order = ['merchant_name', '-top_offer_redeemability']
            if self.is_travel:
                if self.sort_type == DEFAULT:
                    sort_order = ['-is_hww_instant_booking', 'package_price']
                if self.sort_type == BEST_REVIEWED:
                    sort_order = ['-ta_rating', 'is_hww_instant_booking', 'package_price']
                elif self.sort_type == MOST_REVIEWED:
                    sort_order = ['-ta_reviews_count', 'is_hww_instant_booking', 'package_price']
                elif self.sort_type == NEAREST:
                    sort_order = ['distance', '-is_hww_instant_booking', 'package_price']

        if sort_order:
            self.final_outlets = multi_key_sort(self.final_outlets, sort_order)

    def set_attributes_of_featured_merchants(self):
        """
        Set images and attributes of each merchant in response.
        """
        for featured_merchant in self.featured_merchants:
            featured_merchant['locked_image_url'] = ""
            self.outlets_module.set_images_and_attributes(
                company=self.company,
                outlet=featured_merchant,
                categories=self.categories,
                selected_category=self.category
            )

    def prepare_outlet_chunks_to_return(self):
        """
        Pagination of final outlets.
        """
        end = self.limit + self.offset
        self.outlets_chunk_to_return = self.final_outlets[self.offset:None if self.limit <= 0 else end]

    def show_promotional_section(self):
        """
        Show the promotional section if the following conditions are met:
            1) In SKIP mode.
            2) If you are member but don't own any redeemable offers in that particular location.
            3) Only show under the YourOffers tab.
        """
        if (
            not self.final_outlets and
            not int(self.offset) and
            not self.merchant_attributes_selected and
            not self.is_travel and
            not self.query_type and
            not self.is_delivery and
            not self.is_cheers and
            not self.isshared and
            not self.is_more_sa and
            self.offer_redeemability in (Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE, Redemption.REDEEMABILITY_ALL)
        ):
            self.promote_user_to_buy_product = self.outlets_module.get_promotional_section_for_category(
                category=self.category,
                locale=self.message_locale
            )

    def prepare_filtered_final_outlets(self):
        """
        Filter final outlets.
        """
        if not self.cashless_delivery_enabled and self.offer_redeemability == Redemption.REDEEMABILITY_NOT_REDEEMABLE:
            for outlet in self.outlets_chunk_to_return:
                if not outlet['is_purchased'] or not outlet['is_redeemable']:
                    self.filtered_outlets.append(outlet)
        else:
            self.filtered_outlets = self.outlets_chunk_to_return

    def cashless_processing_for_offer_attributes_selected(self):
        """
        If offer_attributes_selected are selected example 'buffet' then we have to determine which outlets are also
        taking part in cashless as their is no way to determine this at offer level.
        """
        self.offer_attributes_selected = True

        if (
            self.cashless_delivery_enabled and
            self.offer_attributes_selected and
            self.location_id in self.util_module.get_delivery_enabled_location_ids_against_company(self.company)
        ):
            non_cashless_delivery_enabled_outlets_ids = []
            for outlet in self.filtered_outlets:
                if not self.outlet_offer_info[outlet.get('id')].get('cashless_delivery_enabled'):
                    non_cashless_delivery_enabled_outlets_ids.append(outlet.get('id'))
            non_cashless_delivery_enabled_outlets_ids = list(set(non_cashless_delivery_enabled_outlets_ids))

            if non_cashless_delivery_enabled_outlets_ids:
                cashless_outlets = self.outlets_module.get_cashless_delivery_outlets(
                    outlet_ids=non_cashless_delivery_enabled_outlets_ids,
                    company=self.company
                )
                if cashless_outlets:
                    for outlet in self.filtered_outlets:
                        if outlet.get('id') in cashless_outlets:
                            outlet['is_delivery'] = True
                            outlet['cashless_delivery_params'] = {
                                'outlet_id': outlet.get('id'),
                                'cashless_delivery': True
                            }
                        self.outlets_module.set_images_and_attributes(
                            company=self.company,
                            outlet=outlet,
                            categories=self.categories,
                            selected_category=self.category
                        )

    def prepare_response(self):
        """
        Prepares http response to send.
        """
        self.outlet_response = {
            'is_elastic_search_results': self.is_fuzzy_search_on,
            'is_elastic_search_server_down': self.is_fuzzy_server_down,
            'ping_section': self.ping_section,
            'search_results': self.search_results,
            'featured_merchants': self.featured_merchants,
            'outlets': self.filtered_outlets,
            'total_records': len(self.final_outlets),
            'show_delivery_purchase_view': True,
            'records_in_current_page': len(self.outlets_chunk_to_return),
            'offset': self.offset,
            'page_size': self.limit,
            'map_zoom_level': self.outlets_module.MAP_ZOOM_LEVEL
        }
        if self.cashless_delivery_enabled and not self.filtered_outlets:
            self.outlet_response['show_delivery_purchase_view'] = False
        if self.promote_user_to_buy_product:
            self.outlet_response['promote_user_to_buy_product'] = self.promote_user_to_buy_product
        self.set_response({
            'data': self.outlet_response,
            'message': 'success',
            'success': True
        })

    def process_fuzzy_search(self):
        """
        Process fuzzy search.
        """
        # TODO: Test with fuzzy when it is available.

        if self.is_ent:
            if self.is_fuzzy_search_on and not self.is_source_es:
                fuzzy_search_result = fuzzy_search_manager.get_fuzzy_results(
                    self.query,
                    self.category,
                    self.sub_category_filter
                )
                if fuzzy_search_result.is_timeout_or_server_down:
                    self.is_fuzzy_search_on = False
                    self.is_fuzzy_server_down = True
                elif (
                        fuzzy_search_result.is_succeeded and
                        fuzzy_search_result.total_unique_results_found > 0
                ):
                    self._fuzzy_search_outlet_ids = fuzzy_search_result.outlet_ids
                    self._fuzzy_search_outlet_id_score = fuzzy_search_result.outlet_id_score

    def set_offer_validity_info(self):
        """
        Set up offer validity info class variables based on current date and time.
        """

        current_datetime = datetime.datetime.now()
        self.offer_valid_from_start_date = datetime.datetime.strptime(
            '{year}-01-31'.format(year=current_datetime.year),
            '%Y-%m-%d'
        )
        self.offer_valid_from_cut_off_date = current_datetime.replace(hour=0, minute=0, second=0)
        self.offer_valid_from_cut_off_date = self.offer_valid_from_cut_off_date - datetime.timedelta(days=30)

    def set_merchant_attributes(self):
        """
        Set merchant attributes and flags based on merchant attributes.
        """
        merchant_attributes = self.merchant_attributes_selected
        self.merchant_attributes_selected = []
        for merchant_attribute in merchant_attributes:
            self.merchant_attributes_selected.append(unquote(merchant_attribute))

        if self.merchant_attributes_selected:
            for filter_selected_for_yes in self.merchant_attributes_selected:
                if filter_selected_for_yes.__contains__(DISABLE_FUZZY):
                    self.query = filter_selected_for_yes.replace(DISABLE_FUZZY, "")
                    self.disable_fuzzy = True
                    self.merchant_attributes_selected = []
                    break

            for filter_selected_for_yes in self.merchant_attributes_selected:
                if self.birthday_feature_enabled and HAPPY_BIRTHDAY_KEYWORD == filter_selected_for_yes:
                    self.category = CATEGORY_ALL
                    self.is_birthday = True

    def set_price_range_info(self):
        """
        Set up price range.
        """
        if self.price_range_encoded:
            price_range_decoded = unquote(self.price_range_encoded)
            price_ranges_str = price_range_decoded.split(',')
            for price_range in price_ranges_str:
                self.price_ranges.append(int(price_range))

    def set_distance_range_info(self):
        """
        If distance coordinates are passed, we update the base coordinates and radius.
        """
        if self.distance_latitude and self.distance_longitude and self.distance_radius:
            self.lat = self.distance_latitude
            self.lng = self.distance_longitude
            self.radius = self.distance_radius

    def set_product_sku(self):
        """
        If the is_more_sa flag is set, the product sku is changed from the request parameter sku to SA product sku.
        """
        if self.is_ent and self.is_more_sa:
            self.product_sku = Product.MORE_SA_PRODUCT_SKU

    def set_category_info(self):
        """
        Set up everything related to categories.
        """
        self.category = unquote(self.category)
        self.category_lower_case = self.category.lower()
        if self.is_ent:
            if self.category == CATEGORY_API_NAME_TRAVEL:
                self.featured_category = FEATURED_CATEGORY_TRAVEL

        self.categories = HomeScreenConfiguration.get_categories(
            is_user_logged_in=self.is_customer_logged_in,
            company=self.company,
            user_id=self.customer_id,
            location_id=self.location_id,
            purchased_product_ids=[],
            purchasable_product_ids=[],
            locale=self.locale
        )

    def set_specific_outlet_ids(self):
        """
        If specific outlets need to be searched, we use this flag.
        """
        if self.specific_outlet_ids_encoded:
            specific_outlet_ids_decode = unquote(self.specific_outlet_ids_encoded)
            self.specific_outlet_ids = specific_outlet_ids_decode.split(',')

    def set_specific_merchant_ids(self):
        """
        To return outlets specific to a merchant, we use this flag.
        """
        if self.merchant_ids_encode:
            merchant_ids_decode = unquote(self.merchant_ids_encode)
            self.merchant_ids = merchant_ids_decode.split(',')

    def set_offer_redeemability(self):
        """
        Sets offer redeemability check flag.
        """
        self.offer_redeemability_check = (
            self.is_ent and
            not self.cashless_delivery_enabled and
            not self.query and
            self.offer_redeemability in (
                Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
                Redemption.REDEEMABILITY_REDEEMABLE,
                Redemption.REDEEMABILITY_REUSABLE
            )
        )

    def set_featured_merchants_info(self):
        """
        To show featured merchants, we use this flag.
        """
        self.is_load_featured_merchants = (
            self.is_ent and
            self.category == CATEGORY_API_NAME_TRAVEL and
            int(self.offset) == 0 and
            not self.cuisines_selected and
            not self.merchant_attributes_selected and
            not self.offer_attributes_selected and
            not self.offer_types_selected and
            not self.show_offers_of_type_selected and
            not self.sub_categories_selected and
            self.offer_redeemability_check
        )

    def initialize_request_framework(self):
        """
        Set up the framework on the base of which we need to perform the request.
        """

        self.set_offer_validity_info()
        self.set_merchant_attributes()
        self.set_price_range_info()
        self.set_distance_range_info()
        self.set_product_sku()
        self.set_category_info()
        self.set_specific_outlet_ids()
        self.set_specific_merchant_ids()
        self.set_offer_redeemability()
        self.set_featured_merchants_info()

    def process_request(self, *args, **kwargs):

        self.check_limit()
        if self.send_response_flag:
            return
        self.initialize_local_variables()
        self.set_api_configurations()
        self.set_up_api_features()
        self.initialize_modules()
        self.initialize_class_attributes()
        self.set_customer_related_data()
        self.initialize_request_framework()
        self.process_request_params()
        self.set_fuzzy_search_status()
        self.get_tabs_info()
        self.set_ping_section()
        self.get_skip_mode_response()
        if self.send_response_flag:
            return
        self.get_top_up_offers()
        self.set_shared_offers()
        self.process_fuzzy_search()   # TODO: MAJOR TODO!
        self.initialize_offers_criteria()
        self.get_offers_from_cache()
        if not self.offers:
            self.get_offers_from_db()
            self.set_offers_in_cache()
        self.load_featured_merchants()
        self.process_offers()
        self.show_promotional_section()
        self.set_attributes_of_featured_merchants()
        self.prepare_outlet_chunks_to_return()
        self.prepare_filtered_final_outlets()
        self.cashless_processing_for_offer_attributes_selected()
        self.prepare_response()
