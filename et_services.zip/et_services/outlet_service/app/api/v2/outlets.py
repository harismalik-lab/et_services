"""
Outlets API V2
"""

from flask import current_app

from app_configurations.settings import ET_SERVICES_LOG_PATH
from outlet_service.app.api.v1.outlets import OutletsApi
from outlet_service.app.api.v2.validations.outlets_validator import outlet_validation_parser_v2
from outlet_service.common.constants import (
    CATEGORY_API_NAME_RETAIL, CATEGORY_API_NAME_SERVICES, MAX_OUTLETS, VALID_CATEGORIES
)
from outlet_service.common.models.api_configuration import ApiConfiguration
from outlet_service.common.models.offer_wl_active import OfferWlActive
from outlet_service.common.models.outlet import Outlet
from outlet_service.common.models.wl_company import WlCompany
from outlet_service.common.models.wl_product import WlProduct
from outlet_service.common.models.wl_tabs import WlTab
from outlet_service.common.rest_urls import RedemptionServiceAPIUrlsV2
from outlet_service.common.utils.api_utils import (
    get_api_configurations, get_category_codes_for_analytics, get_configured_sku_by_company
)
from outlet_service.common.utils.authentication import get_company
from outlet_service.modules.api_constants import (
    REDEEMABILITY_NOT_REDEEMABLE, REDEEMABILITY_REDEEMABLE, REDEEMABILITY_REDEEMABLE_REUSABLE, REDEEMABILITY_REDEEMED,
    REDEEMABILITY_REUSABLE
)
from outlet_service.modules.api_utils import (
    is_search_string_found, set_images_and_attributes_dynamically, sort_categories
)


class OutletsApiV2(OutletsApi):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/outlets_api_v2.log',
        ),
        'name': 'outlets_api_v2'
    }
    request_parser = outlet_validation_parser_v2

    def populate_request_arguments(self):
        super().populate_request_arguments()
        self.tab_id = self.request_args.get('tid')
        self.merchant_categories = self.request_args.get('categories')
        self.unlocked_user_groups = list(filter(None, self.request_args.get('user_groups').split(",")))

    def initialize_local_variables(self):
        """
        Sets variables for api
        """
        self.company = get_company()
        self.api_configs = get_api_configurations(self.company, current_app.config['ENV'].lower())
        self.redemption_api_urls = RedemptionServiceAPIUrlsV2

    def set_customer_product_ids(self):
        """
        Sets customer unlocked product ids
        """
        if self.unlocked_user_groups:
            product_ids = WlProduct.get_configured_product_ids(
                self.company,
                list(map(int, self.unlocked_user_groups)),
                self.location_id
            )
            if product_ids:
                self.customer['product_ids'] = product_ids

    def get_tabs_info(self):
        """
        Gets tabs info
        """
        self.tab = WlTab.get_by_id_and_company(self.tab_id, self.company)
        if self.tab:
            if self.tab.is_sku_specific and self.tab.sku_list:
                self.product_sku = self.tab.sku_list
        else:
            self.set_customer_product_ids()

    def get_offers_from_db(self):
        self.offers = Outlet.find_offers(
            locale=self.locale,
            company=self.company,
            product_ids=self.customer.get('product_ids'),
            product_sku=self.product_sku,
            offer_redeemability=self.offer_redeemability,
            show_only_core_product_offers=self.show_only_core_product_offers,
            is_cuckoo=self.is_cuckoo,
            is_cheers=self.is_cheers,
            is_delivery=self.is_delivery,
            show_monthly_offers=self.show_monthly_offers,
            show_new_offers=self.show_new_offers,
            is_more_sa=self.is_more_sa,
            user_include_cheers=self.user_include_cheers,
            category=self.category,
            _is_fuzzy_search_on=self._is_fuzzy_search_on,
            _fuzzy_search_outlet_ids=self._fuzzy_search_outlet_ids,
            sub_category_filter=self.sub_category_filter,
            outlet_id=self.outlet_id,
            location_id=self.location_id,
            is_company_specific=self.is_company_specific,
            offer_valid_from_start_date=self.offer_valid_from_start_date,
            offer_valid_from_cut_off_date=self.offer_valid_from_cut_off_date,
            show_merlin_offers=self.api_configs.get(ApiConfiguration.SHOW_MERLIN_OFFERS, False),
            merchant_categories=self.merchant_categories
        )

    def process_outlets(self):
        for outlet in self.outlets:
            outlet = dict((zip(outlet._fields, outlet)))
            if not self.update_outlet(outlet):
                continue
            outlet['product_id'] = self.outlet_offer_info[outlet['id']]['product_id']
            outlet['product_sku'] = self.outlet_offer_info[outlet['id']]['product_sku']
            outlet['top_offer_redeemability'] = self.outlet_offer_info[outlet['id']]['redeemability']
            outlet['top_offer_type'] = self.outlet_offer_info[outlet['id']]['type']
            outlet['is_redeemable'] = self.outlet_offer_info[outlet['id']]['is_redeemable']
            outlet['is_purchased'] = self.outlet_offer_info[outlet['id']]['is_purchased']
            outlet['is_monthly'] = self.outlet_offer_info[outlet['id']]['is_monthly']
            outlet['is_new'] = self.outlet_offer_info[outlet['id']]['is_new']
            outlet['is_cheers'] = self.outlet_offer_info[outlet['id']]['is_cheers']
            outlet['is_delivery'] = self.outlet_offer_info[outlet['id']]['is_delivery']
            outlet['is_more_sa'] = self.outlet_offer_info[outlet['id']]['is_more_sa']
            outlet['is_point_based_offer'] = self.outlet_offer_info[outlet['id']]['is_point_based_offer']
            outlet['locked_image_url'] = ""
            outlet['categories'] = self.outlet_offer_info[outlet['id']]['categories']
            outlet['sub_categories'] = self.outlet_offer_info[outlet['id']]['sub_categories']

            if outlet['categories']:
                outlet['categories'] = sort_categories(outlet['categories'])

            outlet['merchant_categories'] = outlet['categories']
            outlet['merchant_categories_analytics'] = get_category_codes_for_analytics(
                outlet['merchant_categories'])

            outlet['merchant']['categories'] = outlet['merchant_categories']
            outlet['merchant']['categories_analytics'] = outlet['merchant_categories_analytics']

            if self.outlet_offer_info[outlet['id']]['sub_categories']:
                outlet['merchant']['digital_section'] = ", ".join(
                    self.outlet_offer_info[outlet['id']]['sub_categories'])
            else:
                outlet['merchant']['digital_section'] = ""
            if (
                self.category and
                self.category in VALID_CATEGORIES
            ):
                outlet['merchant']['category'] = self.category
            elif outlet['categories']:
                outlet['merchant']['category'] = outlet['categories'][0]
            else:
                outlet['merchant']['category'] = ""

            if self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                if outlet['merchant']['category'] == CATEGORY_API_NAME_RETAIL:
                    outlet['merchant']['category'] = CATEGORY_API_NAME_SERVICES
                company_skus = get_configured_sku_by_company(self.company)
                outlet['is_company_specific'] = self.is_company_specific
                if not outlet['is_company_specific']:
                    for skus in outlet['product_sku']:
                        if skus in company_skus:
                            outlet['is_company_specific'] = True
                            break
            set_images_and_attributes_dynamically(
                self.company,
                outlet,
                self.categories,
                self.category,
                self.api_configs,
                self.tab
            )
            if not self._is_fuzzy_search_on:
                if self.query and self.query_type == 'name':
                    if (
                            not is_search_string_found(outlet['merchant_name'], self.query, True) and
                            outlet['id'] not in self.query_matched_offers_outlets
                    ):
                        continue

            if self.featured_merchants:
                for featured_merchant in self.featured_merchants:

                    if featured_merchant['id'] == outlet['merchant']['id']:

                        featured_merchant['is_featured'] = True
                        featured_merchant['category'] = self.category
                        featured_merchant['categories'] = [self.category]

                        if not featured_merchant['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet.get('is_redeemable')

                        if not featured_merchant['is_purchased']:
                            featured_merchant['is_purchased'] = outlet.get('is_purchased')

                        if not featured_merchant['is_monthly']:
                            featured_merchant['is_monthly'] = outlet.get('is_monthly')

                        if not featured_merchant['is_new']:
                            featured_merchant['is_new'] = outlet.get('is_new')

                        if not featured_merchant['is_cheers']:
                            featured_merchant['is_cheers'] = outlet.get('is_cheers')

                        if not featured_merchant['is_delivery']:
                            featured_merchant['is_delivery'] = outlet.get('is_delivery')

                        if outlet['is_redeemable']:
                            featured_merchant['is_redeemable'] = outlet['is_redeemable']
                        if outlet['is_purchased']:
                            featured_merchant['is_purchased'] = outlet['is_purchased']
                        if outlet['is_monthly']:
                            featured_merchant['is_monthly'] = outlet['is_monthly']
                        if outlet['is_new']:
                            featured_merchant['is_new'] = outlet['is_new']
                        if outlet['is_cheers']:
                            featured_merchant['is_cheers'] = outlet['is_cheers']
                        if outlet['is_delivery']:
                            featured_merchant['is_delivery'] = outlet['is_delivery']

            if (
                self.offer_redeemability != REDEEMABILITY_NOT_REDEEMABLE and
                self.offer_redeemability.lower() != 'all'
            ):
                if (
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMABLE_REUSABLE and
                            not (outlet['top_offer_redeemability'] == OfferWlActive.REDEEMABLE or
                                 outlet['top_offer_redeemability'] == OfferWlActive.REUSABLE)
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REUSABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.REUSABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_NOT_REDEEMABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.NOT_REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMABLE and
                            outlet['top_offer_redeemability'] != OfferWlActive.REDEEMABLE
                        ) or
                        (
                            self.offer_redeemability == REDEEMABILITY_REDEEMED and
                            outlet['top_offer_redeemability'] != OfferWlActive.REDEEMED
                        )
                ):
                    continue
            outlet['merchant_name'] = (outlet['merchant_name'] or '').lower()
            self.final_outlets.append(outlet)
            self.redeemabilities.append(outlet['top_offer_redeemability'])
            self.merchant_names.append((outlet['merchant_name'] or '').lower())
            self.distances.append(outlet['distance'])

    def skip_mode(self):
        """
        Skip mode
        """
        if not self.customer.get('session_token') and not self.unlocked_user_groups:
            super().skip_mode()

    def prepare_final_response(self):
        self.outlet_response = {
            'is_fuzzy_search_results': self._is_fuzzy_search_on,
            'is_fuzzy_server_down': self.is_fuzzy_server_down,
            'limit': MAX_OUTLETS,
            'total_records': self.total_records,
            'search_results': self.search_results,
            'featured_merchants': self.featured_merchants,
            'outlets': self.filtered_outlets
        }
        self.set_response({
            'success': True,
            'message': 'success',
            'data': self.outlet_response
        })
