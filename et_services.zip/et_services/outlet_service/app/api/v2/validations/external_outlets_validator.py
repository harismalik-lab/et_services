"""
External Outlets validation parser
"""
from flask_restful import reqparse

external_outlets_validation_parser = reqparse.RequestParser(bundle_errors=True)

external_outlets_validation_parser.add_argument(
    name="external_id",
    type=str,
    required=True,
    location='json',
    action='append'
)
