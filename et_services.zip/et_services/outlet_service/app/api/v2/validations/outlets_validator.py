"""
Outlets validation parser
"""
from outlet_service.app.api.v1.validations.outlets_validator import outlet_validation_parser

outlet_validation_parser_v2 = outlet_validation_parser

outlet_validation_parser_v2.add_argument(
    name="tid",
    required=False,
    default=0,
    type=int,
    location=['mobile', 'values', 'json']
)
outlet_validation_parser_v2.add_argument(
    'categories',
    type=str,
    action='append',
    required=False,
    default=[],
    location='args'
)
outlet_validation_parser_v2.add_argument(
    'user_groups',
    type=str,
    required=False,
    default="",
    location='args'
)
