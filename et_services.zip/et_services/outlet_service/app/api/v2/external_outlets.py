"""
External Outlets API
    - query `Outlet` to get outlets having external_ids
            - convert query result into dict
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from outlet_service.app.api.v2.validations.external_outlets_validator import external_outlets_validation_parser
from outlet_service.common.base_resource import BasePostResource
from outlet_service.common.models.outlet import Outlet


class ExternalOutletsApi(BasePostResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='outlet_service/external_outlets_api.log',
        ),
        'name': 'external_outlets_api'
    }
    request_parser = external_outlets_validation_parser
    required_token = False

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.external_id = self.request_args.get('external_id')

    def get_external_outlets(self):
        """
        query `Outlet` to get outlets having external_ids
            - convert query result into dict
        """
        self.external_outlets = Outlet.get_outlets_by_external_id(self.external_id)
        self.outlets_hash = {}
        if self.external_outlets:
            for outlet in self.external_outlets:
                outlet = outlet._asdict()
                self.outlets_hash[outlet.pop('external_id')] = outlet

    def prepare_final_response(self):
        self.set_response({
            'success': True,
            'message': 'success',
            'data': self.outlets_hash
        })

    def process_request(self, *args, **kwargs):
        self.get_external_outlets()
        self.prepare_final_response()
