"""
This modules loads APIs for a specific service.
"""
from flask import g

from outlet_service.app.routings.routings_v1 import OutletsAPIV1
from outlet_service.app.routings.routings_v2 import OutletsAPIV2
from outlet_service.app.routings.routings_v3 import OutletsAPIRoutesV3
from outlet_service.app.routings.routings_v4 import OutletsAPIRoutesV4


def api_urls():
    OutletsAPIV1(app=g.app, name=OutletsAPIV1.__name__).map_urls()
    OutletsAPIV2(app=g.app, name=OutletsAPIV2.__name__).map_urls()
    OutletsAPIRoutesV3(app=g.app, name=OutletsAPIRoutesV3.__name__).map_urls()
    OutletsAPIRoutesV4(app=g.app, name=OutletsAPIRoutesV4.__name__).map_urls()
