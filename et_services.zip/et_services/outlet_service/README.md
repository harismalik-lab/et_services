# Outlet Service
It contains Outlet related API endpoints.

## Url Pattern
{{base-url}}/v1/outlets
