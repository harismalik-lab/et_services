"""
App Configurations for UAT Node 3 environment.
"""

import os

NEW_CART_URL = "https://entcartut.theentertainerme.com/products2019?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa: E501
ENV = 'UAT_3'
DEBUG = False
CACHE_KEY_PREFIX = 'UAT'
CACHE_TYPE = 'filesystem'
CACHE_DIR = '{present_directory}/.entertainer_cache'.format(present_directory=os.getcwd())
GENERATE_APM_ERROR_LOGS = False
GENERATE_ALL_APM_LOGS = False
ELASTIC_APM = {
    'SERVICE_NAME': 'ENT Microservices UAT Node 3',
    'SECRET_TOKEN': '',
    'SERVER_URL': 'http://10.1.12.53:8200',
    'AUTO_LOG_STACKS': False,
    'SERVER_TIMEOUT': 1,
    "METRICS_INTERVAL": "0s",
    "METRICS_SETS": [],
    'PROCESSORS': (
        'elasticapm.processors.sanitize_stacktrace_locals',
        'elasticapm.processors.sanitize_http_request_cookies',
        'elasticapm.processors.sanitize_http_headers',
        'elasticapm.processors.sanitize_http_wsgi_env',
        'elasticapm.processors.sanitize_http_request_querystring',
        'elasticapm.processors.sanitize_http_request_body'
    )
}
ELASTIC_SEARCH_IS_ON = False
ELASTIC_SEARCH_BASE_URL = 'http://127.0.0.1:9222/'

SQL_USER = 'eut_api_b2c_pyt'
SQL_PASSWORD = '47sfABg8EGKJWL8yGt7j'
SQL_HOST = '127.0.0.1'
SQL_PORT = 6033
SQL_HOST_MASTER = 'te-uat-rds-pro-cluster.cluster-c0afz6kpjwce.eu-west-1.rds.amazonaws.com'
SQL_PORT_MASTER = 3306

SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://{user}:{pwd}@{host}:{port}'.format(
    user=SQL_USER,
    pwd=SQL_PASSWORD,
    host=SQL_HOST,
    port=SQL_PORT
)
SQL_DB_CONFIG_SLAVE = {
    "database": 'entertainer_web',
    "user": SQL_USER,
    "host": SQL_HOST,
    "password": SQL_PASSWORD,
    "port": SQL_PORT
}
SQL_DB_CONFIG_MASTER = {
    "database": 'entertainer_web',
    "user": SQL_USER,
    "host": SQL_HOST_MASTER,
    "password": SQL_PASSWORD,
    "port": SQL_PORT_MASTER
}
PRIO_API_CREDENTIALS = {
    'user': 'TheEntertainerAsia@prioticket.com',
    'password': 'TheEntertainerAsia_prio@2020',
    'env': 'sandbox-distributor-api',
    'version': '3.2',
    'distributor': 1070301
}