"""
App configurations for Staging environment
"""
import os

SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://dummy:dummy@127.0.0.1:9999'
SQLALCHEMY_BINDS = {
        'master': 'mysql+mysqlconnector://eqa_api_b2b_pyt:WAt962ydHuLHA5mhD6nS@te-qa-db-psql-cluster.cluster-cacgzrn7ibpg.eu-west-1.rds.amazonaws.com:3066',  # noqa
        'slave': 'mysql+mysqlconnector://eqa_api_b2b_pyt:WAt962ydHuLHA5mhD6nS@te-qa-db-psql-cluster.cluster-ro-cacgzrn7ibpg.eu-west-1.rds.amazonaws.com:3066',  # noqa
}
NEW_CART_URL = "https://entqacart.etenvbiz.com/products2018?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa: E501
ENV = 'QA'
DEBUG = False
CACHE_KEY_PREFIX = 'STAGE'
CACHE_TYPE = 'filesystem'
CACHE_DIR = '{present_directory}/.entertainer_cache'.format(present_directory=os.getcwd())
GENERATE_APM_ERROR_LOGS = False
GENERATE_ALL_APM_LOGS = False
ELASTIC_APM = {
    'SERVICE_NAME': 'ENT Microservices QA Node',
    'SECRET_TOKEN': '',
    'SERVER_URL': 'http://10.1.12.53:8200',
    'AUTO_LOG_STACKS': False,
    'SERVER_TIMEOUT': 1,
    "METRICS_INTERVAL": "0s",
    "METRICS_SETS": [],
    'PROCESSORS': (
        'app_configurations.flask_elastic_apm.apm_cutom_span_filter_processor',
        'elasticapm.processors.sanitize_stacktrace_locals',
        'elasticapm.processors.sanitize_http_request_cookies',
        'elasticapm.processors.sanitize_http_headers',
        'elasticapm.processors.sanitize_http_wsgi_env',
        'elasticapm.processors.sanitize_http_request_querystring',
        'elasticapm.processors.sanitize_http_request_body'
    )
}
ELASTIC_SEARCH_IS_ON = False
ELASTIC_SEARCH_BASE_URL = 'http://127.0.0.1:9222/'

PRIO_API_CREDENTIALS = {
    'user': 'TheEntertainerAsia@prioticket.com',
    'password': 'TheEntertainerAsia_prio@2020',
    'env': 'sandbox-distributor-api',
    'version': '3.2',
    'distributor': 1070301
}
