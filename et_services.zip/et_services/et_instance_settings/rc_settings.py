"""
App configurations for RC environment
"""

import os

SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://dummy:dummy@127.0.0.1:9999'
SQLALCHEMY_BINDS = {
        'master': 'mysql+mysqlconnector://prd_api_aft_ets:HyjeryGtyrUDHrydnf@aurora-prod.cluster-c5xz9c2xus1u.eu-west-1.rds.amazonaws.com:3306',
        'slave': 'mysql+mysqlconnector://prd_api_aft_ets:HyjeryGtyrUDHrydnf@aurora-prod.cluster-ro-c5xz9c2xus1u.eu-west-1.rds.amazonaws.com:3306',
}
NEW_CART_URL = "https://entcartut.theentertainerme.com/products2019?et=1&utm_source=app&utm_medium=cart-icon&utm_campaign=cart_icon_app_gbl"  # noqa: E501
ENV = 'RC'
DEBUG = False
CACHE_KEY_PREFIX = 'RC'
CACHE_TYPE = 'filesystem'
CACHE_DIR = '{present_directory}/.entertainer_cache'.format(present_directory=os.getcwd())
GENERATE_APM_ERROR_LOGS = False
GENERATE_ALL_APM_LOGS = False
ELASTIC_APM = {
    'SERVICE_NAME': 'ENT Microservices RC Node',
    'SECRET_TOKEN': '',
    'SERVER_URL': 'http://10.1.12.53:8200',
    'AUTO_LOG_STACKS': False,
    'SERVER_TIMEOUT': 1,
    "METRICS_INTERVAL": "0s",
    "METRICS_SETS": [],
    'PROCESSORS': (
        'app_configurations.flask_elastic_apm.apm_cutom_span_filter_processor',
        'elasticapm.processors.sanitize_stacktrace_locals',
        'elasticapm.processors.sanitize_http_request_cookies',
        'elasticapm.processors.sanitize_http_headers',
        'elasticapm.processors.sanitize_http_wsgi_env',
        'elasticapm.processors.sanitize_http_request_querystring',
        'elasticapm.processors.sanitize_http_request_body'
    )
}
ELASTIC_SEARCH_IS_ON = True
ELASTIC_SEARCH_BASE_URL = 'http://127.0.0.1:9222/'
PASSWORD_RESET_URL = "https://rcenter.theentertainerme.com/resetpassword?token="
