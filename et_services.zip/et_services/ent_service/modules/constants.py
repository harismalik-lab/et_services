"""
Constants for Entertainer service
"""
BIRTHDAY_OFFER = 'Birthday Offer'
CATEGORIES = 'categories'
DUBAI_ENTERTAINMENTS_WHAT_NEW = "What’s New"
FEATURED = 'featured'
FEATURED_SECTIONS = 'featured_sections'
LOG_SUB_FOLDERS = []
MAIN_COVER = 'main_cover'
MESSAGES_WHEN_SAVINGS_0 = [
    "Haven't started saving yet? Use your offers today - go _UserName__!",
    "You have 0 savings _UserName__. Let's change that today, shall we?",
    "Hey _UserName__, today looks like a good day to start saving!"
]
MESSAGES_WHEN_SAVINGS_FROM_1_TO_500 = [
    "You’re off to a great start with _SAVINGS_VALUE_ saved. Keep at it _UserName__!",
    "Yay - you’ve saved _SAVINGS_VALUE_ so far! Carry on using your offers _UserName__!",
    "Woo-hoo, _SAVINGS_VALUE_ is in the bag! Save some more today _UserName__!",
    "You’re on a roll with _SAVINGS_VALUE_ saved up. More savings coming your way _UserName__!",
    "Congratulations for saving _SAVINGS_VALUE_! Here’s to more milestones with your offers."
]
MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500 = [
    "You’ve saved _SAVINGS_VALUE_ so far! Great going _UserName__!",
    "Savings worth _SAVINGS_VALUE_ in the bag! Keep at it _UserName__!",
    "Woot – you’re on to good things with _SAVINGS_VALUE_ saved so far!",
    "Yay – You’ve saved _SAVINGS_VALUE_ so far! Don’t stop now _UserName__!",
    "It’s raining _CURRENCY_ _UserName__ – you’ve saved _SAVINGS_VALUE_ so far, well done!"
]
MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000 = [
    "Ka-ching! You’ve saved _SAVINGS_VALUE_ so far, way to go _UserName__!",
    "_SAVINGS_VALUE_ saved so far! You’re on fire _UserName__!",
    "Whoa, _SAVINGS_VALUE_ worth SAVINGS! You should be proud of yourself _UserName__.",
    "Ooh, your savings worth _SAVINGS_VALUE_ look so good! Keep 'em coming _UserName__!",
    "Where’s the party at _UserName__!? Cheers for saving _SAVINGS_VALUE_!"
]
MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000 = [
    "Word’s out that you’re a rainmaker with _SAVINGS_VALUE_ saved up. Way to go _UserName__!",
    "Holla _UserName__! _SAVINGS_VALUE_ in savings is something to brag about. Great going!",
    "Whoa - you’ve saved _SAVINGS_VALUE_ so far! Take a bow _UserName__.",
    "Congratulations & celebrations for saving _SAVINGS_VALUE_ _UserName__!",
    "Cue the confetti – you’ve saved _SAVINGS_VALUE_! Cheers _UserName__!"
]
PARAM_VALUE_GEMS_STUDENT_PATIENT_ID = '{student_parent_id}'
PARAM_VALUE_GEMS_BSU = '{bsu}'
TYPE_EXTRA = "extra"
TYPE_FEATURED = "featured"
TYPE_FOR_THE_WEEKEND = "for_the_weekend"
TYPE_GEMS_REFERAL = "gems_referral"
