"""
Contains API Specific Modules
"""
from collections import OrderedDict
from urllib.parse import urlencode

from flask import g
from rsa import encrypt

from ent_service.common.constants import AED, CN, EN
from ent_service.common.models.exchange_rate import ExchangeRate
from ent_service.common.models.extended_trial_rules import ExtendedTrialRule
from ent_service.common.models.home_screen_configurations import HomeScreenConfiguration
from ent_service.common.models.home_screen_configurations_section import HomeScreenConfigurationsSection
from ent_service.common.models.user_saving import UserSaving
from ent_service.common.utils.translation_manager import TranslationManager
from ent_service.modules import constants

cache = g.cache


def get_user_yearly_savings(
        user_id,
        currency,
        locale='en',
        message_to_append_with_this_year_savings='Saved this year',
        company='entertainer'
):
    """
    The method gets user's yearly savings
    :param int user_id: User Id
    :param str currency: Currency
    :param str locale: Locale
    :param str message_to_append_with_this_year_savings: Message you want to append
    :param str company: User's company name
    :rtype: dict
    """
    savings_response = {
        'offers_used': 0,
        'savings_this_year': 0,
        'savings_this_year_aed': 0
    }
    if locale == CN:
        savings_response['savings_this_year_label'] = message_to_append_with_this_year_savings
    else:
        savings_response['savings_this_year_label'] = '{currency} {message}'.format(
            currency=currency,
            message=message_to_append_with_this_year_savings)
    if user_id == 0:
        return savings_response

    yearly_savings = UserSaving.get_user_yearly_savings(user_id, company)
    if yearly_savings:
        yearly_savings = yearly_savings._asdict()
        yearly_savings['offers_used'] = int(yearly_savings.get('offers_used', 0))
        yearly_savings['savings_this_year_aed'] = int(yearly_savings.get('savings_this_year', 0))
        yearly_savings['savings_this_year_label'] = ''  # check this and next two as well
        yearly_savings['total_points'] = int(yearly_savings.get('total_points', 0))
        yearly_savings['gems_savings'] = int(yearly_savings.get('gems_savings', 0))

        if locale == CN:
            yearly_savings['savings_this_year_label'] = message_to_append_with_this_year_savings
        else:
            yearly_savings['savings_this_year_label'] = '{currency} {message}'.format(
                currency=currency,
                message=message_to_append_with_this_year_savings)
        yearly_savings['savings_this_year'] = round(ExchangeRate.get_conversion_rate(
            yearly_savings['savings_this_year'], AED, currency
        ))
        return yearly_savings
    return savings_response


@cache.memoize(timeout=1800)
def get_home_screen_conf(location_id, user_group=0, company='', locale=EN):
    """
    Gets all home screen configurations section
    :param  int location_id: user location id
    :param  int user_group:  user group
    :param  str company:     user company
    :param  str locale:      user language
    """
    count = 0
    result = HomeScreenConfigurationsSection.get_all(location_id, user_group, company, locale)
    if not result and count == 0:
        count += 1
        result = HomeScreenConfigurationsSection.get_all(location_id=0, user_group=0, company=company, locale=locale)

    home_scr_conf = OrderedDict()
    rec_status = {}  # 0= > no record, 1= > both location and group, 2= > only group
    for item in result:
        item = item._asdict()
        # check if location and user group both present
        if item.get('location_id') == location_id and item.get('user_group') == user_group:
            home_scr_conf[item['section_name']] = item
            rec_status[item['section_name']] = 1
        elif not item['location_id'] and item['user_group'] == user_group and user_group > 0:
            if not rec_status[item['section_name']] or not rec_status[item['section_name']] == 1:
                home_scr_conf[item['section_name']] = item
                rec_status[item['section_name']] = 2
        else:
            if not rec_status.get(item.get('section_name')):
                home_scr_conf[item.get('section_name')] = item
    return home_scr_conf


def get_saving_messages(savings, locale=EN, replacement_data=None):
    """
    Gets savings messages translated into desired locale
    """
    message = []
    if savings == 0:
        message = get_savings_translation(
            constants.MESSAGES_WHEN_SAVINGS_0,
            savings,
            replacement_data
        )
        return message
    elif 1 <= savings <= 500:
        message = get_savings_translation(
            constants.MESSAGES_WHEN_SAVINGS_FROM_1_TO_500,
            savings,
            replacement_data
        )
        return message
    elif 501 <= savings <= 2500:
        message = get_savings_translation(
            constants.MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500,
            savings,
            replacement_data
        )
        return message
    elif 2501 <= savings <= 5000:
        message = get_savings_translation(
            constants.MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000,
            savings,
            replacement_data
        )
        return message
    elif 5001 <= savings:
        message = get_savings_translation(
            constants.MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000,
            savings,
            replacement_data
        )
        return message
    return message


def get_savings_translation(message_list, savings, replacement_data):
    """
    Gets savings translations
    """
    translated_messages = []
    if replacement_data:
        for message_line in message_list:
            savings_value_str = '{currency} {savings}'.format(
                currency=replacement_data.get('currency', ''),
                savings=savings
            )
            user_name = ''
            if replacement_data.get('firstname', ''):
                user_name = replacement_data.get('firstname', '')
            message_line = message_line.replace('_UserName__', user_name.lower().title())
            message_line = message_line.replace('_SAVINGS_VALUE_', savings_value_str)
            message_line = message_line.replace('_CURRENCY_', replacement_data.get('currency', ''))
            translated_messages.append(message_line)
    return translated_messages


def get_sub_section(all_sections, sub_section_type, locale=EN):
    """
    Gets the list of sub sections.
    :param list all_sections: List of all sections
    :param str sub_section_type: Subsection type
    :param str locale: Locale
    :rtype: list
    """
    sub_sections = []
    for section in all_sections:
        if section.get('link_type') == sub_section_type:
            is_external_link = section.get('is_external_link', False)
            sub_sections.append({
                "tile_id": section.get('id'),
                "image": section.get('image_url'),
                "logo": section.get('logo_url'),
                "message": section.get('title'),
                "is_deep_link": bool(section.get('deep_link')),  # True If not None or not empty else False
                "deep_link": section.get('deep_link'),
                "is_external_link": bool(is_external_link),
                "tile_bottom_banner_color": section.get('tile_bottom_banner_color'),
            })
    return sub_sections


def get_gems_ambassador_program_url(gems_referral_url, gems_encryption_key, parent_id, BSU):
    """
    Get gems ambassador program url
    :param: gems_referral_url
    :param: gems_encryption_key
    :param: parent_id
    :param: BSU
    """
    parent_id_encrypted = encrypt(gems_encryption_key, parent_id)
    BSU_encrypted = encrypt(gems_encryption_key, BSU)

    parent_id_encrypted = urlencode(parent_id_encrypted)
    BSU_encrypted = urlencode(BSU_encrypted)

    parent_id_encrypted = parent_id_encrypted.replace("%", "_")
    BSU_encrypted = BSU_encrypted.replace("%", "_")

    __url = gems_referral_url
    __url = __url.replace(constants.PARAM_VALUE_GEMS_STUDENT_PATIENT_ID, parent_id_encrypted, __url)
    __url = __url.replace(constants.PARAM_VALUE_GEMS_BSU, BSU_encrypted, __url)

    return __url


def get_home_screen_tiles(
        locale, location_id, company, user_group, branding_attributes, savings_messages, user_yearly_savings
):
    """
    Home screen tiles

    :param locale: Locale
    :param location_id: id of location
    :param company: company
    :param user_group: user group
    :param branding_attributes: company branding attributes
    :param savings_messages: saving of message
    :param user_yearly_savings: yearly saving of user
    :return:
    """
    tiles = HomeScreenConfiguration.get_all_sections(
        locale=locale,
        location_id=location_id,
        company=company,
        user_group=user_group
    )

    tiles_arr = {}
    for tile in tiles:
        tile = tile._asdict()
        tile["tile_id"] = tile.get('id')
        tile["image"] = tile.get('image_url')
        tile["logo"] = tile.get('logo_url')
        tile["message"] = tile.get('title')
        tile["is_deep_link"] = True if tile.get('deep_link') else False

        if tile.get('link_type') == 'ent_deal_pack':
            tile['product_info'] = {
                'currency': '',
                'price': '',
                'title': tile['title'],
                'sub_title': TranslationManager.get_translation(TranslationManager.UPGRADE_APP, locale),
                'desc': tile.get('description'),
                'purchase_link': tile.get('deep_link')
            }

        if tile['link_type'] == 'messaging_tile':
            tile['identifier'] = tile.get('link_type')
            tile["synsodyne_code"] = tile.get('description')
            tile["messages"] = savings_messages
            tile["main_top_image"] = branding_attributes.get('main_top_image')
            tile["main_top_color"] = branding_attributes.get('main_top_color')
            tile["main_top_text_color"] = branding_attributes.get('main_top_text_color')

        if tile['link_type'] == 'savings_tile':
            tile['identifier'] = tile.get('link_type')
            tile["savings"] = user_yearly_savings

        if not tiles_arr.get(tile['section_identifier']):
            tiles_arr[tile['section_identifier']] = []
        tiles_arr[tile['section_identifier']].append(tile)
    return tiles_arr


@cache.memoize(timeout=3600)
def extended_trail_rules(extended_trail_group_ids=[], location_id=0):
    """
    Gets trail extended rules object of specific location
    :param list extended_trail_group_ids:
    :param int location_id:
    :rtype: dict
    """
    extended_trail_rules_sql = ExtendedTrialRule.user_trial_extended_rules(
        extended_trail_group_ids=extended_trail_group_ids
    )
    extended_trail_rules = []
    for rule in extended_trail_rules_sql:
        rule = rule.__dict__
        if rule.get('location_id') == location_id:
            extended_trail_rules.append(rule)
        # as travel dont hai location id
        elif str(rule.get('category', '')).lower() == 'travel' and not rule.get('location_id'):
            extended_trail_rules.append(rule)
    rules = dict()
    rules['categories'] = []
    rules['category_info'] = {}
    rules['getaways_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_travel_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_cheers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_delivery_info'] = {'enabled': False, 'saving_estimates': []}
    rules['cashless_delivery_enabled_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_monthly_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_more_sa_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_merlin_offer_info'] = {'enabled': False, 'saving_estimates': []}
    rules['has_cinema_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_bonus_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_johor_bahru_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_product_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fine_dining_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_family_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fitness_product'] = {'enabled': False, 'saving_estimates': []}
    for rule in extended_trail_rules:
        category = ''
        if rule.get('category'):
            category = rule.get('category')

        rules['categories'].append(category)
        try:
            rules['category_info'][category]
        except KeyError:
            rules['category_info'][category] = dict()
            rules['category_info'][category]['saving_estimates'] = []
            rules['category_info'][category]['sub_rules'] = False
            rules['category_info'][category]['rules'] = dict()
            rules['category_info'][category]['rules']['is_more_sa'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_travel'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_cheers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_delivery'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['cashless_delivery_enabled'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_merlin_offer'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_monthly'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_bonus_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['has_cinema_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fine_dining_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_family_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fitness_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_johor_bahru'] = {
                'enabled': False, 'saving_estimates': []
            }
        rules['category_info'][category]['saving_estimates'].append(
            rule.get('max_savings_estimate_cap', 0)
        )

        if rule.get('enabled_getaways'):
            rules['getaways_info']['enabled'] = True
        if rule.get('enabled_travel_offers'):
            rules['is_travel_info']['enabled'] = True
            rules['is_travel_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_travel']['enabled'] = True
            rules['category_info'][category]['rules']['is_travel']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cheer_offers'):
            rules['is_cheers_info']['enabled'] = True
            rules['is_cheers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_cheers']['enabled'] = True
            rules['category_info'][category]['rules']['is_cheers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_delivery_offers'):
            rules['is_delivery_info']['enabled'] = True
            rules['is_delivery_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_delivery']['enabled'] = True
            rules['category_info'][category]['rules']['is_delivery']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cashless_offers'):
            rules['cashless_delivery_enabled_info']['enabled'] = True
            rules['cashless_delivery_enabled_info']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['cashless_delivery_enabled']['enabled'] = True
            rules['category_info'][category]['rules']['cashless_delivery_enabled']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_monthly_offers'):
            rules['is_monthly_info']['enabled'] = True
            rules['is_monthly_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_monthly']['enabled'] = True
            rules['category_info'][category]['rules']['is_monthly']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('more_offers'):
            rules['is_more_sa_info']['enabled'] = True
            rules['is_more_sa_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_more_sa']['enabled'] = True
            rules['category_info'][category]['rules']['is_more_sa']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_merlin_offers'):
            rules['is_merlin_offer_info']['enabled'] = True
            rules['is_merlin_offer_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['enabled'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_cinema_offers'):
            rules['has_cinema_offers_info']['enabled'] = True
            rules['has_cinema_offers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['enabled'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_bonus_offers'):
            rules['is_bonus_offers_info']['enabled'] = True
            rules['is_bonus_offers_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['enabled'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_johor_baru_offers'):
            rules['is_johor_bahru_info']['enabled'] = True
            rules['is_johor_bahru_info']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['enabled'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_fine_dining_offers'):
            rules['is_core_fine_dining_product']['enabled'] = True
            rules['is_core_fine_dining_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_family_offers'):
            rules['is_core_family_product']['enabled'] = True
            rules['is_core_family_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
        if rule.get('enabled_core_product_fitness_offers'):
            rules['is_core_fitness_product']['enabled'] = True
            rules['is_core_fitness_product']['saving_estimates'].append(rule.get('max_savings_estimate_cap', 0))
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['saving_estimates'].append(
                rule.get('max_savings_estimate_cap', 0)
            )
    return rules
