# Entertainer Service
It contains Entertainer related API endpoints.

## Url Pattern
{{base-url}}/v1/ent/
