"""
This module contains routing for Entertainer app
"""
from flask import current_app

from ent_service.app.api.v1.category_home import CategoryHomeScreen
from ent_service.app.api.v1.home import HomeApi
from ent_service.common.base_routing import BaseRouting


class EntertainerAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['ENT_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['home_api'] = {
            'url': '/home',
            'view': HomeApi
        }
        self.routing_collection['category_home_api'] = {
            'url': '/categories/home',
            'view': CategoryHomeScreen
        }
