"""
This module contains routing for Entertainer app
"""
from ent_service.app.api.v2.home import HomeApiV2
from ent_service.app.routings.routings_v1 import EntertainerAPIV1


class EntertainerAPIV3(EntertainerAPIV1):
    api_version = '3'

    def set_routing_collection(self):
        super().set_routing_collection()
        self.routing_collection['home_api'] = {
            'url': '/home',
            'view': HomeApiV2
        }
