"""
This modules loads APIs for Entertainer service
"""
from flask import g

from ent_service.app.routings.routings_v1 import EntertainerAPIV1
from ent_service.app.routings.v3 import EntertainerAPIV3


def api_urls():
    EntertainerAPIV1(app=g.app, name=EntertainerAPIV1.__name__).map_urls()
    EntertainerAPIV3(app=g.app, name=EntertainerAPIV3.__name__).map_urls()
