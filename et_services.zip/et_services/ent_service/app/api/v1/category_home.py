"""
Category home screen service
"""

import datetime

from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.utils.api_utils import (
    get_delivery_enabled_location_ids_against_company, get_takeaways_enabled_location_ids_against_company
)
from ent_service.app.api.v1.validations.category_home import category_home_api_parser
from ent_service.common.base_resource import BaseGetResource
from ent_service.common.constants import (
    ANALYTICS_CATEGORY_CODES_DICT, ATTRIBUTE_SELECTION_TYPE_MULTIPLE, CATEGORY_BADGES,
    CATEGORY_NAME_RESTAURANTS_AND_BARS, FEATURED_HOMES_IMAGE, PARAM_NAME_ANALYTICS_CUISINES,
    PARAM_NAME_ANALYTICS_SUB_CATEGORIES, PARAM_NAME_API_CUISINES, PARAM_NAME_API_SUB_CATEGORIES, TYPE_VIRTUAL_CURRENCY
)
from ent_service.common.models.category import Category
from ent_service.common.models.category_home_screen_configurations import CategoryHomeScreenConfiguration
from ent_service.common.models.cuisine import Cuisine
from ent_service.common.models.ent_customer_profile import EntCustomerProfile
from ent_service.common.models.location import Location
from ent_service.common.models.merchant_subcategory import MerchantSubCategory
from ent_service.common.models.offer import Offer
from ent_service.common.models.outlet import Outlet
from ent_service.common.models.product_ent_active import ProductEntActive
from ent_service.common.models.redemption import Redemption
from ent_service.common.models.share_offer import ShareOffer
from ent_service.common.models.top_up_offers import TopUpOffer
from ent_service.common.utils.api_utils import (
    BADGE_DELIVERY_COLOR, BADGE_URL_DELIVERY, BADGE_URL_DELIVERY_OFFERS_BORDER_LESS, calculate_distance,
    calculate_offer_redeemability_for_customer_details, count_offer_redemptions_by_customer,
    count_offer_redemptions_by_customer_shared_offers, get_birthday_offer_validity_in_days, get_category_color_code,
    get_category_home_screen_tabs, get_filter_item, get_locale, get_locale_location_id, get_offer_monthly_status,
    multi_key_sort, redeemed_quantities_for_customer, set_image_and_attributes
)
from ent_service.common.utils.authentication import get_current_customer, token_decorator_v3
from ent_service.common.utils.translation_manager import TranslationManager
from ent_service.modules.api_modules import extended_trail_rules

__author__ = 'ali_zuhaib'


class CategoryHomeScreen(BaseGetResource):
    """
    Category home screen configuration
    @api {get} v3 Gets category home screen
    @apiSampleRequest /v3/categories/home
    @apiVersion 3.0.0
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ent_service/category_home_api.log',
        ),
        'name': 'category_home_api'
    }
    request_parser = category_home_api_parser
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.latitude = self.request_args.get('lat')
        self.longitude = self.request_args.get('lng')
        self.category = self.request_args.get('category')
        self.location_id = self.request_args.get('location_id')
        self.locale = self.request_args.get('language')
        self.show_monthly_offers_product_wise = self.request_args.get('show_monthly_offers_product_wise')

    def process_request_args(self):
        """
        Process request args
        """
        self.content_locale = get_locale_location_id(self.locale, self.location_id)
        self.message_locale = get_locale(self.locale)

    def initialize_class_params(self):
        """
        Initializes the class params of category home screen api
        """
        self.is_active_family_member = False
        self.primary_user_id = 0
        self.shared_offers_received_family = []
        self.shared_offers_pinged_family = []
        self.personal_shared_redemptions_count_records = {}
        self.rules = {}
        self.member_group = EntCustomerProfile.MEMBERSTATUS_PROSPECT
        self.birth_date = False
        self.is_customer_own_cheers_for_location = False
        self.redemptions_quantities = []
        self.top_up_offers = []
        self.offers_pinged = []
        self.featured_merchants = []
        self.categories_home_screen_sections = []
        self.outlet_offers_array_with_redeemability = []
        self.outlet_offers_redeemable_array = []
        self.outlet_offers_not_redeemable_array = []
        self.outlet_offers_cheers_redeemable_array = []
        self.outlet_offers_cheers_not_redeemable_array = []
        self.outlet_offers_delivery_redeemable_array = []
        self.outlet_offers_delivery_not_redeemable_array = []
        self.outlet_offers_monthly_redeemable_array = []
        self.top_up_offers_bucket = {}
        self.offers_pinged_bucket = {}
        self.offer_ids = []
        self.customer_redemptions_records = {}
        self.shared_offers_receive = {}
        self.shared_redemptions_count_records = {}
        self.outlet_offer_info = {}
        self.hashed_outlets = {}
        self.hashed_featured_merchants = {}
        self.outlet_offers_more_africa_redeemable_array = []
        self.outlet_track = {}

    def get_sections(self):
        """
        Gets all the category home screen sections
        :rtype: list
        """
        self.sections = CategoryHomeScreenConfiguration.get_category_home_screen_configurations(
            location_id=self.location_id,
            category=self.category,
            company=self.company,
            locale=self.message_locale
        )
        if not self.sections:
            self.send_response_flag = True
            self.set_response(
                {
                    'success': True,
                    'message': 'success',
                    'data': {
                        'sections': []
                    }
                },
                code=200
            )
            self.status_code = codes.OK

    def get_customer(self):
        """
        Gets all the details of the customer
        """
        self.customer = get_current_customer()
        self.enable_shared_offers = self.customer.get('enable_shared_offers')
        self.enable_ping_feature = self.customer.get('enable_ping_feature')
        self.enable_top_up_offers = self.customer.get('enable_top_up_offers')
        self.enable_extended_trial = self.customer.get('enable_extended_trial')
        self.take_away_flow = self.customer.get('takeaway')
        self.enable_birthday_feature = self.customer.get('enable_birthday_feature')
        self.company_type = self.customer.get('company_type')
        company = self.customer.get('company')
        if company.startswith('entertainer'):
            self.company = 'entertainer'
        else:
            self.company = company

    def set_birthday_product_ids(self):
        """
        Sets birthday product ids of customer
        """
        if self.enable_birthday_feature:
            if (
                (self.member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER or self.is_active_family_member) and
                self.birth_date
            ):
                number_of_birthday_validity_days = get_birthday_offer_validity_in_days(self.birth_date)
                if number_of_birthday_validity_days > -1:
                    birthday_ids = ProductEntActive.get_birthday_product_ids(self.location_id)
                    self.customer['product_ids'] += birthday_ids

    def get_featured_merchants(self):
        """
        Gets featured merchants
        """
        featured_image_category = self.category
        if self.member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER or self.is_active_family_member:
            featured_merchants = Offer().get_featured_merchants_cached(
                locale=self.content_locale,
                location_id=self.location_id,
                category=self.category,
                api_version=self.api_version
            )
            outlet_label_singular = TranslationManager().get_translation(
                TranslationManager.OUTLET_COUNT_SINGULAR,
                self.locale
            )
            outlet_label_plural = TranslationManager().get_translation(
                TranslationManager.OUTLET_COUNT_PLURAL,
                self.locale
            )
            for featured_merchant in featured_merchants:
                featured_merchant = dict((zip(featured_merchant._fields, featured_merchant)))
                featured_merchant['is_featured'] = bool(featured_merchant.get('is_featured', 0))
                featured_merchant['featured_image'] = FEATURED_HOMES_IMAGE.get(featured_image_category)
                featured_merchant['outlets_count'] = int(featured_merchant.get('outlets_count', 0))
                if featured_merchant['outlets_count']:
                    featured_merchant['outlets_info'] = '{outlets_count} {label}'.format(
                        outlets_count=featured_merchant['outlets_count'],
                        label=outlet_label_singular if featured_merchant['outlets_count'] == 1 else outlet_label_plural
                    )
                if featured_merchant.get('id') and int(featured_merchant.get('id', 0)):
                    self.featured_merchants.append(featured_merchant)
            for index, featured_merchant in enumerate(self.featured_merchants):
                featured_merchant = dict((zip(featured_merchant._fields, featured_merchant)))
                self.hashed_featured_merchants[featured_merchant['id']] = index

    def get_extended_trial_rules_current_customer(self, location_id=0):
        """
        Fetch trail rules of current request user
        :param int location_id: location id
        :rtype: dict
        """
        rules = {}
        if self.customer.get('is_member_on_trial') and self.customer.get('is_using_extended_trial'):
            rules = extended_trail_rules(
                extended_trail_group_ids=self.customer.get('extended_trial_ids', []),
                location_id=location_id
            )
        return rules

    def get_customer_related_data(self):
        """
        Sets the customer info to class object
        """
        if self.customer and self.customer.get('customer_id'):
            self.is_active_family_member = self.customer.get('family_is_active') and self.customer.get('is_user_in_family')  # noqa: E501
            if self.is_active_family_member and self.customer['is_primary']:
                self.primary_user_id = self.customer['customer_id']
            elif self.is_active_family_member:
                self.primary_user_id = self.customer['primary_member_info']['user_id']
            self.customer['product_ids'] = list(map(int, filter(None, self.customer.get('product_ids', []))))
            if self.is_active_family_member:
                self.redemptions_quantities = redeemed_quantities_for_customer(
                    customer_id=self.customer['customer_id'],
                    company=self.company,
                    primary_user_id=self.primary_user_id,
                    family_id=self.customer['family_info'].id
                )
                if self.enable_shared_offers:
                    self.shared_offers_received_family = ShareOffer().get_shared_offers_accepted(
                        self.customer['customer_id'],
                        primary_user_id=self.primary_user_id
                    )
                if self.enable_ping_feature:
                    self.offers_pinged = ShareOffer().get_shared_offers_by_sender(
                        self.customer['customer_id'],
                        primary_user_id=self.primary_user_id
                    )
            else:
                self.redemptions_quantities = redeemed_quantities_for_customer(
                    customer_id=self.customer['customer_id'],
                    company=self.company,
                    is_onboarding=self.customer.get('is_using_trial')
                )
                if self.enable_ping_feature:
                    self.offers_pinged = ShareOffer().get_shared_offers_by_sender(self.customer['customer_id'])
            if self.enable_shared_offers:
                self.shared_offers_receive = ShareOffer().get_shared_offers_accepted(self.customer['customer_id'])

            for offer_pinged in self.offers_pinged:
                offer_pinged = offer_pinged._asdict()
                if not self.offers_pinged_bucket.get(offer_pinged['offer_id']):
                    self.offers_pinged_bucket[offer_pinged['offer_id']] = 1
                else:
                    self.offers_pinged_bucket[offer_pinged['offer_id']] += 1

            if self.enable_top_up_offers:
                self.top_up_offers = TopUpOffer().get_top_up_offers(
                    customer_id=self.customer['customer_id'],
                    location_id=self.location_id,
                    merchant_id=0,
                    offer_type=TYPE_VIRTUAL_CURRENCY,
                    primary_user_id=self.primary_user_id
                )
            for top_up_offer in self.top_up_offers:
                top_up_offer = top_up_offer._asdict()
                if not self.top_up_offers_bucket.get(top_up_offer['offer_id']):
                    self.top_up_offers_bucket[top_up_offer['offer_id']] = 1
                else:
                    self.top_up_offers_bucket[top_up_offer['offer_id']] += 1

            self.customer_profile_info = EntCustomerProfile().get_customer_profile_info(self.customer['customer_id'])
            if self.customer_profile_info:
                customer_profile_info = self.customer_profile_info._asdict()
                self.member_group = customer_profile_info.get('member_group')
                self.birth_date = customer_profile_info.get('birth_date')
            if self.is_active_family_member:
                self.member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER

            self.set_birthday_product_ids()
            self.get_featured_merchants()
            self.rules = {}
            if self.enable_extended_trial:
                self.rules = self.get_extended_trial_rules_current_customer(location_id=self.location_id)

    def get_offers_list(self):
        """
        Gets list of offers
        :rtype: list
        """
        offer_obj = Offer().get_offer_array(
            self.location_id,
            self.company,
            self.category,
            self.content_locale,
            self.api_version
        )
        offers = []
        for offer in offer_obj:
            offer_ = offer._asdict()
            offer_["is_monthly"] = get_offer_monthly_status(offer_, self.show_monthly_offers_product_wise)
            offers.append(offer_)

        return offers

    def set_shared_redemptions_count_record(self):
        """
        Set shared_redemptions_count_records.
        """
        if self.shared_offers_receive:
            self.shared_redemptions_count_records = count_offer_redemptions_by_customer_shared_offers(
                self.customer['customer_id'], company=self.company, offer_id=self.offer_ids, group_by=True
            )

    def set_shared_redemptions_count_records(self):
        """
        Set shared_redemptions_count_records.
        """
        self.set_shared_redemptions_count_record()
        if self.is_active_family_member:
            if self.shared_offers_received_family:
                self.personal_shared_redemptions_count_records = count_offer_redemptions_by_customer_shared_offers(  # noqa
                    self.customer['customer_id'], company=self.company, offer_id=self.offer_ids, group_by=True,
                    is_active_family_member=self.is_active_family_member, primary_user_id=self.primary_user_id
                )

    def set_offer_attributes(self, offer):
        """
        Sets offer attributes data
        :param offer: Offers
        """
        current_datetime = datetime.datetime.now()
        offer_valid_from_start_date = datetime.datetime.strptime(
            '{year}-01-31'.format(year=current_datetime.year), '%Y-%m-%d'
        )
        offer_valid_from_cut_off_date = current_datetime.replace(hour=0, minute=0, second=0)
        offer_valid_from_cut_off_date = offer_valid_from_cut_off_date - datetime.timedelta(days=30)
        if offer['type'] == Offer.TYPE_MEMBER:
            offer['is_monthly'] = True
        else:
            offer['is_monthly'] = False
        if (
                offer['is_entertainer'] and offer['type'] != Offer.TYPE_MEMBER and
                offer['valid_from_date'] > offer_valid_from_start_date and
                offer['valid_from_date'] > offer_valid_from_cut_off_date
        ):
            offer['is_new'] = True
        else:
            offer['is_new'] = False
        offer['is_monthly'] = get_offer_monthly_status(
            offer, show_monthly_offers_product_wise=self.show_monthly_offers_product_wise
        )

    def is_offer_redeemable_monthly(self, offer):
        """
        Return offer monthly reedeemable status

        :param dict offer: offer data
        :return bool: flag for offer redeemable monthly status
        """
        if offer.get('is_redeemable', 0) and offer['type'] == Offer.TYPE_MEMBER:
            return True
        return False

    def update_category_specific_offer_data(self, offer):
        """
        Updates specific category offer data
        :param offer: Offer data
        """
        offer['category_image'] = CATEGORY_BADGES.get(self.category, '')
        offer['categories_analytics'] = ANALYTICS_CATEGORY_CODES_DICT.get(self.category.lower(), '')
        offer['category_color'] = get_category_color_code(self.category)

    def set_redeemability(self, offer):
        """
        Sets offer redeemability value
        :param offer: Offer data
        """
        top_up_count = self.top_up_offers_bucket.get(offer['id'], 0)
        pinged_offer_count = self.offers_pinged_bucket.get(offer['id'], 0)
        offer_count_received_via_ping = 0
        if pinged_offer_count:
            offer['top_up_offer'] = True
        else:
            offer['top_up_offer'] = False

        redeemability = calculate_offer_redeemability_for_customer_details(
            offer=offer,
            savings_estimate=offer.get('savings_estimate', 0),
            category=self.category,
            customer=self.customer,
            location_id=self.location_id,
            redemptions_quantities=self.redemptions_quantities,
            shared_count_receive=offer_count_received_via_ping,
            shared_count_sent=pinged_offer_count,
            top_up_offer=offer['top_up_offer'],
            top_up_count=top_up_count,
            offer_redeemability=Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
            member_group=self.member_group,
            customer_redemptions_records=self.customer_redemptions_records,
            shared_redemptions_count_records=self.shared_redemptions_count_records,
            is_active_family_member=self.is_active_family_member,
            primary_user_id=self.primary_user_id,
            rules=self.rules
        )
        offer['is_redeemable'] = redeemability.get('is_redeemable', 0)
        offer['is_redeemable_monthly'] = self.is_offer_redeemable_monthly(offer)
        offer['is_redeemable_delivery'] = redeemability.get('is_redeemable', 0) and offer['is_delivery']
        offer['is_redeemable_cheers'] = redeemability.get('is_redeemable', 0) and offer['is_cheers']
        offer['is_redeemable_more_sa'] = redeemability.get('is_redeemable', 0) and offer['is_more_sa']

        offer['redeemability'] = redeemability['redeemability']
        offer['times_redeemed'] = redeemability['times_redeemed']
        offer['is_purchased'] = redeemability['is_purchased']

    def update_featured_merchant(self, featured_merchant, outlet):
        """
        Updates featured merchant information
        :param featured_merchant:
        :param outlet:
        """
        if not featured_merchant.get('merchant'):
            featured_merchant['merchant'] = {}
        if self.category == CATEGORY_NAME_RESTAURANTS_AND_BARS:
            if not featured_merchant.get('merchant', {}).get('cuisines'):
                featured_merchant['merchant'] = {'cuisines': []}
            for cuisine in outlet['cuisines']:
                if cuisine not in featured_merchant['merchant']['cuisines']:
                    featured_merchant['merchant']['cuisines'].append(cuisine)
        featured_merchant['merchant']['cuisine'] = outlet['merchant']['cuisine']

        featured_merchant['category'] = self.category
        featured_merchant['categories'] = [self.category]
        featured_merchant['category_image'] = outlet['category_image']
        featured_merchant['categories_analytics'] = outlet['categories_analytics']
        featured_merchant['category_color'] = outlet['category_color']
        _attributes = [
            'is_redeemable', 'is_purchased', 'is_monthly', 'is_new', 'is_cheers', 'is_delivery'
        ]
        featured_merchant_keys = list(featured_merchant.keys())
        for attribute in _attributes:
            if attribute not in featured_merchant_keys:
                featured_merchant[attribute] = outlet[attribute]
            elif outlet[attribute]:
                featured_merchant[attribute] = outlet[attribute]
        featured_merchant['is_cheers'] = bool(featured_merchant['is_cheers'])
        featured_merchant['is_delivery'] = bool(featured_merchant['is_delivery'])

    def get_outlet_offer_info_changes(self, offer):
        """
        Gets outlet information changes
        :param offer: Offer data
        """
        return {
            'purchase_product_ids': [
                int(offer['purchase_product_id'])] if (
                    offer['purchase_product_id'] and offer['purchase_product_id']
            ) else [],
            'offer_ids': [offer['id']],
            'product_id': [offer['product_id']],
            'product_sku': [offer['product_sku']],
            'is_redeemable': bool(offer['is_redeemable']),
            'redeemability': offer.get('redeemability', 0),
            'is_purchased': bool(offer.get('is_purchased', 0)),
            'type': offer['type'],
            'is_redeemable_more_sa': offer['is_more_sa'] and offer['is_redeemable'],
            'is_redeemable_monthly': offer['type'] == 2 and offer['is_redeemable'],
            'is_redeemable_delivery': offer['is_delivery'] and offer['is_redeemable'],
            'is_redeemable_cheers': offer['is_cheers'] and offer['is_redeemable'],
            'is_new': offer['is_new'],
            'is_monthly': offer['is_monthly'],
            'is_cheers': bool(offer['is_cheers']),
            'is_delivery': offer['is_delivery'],
            'is_more_sa': offer['is_more_sa'],
            'is_shared': bool(offer['is_shared']),
            'top_up_offer': bool(offer['top_up_offer']),
            'category': offer['merchant_category'],
            'category_image': offer['category_image'],
            'categories_analytics': offer['categories_analytics'],
            'category_color': offer['category_color']
        }

    def track(self, outlet_id, array):
        if self.outlet_track.get(outlet_id):
            self.outlet_track[outlet_id].append({
                'array': array,
                'index': len(array) - 1
            })
        else:
            self.outlet_track[outlet_id] = [{
                'array': array,
                'index': len(array) - 1
            }]

    def separate_outlets_according_to_their_types(self, outlet, append_mode=True):
        """
        Seperate outlets according to their types
        :param outlet: Outlet data
        :param append_mode: Append mode flag
        """
        if not append_mode:
            tracks = self.outlet_track.get(outlet['id'], [])
            for track in tracks:
                track['array'][track['index']] = None
        if outlet['is_redeemable']:
            self.outlet_offers_redeemable_array.append(outlet)
            self.track(outlet['id'], self.outlet_offers_redeemable_array)
        elif outlet.get('purchase_product_ids'):
            self.outlet_offers_not_redeemable_array.append(outlet)
            self.track(outlet['id'], self.outlet_offers_not_redeemable_array)
        if self.customer and outlet['is_cheers']:
            if outlet['is_redeemable_cheers']:
                self.outlet_offers_cheers_redeemable_array.append(outlet)
                self.track(outlet['id'], self.outlet_offers_cheers_redeemable_array)
            elif outlet.get('purchase_product_ids'):
                self.outlet_offers_cheers_not_redeemable_array.append(outlet)
                self.track(outlet['id'], self.outlet_offers_cheers_not_redeemable_array)
        if self.customer and outlet['is_delivery']:
            if outlet['is_redeemable_delivery']:
                self.outlet_offers_delivery_redeemable_array.append(outlet)
                self.track(outlet['id'], self.outlet_offers_delivery_redeemable_array)
            elif outlet.get('purchase_product_ids'):
                self.outlet_offers_delivery_not_redeemable_array.append(outlet)
                self.track(outlet['id'], self.outlet_offers_delivery_not_redeemable_array)
        if outlet['is_monthly'] and outlet['is_redeemable_monthly']:
            self.outlet_offers_monthly_redeemable_array.append(outlet)
            self.track(outlet['id'], self.outlet_offers_monthly_redeemable_array)
        if outlet['is_more_sa'] and outlet['is_redeemable_more_sa']:
            self.outlet_offers_more_africa_redeemable_array.append(outlet)
            self.track(outlet['id'], self.outlet_offers_more_africa_redeemable_array)
        if self.hashed_featured_merchants.get(outlet.get('merchant', {}).get('id', 0)) is not None:
            index = self.hashed_featured_merchants[outlet['merchant']['id']]
            featured_merchant = self.featured_merchants[index]
            self.update_featured_merchant(featured_merchant, outlet)

    def update_outlet_offer_info(self, offer, outlet_id):
        """
        Updates outlet offer information
        :param offer: Offer data
        :param outlet_id: Id of the outlet
        """
        if (
            offer['purchase_product_id'] and
            int(offer['purchase_product_id']) not in self.outlet_offer_info[outlet_id]['purchase_product_ids']
        ):
            self.outlet_offer_info[outlet_id]['purchase_product_ids'].append(int(offer['purchase_product_id']))
        if not offer['id'] in self.outlet_offer_info[outlet_id]['offer_ids']:
            self.outlet_offer_info[outlet_id]['offer_ids'].append(offer['id'])
        if offer['product_id'] not in self.outlet_offer_info[outlet_id]['product_id']:
            self.outlet_offer_info[outlet_id]['product_id'].append(offer['product_id'])
        if offer['product_sku'] not in self.outlet_offer_info[outlet_id]['product_sku']:
            self.outlet_offer_info[outlet_id]['product_sku'].append(offer['product_sku'])
        if offer.get('is_redeemable'):
            self.outlet_offer_info[outlet_id]['is_redeemable'] = True
        if offer.get('redeemability', 0) > self.outlet_offer_info[outlet_id]['redeemability']:
            self.outlet_offer_info[outlet_id]['redeemability'] = offer['redeemability']
        if offer['is_purchased']:
            self.outlet_offer_info[outlet_id]['is_purchased'] = bool(offer['is_purchased'])
        if offer['type'] > self.outlet_offer_info[outlet_id]['type']:
            self.set_offer_attributes(offer)
            offer['is_redeemable_monthly'] = self.is_offer_redeemable_monthly(offer)
            offer['is_redeemable_delivery'] = offer.get('is_redeemable', 0) and offer['is_delivery']
            offer['is_redeemable_cheers'] = offer.get('is_redeemable', 0) and offer['is_cheers']
            offer['is_redeemable_more_sa'] = offer.get('is_redeemable', 0) and offer['is_more_sa']
        if offer.get('is_redeemable_more_sa'):
            self.outlet_offer_info[outlet_id]['is_redeemable_more_sa'] = offer['is_redeemable_more_sa']
        if offer.get('is_redeemable_monthly'):
            self.outlet_offer_info[outlet_id]['is_redeemable_monthly'] = offer['is_redeemable_monthly']
        if offer.get('is_redeemable_delivery'):
            self.outlet_offer_info[outlet_id]['is_redeemable_delivery'] = offer['is_redeemable_delivery']
        if offer.get('is_redeemable_cheers'):
            self.outlet_offer_info[outlet_id]['is_redeemable_cheers'] = offer['is_redeemable_cheers']
        if offer['is_monthly']:
            self.outlet_offer_info[outlet_id]['is_monthly'] = offer['is_monthly']
        if offer['is_new']:
            self.outlet_offer_info[outlet_id]['is_new'] = offer['is_new']
        if offer['is_cheers']:
            self.outlet_offer_info[outlet_id]['is_cheers'] = bool(offer['is_cheers'])

        locations_ids = get_delivery_enabled_location_ids_against_company(self.company)

        if self.location_id in locations_ids:
            self.outlet_offer_info[outlet_id]['is_delivery'] = 0
            if offer.get('cashless_delivery_enabled'):
                self.outlet_offer_info[outlet_id]['is_delivery'] = 1
                self.outlet_offer_info[outlet_id]['cashless_delivery_params'] = {
                    'outlet_id': outlet_id,
                    'cashless_delivery': True
                }
        elif offer['is_delivery']:
            self.outlet_offer_info[outlet_id]['is_delivery'] = offer['is_delivery']

        if offer['is_more_sa']:
            self.outlet_offer_info[outlet_id]['is_more_sa'] = offer['is_more_sa']
        if offer['is_shared']:
            self.outlet_offer_info[outlet_id]['is_shared'] = bool(offer['is_shared'])
        if offer['top_up_offer']:
            self.outlet_offer_info[outlet_id]['top_up_offer'] = bool(offer['top_up_offer'])
        if not self.outlet_offer_info[outlet_id].get('sub_categories'):
            self.outlet_offer_info[outlet_id]['sub_categories'] = {}
        if not self.outlet_offer_info[outlet_id]['sub_categories'].get(offer['merchant_category']):
            self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']] = []
        if (
            offer['sub_category'] and
            offer['sub_category'] not in self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']]
        ):
            self.outlet_offer_info[outlet_id]['sub_categories'][offer['merchant_category']].append(offer['sub_category'])
            if not self.outlet_offer_info[outlet_id].get('sub_categories_analytics'):
                self.outlet_offer_info[outlet_id]['sub_categories_analytics'] = offer['sub_category']
            else:
                appended_str = "{},{}".format(
                    self.outlet_offer_info[outlet_id]['sub_categories_analytics'],
                    offer['sub_category']
                )
                self.outlet_offer_info[outlet_id]['sub_categories_analytics'] = appended_str

    def process_offers_and_outlets(self):
        """
        Gets all the offers and outlets
        """
        self.offers = self.get_offers_list()
        if self.redemptions_quantities:
            self.customer_redemptions_records = count_offer_redemptions_by_customer(
                self.customer['customer_id'], self.company, offer_id=self.offer_ids, group_by=True
            )

        self.set_shared_redemptions_count_records()
        self.outlets, self.hashed_outlets = Outlet().get_outlet_array(
            self.location_id,
            self.category,
            self.company,
            self.content_locale,
            self.api_version
        )

        separated_outlet_ids = set()
        self.flag_details = {}
        for offer in self.offers:
            if offer['is_cheers'] and not self.customer:
                continue
            if (
                offer['is_cheers'] and
                self.customer and
                self.is_active_family_member and
                self.customer['owns_cheer_products'] and
                not self.customer['family_member_info']['is_cheers_to_include']
            ):
                continue
            if self.customer and self.customer['is_using_trial'] and offer['is_for_members_only']:
                continue
            if self.category != offer['merchant_category']:
                continue
            self.set_offer_attributes(offer)
            self.update_category_specific_offer_data(offer)
            self.offer_ids.append(offer['id'])
            if all([
                self.customer,
                any([
                    self.customer.get('member_type_id', 0) in [
                        EntCustomerProfile.MEMBERSTATUS_ONBOARDING,
                        EntCustomerProfile.MEMBERSTATUS_MEMBER
                    ],
                    self.is_active_family_member
                ])
            ]):
                self.set_redeemability(offer)
            if isinstance(offer.get('outlet_ids'), list):
                outlet_ids = offer['outlet_ids']
            elif isinstance(offer.get('outlet_ids'), str):
                outlet_ids = list(set(map(int, filter(None, offer.get('outlet_ids').split(',')))))
            else:
                outlet_ids = []
            for outlet_id in outlet_ids:
                if self.hashed_outlets.get(outlet_id):
                    if not self.outlet_offer_info.get(outlet_id):
                        self.outlet_offer_info[outlet_id] = self.hashed_outlets[outlet_id]
                        changes = self.get_outlet_offer_info_changes(offer)
                        self.outlet_offer_info[outlet_id].update(changes)
                        if self.latitude and self.longitude:
                            self.outlet_offer_info[outlet_id]['distance'] = calculate_distance(
                                float(self.latitude),
                                float(self.longitude),
                                self.outlet_offer_info[outlet_id]['lat'] or 0.0,
                                self.outlet_offer_info[outlet_id]['lng'] or 0.0
                            )
                    else:
                        self.update_outlet_offer_info(offer, outlet_id)
                    append_mode = outlet_id not in separated_outlet_ids
                    self.separate_outlets_according_to_their_types(self.outlet_offer_info[outlet_id], append_mode)
                    if append_mode:
                        separated_outlet_ids.add(outlet_id)

    def get_section(self, section_id, section_identifier, section_type, section_for,
                    rendering_mode, section_title, show_view_all_button, section_background_color,
                    section_header_background_color):
        section_id = CategoryHomeScreenConfiguration.SECTION_ID_FOR_SECTION[section_for]
        return {
            "section_id": section_id,
            "section_identifier": section_identifier,
            "section_type": section_type,
            "section_for": section_for,
            "rendering_mode": rendering_mode,
            "section_title": section_title,
            "section_background_color": section_background_color,
            "section_header_background_color": section_header_background_color,
            "show_view_all_button": show_view_all_button,
            "tabs": [],
            "outlets": [],
            "filters": []
        }

    def get_section_params(self, title, section):
        return [
            section["id"],
            section["identifier"],
            section["section_type"],
            section["section_for"],
            section["rendering_mode"],
            title,
            bool(section["show_view_all_button"]),
            section["background_color"],
            section["header_background_color"]
        ]

    def add_section(
            self, section, title, outlets=list(), filters=list(), extra={}, color=False, skip_sort=False,
            skip_tabs=False, is_take_away=False, is_delivery=False
    ):
        """
        Add category home screen sections
        """
        all_offers_section = self.get_section(*self.get_section_params(title, section))
        all_offers_section.update({'outlets': outlets, 'filters': filters, 'tabs': []})
        if not skip_tabs:
            all_offers_section.update({
                'tabs': get_category_home_screen_tabs(
                    section['section_for'],
                    is_take_away,
                    is_delivery,
                    self.locale
                )
            })
        if not skip_sort:
            if self.latitude and self.longitude:
                all_offers_section['outlets'] = filter(None, all_offers_section['outlets'])
                all_offers_section['outlets'] = multi_key_sort(
                    all_offers_section['outlets'],
                    ['distance', 'merchant_name']
                )
            else:
                all_offers_section['outlets'] = filter(None, all_offers_section['outlets'])
                all_offers_section['outlets'] = multi_key_sort(all_offers_section['outlets'], ['merchant_name'])
        if extra:
            all_offers_section.update(extra)
        chunk = all_offers_section['outlets'][0:section['item_limit']]
        for outlet in chunk:
            set_image_and_attributes(outlet, self.category)
        all_offers_section['outlets'] = chunk
        if color:
            for outlet in all_offers_section['outlets']:
                outlet['category_color'] = color
        self.categories_home_screen_sections.append(all_offers_section)

    def populate_sections(self):
        """
        Populate sections
         1. Updated Button section for delivery cashless with new params of takeaways.
         2. In case of Takeaways if location_feature is enabled we will show takeaways section with delivery.
        """
        for section_obj in self.sections:
            section = section_obj._asdict()
            if self.customer.get('is_using_trial'):
                if section['section_for'] in (
                    CategoryHomeScreenConfiguration.SECTION_FOR_CHEERS,
                    CategoryHomeScreenConfiguration.SECTION_FOR_MONTHLY
                ):
                    continue
            if section['section_type'] == CategoryHomeScreenConfiguration.SECTION_TYPE_OUTLET_LISTING:
                if section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_ALL_OUTLETS:
                    title = section["title_locked"]
                    outlets = self.outlet_offers_not_redeemable_array
                    if self.outlet_offers_redeemable_array:
                        title = section["title"]
                        outlets = self.outlet_offers_redeemable_array
                    self.add_section(section, title, outlets, extra={'section_for': 'nearby'})

                elif section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_CHEERS:
                    title = section["title_locked"]
                    outlets = self.outlet_offers_cheers_not_redeemable_array
                    if self.outlet_offers_cheers_redeemable_array:
                        title = section["title"]
                        outlets = self.outlet_offers_cheers_redeemable_array
                    if outlets:
                        self.add_section(section, title, outlets, color=Category.Color_Cheers)

                elif all([
                    section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_MORE_AFRICA,
                    self.outlet_offers_more_africa_redeemable_array
                ]):
                    title = section["title"]
                    outlets = self.outlet_offers_more_africa_redeemable_array
                    self.add_section(section, title, outlets)
                elif all([
                    section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_MONTHLY,
                    self.outlet_offers_monthly_redeemable_array
                ]):
                    title = section["title"]
                    outlets = self.outlet_offers_monthly_redeemable_array
                    self.add_section(section, title, outlets)
            elif section['section_type'] == CategoryHomeScreenConfiguration.SECTION_TYPE_BUTTON:
                # check if take is enable for location then show take away tab in screen
                self.is_take_away = False
                take_away_locations_ids = get_takeaways_enabled_location_ids_against_company(self.company)
                if (
                    self.location_id in take_away_locations_ids and
                    self.customer.get('customer_id', None) and self.take_away_flow
                ):
                    self.is_take_away = True
                # If RC environment enabled and location in singapore then will display Takeaways section.
                if (
                    current_app.config.get('IS_RC_ENVIRONMENT', False) and
                    self.location_id in (Location.LOCATION_ID_SINGAPORE, Location.LOCATION_ID_ABU_DHABI)
                ):
                    self.is_take_away = True
                if section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_DELIVERY:
                    # for dubai and abu dhabi location
                    locations_ids = get_delivery_enabled_location_ids_against_company(self.company)
                    if (
                        self.location_id in locations_ids and
                        self.customer.get('customer_id', None)
                    ):
                        if self.is_take_away:
                            title = CategoryHomeScreenConfiguration.ONLINE_DELIVERY_TAKEAWAYS_OFFERS_BUTTON_TITLE  # noqa: E501
                            extra = {
                                'section_border_color': BADGE_DELIVERY_COLOR,
                                'delivery_image': BADGE_URL_DELIVERY_OFFERS_BORDER_LESS,
                                'cashless_delivery_params': {'cashless_delivery_enabled': True},
                                'online_delivery_title': CategoryHomeScreenConfiguration.ONLINE_DELIVERY_TAKEAWAYS_TITLE
                            }
                            self.add_section(
                                section=section, title=title, extra=extra, is_take_away=True, is_delivery=True
                            )
                        else:
                            title = CategoryHomeScreenConfiguration.ONLINE_DELIVERY_BUTTON_TITLE
                            extra = {
                                'section_border_color': BADGE_DELIVERY_COLOR,
                                'delivery_image': BADGE_URL_DELIVERY_OFFERS_BORDER_LESS,
                                'cashless_delivery_params': {'cashless_delivery_enabled': True},
                                'online_delivery_title': CategoryHomeScreenConfiguration.ONLINE_DELIVERY_TITLE
                            }
                            self.add_section(section=section, title=title, extra=extra, skip_tabs=True)
                    elif self.is_take_away:
                        title = CategoryHomeScreenConfiguration.ONLINE_TAKEAWAY_OFFERS_BUTTON_TITLE
                        extra = {
                            'section_border_color': BADGE_DELIVERY_COLOR,
                            'delivery_image': BADGE_URL_DELIVERY_OFFERS_BORDER_LESS,
                            'cashless_delivery_params': {'cashless_delivery_enabled': True},
                            'online_delivery_title': CategoryHomeScreenConfiguration.ONLINE_TAKEAWAYS_TITLE
                        }
                        self.add_section(section=section, title=title, extra=extra, is_take_away=True)

                    elif any([
                        self.outlet_offers_delivery_redeemable_array,
                        self.outlet_offers_delivery_not_redeemable_array
                    ]):
                        title = section['title_locked']
                        if self.outlet_offers_delivery_redeemable_array:
                            title = section['title']
                        extra = {
                            'section_border_color': BADGE_DELIVERY_COLOR,
                            'delivery_image': BADGE_URL_DELIVERY
                        }
                        self.add_section(section=section, title=title, extra=extra)

            elif section['section_type'] == CategoryHomeScreenConfiguration.SECTION_TYPE_FILTER:
                if section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_SUB_CATEGORY:
                    title = section['title']
                    merchant_sub_categories = MerchantSubCategory.get_merchant_sub_categories(
                        self.locale,
                        section['category_id']
                    )
                    filters = []
                    for index, sub_category_obj in enumerate(merchant_sub_categories):
                        sub_category = sub_category_obj._asdict()
                        filters.append(
                            get_filter_item(
                                '{count}_cat_id_{category_id}_{sub_category_id}'.format(
                                    count=len(filters),
                                    category_id=section['category_id'],
                                    sub_category_id=sub_category['sub_category_id']
                                ),
                                PARAM_NAME_API_SUB_CATEGORIES,
                                PARAM_NAME_ANALYTICS_SUB_CATEGORIES,
                                sub_category['sub_category_id'],
                                sub_category['key'],
                                sub_category['name'],
                                sub_category['image_url_default'],
                                sub_category['image_url_default'],
                                section['category_id'],
                                ATTRIBUTE_SELECTION_TYPE_MULTIPLE
                            )
                        )
                        if index >= 3:
                            break
                    self.add_section(section, title, [], filters)
                elif section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_CUISINE:
                    cuisines = Cuisine().get_cuisines_for_merchant_filters(locale=self.locale)
                    filter_options = []
                    title = section['title']
                    for index, cuisine_obj in enumerate(cuisines):
                        cuisine = cuisine_obj._asdict()
                        filter_options.append(
                            get_filter_item(
                                '{count}_{cuisine}'.format(
                                    count=len(filter_options['options']),
                                    cuisine=cuisine['value']
                                ),
                                PARAM_NAME_API_CUISINES,
                                PARAM_NAME_ANALYTICS_CUISINES,
                                cuisine['value'],
                                cuisine['value'],
                                cuisine['name'],
                                cuisine['image_url_default'],
                                cuisine['image_url_default'],
                                section['category_id'],
                                ATTRIBUTE_SELECTION_TYPE_MULTIPLE
                            )
                        )
                        if index >= 3:
                            break
                    self.add_section(section, title, [], filter_options)

            elif section['section_type'] == CategoryHomeScreenConfiguration.SECTION_TYPE_MERCHANTS_LISTING:
                if all([
                    section['section_for'] == CategoryHomeScreenConfiguration.SECTION_FOR_FEATURED_MERCHANTS,
                    self.featured_merchants,
                    self.outlet_offers_redeemable_array
                ]):
                    title = section['title']
                    if all([
                        self.member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER,
                        self.category == CATEGORY_NAME_RESTAURANTS_AND_BARS
                    ]):
                        self.is_customer_own_cheers_for_location = ProductEntActive().is_customer_own_cheers_for_location_by_product_ids(  # noqa
                            self.customer['product_ids'], self.location_id
                        )
                    filtered_featured_merchants = []
                    for featured_merchant in self.featured_merchants:
                        featured_merchant["is_featured"] = False
                        if featured_merchant.get("is_cheers"):
                            if self.is_customer_own_cheers_for_location:
                                featured_merchant['locked_image_url'] = ""
                                set_image_and_attributes(featured_merchant, self.category)
                                featured_merchant["is_featured"] = True
                                filtered_featured_merchants.append(featured_merchant)
                        else:
                            featured_merchant['locked_image_url'] = ""
                            set_image_and_attributes(featured_merchant, self.category)
                            featured_merchant["is_featured"] = True
                            filtered_featured_merchants.append(featured_merchant)
                        if featured_merchant.get('merchant') is not None:
                            del featured_merchant['merchant']
                    self.add_section(section, title, filtered_featured_merchants, skip_sort=True)

    def prepare_final_reponse(self):
        """
        Sets the final response of category home screen service
        :rtype: list of dict
        """
        self.status_code = codes.OK
        self.set_response(
            {
                'success': True,
                'message': 'success',
                'data': {
                    'sections': self.categories_home_screen_sections
                }
            },
            code=0
        )

    def process_request(self, *args, **kwargs):
        """
        Process request of category home screen service
        :param args:
        :param kwargs:
        :rtype: dict
        """
        self.process_request_args()
        self.initialize_class_params()
        self.get_customer()
        self.get_sections()
        if self.send_response_flag:
            return
        self.get_customer_related_data()
        self.process_offers_and_outlets()
        self.populate_sections()
        self.prepare_final_reponse()
