"""
This module contains API endpoint of Home api.
"""

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from ent_service.app.api.v1.validations.home import home_api_parser
from ent_service.common import constants
from ent_service.common.base_resource import BaseGetResource
from ent_service.common.models.ent_customer_profile import EntCustomerProfile
from ent_service.common.models.home_screen_configurations import HomeScreenConfiguration
from ent_service.common.models.wl_company import WlCompany
from ent_service.common.models.wl_validation import Wlvalidation
from ent_service.common.rest_urls import LocationServiceAPIUrls
from ent_service.common.utils.api_utils import get_locale
from ent_service.common.utils.authentication import get_company, get_current_customer
from ent_service.common.utils.cummunicator import communicator
from ent_service.common.utils.translation_manager import TranslationManager
from ent_service.modules.api_modules import (
    get_home_screen_conf, get_saving_messages, get_sub_section, get_user_yearly_savings
)
from ent_service.modules.constants import (
    BIRTHDAY_OFFER, CATEGORIES, FEATURED, FEATURED_SECTIONS, MAIN_COVER, TYPE_EXTRA, TYPE_FEATURED,
    TYPE_FOR_THE_WEEKEND
)

__author__ = 'tamoor'


class HomeApi(BaseGetResource):
    """
    @api {get} /v1/home Get home screen
    @apiSampleRequest /v1/home
    @apiVersion 1.0.0
    @apiName UserGemsPointsSummaryApiWL
    @apiGroup Users
    @apiParam {Integer}                                     [location_id]    User Location Id.
    @apiParam {String='de', 'en', 'ar', 'cn', 'el', 'zh'}   [language]       Response Language.
    @apiParam {String="BHD", "EGP", "EUR", "GBP", "HKD", "JOD", "KWD", "LBP", "MYR", "OMR", "QAR", "SAR", "SGD", "USD", "ZAR", "AED"}    [currency]  Currency   # noqa:E501
    """
    required_token = True
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ent_service/home_api.log',
        ),
        'name': 'home_api'
    }
    request_parser = home_api_parser
    location_categories_url = LocationServiceAPIUrls.LOCATION_CATEGORIES

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.locale = self.request_args.get('language')

    def initialize_local_variables(self):
        """
        Initialize local variables
        """
        self.company = get_company()
        self.user_id = 0
        self.is_user_logged_in = False
        self.featured_heading = FEATURED.title()
        self.savings_messages = []
        self.home_sections = []
        self.app_configuration_version = 1

    def parse_request_args(self):
        """
        Parses request args
        """
        self.customer = get_current_customer()
        self.is_user_logged_in = self.customer['is_user_logged_in']
        if self.is_user_logged_in:
            self.user_id = self.customer.get('customer_id')
        self.locale = get_locale(self.locale)
        self.message_to_append_with_this_year_savings = TranslationManager.get_translation(
            TranslationManager.SAVED_THIS_YEAR_LABEL,
            self.locale
        )
        self.user_yearly_savings = get_user_yearly_savings(
            user_id=self.user_id,
            currency=self.currency,
            locale=self.locale,
            message_to_append_with_this_year_savings=self.message_to_append_with_this_year_savings,
            company=self.company
        )

    def get_users_points(self):
        """
        Gets users points
        """
        # Gems logic commented out
        # if self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
        #     user_points_result = WlGemsPointsSource.get_user_points_stats(self.user_id)
        #     if user_points_result:
        #         user_points_result = user_points_result._asdict()
        #         self.user_points_earned = user_points_result.get('points_earned', '')
        #         self.user_points_burned = user_points_result.get('points_burned', '')
        #         self.user_points_available = (
        #             user_points_result.get('points_earned', 0) -
        #             user_points_result.get('points_burned', 0)
        #         )
        #     if self.user_yearly_savings.get('total_points'):
        #         self.user_points = self.user_yearly_savings.get('total_points')
        #     else:
        #         self.user_points = 0
        #     self.user_yearly_savings['smiles_earned'] = self.user_points_earned
        # else:
        if self.user_yearly_savings.get('total_points'):
            self.external_savings = self.user_yearly_savings.get('total_points')
        else:
            self.external_savings = 0
        self.user_yearly_savings['external_savings'] = self.external_savings
        if self.user_yearly_savings.get('gems_savings'):
            del self.user_yearly_savings['gems_savings']
        if self.user_yearly_savings.get('total_points'):
            del self.user_yearly_savings['total_points']

    def show_message(self):
        self.user_profile = EntCustomerProfile.load_customer_profile_by_user_id(self.user_id)
        if self.user_profile:
            self.user_profile = self.user_profile.to_dict()
        # Company specific code is commented
        # if self.company == WlCompany.COMPANY_CODE_AAG:
        #     user_yearly_saving = self.user_yearly_savings.get('savings_this_year')
        #     self.savings_messages = "{user_name} you've saved {currency} {user_yearly_saving} so far!".format(
        #         user_name=user_name,
        #         currency=self.currency,
        #         user_yearly_saving=user_yearly_saving
        #     )
        # else:
        if self.user_yearly_savings.get('savings_this_year'):
            self.savings_messages = get_saving_messages(
                self.user_yearly_savings.get('savings_this_year'), self.locale, self.user_profile
            )
        else:
            self.savings_messages = get_saving_messages(
                0, self.locale, self.user_profile
            )

        self.all_links = HomeScreenConfiguration.get_configurations(self.locale, self.location_id, self.company)
        for _index, link in enumerate(self.all_links):
            link = link._asdict()
            self.all_links[_index] = link

        self.location_version = WlCompany.get_location_version()
        self.main_cover = {
            'identifier': MAIN_COVER,
            'section_identifier': MAIN_COVER,
            'title': '',
            'section_title': MAIN_COVER,
            'tiles': []
        }

    def set_categories(self):
        response = communicator.communicate(
            self.location_categories_url,
            'GET',
            params=dict(
                location_id=self.location_id,
                language=self.locale
            )
        )
        self.categories = {
            'identifier': CATEGORIES,
            'section_identifier': CATEGORIES,
            'title': '',
            'section_title': CATEGORIES,
            'tiles': response.json()['data']['location_categories']
        }

    def is_user_hsbc_black_card_holder(self):
        self.hsbc_black_card_holder = False
        if (
            self.customer and
            self.company.lower() == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC
        ):
            user_group = Wlvalidation.get_user_group(self.company, self.user_id)
            if user_group == constants.USER_GROUP_2:
                self.hsbc_black_card_holder = True

    # gems code commented
    # def add_ambassador_program_link(self):
    #     if (
    #         self.customer and
    #         self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS
    #     ):
    #         try:
    #             gems_encryption_key = current_app.config.get('gems_encryption_key')
    #             if gems_encryption_key:
    #                 gem_lookup_data = EntGemsData.find_gem_data_by_id(self.user_id)
    #                 if gem_lookup_data:
    #                     parent_id = gem_lookup_data.get('parent_id', '')
    #                     gem_school = gem_lookup_data.get('school', '')
    #                     for link in self.all_links:
    #                         if link['link_type'] == TYPE_GEMS_REFERAL:
    #                             gems_referral_url = self.home_screen_config_repo.get_gems_ambassador_program_url(
    #                                 link['deep_link'],
    #                                 gems_encryption_key,
    #                                 parent_id,
    #                                 gem_school
    #                             )
    #                             link['deep_link'] = gems_referral_url
    #                             if gems_referral_url:
    #                                 link['link_type'] = TYPE_EXTRA
    #         except Exception:
    #             pass

    def check_user_black_card_holder(self):
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(TYPE_EXTRA)
        else:
            self.link_type = TYPE_EXTRA
        self.extras = {
            'identifier': FEATURED_SECTIONS,
            'section_identifier': 'more_to_enjoy',
            'title': '',   # 'Extras',
            'section_title': 'more_to_enjoy',
            'tiles': get_sub_section(self.all_links, self.link_type, self.locale)
        }
        self.for_the_weekend = {
            'identifier': FEATURED_SECTIONS,
            'section_identifier': 'for_the_weekend',
            'title': '',
            'section_title': 'for_the_weekend',
            'tiles': get_sub_section(
                self.all_links,
                TYPE_FOR_THE_WEEKEND,
                self.locale
            )
        }

    def set_featured_section(self):
        if self.hsbc_black_card_holder:
            self.link_type = '{}_group2'.format(TYPE_FEATURED)
        else:
            self.link_type = TYPE_FEATURED

        self.feature_section = get_sub_section(
            self.all_links,
            self.link_type,
            self.locale
        )
        # Company specific code is commented
        # if self.company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
        #     self.featured_heading = TranslationManager.get_translation(
        #         TranslationManager.gems_featured_heading,
        #         self.locale
        #     )
        # elif self.company.lower() == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
        #     if self.hsbc_black_card_holder:
        #         self.featured_heading = TranslationManager.get_translation(
        #             TranslationManager.hsbc_more_to_enjoy_group2,
        #             self.locale
        #         )
        #     else:
        #         self.featured_heading = TranslationManager.get_translation(
        #             TranslationManager.hsbc_more_to_enjoy,
        #             self.locale
        #         )
        # elif self.company == WlCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS:
        #     self.featured_heading = TranslationManager.get_translation(
        #         DUBAI_ENTERTAINMENTS_WHAT_NEW,
        #         self.locale
        #     )
        self.featured = {
            'identifier': FEATURED_SECTIONS,
            'section_identifier': FEATURED,
            'title': self.featured_heading,
            'section_title': FEATURED,
            'is_show_view_all_button': False,
            'tiles': self.feature_section
        }
        self.birthday = {
            'identifier': FEATURED_SECTIONS,
            'section_identifier': BIRTHDAY_OFFER,
            'title': '',
            'section_title': BIRTHDAY_OFFER,
            'tiles': []
        }

    def set_branding_attributes(self):
        if not self.savings_messages:
            self.savings_messages = []
            self.savings_messages.append(TranslationManager.get_translation(
                TranslationManager.savings_message_welcome_guest,
                self.locale
            )
            )
        # Company Specific code is commented
        # if self.company.lower() == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
        #     if self.hsbc_black_card_holder:
        #         self.branding_attributes = {
        #             'main_top_image': constants.ENTERTAINER_HSBC_MAIN_TOP_IMAGE_BLACK_CARD,
        #             'main_top_color': constants.ENTERTAINER_HSBC_MAIN_TOP_COLOR_BLACK_CARD,
        #             'main_top_text_color': constants.ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR
        #         }
        #     else:
        #         self.branding_attributes = {
        #             'main_top_image': constants.ENTERTAINER_HSBC_MAIN_TOP_IMAGE,
        #             'main_top_color': constants.ENTERTAINER_HSBC_MAIN_TOP_COLOR,
        #             'main_top_text_color': constants.ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR
        #         }
        # elif self.company == WlCompany.COMPANY_CODE_AAG:
        #     self.branding_attributes = {
        #         'main_top_image': constants.AAG_MAIN_TOP_IMAGE,
        #         'main_top_color': constants.AAG_MAIN_TOP_COLOR,
        #         'main_top_text_color': constants.AAG_MAIN_TOP_TEXT_COLOR
        #     }
        # else:

        self.branding_attributes = {
            'main_top_image': '',
            'main_top_color': 'B3000000',
            'main_top_text_color': "ffffff"
        }

    def set_main_cover_title(self):
        self.main_cover['tiles'].append({
            'identifier': 'messaging_tile',
            'image': '',
            'messages': self.savings_messages,   # {("You have saved 10,000 AED this year so far!") //$savings_messages
            'main_top_image': self.branding_attributes.get('main_top_image'),
            'main_top_color': self.branding_attributes.get('main_top_color'),
            'main_top_text_color': self.branding_attributes.get('main_top_text_color')
        })
        self.main_cover['tiles'].append({
            'identifier': 'savings_tile',
            'image': '',
            'savings': self.user_yearly_savings
        })
        # gems code commented
        # if (
        #         self.company.lower() == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS and
        #         self.app_version > constants.MIN_VALID_APP_VERSION
        # ):
        #     self.is_show_grey_view = True
        #     if self.user_points_available >= 5550:
        #         self.is_show_grey_view = False
        #     self.main_cover['tiles'].append({
        #         'identifier': 'points_section',
        #         'image': "",
        #         'detail': {
        #             'points_available_image': constants.POINTS_AVAILABLE_IMAGE,
        #             'points_used_image': constants.POINTS_USED_IMAGE,
        #             'points_available': self.user_points_available,
        #             'points_used': self.user_points_burned,
        #             'points_available_title': "GEMS POINTS AVAILABLE",
        #             'points_used_title': "GEMS POINTS USED",
        #             'bottom_message': constants.TITLE_DETAIL_BOTTOM_MESSAGE,
        #             'is_show_grey_view': self.is_show_grey_view
        #         }
        #     })
        self.home_sections.append(self.main_cover)
        self.home_sections.append(self.categories)

    def get_home_screen_configuration(self):
        self.user_group = Wlvalidation.get_user_group(self.company, self.user_id)
        home_scr_conf = get_home_screen_conf(self.location_id, self.user_group, self.company, self.locale)

        # setting home sections attributes
        if home_scr_conf:
            for index, key in enumerate(self.home_sections):
                if home_scr_conf.get(key["section_title"]):
                    # setting title
                    if home_scr_conf[key["section_title"]].get('title'):
                        self.home_sections[index]["title"] = home_scr_conf[key["section_title"]].get('title')
                    else:
                        self.home_sections[index]["title"] = ""
                    # setting title color
                    if home_scr_conf[key["section_title"]].get('title_color'):
                        self.home_sections[index]["section_title_color"] = home_scr_conf[key["section_title"]].get('title_color')  # noqa:501
                    # setting background color
                    if home_scr_conf[key["section_title"]].get('background_color'):
                        self.home_sections[index]["section_bg_color"] = home_scr_conf[key["section_title"]].get('background_color')  # noqa:501
                    del self.home_sections[index]["section_title"]

    def set_home_section(self):
        if len(self.birthday['tiles']) > 0:
            self.home_sections.append(self.birthday)
        if len(self.extras['tiles']) > 0:
            self.home_sections.append(self.extras)
        if len(self.for_the_weekend['tiles']) > 0:
            self.home_sections.append(self.for_the_weekend)
        if len(self.featured['tiles']) > 0:
            self.home_sections.append(self.featured)

    def generate_final_response(self):
        data = {
            'location_version': self.location_version,
            'app_configuration_version': self.app_configuration_version,
            'home_sections': self.home_sections
        }
        self.send_response_flag = True
        self.response = {
            'data': data,
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK

    def process_request(self):
        self.initialize_local_variables()
        self.parse_request_args()
        self.get_users_points()
        self.show_message()
        self.set_categories()
        self.is_user_hsbc_black_card_holder()
        # self.add_ambassador_program_link()      required for gems so commented
        self.check_user_black_card_holder()
        self.set_featured_section()
        self.set_branding_attributes()
        self.set_main_cover_title()
        self.set_home_section()
        self.get_home_screen_configuration()
        self.generate_final_response()
