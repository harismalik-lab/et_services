"""
This module contains V2 API endpoint of Home api.
"""
from app_configurations.settings import ET_SERVICES_LOG_PATH
from ent_service.app.api.v1.home import HomeApi
from ent_service.app.api.v2.validations.home import home_api_parser_v2
from ent_service.common.models.company_home_screen_branding import CompanyHomeScreenBranding
from ent_service.common.models.wl_validation import Wlvalidation
from ent_service.common.rest_urls import LocationServiceAPIUrlsV2
from ent_service.common.utils.cummunicator import communicator
from ent_service.modules.api_modules import get_home_screen_conf, get_home_screen_tiles

__author__ = 'tamoor'


class HomeApiV2(HomeApi):
    """
    @api {get} /v2/home Get home screen
    @apiSampleRequest /v2/home
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ent_service/home_api_v2.log',
        ),
        'name': 'home_api_v2'
    }
    request_parser = home_api_parser_v2
    location_categories_url = LocationServiceAPIUrlsV2.LOCATION_CATEGORIES

    def populate_request_arguments(self):
        """
        Populates request arguments
        """
        self.location_id = self.request_args.get('location_id')
        self.currency = self.request_args.get('currency')
        self.locale = self.request_args.get('language')
        self.platform = self.request_args.get('platform')
        self.home_sections = []

    def set_branding_attributes(self):
        self.user_group = Wlvalidation.get_user_group(self.company, self.user_id)
        self.branding_attributes = CompanyHomeScreenBranding.get_branding(
            self.company,
            location_id=self.location_id,
            user_group=self.user_group,
            platform=self.platform
        )

        if self.branding_attributes:
            self.branding_attributes = self.branding_attributes._asdict()
        else:
            self.branding_attributes = {
                'main_top_image': '',
                'main_top_color': '99ffffff',
                'main_top_text_color': '252525'
            }

    def set_categories(self):
        response = communicator.communicate(
            self.location_categories_url,
            'GET',
            params=dict(
                location_id=self.location_id,
                language=self.locale
            )
        )
        self.categories = response.json()['data']['location_categories']

    def get_home_screen_configuration(self):
        home_scr_conf = get_home_screen_conf(self.location_id, self.user_group, self.company, self.locale)
        home_screen_tiles = get_home_screen_tiles(
            self.locale,
            self.location_id,
            self.company,
            self.user_group,
            self.branding_attributes,
            self.savings_messages,
            self.user_yearly_savings
        )
        for key, sec in home_scr_conf.items():
            sec['section_title_color'] = sec.get('title_color')
            sec['section_bg_color'] = sec.get('background_color')
            tile_temp = home_screen_tiles.get(sec.get('section_identifier', ''))

            if sec.get('section_name') == "categories":
                tile_temp = self.categories

            if tile_temp:
                sec['tiles'] = tile_temp
            else:
                continue

            sec['section_identifier'] = sec.get('section_name')
            del sec['section_name']
            del sec['title_color']
            del sec['background_color']

            self.home_sections.append(sec)

    def process_request(self):
        self.initialize_local_variables()
        self.parse_request_args()
        self.get_users_points()
        self.show_message()
        self.set_categories()
        self.set_branding_attributes()
        self.get_home_screen_configuration()
        self.generate_final_response()
