# et_services

Install requisite packages:
```shell
$ sh scripts/install_requirements.sh
```
# Docker build Image
```shell
$ docker build --tag <image_tag_name> .
```
# Docker run Container
```shell
$ docker run --publish 8000:5000 <image_tag_name>
```
