from ping_service.common.constants import SUPPORTED_LOCALES

LOG_SUB_FOLDERS = []
