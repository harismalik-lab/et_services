import datetime

from dateutil.parser import parse
from flask import current_app
from requests import codes
from werkzeug.exceptions import Forbidden

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.utils.api_utils import get_formatted_date
from ping_service.app.api.v3.validations.pings_validator import ping_parser
from ping_service.common.models.api_configuration import ApiConfiguration
from ping_service.common.models.ent_customer_profile import EntCustomerProfile
from ping_service.common.models.product import Product
from ping_service.common.models.purchased_offer_pings import PurchasedOfferPing
from ping_service.common.models.share_offer import ShareOffer
from ping_service.common.models.user import User
from ping_service.common.models.user_info import UserInfo
from ping_service.common.utils.api_utils import get_api_configurations
from ping_service.common.utils.authentication import (get_current_customer,
                                                      token_decorator_v3)
from ping_service.common.utils.translation_manager import TranslationManager


class GetSharingSendOffers(BasePostResource):
    """
    This class handles the retrieval of sent offers endpoint
    :return: Response with a list of sent offers
    """
    strict_token = True
    required_token = True
    request_parser = ping_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ping_service/sharing_send_api.log',
        ),
        'name': 'sharing_send_api'
    }
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        self.user_id = 0
        self.membership_status = EntCustomerProfile.MEMBERSTATUS_PROSPECT
        self.customer_profile = None
        self.product_id_owned_by_user = []
        self.ping_message = ""
        self.ping_background_color = ShareOffer.COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND
        self.ping_details = {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }

    def load_customer_data(self):
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        if self.customer:
            show_pop_up = False
            self.primary_customer = self.customer.get('is_primary', False)
            self.user_id = self.customer['customer_id']
            self.product_id_owned_by_user = list(map(int, filter(None, self.customer['product_ids'])))
            self.customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(self.user_id)
            if self.customer_profile:
                self.membership_status = self.customer_profile.new_member_group
            self.primary_user_id = self.customer.get('primary_member_info').user_id
            self.is_active_family_member = self.customer['family_is_active'] and self.customer['is_user_in_family']
            if not self.is_active_family_member:
                if self.customer['member_type_id'] == EntCustomerProfile.MEMBERSTATUS_MEMBER:
                    cheer_products = Product.get_cheers_product_by_product_ids(
                        self.company_type, self.customer['company'], self.customer.get('product_ids', [])
                    )
                    if not cheer_products:
                        show_pop_up = True
                else:
                    show_pop_up = True
            if self.primary_customer:
                self.shared_offers = ShareOffer.get_shared_sent_offers(
                    sender_id=self.customer_id,
                    primary_user_id=self.primary_user_id,
                    locale='en',
                    pings_history=True,
                    order_by_status=True,
                    include_rejected=True
                )
            else:
                self.shared_offers = ShareOffer.get_shared_sent_offers(
                    self.customer_id,
                    'en',
                    primary_user_id=self.primary_user_id,
                    pings_history=True,
                    order_by_status=True,
                    include_rejected=True
                )
            self.shared_offers = self.populate_send_offers_ping_history(
                send_offers=self.shared_offers, show_pop_up=show_pop_up, locale=self.locale
            )

    def populate_send_offers_ping_history(self, send_offers=[], show_pop_up=False, locale='en'):
        """
        Returns send offers history of pings
        """
        for offer in send_offers:
            offer['is_sent'] = True
            offer['ping_status'] = ShareOffer.PING_STATUS_SENT
            offer['is_accepted'] = offer['status'] == ShareOffer.TYPE_ACCEPTED
            offer['is_cancellable'] = offer['status'] == ShareOffer.TYPE_NEW
            offer['recall_button_text'] = ShareOffer.OFFER_RECALL_BUTTON_TEXT
            offer['recall_message'] = TranslationManager.get_translation('Recall_Ping_Message', locale)
            offer['recall_title'] = TranslationManager.get_translation('Recall_Ping_Title', locale)
            if offer['status'] == ShareOffer.TYPE_CANCELLED:
                offer['ping_status'] = ShareOffer.PING_STATUS_CANCELLED
            if offer['status'] == ShareOffer.TYPE_ACCEPTED:
                offer['ping_status'] = ShareOffer.PING_STATUS_ACCEPTED
            if offer['status'] == ShareOffer.TYPE_REJECTED:
                offer['ping_status'] = ShareOffer.PING_STATUS_REJECTED
            if show_pop_up:
                offer["is_cheers"] = offer['is_cheers']
            else:
                offer["is_cheers"] = show_pop_up
            offer['pings_order'] = 9999
            if offer['status'] == ShareOffer.TYPE_NEW:
                offer['pings_order'] = 1
            offer['createdDate'] = get_formatted_date(offer['createdDate'])
            offer['acceptedDate'] = get_formatted_date(offer['acceptedDate'])
        return send_offers

    def set_ping_details(self):
        if not self.customer.get('is_user_in_family'):
            self.ping_details = self.get_ping_details(
                self.user_id, self.membership_status,
                self.product_id_owned_by_user, True
            )
        elif self.customer.get('is_user_in_family') and self.customer.get('family_is_active', False):
            product_ids_owned = self.product_id_owned_by_user
            if self.customer['owns_cheer_products'] and not self.customer['family_member_info'].is_cheers_to_include:
                product_ids_owned = list(map(int, filter(
                    None, self.customer['product_ids'] + self.customer.get('cheers_product_ids', [])
                )))
            self.ping_details = self.get_ping_details(
                self.primary_user_id, EntCustomerProfile.MEMBERSTATUS_MEMBER,
                product_ids_owned, True,
                primary_user_id=self.primary_user_id
            )
        pings_left = self.ping_details['total_quota_to_send_pings'] - self.ping_details['total_pings_sent']
        if self.ping_details['can_user_ping']:
            self.ping_background_color = ShareOffer.COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND
            message_key = TranslationManager.Ping_Count_Left_To_Send_Single
            if pings_left > 1:
                message_key = TranslationManager.Ping_Count_Left_To_Send_Multiple
            self.ping_message = TranslationManager.get_translation(message_key, self.locale)
            self.ping_message = self.ping_message.replace('__offer_count__', str(pings_left))
        else:
            self.ping_background_color = ShareOffer.COLOR_CODE_WHEN_USER_HAS_NO_PING_QUOTA_LEFT_TO_RECEIVE_OR_SEND
            self.ping_message = TranslationManager.get_translation(
                TranslationManager.Ping_Quota_Finished_To_Send,
                self.locale
            )

    def get_ping_details(self, user_id, membership_status, product_id_owned, is_sender, is_family_member=False,
                         primary_user_id=None):
        """
        Returns ping details
        :param primary_user_id:
        :param is_family_member:
        :param user_id:
        :param membership_status:
        :param product_id_owned:
        :param is_sender:
        :rtype: dict
        """
        ping_details = {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }
        if user_id:
            user_quota_to_send_pings = 0
            if membership_status == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_family_member:
                # user_quota_to_send_pings = ShareOfferRepository.MAX_ALLOWED_SHARES
                current_time = datetime.datetime.now()
                free_pings_start_time = current_app.config.get('FREE_PINGS_START_TIME', parse('2019-12-01 00:00:00'))
                free_pings_end_time = current_app.config.get('FREE_PINGS_END_TIME', parse('2019-12-31 23:59:59'))
                if free_pings_start_time <= current_time < free_pings_end_time:
                    user_quota_to_send_pings = ShareOffer.FREE_PINGS_QUOTA
                    total_offers_pinged = ShareOffer.FREE_PINGS_USED_FOR_DEC
                else:
                    user_quota_to_send_pings = self.get_number_of_allowed_pings(
                        user_id=user_id,
                        product_id_owned=product_id_owned
                    )
                    total_offers_pinged = ShareOffer.get_shared_offers_by_sender_count(
                        user_id, primary_sender_user_id=primary_user_id
                    )
            else:
                total_offers_pinged = ShareOffer.get_shared_offers_by_sender_count(
                    user_id, primary_sender_user_id=primary_user_id
                )
            ping_details['is_sender_info'] = is_sender
            ping_details['is_recipient_info'] = not is_sender
            ping_details['can_user_ping'] = user_quota_to_send_pings > total_offers_pinged
            ping_details['total_quota_to_send_pings'] = user_quota_to_send_pings
            ping_details['total_pings_sent'] = total_offers_pinged
        return ping_details

    def get_number_of_allowed_pings(self, *args, **kwargs):
        """
        This returns number of allowed pings
        :rtype: int
        """
        user_id = kwargs['user_id']
        customer_ping_offer_limit = UserInfo.get_ping_offer_limit(user_id)

        # Get the Number of Purchased Pings through Smiles
        purchased_pings = PurchasedOfferPing.get_purchased_pings(
            user_id,
            datetime.datetime.utcnow().year
        )
        # If older pings available
        if customer_ping_offer_limit:
            if purchased_pings:
                # add the purchased pings
                return purchased_pings + customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES
            return customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES

        number_of_allowed_pings = ShareOffer.MAX_ALLOWED_SHARES
        if purchased_pings:
            number_of_allowed_pings += purchased_pings
        return number_of_allowed_pings

    def update_received_offers(self):
        recipient_ids = [offer['recipientId'] for offer in self.shared_offers]
        recipients = User.load_customer_by_id(recipient_ids)
        if recipients:
            ping_to_message_key = TranslationManager.PING_TO_MESSAGE
            ping_to_message = TranslationManager.get_translation(ping_to_message_key, self.locale)
            for offer in self.shared_offers:
                firstname = recipients.get(offer.get('recipientId')).first_name
                lastname = recipients.get(offer.get('recipientId')).last_name
                if not firstname and not lastname:
                    firstname = offer.get('recipientEmail', '')
                offer['recipienName'] = '{firstname} {lastname}'.format(
                    firstname=firstname,
                    lastname=lastname
                ).strip()
                offer['ping_info'] = '{ping_to_message}: {recipient_name}'.format(
                    recipient_name=offer['recipienName'],
                    ping_to_message=ping_to_message)

    def process_date(self):
        for date_object in self.shared_offers:
            for key in date_object.keys():
                if isinstance(date_object[key], datetime.datetime or datetime or datetime.date):
                    date_object[key] = get_formatted_date(date_object[key])

    def set_ping_message_and_color(self):
        self.ping_details['message'] = self.ping_message
        self.ping_details['background_color'] = self.ping_background_color

    def process_request(self, *args, **kwargs):
        """
        This method gets the list of shared offers.
        :return: Response with a list of pending offers
        """
        # customer_id is not a required param in php but without, API doesn't work. so either make it required or fetch
        # it from session data in case it is not there in query_params
        # if not self.customer_id:
        # self.customer_id = get_current_customer().get('customer_id', 0)
        self.initialize_class_attributes()

        self.load_customer_data()
        api_configs = get_api_configurations(self.customer['company'], current_app.config['ENV'].lower())
        self.company_type = api_configs.get('company_type')
        if not api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE):
            raise Forbidden("You are not allowed to access this API.")
        self.set_ping_details()
        if self.shared_offers:
            self.update_received_offers()
            self.process_date()
        self.set_ping_message_and_color()
        self.send_response_flag = True
        self.response = {
            'data': {
                'shareOffers': self.shared_offers,
                'ping_section': self.ping_details
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
