"""
Validation params of hotels api
"""
from flask_restful import reqparse

from ping_service.common.utils.custom_request_fields_parser import language

accept_ping_parser = reqparse.RequestParser(bundle_errors=True)


accept_ping_parser.add_argument(
    'language',
    type=language,
    required=False,
    default="en",
    location='json'
)
accept_ping_parser.add_argument(
    'status',
    type=int,
    default=1,
    location='json'
)
accept_ping_parser.add_argument(
    'entry_id',
    type=str,
    required=False,
    location='json'
)
accept_ping_parser.add_argument(
    'ping_id',
    type=int,
    required=False,
    location='json'
)
accept_ping_parser.add_argument(
    'ping_ids',
    type=int,
    action='append',
    required=False,
    default=[],
    location=['json']
)
