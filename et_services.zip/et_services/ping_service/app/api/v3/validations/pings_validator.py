"""
Validation params of hotels api
"""
from flask_restful import reqparse

from ping_service.common.utils.custom_request_fields_parser import language, validate_email

ping_parser = reqparse.RequestParser(bundle_errors=True)

ping_parser.add_argument(
    'language',
    type=language,
    required=False,
    default="en",
    location='json'
)
ping_parser.add_argument(
    'email',
    type=validate_email,
    required=False,
    default=None,
    location='json'
)
ping_parser.add_argument(
    'offer_ids[]',
    type=int,
    required=False,
    action="append",
    location='json'
)
