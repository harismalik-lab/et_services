import uuid

from flask import current_app, request
from phpserialize import dumps as php_json_dumps
from requests import codes
from werkzeug.exceptions import Forbidden

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.constants import (
    CUSTOMER_ID_NOT_FOUND, OFFER_IDS_MISSING, USER_CANNOT_PING_OFFER_CHEER, YOU_CANNOT_PING_THIS_OFFER
)
from ping_service.app.api.v3.validations.pings_validator import ping_parser
from ping_service.common.base_resource import BasePostResource
from ping_service.common.models.api_configuration import ApiConfiguration
from ping_service.common.models.ent_customer_profile import EntCustomerProfile
from ping_service.common.models.ent_send_email import EntSendEmail
from ping_service.common.models.family_member import FamilyMember
from ping_service.common.models.offer import Offer
from ping_service.common.models.product import Product
from ping_service.common.models.product_offer import ProductOffer
from ping_service.common.models.redemption import Redemption
from ping_service.common.models.share_offer import ShareOffer
from ping_service.common.models.top_up_offers import TopUpOffer
from ping_service.common.models.user_info import UserInfo
from ping_service.common.utils.api_utils import get_api_configurations, get_locale_location_id
from ping_service.common.utils.authentication import get_current_customer, token_decorator_v3
from ping_service.common.utils.translation_manager import TranslationManager


class PostSharingSendApi(BasePostResource):
    """
    This class handles the post request for sending an offer endpoint.
    """
    request_parser = ping_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ping_service/sharing_sending_api.log',
        ),
        'name': 'sharing_sending_api'
    }
    strict_token = True
    required_token = True
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        self.offer_ids = self.request_args.get('offer_ids[]', [])
        if not self.offer_ids:
            self.offer_ids = request.form.get('offer_ids', [])
        self.email = self.request_args.get('email')
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        self.locale = get_locale_location_id(self.locale, location_id=0)
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.logged_in_customer = EntCustomerProfile.load_customer_profile_by_user_id(self.customer_id)
        self.email_data = {}
        self.merchant_name = ''
        self.ping_status = True
        self.any_condition_failed_for_ping = False
        #todo
        self.max_pings_allowed_to_receive = ShareOffer.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_NON_MEMBER
        self.is_ping_exempted_from_yearly_quota = False
        self.pings_received_by_recipient_count = 0
        self.pings_recipient_can_receive = 0
        self.is_cheers_to_include_recipient = False
        self.is_active_family_member = False
        self.ping_message = TranslationManager.get_translation(
            TranslationManager.Ping_Offer_Success_Message,
            self.locale
        )
        self.primary_user_id = self.customer_id
        self.primary_user_sender_id = self.customer_id
        self.secondary_member = False
        self.receiver_secondary = False
        self.recipient_family_info = {}
        self.sender_is_active_family_member = False
        if self.customer.get('is_user_in_family') and self.customer.get('family_is_active', False):
            self.sender_is_active_family_member = True
        if (
            not self.customer.get('is_primary', False) and
            self.customer.get('is_user_in_family') and
            self.customer.get('family_is_active', False)
        ):
            self.primary_user_id = self.customer.get('primary_member_info').get('user_id')
            self.primary_user_sender_id = self.primary_user_id
            self.sender_secondary_member = True

        self.recipient_user = EntCustomerProfile.load_customer_profile_by_email(self.email)
        if self.recipient_user:
            self.recipient_id = self.recipient_user.user_id
            self.recipient_family_info = FamilyMember.find_family_member(
                filters={
                    'user_id': self.recipient_id,
                    'status': FamilyMember.ACCEPTED,
                    'is_active': 1
                }
            )
            if self.recipient_family_info:
                self.is_active_family_member = True
                if not self.recipient_family_info.is_primary:
                    self.receiver_secondary = True
                self.primary_recipient_user_id = 0
                self.recipients_family_members = FamilyMember.find_family_member(
                    filters={
                        'family_id': self.recipient_family_info.family_id
                    },
                    single=False
                )
                self.is_cheers_to_include_recipient = self.recipient_family_info.is_cheers_to_include
                for recipients_family_member in self.recipients_family_members:
                    if recipients_family_member.is_primary:
                        self.primary_recipient_user_id = recipients_family_member.user_id
        self.customer['product_ids'] = list(map(int, list(filter(None, self.customer.get('product_ids', [])))))

    def get_family_members_users_ids_list(self):
        """
        Gets the family members users id list
        """
        family_id = self.customer['family_info'].id
        # todo
        family_members = FamilyMember.find_family_member(
            filters={
                'family_id': family_id,
                'is_active': 1,
                'status': FamilyMember.ACCEPTED
            }
            , single=False
        )
        self.family_user_ids = []
        for family_member in family_members:
            if family_member.user_id:
                self.family_user_ids.append(family_member.user_id)

    def prepare_email_data(self):
        # two fields in the following dict are interchanged in php code. I haven't changed it for consistency
        self.email_data = php_json_dumps({
            '{FIRST_NAME}': self.recipient_user.firstname,
            '{var sender_name}': self.logged_in_customer.email,
            '{var sender_email_address}': EntCustomerProfile.get_full_customer_name(
                self.logged_in_customer
            ),
            '{var num_of_offers}': len(self.offer_ids),
            '{var merchant_name}': self.merchant_name
        })

    def prepare_response(self, status_message, ping_message, code, status, success, ping_status):
        self.send_response_flag = True
        self.response = {
            'code': code,
            'success': success,
            'message': status_message,
            'data': {
                'status': ping_status,
                'message': ping_message,
            }
        }
        if success:
            self.response['message'] = 'success'
        self.status_code = status
        return self.send_response(self.response, self.status_code)

    def prepare_valid_customer_response(self):
        self.send_response_flag = True
        if self.any_condition_failed_for_ping:
            self.prepare_response(self.ping_message, self.ping_message, 90, codes.unprocessable, False, False)
            return
        self.prepare_response(True, self.ping_message, 70, codes.ok, True, True)

    def prepare_invalid_customer_response(self):
        self.send_response_flag = True
        self.response = {
            'code': 70,
            'success': False,
            'message': CUSTOMER_ID_NOT_FOUND
        }
        self.status_code = 422
        return self.send_response(self.response, self.status_code)

    def logged_in_customer_processing(self):
        if self.receiver_secondary:
            customer_ping_quota = UserInfo.get_customer_ping_quota(self.primary_recipient_user_id)
        else:
            customer_ping_quota = UserInfo.get_customer_ping_quota(self.customer_id)

        self.is_ping_exempted_from_yearly_quota = bool(customer_ping_quota.is_exempt_from_yearly_quota)
        self.recipient_id = 0
        self.recipient_user = EntCustomerProfile.load_customer_profile_by_email(self.email)
        if self.recipient_user:
            self.recipient_id = self.recipient_user.user_id
            if self.receiver_secondary:
                self.max_pings_allowed_to_receive = ShareOffer.get_ping_limit_allowed(
                    EntCustomerProfile.MEMBERSTATUS_MEMBER
                )
            else:
                self.max_pings_allowed_to_receive = ShareOffer.get_ping_limit_allowed(
                    self.recipient_user.new_member_group
                )
        if self.recipient_id == self.customer_id:
            self.ping_message = TranslationManager.get_translation(
                TranslationManager.Ping_Sender_Cant_Be_Recipient,
                self.locale
            )
            self.any_condition_failed_for_ping = True
        else:
            self.get_family_members_users_ids_list()
            if self.recipient_id in self.family_user_ids:
                self.ping_message = TranslationManager.get_translation(
                    TranslationManager.Ping_Recipient_Cant_Be_Family_Member,
                    self.locale
                )
                self.any_condition_failed_for_ping = True

            # Checks that the recipient is the primary family member or the secondary family member.
        if not self.any_condition_failed_for_ping:
            if self.recipient_id:
                primary_recipient_user_id = 0
                if self.recipient_family_info:
                    for recipients_family_member in self.recipients_family_members:
                        if recipients_family_member.is_primary:
                            primary_recipient_user_id = recipients_family_member.user_id
                self.process_pings_received_by_recipient(self.recipient_id, primary_recipient_user_id)
            else:
                self.process_pings_received_by_recipient(
                    self.recipient_id
                )

    def validate_offers_before_pinging(self, offer_ids, product_ids, customer_id, member_type):
        """
        Validates offers are ping able
        :param list offer_ids: Offer Ids
        :param list product_ids: Product Ids
        :param int customer_id: Customer Id
        :param int member_type: Customer membership status
        :return: bool
        """
        offer_ids = list(map(int, filter(None, offer_ids)))
        if member_type != EntCustomerProfile.MEMBERSTATUS_MEMBER:
            return False
        top_up_offers = TopUpOffer.get_top_up_offers_primary(customer_id, location_id=0, offer_id=offer_ids)
        top_up_offers_dict = {}
        for top_up_offer in top_up_offers:
            top_up_offer = top_up_offer._asdict()
            if top_up_offers_dict.get(top_up_offer['offer_id']):
                top_up_offers_dict[top_up_offer['offer_id']] += 1
            else:
                top_up_offers_dict[top_up_offer['offer_id']] = 1
        shared_offers_sent = ShareOffer.get_shared_offers_by_sender_primary(customer_id, offer_id=offer_ids)
        redemptions_dict = Redemption.get_redeemed_quantites_for_customer_primary(
            customer_id, company='entertainer', offer_id=offer_ids
        )
        product_ids_dict = ProductOffer.get_product_ids_against_offer_ids(offer_ids)
        # todo

        quantities = Offer.get_offer_quantities(offer_ids)
        unique_offer_ids = list(set(offer_ids))
        for offer_id in unique_offer_ids:
            shared_sent_count = 0
            num_purchased = 0
            for shared_offer_sent in shared_offers_sent:
                shared_offer_sent = shared_offer_sent._asdict()
                if shared_offer_sent.get('offer_id') == offer_id:
                    shared_sent_count = shared_sent_count + 1
            num_redemptions = redemptions_dict.get(offer_id, 0) - top_up_offers_dict.get(offer_id, 0)
            set_of_product_ids = product_ids_dict.get(int(offer_id))
            if set_of_product_ids:
                for product_id in list(set_of_product_ids):
                    num_purchased += product_ids.count(product_id)
            quantity_redeemable = 0
            if quantities:
                quantity_redeemable = num_purchased * quantities.get(int(offer_id), 0)
            quantity_redeemable -= shared_sent_count
            quantity_redeemable = max(0, quantity_redeemable - num_redemptions)
            if not quantity_redeemable or offer_ids.count(offer_id) > quantity_redeemable:
                return False
        return True

    def check_offer_ids(self):
        if not self.offer_ids:
            self.send_response_flag = True
            self.response = {
                'code': 400,
                'success': False,
                'message': OFFER_IDS_MISSING
            }
            self.status_code = 400
            return self.send_response(self.response, self.status_code)

    def validate_offers_are_pingable(self):
        """
        Validates whether offers are ping-able
        """
        # todo
        allow = not Offer.any_offer_monthly_or_not_pingable(self.offer_ids)
        if not allow:
            self.response = {
                "success": False,
                "message": YOU_CANNOT_PING_THIS_OFFER,
                "code": 422
            }
            self.status_code = 422
            self.send_response_flag = True
        if self.is_active_family_member:
            if not self.is_cheers_to_include_recipient:
                # todo
                offer_types = Product.get_offer_types(self.offer_ids, self.company_type, self.customer['company'])
                any_cheer_offer = False
                for _, value in offer_types.items():
                    if value:
                        any_cheer_offer = True
                        break
                if any_cheer_offer:
                    self.response = {
                        "success": False,
                        "message": USER_CANNOT_PING_OFFER_CHEER,
                        "code": 422
                    }
                    self.status_code = 422
                    self.send_response_flag = True
                    return

        if self.sender_is_active_family_member:
            allow = self.validate_offers_before_pinging(
                self.offer_ids,
                self.customer.get('product_ids'),
                self.primary_user_id,
                EntCustomerProfile.MEMBERSTATUS_MEMBER
            )
        else:
            allow = self.validate_offers_before_pinging(
                self.offer_ids,
                self.customer.get('product_ids'),
                self.customer_id,
                self.customer.get('member_type_id')
            )
        if not allow:
            self.response = {
                "success": False,
                "message": YOU_CANNOT_PING_THIS_OFFER,
                "code": 422
            }
            self.status_code = 422
            self.send_response_flag = True

    def process_pings_received_by_recipient(self, recipient_id, primary_recipient_user_id=0):
        # if receiver is the member of the family then pass the recipient_primary_member_user_id.
        if primary_recipient_user_id:
            # Get counter of user received pings. Currently set to zero as allowing unlimited quota.
            self.pings_received_by_recipient_count = 0
        elif recipient_id and self.recipient_user.new_member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER:
            self.pings_received_by_recipient_count = 0
        elif recipient_id:
            self.pings_received_by_recipient_count = ShareOffer.get_pings_accepted_or_pending_by_user_id_or_email(
                self.recipient_id, True, True
            )
        elif self.email:
            self.pings_received_by_recipient_count = ShareOffer.get_pings_accepted_or_pending_by_user_id_or_email(
                self.email, True, True
            )
        self.pings_recipient_can_receive = max(
            0, self.max_pings_allowed_to_receive - self.pings_received_by_recipient_count
        )
        if len(self.offer_ids) > self.pings_recipient_can_receive:
            self.any_condition_failed_for_ping = True
            if self.pings_recipient_can_receive == 0:
                self.ping_message = TranslationManager.get_translation(
                    TranslationManager.Ping_Quota_Finished_To_Receive_For_Recipient,
                    self.locale
                )
            else:
                message_key = TranslationManager.Ping_Quota_Left_To_Receive_For_Recipient_Single
                if self.pings_recipient_can_receive > 0:
                    message_key = TranslationManager.Ping_Quota_Left_To_Receive_For_Recipient_Multiple
                self.ping_message = TranslationManager.get_translation(message_key, self.locale)
                self.ping_message = self.ping_message.replace('__offer_count__', str(self.pings_recipient_can_receive))
        if not self.any_condition_failed_for_ping:
            gu_id = str(uuid.uuid4().hex)
            # todo
            product_ids = Product.get_product_id_by_offer_id(
                self.offer_ids, self.company_type, self.customer['company'], default={}
            )
            for offer_id in self.offer_ids:
                if not self.merchant_name:
                    self.merchant_name = Offer.find_merchant_name(offer_id, 'en')
                share_offer_obj = ShareOffer(
                    entry_id=gu_id, offer_id=offer_id,
                    user_id=self.customer_id, recipient_email=self.email,
                    recipient_id=recipient_id, primary_recipient_user_id=primary_recipient_user_id,
                    primary_sender_user_id=self.primary_user_sender_id,
                    product_id=product_ids.get(int(offer_id)).id
                )
                share_offer_obj.insert_record()

    def process_request(self, *args, **kwargs):
        self.check_offer_ids()
        if self.send_response_flag:
            return

        self.initialize_class_attributes()
        api_configs = get_api_configurations(self.customer['company'], current_app.config['ENV'].lower())
        self.company_type = api_configs.get('company_type')
        if not api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE):
            raise Forbidden("You are not allowed to access this API.")
        self.validate_offers_are_pingable()
        if self.send_response_flag:
            return

        if self.logged_in_customer:
            self.logged_in_customer_processing()
            if not self.any_condition_failed_for_ping:
                self.prepare_email_data()
                send_email_obj = EntSendEmail(
                    email_template_type_id=7,
                    email_to=self.email,
                    language=self.locale,
                    priority=2,
                    email_template_data=self.email_data.decode(errors='ignore'),
                    optional_data=php_json_dumps({})
                )
                send_email_obj.insert_record()

        else:
            self.prepare_invalid_customer_response()
            if self.send_response_flag:
                return
        self.prepare_valid_customer_response()
