from flask import current_app
from requests import codes
from werkzeug.exceptions import Forbidden

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from ping_service.app.api.v3.validations.accept_ping_validator import accept_ping_parser
from ping_service.common.models.api_configuration import ApiConfiguration
from ping_service.common.models.share_offer import ShareOffer
from ping_service.common.utils.api_utils import get_api_configurations
from ping_service.common.utils.authentication import get_current_customer, token_decorator_v3
from ping_service.common.utils.translation_manager import TranslationManager


class PostSharingAcceptApi(BasePostResource):
    """
    This class handles the post request of accept sharing endpoint.
    """
    request_parser = accept_ping_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ping_service/sharing_accept_api.log',
        ),
        'name': 'sharing_accept_api'
    }
    strict_token = True
    required_token = True

    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        self.entry_id = self.request_args.get('entry_id')
        self.status = self.request_args.get('status')
        self.locale = self.request_args.get('language')
        self.ping_id = self.request_args.get('ping_id')
        self.ping_ids = self.request_args.get('ping_ids')

    def process_request(self, *args, **kwargs):
        self.customer_data = get_current_customer()
        api_configs = get_api_configurations(self.customer_data['company'], current_app.config['ENV'].lower())
        if not api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE):
            raise Forbidden("You are not allowed to access this API.")
        if self.ping_ids:
            self.validate_ping = ShareOffer.validate_pings_to_accept_or_reject(
                recipient_id=self.customer_data.get('user_id', 0),
                ping_ids=self.ping_ids
            )
            if self.validate_ping:
                ShareOffer.post_accept_or_reject_shared_offers(self.status, ping_ids=self.ping_ids)
                self.message = TranslationManager.get_translation('Ping_Accepted_Message', self.locale)

        self.send_response_flag = True
        self.response = {
            'data': {
                'message': self.message,
                'status': True
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
