import datetime

from flask import current_app
from requests import codes
from werkzeug.exceptions import Forbidden

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.utils.api_utils import get_formatted_date, get_locale_location_id, multi_key_sort
from ping_service.app.api.v3.validations.pings_validator import ping_parser
from ping_service.common.models.api_configuration import ApiConfiguration
from ping_service.common.models.ent_customer_profile import EntCustomerProfile
from ping_service.common.models.product import Product
from ping_service.common.models.share_offer import ShareOffer
from ping_service.common.utils.api_utils import get_api_configurations
from ping_service.common.utils.authentication import get_current_customer, token_decorator_v3
from ping_service.common.utils.translation_manager import TranslationManager


class GetSharingReceivedOffers(BasePostResource):
    """
    This class handles the retrieval of received offers endpoint
    :return: Response with a list of received offers
    """
    strict_token = True
    required_token = True
    request_parser = ping_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ping_service/sharing_receive_offer_api.log',
        ),
        'name': 'sharing_receive_offer_api'
    }
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        self.locale = get_locale_location_id(self.locale, location_id=0)
        self.max_pings_allowed_to_receive = 0
        self.pings_received_by_recipient_count = 0
        self.ping_message = ""
        self.ping_color_code = ShareOffer.COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND
        self.ping_section = {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }
        self.customer = get_current_customer()
        self.customer_id = self.customer.get('customer_id')
        self.primary_user_id = self.customer.get('primary_member_info').user_id
        show_pop_up = False
        self.is_active_family_member = self.customer['family_is_active'] and self.customer['is_user_in_family']
        if not self.is_active_family_member:
            if self.customer['member_type_id'] == EntCustomerProfile.MEMBERSTATUS_MEMBER:
                cheer_products = Product.get_cheers_product_by_product_ids(
                    self.customer.get('product_ids', [])
                )
                if not cheer_products:
                    show_pop_up = True
            else:
                show_pop_up = True
        if self.customer.get('is_primary', False) or not self.customer.get('is_user_in_family'):
            self.received_offers = ShareOffer.get_shared_received_offers(
                self.customer_id,
                self.locale,
                primary_recipent_id=self.primary_user_id,
                pings_history=True,
                include_rejected=True
            )
        else:
            self.received_offers = ShareOffer.get_shared_received_offers(
                recipient_id=self.customer_id,
                primary_recipent_id=self.primary_user_id,
                locale=self.locale,
                pings_history=True,
                include_rejected=True
            )
        self.received_offers = self.populate_received_offers_ping_history(
            received_offers=self.received_offers,
            show_pop_up=show_pop_up,
            locale=self.locale,
            order_by_status=True
        )

    def populate_received_offers_ping_history(
        self, received_offers=[], show_pop_up=False, locale='en', order_by_status=False
    ):
        resultant_offers = []
        for offer_obj in received_offers:
            offer = offer_obj._asdict()
            offer['is_sent'] = False
            offer['ping_status'] = ShareOffer.PING_STATUS_SENT
            if show_pop_up:
                offer["is_cheers"] = offer['is_cheers']
            else:
                offer["is_cheers"] = show_pop_up
            offer['is_accepted'] = offer['status'] == ShareOffer.TYPE_ACCEPTED
            if offer['is_accepted']:
                offer['ping_status'] = ShareOffer.PING_STATUS_ACCEPTED
            offer['pings_order'] = 9999
            if offer['status'] == ShareOffer.TYPE_NEW:
                offer['pings_order'] = 1
            if offer['status'] == ShareOffer.TYPE_REJECTED:
                offer['ping_status'] = ShareOffer.PING_STATUS_REJECTED
                offer['is_accepted'] = True
            offer['accept_button_text'] = ShareOffer.OFFER_ACCEPT_BUTTON_TEXT
            offer['reject_button_text'] = ShareOffer.OFFER_REJECT_BUTTON_TEXT
            offer['reject_message'] = TranslationManager.get_translation('Reject_Ping_Message', locale)
            offer['reject_title'] = TranslationManager.get_translation('Reject_Ping_Title', locale)
            offer['createdDate'] = get_formatted_date(offer['createdDate'])
            offer['acceptedDate'] = get_formatted_date(offer['acceptedDate'])
            resultant_offers.append(offer)
        if order_by_status:
            received_offers = multi_key_sort(
                resultant_offers,
                ['pings_order', 'id']
            )
        return received_offers

    def add_ping_section(self):
        if self.customer.get('is_primary', False) or not self.customer.get('is_user_in_family'):
            recipient = EntCustomerProfile.load_customer_profile_by_user_id(self.customer_id)
        else:
            recipient = EntCustomerProfile.load_customer_profile_by_user_id(self.primary_user_id)
        if recipient:
            self.max_pings_allowed_to_receive = ShareOffer.get_ping_limit_allowed(
                recipient.new_member_group
            )
        if self.customer.get('is_primary', False) or self.customer.get('is_user_in_family'):
            self.pings_received_by_recipient_count = 0
        else:
            self.pings_received_by_recipient_count = ShareOffer.get_pings_accepted_or_pending_by_user_id_or_email(
                self.customer_id, False, True, primary_user_id=self.primary_user_id
            )

        pings_recipient_can_receive = max(0, self.max_pings_allowed_to_receive - self.pings_received_by_recipient_count)

        if pings_recipient_can_receive:
            self.ping_color_code = ShareOffer.COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND  # noqa : E501
            message_key = TranslationManager.Ping_Count_Left_To_Receive_Single
            if pings_recipient_can_receive > 1:
                message_key = TranslationManager.Ping_Count_Left_To_Receive_Multiple
        else:
            self.ping_color_code = ShareOffer.COLOR_CODE_WHEN_USER_HAS_NO_PING_QUOTA_LEFT_TO_RECEIVE_OR_SEND
            message_key = TranslationManager.Ping_Quota_Finished_To_Receive
        if self.customer.get('is_primary', False) or self.customer.get('is_user_in_family'):
            self.ping_message = TranslationManager.get_translation(
                TranslationManager.Ping_Count_Left_To_Receive_Unlimited, self.locale
            )
        else:
            self.ping_message = TranslationManager.get_translation(message_key, self.locale)
            self.ping_message = self.ping_message.replace('__offer_count__', str(pings_recipient_can_receive))
        self.ping_section['is_recipient_info'] = True
        self.ping_section['can_user_receive_ping'] = bool(pings_recipient_can_receive)
        self.ping_section['total_quota_to_receive_pings'] = self.max_pings_allowed_to_receive
        self.ping_section['total_pings_received'] = self.pings_received_by_recipient_count
        self.ping_section['message'] = self.ping_message
        self.ping_section['background_color'] = self.ping_color_code

    def update_received_offers(self):
        sender_ids = [offer['senderId'] for offer in self.received_offers]
        senders = EntCustomerProfile.load_customer_profile_by_user_id(sender_ids)
        if senders:
            ping_by_message_key = TranslationManager.PING_BY_MESSAGE
            ping_by_message = TranslationManager.get_translation(ping_by_message_key, self.locale)
            for received_offer in self.received_offers:
                received_offer['senderName'] = '{firstname} {lastname}'.format(
                    firstname=senders.get(received_offer.get('senderId'), {}).firstname,
                    lastname=senders.get(received_offer.get('senderId'), {}).lastname
                )
                received_offer['ping_info'] = '{ping_by_message}: {sender_name}'.format(
                    sender_name=received_offer['senderName'],
                    ping_by_message=ping_by_message)

    def process_date(self):
        for date_object in self.received_offers:
            for key in date_object.keys():
                if isinstance(date_object[key], datetime.datetime or datetime or datetime.date):
                    date_object[key] = get_formatted_date(date_object[key])

    def process_request(self, *args, **kwargs):
        """
        This method gets the list of pending shared offers.
        :return: Response with a list of received offers
        """
        # customer_id is not a required param in php but without, API doesn't work. so either make it required or fetch
        # it from session data in case it is not there in query_params
        # if not self.customer_id:
        # self.customer_id = get_current_customer().get('customer_id', 0)
        self.initialize_class_attributes()
        api_configs = get_api_configurations(self.customer['company'], current_app.config['ENV'].lower())
        self.company_type = api_configs.get('company_type')
        if not api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE):
            raise Forbidden("You are not allowed to access this API.")
        if self.received_offers:
            self.update_received_offers()
            self.process_date()
        self.add_ping_section()
        self.send_response_flag = True
        self.response = {
            'data': {
                'shareOffers': self.received_offers,
                'ping_section': self.ping_section
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
