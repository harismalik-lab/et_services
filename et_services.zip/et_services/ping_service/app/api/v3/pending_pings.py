import datetime

from flask import current_app
from requests import codes
from werkzeug.exceptions import Forbidden

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.base_resource import BasePostResource
from common.utils.api_utils import get_formatted_date, get_locale_location_id
from ping_service.app.api.v3.validations.pings_validator import ping_parser
from ping_service.common.constants import (
    BODY, COLOR_BODY, COLOR_LEISURE, COLOR_RESTAURANTS_AND_BARS, COLOR_RETAIL, COLOR_SERVICES, COLOR_TRAVEL, IMAGE_BODY,
    IMAGE_LEISURE, IMAGE_RESTAURANTS_AND_BARS, IMAGE_RETAIL, IMAGE_SERVICES, IMAGE_TRAVEL, LEISURE,
    RESTAURANTS_AND_BARS, RETAIL, SERVICES, TRAVEL
)
from ping_service.common.models.api_configuration import ApiConfiguration
from ping_service.common.models.ent_customer_profile import EntCustomerProfile
from ping_service.common.models.offer import Offer
from ping_service.common.models.share_offer import ShareOffer
from ping_service.common.models.user import User
from ping_service.common.utils.api_utils import get_api_configurations
from ping_service.common.utils.authentication import get_current_customer, token_decorator_v3


class GetSharingPendingApi(BasePostResource):
    """
    This class handles the retrieval of pending shared offers endpoint
    """
    strict_token = True
    required_token = True
    request_parser = ping_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='ping_service/sharing_pending_api.log',
        ),
        'name': 'sharing_pending_api'
    }
    validators = [token_decorator_v3]

    def populate_request_arguments(self):
        """
        Populate the request arguments
        """
        self.locale = self.request_args.get('language')

    def initialize_class_attributes(self):
        """
        Initializes the class attributes
        """
        self.locale = get_locale_location_id(self.locale, location_id=0)
        self.customer = User.load_customer_by_id(self.customer_id)
        self.pending_offers = []

    def valid_customer_and_pending_offers_not_empty_processing(self):
        """
        Validates customer pending pings
        """
        user_ids = [offer['user_id'] for offer in self.pending_offers]
        offer_ids = [offer.get('offer_id', 0) for offer in self.pending_offers]
        senders = EntCustomerProfile.load_customer_profile_by_user_id(user_ids)
        offer_details = Offer.get_offer_merchant_details(offer_ids, self.locale, group_by=True)
        grouped_offers = {}
        for offer_obj in offer_details:
            offer = offer_obj._asdict()
            if offer['category'].lower() == RESTAURANTS_AND_BARS:
                offer['category_image'] = IMAGE_RESTAURANTS_AND_BARS
                offer['category_color'] = COLOR_RESTAURANTS_AND_BARS
            elif offer['category'].lower() == BODY:
                offer['category_image'] = IMAGE_BODY
                offer['category_color'] = COLOR_BODY
            elif offer['category'].lower() == LEISURE:
                offer['category_image'] = IMAGE_LEISURE
                offer['category_color'] = COLOR_LEISURE
            elif offer['category'].lower() == TRAVEL:
                offer['category_image'] = IMAGE_TRAVEL
                offer['category_color'] = COLOR_TRAVEL
            elif offer['category'].lower() == SERVICES:
                offer['category_image'] = IMAGE_SERVICES
                offer['category_color'] = COLOR_SERVICES
            elif offer['category'].lower() == RETAIL:
                offer['category_image'] = IMAGE_RETAIL
                offer['category_color'] = COLOR_RETAIL
            # grouping by o.id in case of list of offer ids
            if offer['offer_valid_to']:
                offer['offer_valid_to'] = get_formatted_date(offer['offer_valid_to'])
            grouped_offers.update({offer['offer_id']: offer})
        offer_details = grouped_offers
        for pending_offer in self.pending_offers:
            pending_offer['user_name'] = 'A user'
            if senders:
                pending_offer['user_name'] = '{firstname} {lastname}'.format(
                    firstname=senders.get(pending_offer['user_id'], {}).firstname,
                    lastname=senders.get(pending_offer['user_id'], {}).lastname
                )
            pending_offer['offer_id'] = pending_offer['offer_id'].split(',')
            pending_offer['offers'] = []
            pending_offer['offers'].extend(
                [offer_details.get(int(off_id), {}) for off_id in pending_offer['offer_id']]
            )

    def process_date(self):
        """
        Processes the date
        """
        for date_object in self.pending_offers:
            for key in date_object.keys():
                if isinstance(date_object[key], datetime.datetime or datetime or datetime.date):
                    date_object[key] = get_formatted_date(date_object[key])

    def process_request(self, *args, **kwargs):
        """
        This method gets the list of pending shared offers.
        :return: Response with a list of pending offers
        """
        self.current_customer = get_current_customer()
        self.customer_id = self.current_customer.get('customer_id', 0)
        self.initialize_class_attributes()
        api_configs = get_api_configurations(self.current_customer['company'], current_app.config['ENV'].lower())
        if not api_configs.get(ApiConfiguration.ENABLE_PING_FEATURE):
            raise Forbidden("You are not allowed to access this API.")
        if self.customer:
            shared_offers = ShareOffer.get_shared_offers_pending(self.customer_id)
            offer_ids = []
            self.pending_offers = []
            if shared_offers:
                for shared_offer_obj in shared_offers:
                    shared_offer = shared_offer_obj._asdict()
                    is_cheers = map(int, shared_offer.get('is_cheers').split(','))
                    shared_offer["is_cheers"] = any(is_cheers)
                    # if return_offer_ids:
                    offer_ids.extend(list(map(int, shared_offer.get('offer_id').split(','))))
                    shared_offer['offer_id'] = ','.join(list(map(lambda offer_id: str(offer_id), list(set(offer_ids)))))
                    self.pending_offers.append(shared_offer)
            # if self.pending_offers:
            #     return shared_offer_result, list(set(offer_ids))

            if self.pending_offers:
                self.valid_customer_and_pending_offers_not_empty_processing()
                self.process_date()

        self.send_response_flag = True
        self.response = {
            'data': {
                'shareOffers': self.pending_offers
            },
            'success': True,
            'message': 'success'
        }
        self.status_code = codes.OK
