#!/usr/bin/env python
import os

from elasticapm.contrib.flask import ElasticAPM
from flask import Flask, g
from flask_caching import Cache
from flask_compress import Compress
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_mongoengine import MongoEngine

from app_configurations.app_environments import DevelopmentConfig
from app_configurations.settings import api_prefix
from ping_service.common.models.db import db

compress = Compress()
cache = None


# TODO: Remove these logs when we go to proper micro services
def make_log_folders(_app):
    """
    Makes the log folders
    :param _app: current app
    """
    if _app.config.get('LOGS_PATH', ''):
        parent_log_folder = _app.config.get('LOGS_PATH')
        if not os.path.exists(parent_log_folder):
            os.makedirs(parent_log_folder)
            if _app.config.get('ALL_SUBS_LOGS_FOLDERS', ''):
                sub_folder_names = _app.config.get('ALL_SUBS_LOGS_FOLDERS', [])
            else:
                from ping_service.modules.constants import LOG_SUB_FOLDERS
                sub_folder_names = LOG_SUB_FOLDERS
            for sub_folder_name in sub_folder_names:  # creating sub folders
                if not os.path.exists(os.path.join(parent_log_folder, sub_folder_name)):
                    os.makedirs(os.path.join(parent_log_folder, sub_folder_name))


def create_app(config_settings=DevelopmentConfig):
    """
    Configure the flask-app.
    :param config_settings: config_settings
    :return flask-app
    """
    global cache
    _app = Flask(__name__, instance_relative_config=True)
    _app.config.from_object(config_settings)
    try:
        _app.config.from_envvar('APPLICATION_SETTINGS')
    except RuntimeError:
        pass
    if not cache:
        cache = Cache(config=_app.config)
    _app.url_map.strict_slashes = False
    make_log_folders(_app)
    compress.init_app(_app)
    jwt = JWTManager(_app)
    mongo_db = MongoEngine(_app)
    cache.init_app(_app)
    db.init_app(_app)
    db.app = _app

    with _app.app_context():
        cache.clear()
        g.app = _app
        g.mongo_db = mongo_db
        g.jwt = jwt
        g.cache = cache
        g.db = db
        if _app.config.get('TOKEN_DECORATOR'):
            from ping_service.common.utils.api_utils import get_function_from_string
            setattr(_app, 'token_decorator', get_function_from_string(_app.config.get('TOKEN_DECORATOR')).get('func'))
        from ping_service.app.api_settings import api_urls
        api_urls()  # routings initialization
        CORS(_app, resources={r"/{}/*".format(api_prefix): {"origins": "*"}})
    if _app.config.get('GENERATE_ALL_APM_LOGS', False):
        ElasticAPM(_app)
    return {'app': _app}


app = create_app()['app']
