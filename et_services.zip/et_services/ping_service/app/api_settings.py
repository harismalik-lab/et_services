"""
This modules loads APIs for a specific service
"""
from flask import g

from ping_service.app.routings.routings_v3 import PingAPIV3

API_LOG_PATH = 'ping_service/'


def api_urls():
    PingAPIV3(app=g.app, name=PingAPIV3.__name__).map_urls()
