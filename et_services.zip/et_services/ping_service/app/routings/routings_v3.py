"""
This module contains routing for ping app
"""

from ping_service.app.api.v3.accept_ping import PostSharingAcceptApi
from ping_service.app.api.v3.pending_pings import GetSharingPendingApi
from ping_service.app.api.v3.received_pings import GetSharingReceivedOffers
from ping_service.app.api.v3.send_ping import PostSharingSendApi
from ping_service.app.api.v3.sent_pings import GetSharingSendOffers
from ping_service.common.base_routing import BaseRouting


class PingAPIV3(BaseRouting):
    api_version = '3'

    def set_routing_collection(self):
        self.routing_collection['send_offer'] = {
            'url': '/sharing/send',
            'view': PostSharingSendApi
        }

        self.routing_collection['sent_offers'] = {
            'url': '/sharing/sendoffers',
            'view': GetSharingSendOffers
        }
        self.routing_collection['received_offers'] = {
            'url': '/sharing/receivedoffers',
            'view': GetSharingReceivedOffers
        }

        self.routing_collection['accept_offer'] = {
            'url': '/sharing/accept',
            'view': PostSharingAcceptApi
        }

        self.routing_collection['pending_offers'] = {
            'url': '/sharing/pending',
            'view': GetSharingPendingApi
        }
