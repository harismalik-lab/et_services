"""
Micro services' REST URLs reside here
"""
from app_configurations.settings import (DEV, LOCAL, PROD, QA, RC, UAT, UAT_2,
                                         UAT_3, api_prefix)
from common.routes import TEAPIs
from flask import current_app

LOCAL_HOST = '127.0.0.1'


def _get_host_name(service_name, port_number):
    """
    This function gives the Base API Url depending on the environment variable.
    If api_version is provided, it also appends the version of API.
    :param str service_name: Name of service
    :param int port_number: Port number of service
    """
    env = current_app.config['ENV']

    uat_base_urls = {
        TEAPIs.REDEMPTION_SERVICE_NAME: 'apiutb2brdmsrvrpy',
        TEAPIs.CONFIG_SERVICE_NAME: 'apiutb2bcnfsrvrpy',
        TEAPIs.OUTLET_SERVICE_NAME: 'apiutb2boutsrvrpy',
        TEAPIs.MERCHANT_SERVICE_NAME: 'apiutb2bmrhsrvrpy',
        TEAPIs.ENT_SERVICE_NAME: 'apiutb2bentsrvrpy',
        TEAPIs.USER_SERVICE_NAME: 'apiutb2busrsrvrpy'
    }

    rc_base_urls = {
        TEAPIs.REDEMPTION_SERVICE_NAME: 'apircb2brdmsrvrpy',
        TEAPIs.CONFIG_SERVICE_NAME: 'apircb2bcnfsrvrpy',
        TEAPIs.OUTLET_SERVICE_NAME: 'apircb2boutsrvrpy',
        TEAPIs.MERCHANT_SERVICE_NAME: 'apircb2bmrhsrvrpy',
        TEAPIs.ENT_SERVICE_NAME: 'apircb2bentsrvrpy',
        TEAPIs.USER_SERVICE_NAME: 'apircb2busrsrvrpy'
    }

    prod_base_urls = {
        TEAPIs.REDEMPTION_SERVICE_NAME: 'redemption',
        TEAPIs.CONFIG_SERVICE_NAME: 'etconf',
        TEAPIs.OUTLET_SERVICE_NAME: 'outlet',
        TEAPIs.MERCHANT_SERVICE_NAME: 'merchant',
        TEAPIs.ENT_SERVICE_NAME: 'ent',
        TEAPIs.USER_SERVICE_NAME: 'user'
    }

    environment_base_urls = {
        LOCAL: 'http://{}:{}'.format(LOCAL_HOST, port_number),
        DEV: 'https://{}dvsvr.etenvbiz.com/{}'.format(service_name, api_prefix),
        QA: 'https://{}qasvr.etenvbiz.com/{}'.format(service_name, api_prefix),
        UAT: 'https://{}.theentertainerme.com/{}'.format(uat_base_urls[service_name], api_prefix),
        UAT_2: 'https://{}2.theentertainerme.com/{}'.format(uat_base_urls[service_name], api_prefix),
        UAT_3: 'https://{}3.theentertainerme.com/{}'.format(uat_base_urls[service_name], api_prefix),
        RC: 'https://{}.theentertainerme.com/{}'.format(rc_base_urls[service_name], api_prefix),
        PROD: 'https://apipdb2balftpy.theentertainerme.com/{}'.format(prod_base_urls[service_name]),
    }

    if environment_base_urls.get(env):
        return environment_base_urls[env]
    else:
        raise Exception("Environment variable ENV not set correctly: Should be {}".format(", ".join(environment_base_urls.keys())))  # noqa


class RedemptionServiceAPIUrls(object):
    """
    Redemption Service Rest API Urls
    """
    VERSION = 1
    HOSTNAME = _get_host_name(TEAPIs.REDEMPTION_SERVICE_NAME, TEAPIs.REDEMPTION_SERVICE_PORT)
    # Calculate Redeemability REST URL
    CALCULATE_REDEEMABILITY = '{0}/v{1}/offer/check/redeemability'.format(
        HOSTNAME,
        VERSION
    )


class RedemptionServiceAPIUrlsV2(object):
    """
    Redemption Service Rest API Urls
    """
    VERSION = 2
    HOSTNAME = _get_host_name(TEAPIs.REDEMPTION_SERVICE_NAME, TEAPIs.REDEMPTION_SERVICE_PORT)
    # Calculate Redeemability REST URL
    CALCULATE_REDEEMABILITY = '{0}/v{1}/offer/check/redeemability'.format(
        HOSTNAME,
        VERSION
    )


class RedemptionServiceAPIUrlsV3(object):
    """
    Redemption Service Rest API Urls
    """
    VERSION = 3
    HOSTNAME = _get_host_name(TEAPIs.REDEMPTION_SERVICE_NAME, TEAPIs.REDEMPTION_SERVICE_PORT)
    CALCULATE_REDEEMABILITY = '{0}/v{1}/offer/check/redeemability'.format(
        HOSTNAME,
        VERSION
    )
    BUSINESS_DB_UPDATE_API = f'{HOSTNAME}/v{VERSION}/redeem/business_db_update'


class RedemptionServiceAPIUrlsV4(object):
    """
    Redemption Service Rest API Urls
    """
    VERSION = 4
    HOSTNAME = _get_host_name(TEAPIs.REDEMPTION_SERVICE_NAME, TEAPIs.REDEMPTION_SERVICE_PORT)
    CALCULATE_REDEEMABILITY = '{0}/v{1}/offer/check/redeemability'.format(
        HOSTNAME,
        VERSION
    )
    BUSINESS_DB_UPDATE_API = f'{HOSTNAME}/v{VERSION}/redeem/business_db_update'


class LocationServiceAPIUrls(object):
    """
    Config service Rest API Urls
    """
    VERSION = 1
    HOSTNAME = _get_host_name(TEAPIs.CONFIG_SERVICE_NAME, TEAPIs.CONFIG_SERVICE_PORT)
    LOCATION_CATEGORIES = '{0}/v{1}/location/categories'.format(
        HOSTNAME,
        VERSION
    )


class LocationServiceAPIUrlsV2(object):
    """
    Config service Rest API Urls
    """
    VERSION = 2
    HOSTNAME = _get_host_name(TEAPIs.CONFIG_SERVICE_NAME, TEAPIs.CONFIG_SERVICE_PORT)
    LOCATION_CATEGORIES = '{0}/v{1}/location/categories'.format(
        HOSTNAME,
        VERSION
    )
