"""
Common Constants reside here
"""

ENTERTAINER_WEB = 'entertainer_web'
ENTERTAINER_WL_LOOKUP = 'entertainer_wl_lookup'
CONSOLIDATION = 'consolidation'
INFORMATICA = 'informatica'
ENTERTAINER_TRAVEL = 'entertainer_travel'
ENTERTAINER_TOURS = 'entertainer_tours'
GAMIFICATION = 'gamification'

ENTERTAINER = "entertainer"
EN, AR, DE, CN, EL, ZH = 'en', 'ar', 'de', 'cn', 'el', 'zh'
INTERNAL_SERVER_ERROR = 'Internal Server Error'
SUPPORTED_LOCALES = (DE, EN, AR, CN, EL, ZH)
AED = 'AED'
USD = 'USD'
VALID_CURRENCIES = (
    AED,
    'BHD',
    'EGP',
    'EUR',
    'GBP',
    'HKD',
    'JOD',
    'KWD',
    'LBP',
    'MYR',
    'OMR',
    'QAR',
    'SAR',
    'SGD',
    USD,
    'ZAR'
)

FORBIDDEN_ERROR = 'you_are_not_allowed_to_access_this_application'
EN, AR, DE, CN, EL, ZH = 'en', 'ar', 'de', 'cn', 'el', 'zh'

ARABIC_LOCATION_IDS = (1, 2, 3, 6, 7, 8, 9, 10, 16, 18, 49)
GREEK_LOCATION_IDS = (5, 23)
CANTONESE_LOCATION_IDS = (13)
ALL_LOCATION_IDS = (1, 2, 3, 6, 7, 8, 9, 10, 13, 16, 18, 23)
DUBAI_LOCATION_ID = 1
# Custom API Response Codes
CUSTOM_ERROR_CODE = 70
INVALID_UUID_CODE = 71
USED_UUID_CODE = 72
CUSTOM_DOB_ERROR_CODE = 90
CUSTOM_USER_EXISTS_ERROR_CODE = 91
DEVICE_LIMIT_EXCEEDED = 80
INVOICE_CUSTOM_ERROR_CODE = 0
CUSTOM_EMAIL_NOT_LINKED_CODE = 73
CUSTOM_ERROR_CODE_EMAIL_ALREADY_EXISTS = 91
RADIUS_CONVERSION_UNIT = 100000
PLATFORM_IOS = "ios"
PLATFORM_ANDROID = "android"
JWT_AUTH_LAMBDA = 'JwtAuth'
OFFER_DOES_NOT_EXIST = 31
USER_INACTIVE = 13
# following constants are Global
BODY = 'body'
KIDS = 'kids'
LEISURE = 'leisure'
RESTAURANTS_AND_BARS = 'restaurants and bars'
RETAIL = 'retail'
SERVICES = 'services'
TRAVEL = 'travel'
ALL = 'all'

CATEGORY_NAME_BODY = 'Body'
CATEGORY_NAME_LEISURE = 'Leisure'
CATEGORY_NAME_RESTAURANTS_AND_BARS = 'Restaurants and Bars'
CATEGORY_NAME_RETAIL = 'Retail'
CATEGORY_NAME_SERVICES = 'Services'
CATEGORY_NAME_TRAVEL = 'Travel'
CATEGORY_ALL = 'All'

CATEGORY_API_NAME_BODY = 'Body'
CATEGORY_API_NAME_LEISURE = 'Leisure'
CATEGORY_API_NAME_RESTAURANTS_AND_BARS = 'Restaurants and Bars'
CATEGORY_API_NAME_RETAIL = 'Retail'
CATEGORY_API_NAME_SERVICES = 'Services'
CATEGORY_API_NAME_TRAVEL = 'Travel'
CATEGORY_API_NAME_KIDS = 'Kids'
CATEGORY_API_NAME_ALL = 'All'

VALID_CATEGORIES = (
    CATEGORY_API_NAME_BODY,
    CATEGORY_API_NAME_LEISURE,
    CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
    CATEGORY_API_NAME_RETAIL,
    CATEGORY_API_NAME_SERVICES,
    CATEGORY_API_NAME_TRAVEL
)

FEATURED_CATEGORY_TRAVEL = "Hotels Worldwide"

ENTERTAINER_GETAWAYS = "ENTERTAINER getaways"
CHEERS_LOCATION_CHECK = (1, 2)
MIN_VALID_APP_VERSION = '1.3'
SERVICE_Session_Helper_DEFAULT = "api.session_helper"
PARAM_VALUE_GEMS_Student_Patent_Id = "{student_parent_id}"
PARAM_VALUE_GEMS_BSU = "{bsu}"
CUSTOMER_ID = "customer_id"
IS_USER_LOGGED_IN = "is_user_logged_in"
IS_PREACTIVATED_APP = "is_preactivated_app"
NON_DEPLETABLE_OFFERS_APP = "non_depletable_offers_app"
PRODUCT_IDS = "product_ids"
PARAM_FETCHER = "param_fetcher"
REQUEST = 'request'
APP_TUTORIAL_BACKGROUND_IMAGE = 'https://www.pixelstalk.net/wp-content/uploads/2016/11/iPhone-7-Wallpaper-Grey-no-logo.jpg'  # noqa: E501
SAVINGS_IMAGE_URL = "https://s3.amazonaws.com/entertainer-app-assets/savings_image.png"
SAVINGS_SMALL_IMAGE_URL = "https://s3.amazonaws.com/entertainer-app-assets/savings_image_small.png"
NOT_INTERESTED_CHEERS_OFFER_MESSAGE = 'I do not want Clink but thanks anyway.'
PRODUCT_INFORMATION = 'Hundreds of Buy One Get One Free offers for drinks in the best restaurants, bars and nightspots across the UAE.'  # noqa: E501
CHEERS_LOGO_URL = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/logo-cheers-gems.png'  # noqa: E501
SYNSODYNE_CODE = 'CHSAU/CHSENO/0094/17a'

ENTERTAINER_HSBC_MAIN_TOP_COLOR_BLACK_CARD = 'aa000000'
ENTERTAINER_HSBC_MAIN_TOP_COLOR = 'aae63a2a'
ENTERTAINER_HSBC_MAIN_TOP_TEXT_COLOR = 'FFFFFF'
ENTERTAINER_HSBC_MAIN_TOP_IMAGE_BLACK_CARD = 'https://s3.amazonaws.com/app-home-tiles/more-from-hsbc/Black_hs.jpg'
ENTERTAINER_HSBC_MAIN_TOP_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/Generic-ios-Visual.jpg'

POINTS_AVAILABLE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png'
POINTS_USED_IMAGE = "https://s3.amazonaws.com/entertainer-app-assets/icons/ic_home_points.png"
TITLE_DETAIL_BOTTOM_MESSAGE = "Use your GEMS Points toward school fees! Minimum number of GEMS Points required: 5,550"  # noqa:E501
ENTERTAINER_GETAWAYS_INTERNAL_WEBVIEW_TITTLE = "ENTERTAINER getaways"
ENTERTAINER_GETAWAYS_CLOSE_WEBVIEW_MESSAGE = 'Are you sure you want to navigate away from ENTERTAINER getaways?'

AAG_MAIN_TOP_COLOR = 'aaff5c5c'
AAG_MAIN_TOP_TEXT_COLOR = '252525'
AAG_MAIN_TOP_IMAGE = ''

USER_GROUP_2 = 2
TITLE_COLOR = 'f99f1c'
TRAVEL_CAT_IMG_GEM = "https://s3.amazonaws.com/app-home-tiles/category-icons/gem/hotel.png"
TRAVEL_CAT_IMG_HSBS = "https://s3.amazonaws.com/entertainer-app-assets/categories/hsbc/hotel.png"
DUBAI_ENTERTAINMENTS_What_New = "What’s New"

ICON_URL_BASE = "https://s3.amazonaws.com/entertainer-app-assets/icons/"
HOTEL_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/hotel.png"
MALL_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/mall.png"
NEIGHBORHOOD_IMAGE = "https://s3-us-west-2.amazonaws.com/ent-search-results/neighbourhood.png"
BADGE_NEW_IMAGE_URL = "{icon_base}badge_new.png".format(icon_base=ICON_URL_BASE)
BADGE_MONTHLY_IMAGE_URL = "{icon_base}badge_monthly.png".format(icon_base=ICON_URL_BASE)
BADGE_CHEERS_IMAGE_URL = "{icon_base}badge_cheers.png".format(icon_base=ICON_URL_BASE)
BADGE_DELIVERY_IMAGE_URL = "{icon_base}badge_delivery.png".format(icon_base=ICON_URL_BASE)
BADGE_MORE_SA_IMAGE_URL = "{icon_base}badge_more_sa.png".format(icon_base=ICON_URL_BASE)
BADGE_PINGED_IMAGE_URL = "{icon_base}badge_pinged.png".format(icon_base=ICON_URL_BASE)
EID_OFFERS = ('eid', 'eid offers')
EID_OFFER = 'eid offer'
DEFAULT = 'default'
BEST_REVIEWED = 'best_reviewed'
MOST_REVIEWED = 'most_reviewed'
NEAREST = 'nearest_to_me'
ALPHA = 'alpha'
HOTEL = 'hotel'
MALL = 'mall'
NEIGHBORHOOD = 'neighborhood'

GEMS_LOGO = 'https://s3.amazonaws.com/entertainer-app-assets/icons/gem-logo.png'
NBAD_PAY_GEMS_LOGO = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/nbad.png'
NBAD_PAY = "NBAD Pay"
ENBD = "ENBD"
ENBD_GEMS_LOGO = 'https://s3-us-west-2.amazonaws.com/app-assets-whitelabel/nbd.png'
EMAX_LOGO = 'https://s3.amazonaws.com/entertainer-app-assets/icons/emax_logo.png'

SUMMARY_TYPE_BY_YEAR = 'by_year'
SUMMARY_TYPE_BY_MONTH = 'by_month'

JWT_HEADER_ERROR_MESSAGE = 'This device is not authorized to access the server. Please contact support team'
MISSING_JWT_ERROR_MESSAGE = 'JWT authorization missing'
JWT_DECODE_ERROR_MESSAGE = 'Invalid JWT'
JWT_SIGNATURE_MISMATCH = 'JWT SIGNATURE MISMATCH'

INVALID_TOKEN = "Token is not valid"
INVALID_JWT = "Unauthorized JWT Token"
INVALID_PARAMS = 'Invalid parameters'

DEFAULT_LIMIT = "0/day;0/hour;0/minute"
FUZZY_SEARCH_INDEX = 'entertainer_2018_en'

BODY_ID = 1
KIDS_ID = 2
LEISURE_ID = 3
RESTAURANTS_AND_BARS_ID = 4
SERVICES_ID = 5
TRAVEL_ID = 6
RETAIL_ID = 7

COLOR_BODY = "C7318C"
COLOR_LEISURE = "88C867"
COLOR_RESTAURANTS_AND_BARS = "4F99D2"
COLOR_RETAIL = "9866AC"
COLOR_SERVICES = "20909A"
COLOR_TRAVEL = "B3995D"
COLOR_CHEERS = "F05D51"

IMAGE_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/body.png"
IMAGE_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/leisure.png"
IMAGE_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/food.png"
IMAGE_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/retail.png"
IMAGE_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/services_2.png"
IMAGE_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel.png"
IMAGE_FREE_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/retail_free.png"
IMAGE_FREE_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/services_free.png"
IMAGE_FREE_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel_free.png"

# TODO: Need to change the followings according to pep8 constants convention
# please don't update constant name from here till the next comment as these are DB Defined
MAP_PIN_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_body@2x.png"
MAP_PIN_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_leisure@2x.png"
MAP_PIN_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_food@2x.png"
MAP_PIN_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_retail@2x.png"
MAP_PIN_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_services@2x.png"
MAP_PIN_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_travel@2x.png"

MAP_PIN_INVALID_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_body@2x.png"
MAP_PIN_INVALID_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_leisure@2x.png"  # noqa : E501
MAP_PIN_INVALID_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_food@2x.png"  # noqa : E501
MAP_PIN_INVALID_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_retail@2x.png"  # noqa : E501
MAP_PIN_INVALID_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_services@2x.png"  # noqa : E501
MAP_PIN_INVALID_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_invalid_travel@2x.png"  # noqa : E501


FEATURED_MERCHANT_ICON_URL_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501
# please don't update constant name till here

MAP_PIN_SELECTED_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_body@2x.png"  # noqa : E501
MAP_PIN_SELECTED_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_leisure@2x.png"  # noqa : E501
MAP_PIN_SELECTED_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_food@2x.png"  # noqa : E501
MAP_PIN_SELECTED_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_retail@2x.png"  # noqa : E501
MAP_PIN_SELECTED_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_services@2x.png"  # noqa : E501
MAP_PIN_SELECTED_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_travel@2x.png"  # noqa : E501

MAP_PIN_SELECTED_INVALID_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_body@2x.png"  # noqa : E501
MAP_PIN_SELECTED_INVALID_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_leisure@2x.png"  # noqa : E501
MAP_PIN_SELECTED_INVALID_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_food@2x.png"  # noqa : E501
MAP_PIN_SELECTED_INVALID_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_retail@2x.png"  # noqa : E501
MAP_PIN_SELECTED_INVALID_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_services@2x.png"  # noqa : E501
MAP_PIN_SELECTED_INVALID_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/cat_pin_selected_invalid_travel@2x.png"  # noqa : E501

FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501

ICON_URL_BODY = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_body.png"
ICON_URL_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_leisure.png"
ICON_URL_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_restaurants_and_bars.png"
ICON_URL_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_retail.png"
ICON_URL_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_services.png"
ICON_URL_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_travel.png"

FREE_CATEGORY_ICON = "https://s3.amazonaws.com/entertainer-app-assets/icons/free_category_icon.png"

IMAGE_LEISURE_LOCKED = "https://s3.amazonaws.com/entertainer-app-assets/categories/leisure_locked_for_onboarding.png"  # noqa : E501
IMAGE_TRAVEL_LOCKED = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel_locked_for_onboarding.png"
IMAGE_BODY_LOCKED = "https://s3.amazonaws.com/entertainer-app-assets/categories/beauty_locked_for_onboarding.png"
IMAGE_RETAIL_LOCKED = "https://s3.amazonaws.com/entertainer-app-assets/categories/fashion_locked_for_onboarding.png"
IMAGE_SERVICES_LOCKED = "https://s3.amazonaws.com/entertainer-app-assets/categories/everyday_services_locked_for_onboarding.png"  # noqa : E501

COLOR_BODY_GEMS = "C7318C"  # "ba3281"
COLOR_LEISURE_GEMS = "88C867"  # "84bf66"
COLOR_RESTAURANTS_AND_BARS_GEMS = "4F99D2"  # "4d92c6"
COLOR_RETAIL_GEMS = "9866AC"  # "249584"
COLOR_SERVICES_GEMS = "20909A"  # "249584"
COLOR_TRAVEL_GEMS = "B3995D"  # "b09660"
DELIVERY_STATUS_CANCELLED = 'cancelled'
DELIVERY_STATUS_PICK_START = 'pickup_started'
DELIVERY_STATUS_PICK_REACHED = 'pickup_arrived'
DELIVERY_STATUS_DROP_START = 'drop_started'
DELIVERY_STATUS_DROP_REACHED = 'drop_arrived'
DELIVERY_STATUS_COMPLETED = 'complete'
DELIVERY_STATUS_REQUESTED = 'requested'
SERVICE_DELAY_MESSAGE = 'Sorry, please expect a delay in delivery due to heavy rains'

CANCELLED = 'cancelled'
PENDING = 'pending'
COMPLETED = 'completed'

QUIQ_UP_COMPLETED_IMAGE_URL = 'https://entertainer-app-assets.s3.amazonaws.com/delivery/en/image_2019_08_19T08_04_40_502Z.png'  # noqa: E501

MAP_PIN_GENERIC_PIN_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/gems/cat_pin_{category}@2x.png"  # noqa:E501
Map_Pin_GENERIC_PIN_INVALID_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/categories/pins/gems/cat_pin_invalid_{category}@2x.png"  # noqa:E501


CATEGORY_BADGES = {
    CATEGORY_NAME_BODY: IMAGE_BODY,
    CATEGORY_NAME_LEISURE: IMAGE_LEISURE,
    CATEGORY_NAME_RESTAURANTS_AND_BARS: IMAGE_RESTAURANTS_AND_BARS,
    CATEGORY_NAME_RETAIL: IMAGE_RETAIL,
    CATEGORY_NAME_SERVICES: IMAGE_SERVICES,
    CATEGORY_NAME_TRAVEL: IMAGE_TRAVEL
}

FEATURED_RIBBON_IMAGE = {
    CATEGORY_NAME_BODY: FEATURED_MERCHANT_ICON_URL_BODY,
    CATEGORY_NAME_LEISURE: FEATURED_MERCHANT_ICON_URL_LEISURE,
    CATEGORY_NAME_RESTAURANTS_AND_BARS: FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS,
    CATEGORY_NAME_RETAIL: FEATURED_MERCHANT_ICON_URL_RETAIL,
    CATEGORY_NAME_SERVICES: FEATURED_MERCHANT_ICON_URL_SERVICES,
    CATEGORY_NAME_TRAVEL: FEATURED_MERCHANT_ICON_URL_TRAVEL
}

FEATURED_HOMES_IMAGE = {
    CATEGORY_NAME_BODY: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_BODY,
    CATEGORY_NAME_LEISURE: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_LEISURE,
    CATEGORY_NAME_RESTAURANTS_AND_BARS: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RESTAURANTS_AND_BARS,
    CATEGORY_NAME_RETAIL: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RETAIL,
    CATEGORY_NAME_SERVICES: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_SERVICES,
    CATEGORY_NAME_TRAVEL: FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_TRAVEL
}

CATEGORIES_LOWER_TO_TITLE = {
    BODY: CATEGORY_API_NAME_BODY,
    KIDS: CATEGORY_API_NAME_KIDS,
    LEISURE: CATEGORY_API_NAME_LEISURE,
    RESTAURANTS_AND_BARS: CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
    RETAIL: CATEGORY_API_NAME_RETAIL,
    SERVICES: CATEGORY_API_NAME_SERVICES,
    TRAVEL: CATEGORY_API_NAME_TRAVEL
}

IMAGE_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/body.png"
IMAGE_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/leisure.png"
IMAGE_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/food.png"
IMAGE_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/retail.png"
IMAGE_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/services_2.png"
IMAGE_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/travel.png"

# TODO: Need to change the followings according to pep8 constants convention
# please don't update constant name from here till the next comment as these are DB Defined
ANALYTICS_CATEGORY_CODE_Body = "BF"
ANALYTICS_CATEGORY_CODE_Leisure = "AL"
ANALYTICS_CATEGORY_CODE_RestaurantsandBars = "FD"
ANALYTICS_CATEGORY_CODE_Retail = "FR"
ANALYTICS_CATEGORY_CODE_Services = "ES"
ANALYTICS_CATEGORY_CODE_Travel = "HW"

FEATURED_MERCHANT_ICON_URL_Body = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_Leisure = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_RestaurantsandBars = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_Retail = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_Services = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_Travel = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501
# please don't update constant name till here

FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_BODY = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_body_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_LEISURE = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_leisure_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RESTAURANTS_AND_BARS = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_food_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_RETAIL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_retail_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_SERVICES = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_services_category_home_screen.png"  # noqa : E501
FEATURED_MERCHANT_ICON_URL_CATEGORY_HOME_SCREEN_TRAVEL = "https://s3.amazonaws.com/entertainer-app-assets/categories/ribbons/cat_ribbon_travel.png"  # noqa : E501

VOUCHER_TYPE_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/voucher_type_"
VOUCHER_RESTRICTION_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/voucher_restriction_"  # noqa: E501
PARTY_SIZE_IMAGE_URL_PREFIX = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/"
VOUCHER_TYPE_IMAGE_URL_PREFIX_HS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/hs/voucher_type_"  # noqa: E501
VOUCHER_TYPE_IMAGE_URL_PREFIX_GEM = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types/gem/voucher_type_"  # noqa: E501
VOUCHER_RESTRICTION_IMAGE_URL_PREFIX_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_restrictions/gems/voucher_restriction_"  # noqa: E501
PARTY_SIZE_IMAGE_URL_PREFIX_GEMS = "https://s3.amazonaws.com/entertainer-app-assets/icons/party_size/gems/"
VOUCHER_TYPE_IMAGE_URL_PREFIX_V7_V7 = "https://s3.amazonaws.com/entertainer-app-assets/icons/voucher_types_v7/voucher_type_"  # noqa

ANALYTICS_CATEGORY_CODES_DICT = {
    CATEGORY_NAME_BODY.lower(): ANALYTICS_CATEGORY_CODE_Body,
    CATEGORY_NAME_LEISURE.lower(): ANALYTICS_CATEGORY_CODE_Leisure,
    CATEGORY_NAME_RESTAURANTS_AND_BARS.lower(): ANALYTICS_CATEGORY_CODE_RestaurantsandBars,
    CATEGORY_NAME_RETAIL.lower(): ANALYTICS_CATEGORY_CODE_Retail,
    CATEGORY_NAME_SERVICES.lower(): ANALYTICS_CATEGORY_CODE_Services,
    CATEGORY_NAME_TRAVEL.lower(): ANALYTICS_CATEGORY_CODE_Travel
}
REDEEMBILITY_NOT_REDEEMABLE = "not_redeemable"
REDEEMABILITY_REDEEMABLE = "redeemable"
REDEEMABILITY_REDEEMABLE_REUSABLE = "redeemable_reusable"
REDEEMABILITY_REUSABLE = 'reusable'

MERCHANT_ATTRIBUTES_BODY = [
    'by_appointment_only',
    'certified',
    'female_only',
    'couples_friendly',
    'indoor_facilities',
    'jacuzzi',
    'kids_play_area',
    'male_only',
    'moroccan_bath',
    'outdoor_facilities',
    'personal_trainer',
    'refreshments',
    'pool',
    'sauna',
    'steam_room',
    'supervised_play_area',
    'parking',
    'valet_parking'
]

MERCHANT_ATTRIBUTES_LEISURE = [
    'age_restrictions',
    'aviation',
    'desert_safari',
    'fishing',
    'height_restrictions',
    'indoor_activities',
    'kids_welcome',
    'motor_sports',
    'outdoor_activities',
    'parking',
    'team_sports',
    'valet_parking',
    'alcohol',
    'boating',
    'extreme_sports',
    'golf',
    'holiday_programmes',
    'indoor_play_area',
    'live_entertainment',
    'outdoor_cooling',
    'outdoor_play_area',
    'racquet_sports',
    'rooftop_bars',
    'theme_park',
    'water_park',
    'water_sports',
    'wineries'
]

MERCHANT_ATTRIBUTES_RESTAURANTS_AND_BARS = [
    'alcohol',
    'brunch',
    'buffet',
    'cuisine',
    'delivery',
    'dress_code',
    'fine_dining',
    'groups_welcome',
    'halal',
    'hubbly_bubbly',
    'kids_welcome',
    'live_entertainment',
    'open_late',
    'outdoor_cooling',
    'outdoor_heating',
    'outdoor_seating',
    'parking',
    'pets_allowed',
    'pork_products',
    'price_range',
    'rooftop_bars',
    'smoking_indoor',
    'smoking_outdoor',
    'smoking_shisha',
    'sports_screens',
    'supervised_play_area',
    'takeaway',
    'valet_parking',
    'wheelchair_accessible',
    'wi_fi',
    'wineries',
    'with_a_view'
]

MERCHANT_ATTRIBUTES_SERVICES = [
    'beauty_products',
    'by_appointment_only',
    'delivery',
    'pharmacy',
    'pick_up_drop_off'
]

MERCHANT_ATTRIBUTES_TRAVEL = [
    'x24_hour_reception',
    'x24_hour_room_service',
    'air_conditioning',
    'alcohol',
    'balcony',
    'beach',
    'beach_club',
    'beauty_centre',
    'bed_breakfast',
    'boutique',
    'car_park',
    'city',
    'closest_airport_name',
    'club_lounge',
    'concierge',
    'couples_only',
    'day_spa',
    'family',
    'golf',
    'gym_fitness',
    'hair_salon',
    'health_programmes',
    'health_spa_resort',
    'heating',
    'hotel_apartment',
    'inhouse_movies',
    'in_room_spa_bath',
    'kids_club',
    'kitchen_facilities',
    'laundry_service',
    'lodge_safari',
    'lodge_ski',
    'mini_bar',
    'mountain_country',
    'night_club',
    'no_of_bars',
    'no_of_cafes',
    'no_of_restaurants',
    'plunge_pool',
    'prayer_room',
    'proximity_to_airport_kms',
    'proximity_to_city_centre_kms',
    'resort',
    'safe_deposit_box',
    'seaside',
    'shopping_mall',
    'smoking_rooms',
    'sound_system',
    'sports_club',
    'swimming_pool',
    'total_no_of_rooms',
    'tv_in_room',
    'valet_parking',
    'villas',
    'water_sports',
    'wheelchair_accessible',
    'wi_fi'
]

LOCATION_TIME_ZONE_MAP = {
    1: '+0400',
    2: '+0400',
    3: '+0300',
    4: '+0200',
    5: '+0300',
    6: '+0200',
    7: '+0300',
    8: '+0400',
    9: '+0300',
    10: '+0300',
    11: '+0800',
    12: '+0300',
    13: '+0800',
    14: '+0200',
    15: '+0800',
    16: '+0300',
    17: '+0100',
    18: '+0300',
    19: '+0400',
    20: '+0200',
    21: '+0200',
    23: '+0300',
    25: '+0100',
    28: '+0300',
    31: '+0100',
    34: '+0400',
    37: '+0400',
    40: '+0200',
    43: '+0300',
    46: '+0800',
    49: '+0300',
    50: '+0800'
}

MERCHANT_ATTRIBUTES_RETAIL = [
    'children_baby_only',
    'fashion_accessories',
    'footwear',
    'ladieswear',
    'menswear',
    'opticians',
    'sportswear'
]

MAX_OUTLETS = 60

COMMA_BASED_API_CONFIG_KEYS = (
    'lookup_update_columns',
    'replace_241_type_with_141_locations',
)


ORDER_NOT_FOUND = "No order found."
SUCCESS_MSG = 'Success'
CANCEL_RESERVATION_STATUS = 6

# Error Codes
SESSION_EXPIRED_STATUS_CODE = 801
ENT_COMPANY = 'entertainer'


ENT_COMPANY_TYPE = 'ent'
ENT_COMPANY_TYPE_FULL = 'entertainer'
PACKAGE_ATTRIBUTES = (
    "hww_dine",
    "hww_brunch",
    "hww_relax",
    "hww_play"
)
PACKAGE_ATTR_MAPPING = {
    "hww_dine": "is_dine",
    "hww_brunch": "is_brunch",
    "hww_relax": "is_relax",
    "hww_play": "is_play",
}
OFFER_ATTRIBUTES = {
    'activity_camps',
    'alcohol',
    'beauty_products',
    'boating',
    'body_treatments',
    'brunch',
    'buffet',
    'by_appointment_only',
    'dance_classes',
    'delivery',
    'dental',
    'dermatology',
    'desert',
    'diet_and_nutrition',
    'express',
    'facials',
    'fishing',
    'fitness_classes',
    'for_kids',
    'golf',
    'gym_membership',
    'hair',
    'health_beauty',
    'hubbly_bubbly',
    'make_overs',
    'mani_pedi',
    'martial_arts',
    'massage',
    'moroccan_bath',
    'motor_sports',
    'personal_training',
    'pharmacy',
    'pick_up_drop_off',
    'pilates',
    'pool_swimming',
    'pre_natal',
    'slimming',
    'spin_cycle',
    'tanning',
    'team_sports',
    'theme_park',
    'water_park',
    'water_sports',
    'waxing_threading_laser',
    'weight_loss',
    'yoga',
    'hww_brunch',
    'hww_relax',
    'hww_dine',
    'hww_play'
}
VOUCHER_RESTRICTIONS = {
    1: "Valid for Dine-in and Take-away",
    2: "Excluding Friday Brunch",
    3: "Advance Booking is required",
    4: "Delivery only",
    5: "Dine-in only",
    6: "Excluding Brunch",
    7: "Food only",
    8: "No corkage allowed",
    9: "Not Valid on Delivery",
    10: "Not valid on Public Holidays",
    11: "Rack rate applies",
    12: "To redeem, you must be of legal drinking age and non-Muslim",  # Must comply with applicable local laws
    13: "Valid on all packages",
    14: "Valid on Delivery",
    15: "Must comply with applicable local laws",
    16: "Rate includes breakfast",
    17: "Rate Room only",
    18: "Based on Best Available Rates",
    19: "All Inclusive",
    20: "Consume on premises only",
    21: "Drink Responsibly",
    22: "Valid on soft beverages",
    23: "Valid on house beverages",
    24: "Valid on bubbly package",
    25: "Min. order & delivery charges apply",
    26: "Half board",
    27: "Best available rate",
    28: "Best flexible rate",
    29: "Fixed rate per night",
    30: "Online offer",
    31: "Takeaway"
}
IMAGE_TYPE_VOUCHER_TYPE = 1
IMAGE_TYPE_VOUCHER_RESTRICTION = 2
IMAGE_TYPE_PARTY_SIZE = 3

LOCALES_PATH = 'common/locales'
HAPPY_BIRTHDAY_START_RANGE_DAYS = -8
HAPPY_BIRTHDAY_END_RANGE_DAYS = 21
DEFAULT_OFFER_EXPIRY_HOURS = 12
DEFAULT_OFFER_EXPIRY_MINUTES = 0
DEFAULT_OFFER_EXPIRY_SECONDS = 0

TYPE_DEFAULT = 0
TYPE_TRIAL = 1
TYPE_MEMBER = 2
TYPE_BOTH = 3
TYPE_NEW_OFFER = 4
TYPE_FEATURED_OFFER = 5
OFFER_TYPE_VALUE_DEFAULT = 0
OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
OFFER_TYPE_VALUE_GIFT = 3
OFFER_TYPE_VALUE_PACKAGE = 4
OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

SORT_EXPIRED = 6

SECTION_REDEEMABLE = 1
SECTION_REDEEMED = 2
SECTION_PINGED = 3
SECTION_NOT_REDEEMABLE = 4
SORT_REDEEMABLE = 1
SORT_PURCHASED_AVAILABLE_IN_FUTURE = 2
SORT_REDEEMED = 3
SORT_PINGED = 4
SORT_NOT_REDEEMABLE = 5

SMILES_ICON_URL = "https://s3.amazonaws.com/entertainer-app-assets/icons/smiles_icon.png"
SMILES_COLOR_CODE = "e2bb55"
COLOR_CODE_ALREADY_REDEEMED = "de595b"


OFFER_TYPE_TEXT_BUY_ONE_GET_ONE_FREE = "Buy One Get One Free"
OFFER_TYPE_TEXT_SPEND_THIS_GET_THIS = "Spend This Get That"
OFFER_TYPE_TEXT_PERCENTAGE_OFF = "% Off"
OFFER_TYPE_TEXT_GIFT = "Gift"
OFFER_TYPE_TEXT_PACKAGE = "Package"
OFFER_TYPE_TEXT_FIX_PRICE_OFF = "Fixed Price Off"

OFFER_ON_HOLD_STATUS = 2
OFFER_AZ_SYNC = 1

HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM = 4
HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO = -18

OFFER_TYPE_MONTHLY = 2
WL_COMPANY_TYPE = 'wl'

EDIT_ORDER_TIMER_VALUE = 15
EDIT_ORDER_IDLE_TIMER_VALUE = 1200
ORDER_STATUS_REFRESH_INTERVAL = 10
LIVE_OFFERS_IMAGE = "https://entertainer-app-assets.s3.amazonaws.com/icons/deal-icon.png"

OFFER_TEXT_COLOR = "ffffff"
GREY_BACKGROUND_COLOR = 'd8d8d8'
TAG_TITLE_COLOR = 'ffffff'
V7_ADDITIONAL_DETAIL_COLOR = 'a4a3a3'

ATTRIBUTE_SELECTION_TYPE_MULTIPLE = 2
PARAM_NAME_ANALYTICS_CUISINES = "cuisines"
PARAM_NAME_ANALYTICS_SUB_CATEGORIES = "in_mood_for"
PARAM_NAME_API_CUISINES = "cuisines"
PARAM_NAME_API_SUB_CATEGORIES = "sub_categories"

TYPE_VIRTUAL_CURRENCY = 1
ORDER_CREATION = 2
FORGOT_PASSWORD = 3
ACTIVATION_OF_TRIAL = 4
PROCCESSED_EMAIL = 5
GIFT_PURCHASE_PRODUCT = 6
OFFER_PING = 7
VIP_Key_ACTIVATION_ENGLISH = 22
OFFER_SHARE_FOR_REGISTERED_CUSTOMER = 23
BOOKING_ENQUIRY_Merchant = 148
BOOKING_ENQUIRY_Customer = 106
VIP_KEY_ACTIVATION_SLICE = 153
VIP_KEY_ACTIVATION_REWARD_PLUS = 225

FAMILY_PROSPECT_TYPE = 540
FAMILY_SECONDARY_TYPE = 542
EMAIL_VERIFICATION_ID = 547

SMILES_ACTION_BURN_OFFERS_TOP_UP_ID = 137
TOP_UP_OFFER_BURN_VALUE = 1000

COMPANY_SERVICE_MESSAGE = "Oops! There’s a problem with the account, please contact customer service at " \
                          "customerservice@theentertainerme.com"

CUSTOMER_ID_NOT_FOUND = 'A customer matching that ID could not be found.'
OFFER_IDS_MISSING = 'offer_ids are missing.'
YOU_CANNOT_PING_THIS_OFFER = "You cannot ping this offer."
USER_CANNOT_PING_OFFER_CHEER = "This user cannot receive cheer offers"
QUICKUP_SERVICE_DELAY_MESSAGE = 'quiqup_service_delay_message'

TRAVEL_INSTANT_BOOKING_FLAG = 'is_hww_instant_booking'
TRAVEL_INQUIRE_FOR_RATES = 'Inquire For Rates'
TRAVEL_INSTANT_BOOKING = 'Instant Booking'
