"""
This module contains translation manager class
"""
from gettext import gettext

from babel import support

from ..constants import LOCALES_PATH


class TranslationManager(object):

    @classmethod
    def get_translation(cls, translation_key, locale='en'):
        """
        Returns quick translated text in desired locale
        :param str translation_key: Translation constant name
        :param str locale: Desired translation
        :rtype: str
        """
        if cls._translations.get(translation_key):
            return cls._translations.get(translation_key).get(locale, '')
        return ''

    @classmethod
    def get_message_by_string(cls, message, locale):
        """
        This method checks if code is a valid class attribute then returns it's translation else returns code
        :param str message: Dict of localed messages
        :param str locale: Locale
        :rtype: str
        """
        translation = support.Translations.load(cls.DIR_NAME, locale, cls.DOMAIN)
        return translation.ugettext(message) if message else message

    DIR_NAME = LOCALES_PATH
    DOMAIN = 'messages'
    PROMOTIONAL_SECTION_BOTTOM_BUTTON_TITLE = gettext("VIEW OFFERS")

    REMOVE_FROM_FAMILY = "REMOVE_FROM_FAMILY"
    NO_FAMILY_SECONDARY_FOUND = "NO_FAMILY_SECONDARY_FOUND"
    FAMILY_HEADER_TITLE = "FAMILY_HEADER_TITLE"
    BUTTON_LEAVE_FAMILY_TITLE = "BUTTON_LEAVE_FAMILY_TITLE"

    CONFIRM_LEAVE_PRIMARY = "CONFIRM_LEAVE_PRIMARY"
    CONFIRM_ACTIVE_REMOVE_MEMBER = "CONFIRM_ACTIVE_REMOVE_MEMBER"
    CONFIRM_REMOVE_MEMBER = "CONFIRM_REMOVE_MEMBER"
    CONFIRM_LEAVE_SECONDARY = "CONFIRM_LEAVE_SECONDARY"
    FAMILY_CLOSED = "FAMILY_CLOSED"
    LEAVED_SUCCESSFULLY = "LEAVED_SUCCESSFULLY"
    INVITATION_CANCELLED = "INVITATION_CANCELLED"
    MEET_YOUR_FAMILY_TITLE = "MEET_YOUR_FAMILY_TITLE"
    WELCOME_MESSGAE = "WELCOME_MESSGAE"
    SUCCESS_INVITATION = "SUCCESS_INVITATION"
    MEMBER_NOT_ALLOWED = "MEMBER_NOT_ALLOWED"
    JOIN_FAMILY_TITLE = "JOIN_FAMILY_TITLE"
    BUTTON_BUY_NOW_TITLE = "BUTTON_BUY_NOW_TITLE"

    FAMILY_ACCOUNT_EXPIRED = "FAMILY_ACCOUNT_EXPIRED"
    FAMILY_EXPIRED = "FAMILY_EXPIRED"
    BUTTON_RESEND_TITLE = "BUTTON_RESEND_TITLE"
    BUTTON_CANCEL_TITLE = "BUTTON_CANCEL_TITLE"
    BUTTON_CLOSE_FAMILY_TITLE = "BUTTON_CLOSE_FAMILY_TITLE"

    SAVED_THIS_YEAR_LABEL = 'SAVED_THIS_YEAR_LABEL'
    OUTLET_COUNT_SINGULAR = 'OUTLET_COUNT_SINGULAR'
    OUTLET_COUNT_PLURAL = 'OUTLET_COUNT_PLURAL'
    TRAVEL_LOCATION = 'TRAVEL_LOCATION'

    USER_INACTIVE = 'USER_INACTIVE'

    voucher_type_1 = 'VOUCHER_TYPE_Buy_One_Get_One_Free'
    THIS_IS_A_BUNDLED_PRODUCT = "THIS_IS_A_BUNDLED_PRODUCT"
    NOT_YET_PURCHASED = 'NOT_YET_PURCHASED'

    BOOK_A_TABLE = "BOOK_A_TABLE"
    MINIMUM_DELIVERY_FEE = 'MINIMUM_DELIVERY_FEE'
    OFFER_INSTRUCTION_MESSAGE = "Offer_instruction_message"

    PROMO_CODE_HISTORY_TITLE = "Promo_Code_History"
    PROMO_CODE_HISTORY_SUB_TITLE = "See_all"
    PROMO_CODE_INSTRUCTION_MESSAGE = "Promo_offer_instruction_message"

    People = 'People'
    Person = 'Person'
    Persons = 'Persons'

    voucher_type_1 = 'VOUCHER_TYPE_BUY_ONE_GET_ONE_FREE'
    voucher_type_2 = 'VOUCHER_TYPE_PERCENTAGE_OFF'
    voucher_type_3 = 'VOUCHER_TYPE_GIFT'
    voucher_type_4 = 'VOUCHER_TYPE_PACKAGE'
    voucher_type_5 = 'VOUCHER_TYPE_FIX_PRICE_OFF'
    voucher_type_6 = 'VOUCHER_TYPE_SPEND_THIS_GET_THIS'
    voucher_type_141 = 'VOUCHER_TYPE_BUY_ONE_GET_ONE_FREE_141'

    voucher_type_1_Label = 'VOUCHER_TYPE_Buy_One_Get_One_Free_LABEL'
    voucher_type_2_Label = 'VOUCHER_TYPE_PERCENTAGE_OFF_LABEL'
    voucher_type_3_Label = 'VOUCHER_TYPE_GIFT_LABEL'
    voucher_type_4_Label = 'VOUCHER_TYPE_PACKAGE_LABEL'
    voucher_type_5_Label = 'VOUCHER_TYPE_FIX_PRICE_OFF_LABEL'
    voucher_type_6_Label = 'VOUCHER_TYPE_SPEND_THIS_GET_THIS_LABEL'

    voucher_restriction_1 = 'voucher_restriction_1_valid_for_dine_in_and_takeaway'
    voucher_restriction_2 = 'voucher_restriction_2_excluding_friday_brunch'
    voucher_restriction_3 = 'voucher_restriction_3_advance_booking_is_required'
    voucher_restriction_4 = 'voucher_restriction_4_delivery_only'
    voucher_restriction_5 = 'voucher_restriction_5_dine_in_only'
    voucher_restriction_6 = 'voucher_restriction_6_excluding_brunch'
    voucher_restriction_7 = 'voucher_restriction_7_food_only'
    voucher_restriction_8 = 'voucher_restriction_8_no_corkage_allowed'
    voucher_restriction_9 = 'voucher_restriction_9_not_valid_on_delivery'
    voucher_restriction_10 = 'voucher_restriction_10_not_valid_on_public_holidays'
    voucher_restriction_11 = 'voucher_restriction_11_rack_rate_applies'
    voucher_restriction_12 = 'voucher_restriction_12_to_redeem_you_must_be_of_legal_drinking_age_and_non_muslim'
    voucher_restriction_13 = 'voucher_restriction_13_valid_on_all_packages'
    voucher_restriction_14 = 'voucher_restriction_14_valid_on_delivery'
    voucher_restriction_15 = 'voucher_restriction_15_must_comply_with_applicable_local_laws'
    voucher_restriction_16 = 'voucher_restriction_16_rate_includes_breakfast'
    voucher_restriction_17 = 'voucher_restriction_17_rate_room_only'
    voucher_restriction_18 = 'voucher_restriction_18_based_on_best_available_rates'
    voucher_restriction_19 = 'voucher_restriction_19_all_inclusive'
    your_next_getaway_starts_here = 'your_next_getaway_starts_here'
    access_restricted_to_application_crg = 'access_restricted_to_application_crg'
    access_restricted_to_application_gem = 'access_restricted_to_application_gems'
    access_restricted_to_application_nma = 'access_restricted_to_application_nma'
    access_restricted_to_application_dpr = 'access_restricted_to_application_dpr'
    offer_is_not_redeemable = 'offer_is_not_redeemable'
    email_required = 'email_required'
    email_password_required = 'email_password_required'
    invalid_vip_key = 'invalid_vip_key'
    email_not_exist = 'email_not_exist'
    Two_People = 'Two_People'
    linked_entertainer_account_to_facebook = 'linked_entertainer_account_to_facebook'
    wrong_device_install_token = 'wrong_device_install_token'
    wrong_session_token = 'wrong_session_token'
    problems_with_saving_of_family_member_info = 'problems_with_saving_of_family_member_info'
    vip_key_already_used = 'vip_key_already_used'
    success_vip_key_applied_and_product_unlocked = 'success_vip_key_applied_and_product_unlocked'
    invalid_email_address = 'invalid_email_address'
    not_implemented = 'not_implemented'
    social_id_not_tied_to_magento_customer_account = 'social_id_not_tied_to_magento_customer_account'
    not_authorized_to_access_user = 'not_authorized_to_access_user'
    not_authorized_to_access_key = 'not_authorized_to_access_key'
    problems_with_your_submission = 'problems_with_your_submission'
    you_are_not_authorized_to_access_this_user = 'you_are_not_authorized_to_access_this_user'
    customer_with_this_email_address_exists = 'customer_with_this_email_address_exists'
    customer_register_success = 'customer_register_success'
    activation_of_trial = 'activation_of_trial'
    merchant_does_not_exist = 'merchant_does_not_exist'
    offer_does_not_exist = 'offer_does_not_exist'
    offer_does_not_exist_or_inactive = 'offer_does_not_exist_or_inactive'
    customer_has_already_redeemed_offer_x_the_maximum_allowed_times = 'customer_has_already_redeemed_offer_x_the_maximum_allowed_times'  # noqa:E501
    customer_does_not_own_offer_x = 'customer_does_not_own_offer_x'
    offer_x_is_not_available_at_outlet_y = 'offer_x_is_not_available_at_outlet_y'
    offer_can_be_redeemed_a_maximum_of_x_times_you_requested_y_times = 'offer_can_be_redeemed_a_maximum_of_x_times_you_requested_y_times'  # noqa:E501
    no_offers_specified = 'no_offers_specified'
    offers_must_belong_to_the_same_merchant = 'offers_must_belong_to_the_same_merchant'
    invalid_merchant_pin = 'invalid_merchant_pin'
    informatica_error = 'informatica_error'
    for_given_key_values_are_not_found = 'for_given_key_values_are_not_found'
    there_is_no_such_record = 'there_is_no_such_record'
    you_are_not_authorized_to_delete_this_customer_devices_record = 'you_are_not_authorized_to_delete_this_customer_devices_record'  # noqa:E501
    problems_with_customer_devices_record_deleting = 'problems_with_customer_devices_record_deleting'
    there_are_no_customer_devices_belonging_to_the_specified_customer = 'there_are_no_customer_devices_belonging_to_the_specified_customer'  # noqa:E501
    email_and_key_required = 'email_and_key_required'
    you_are_not_authorized_to_access_this_key = 'you_are_not_authorized_to_access_this_key'
    invalid_login_or_password = 'invalid_login_or_password'
    invalid_password = 'invalid_password'
    you_are_not_allowed_to_access_this_application = 'you_are_not_allowed_to_access_this_application'
    you_are_not_allowed_to_access_this_application_due = 'you_are_not_allowed_to_access_this_application_due'
    you_are_not_allowed_to_access_this_application_dut = 'you_are_not_allowed_to_access_this_application_dut'
    player_not_found = 'player_not_found'
    player_not_created = 'player_not_created'
    player_answers_not_saved = 'player_answers_not_saved'
    reward_definition_not_found = 'reward_definition_not_found'
    no_data_available = 'no_data_available'
    you_have_exceeded_your_devices_limit = 'you_have_exceeded_your_devices_limit'
    vip_key_validation_is_unavailable_temporarily = 'vip_key_validation_is_unavailable_temporarily'
    social_sign_in_not_available_at_the_moment = 'social_sign_in_not_available_at_the_moment'
    functionality_not_available_in_offline_mode = 'functionality_not_available_in_offline_mode'
    upgrade_your_app = 'upgrade_your_app'
    please_Select_Log_in_as_a_different_user_to_access_your_2016_offers = 'please_Select_Log_in_as_a_different_user_to_access_your_2016_offers'  # noqa:E501
    bin_key_is_not_valid = 'bin_key_is_not_valid'
    bin_already_registered = 'bin_already_registered'
    invalid_dob = 'invalid_dob'
    invalid_dates_selected = 'invalid_dates_selected'
    limit_exceeded_to_verify_the_code = 'limit_exceeded_to_verify_the_code'
    phone_number_has_already_been_verified_with_some_other_account = 'phone_number_has_already_been_verified_with_some_other_account'  # noqa:E501
    verification_code_request_limit_exceeded = 'verification_code_request_limit_exceeded'
    merchant_details_not_found = 'merchant_details_not_found'
    failed_to_send_verification_code = 'failed_to_send_verification_code'
    invalid_verification_code = 'invalid_verification_code'
    cheers_offer_message_for_ping_for_app_upgrade = 'cheers_offer_message_for_ping_for_app_upgrade'
    cheers_vip_key_app_upgrade_message = 'cheers_vip_key_app_upgrade_message'
    sign_in_failed = 'sign_in_failed'
    dob_minimum_value_error = 'dob_minimum_value_error'
    du_product_purchase_success_message = 'du_product_purchase_success_message'
    du_failed_product_purchase = 'du_failed_product_purchase'
    customer_details_not_found = 'customer_details_not_found'
    Open_to_be_used = 'Open to be used'
    key_required = 'key_required'
    invalid_wl_key = 'invalid_wl_key'
    invalid_wl_key_with_branch = 'invalid_wl_key_with_branch'
    invalid_link = 'invalid_link'
    imie_number_not_valid = 'imie_number_not_valid'
    imie_number_is_required = 'imie_number_is_required'
    du_otp_message = 'du_otp_message'
    elf_pop_up_screen_upon_successful_activation = 'elf_pop_up_screen_upon_successful_activation'
    friend_referral_message = 'friend_referral_message'
    friend_connect_message = 'friend_connect_message'
    transaction_succeeded = 'transaction_succeeded'
    transaction_failed = 'transaction_failed'
    smiles_burn_buy_back_offer_scuccess = 'smiles_burn_buy_back_offer_scuccess'
    smiles_burn_purchase_pings_scuccess = 'smiles_burn_purchase_pings_scuccess'
    smiles_burn_purchase_promotional_app_scuccess = 'smiles_burn_purchase_promotional_app_scuccess'
    unfriend_successfully = 'unfriend_successfully'
    unfriend_failed = 'unfriend_failed'
    product_buy_screen_product_supplement_title = 'product_buy_screen_product_supplement_title'
    product_buy_screen_merchant_section_title = 'product_buy_screen_merchant_section_title'
    delivery_offers_remaining = 'delivery_offers_remaining'
    du_error_encountered_verifying_code = 'du_error_encountered_verifying_code'
    du_invalid_code_entered = 'du_invalid_code_entered'
    du_exceeded_limit_verify_code = 'du_exceeded_limit_verify_code'
    du_phone_number_already_verified = 'du_phone_number_already_verified'
    du_phone_number_not_found = 'du_phone_number_not_found'
    elf_pop_up_screen_upon_successful_activation_30_june_2018 = 'elf_pop_up_screen_upon_successful_activation_30_june_2018'  # noqa:E501
    elf_pop_up_screen_upon_successful_activation_30_dec_2018 = 'elf_pop_up_screen_upon_successful_activation_30_dec_2018'  # noqa:E501
    signin_validation_message_squ = 'signin_validation_message_squ'
    signin_validation_message_ocb = 'signin_validation_message_ocb'
    signin_validation_message_etd = 'signin_validation_message_etd'
    signin_validation_message_tca = 'signin_validation_message_tca'
    signin_validation_message_mbd = 'signin_validation_message_mbd'
    signin_validation_message_ibq = 'signin_validation_message_ibq'
    signin_validation_message_ncb = 'signin_validation_message_ncb'
    signin_validation_message_sst = 'signin_validation_message_sst'
    signin_validation_message_alb = 'signin_validation_message_alb'
    signin_validation_message_mce = 'signin_validation_message_mce'
    signin_validation_message_elf = 'signin_validation_message_elf'
    signin_validation_message_pse = 'signin_validation_message_pse'
    signin_validation_message_saab = 'signin_validation_message_saab'
    signin_validation_message_cbe = 'signin_validation_message_cbe'
    signin_validation_message_bme = 'signin_validation_message_bme'
    signin_validation_message_hs = 'signin_validation_message_hs'
    signin_validation_message_amb = 'signin_validation_message_amb'
    signin_validation_message_ded = 'signin_validation_message_ded'
    signin_validation_message_jre = 'signin_validation_message_jre'
    signin_validation_message_mca = 'signin_validation_message_mca'
    signin_validation_message_gbe = 'signin_validation_message_gbe'
    signin_validation_message_ome = 'signin_validation_message_ome'
    signin_validation_message_bcl = 'signin_validation_message_bcl'
    signin_validation_message_hut = 'signin_validation_message_hut'
    signin_validation_message_due = 'signin_validation_message_due'
    signin_validation_message_dut = 'signin_validation_message_dut'
    signin_validation_message_aje = 'signin_validation_message_aje'
    signin_validation_message_zin = 'signin_validation_message_zin'
    signin_validation_message_tvx = 'signin_validation_message_tvx'
    password_required = 'password_required'
    email_not_linked_message = 'email_not_linked_message'
    email_not_linked_message_dut = 'email_not_linked_message_dut'
    email_not_linked_message_due = 'email_not_linked_message_due'
    success_validation_message_amb = 'success_validation_message_amb'
    register_validation_message_amb = 'register_validation_message_amb'
    password_signin_validation_message = 'password_signin_validation_message'
    final_success_register_message_amb = 'final_success_register_message_amb'
    final_success_register_message_bme = 'final_success_register_message_bme'
    final_success_register_message_cbe = 'final_success_register_message_cbe'
    final_success_register_message_ded = 'final_success_register_message_ded'
    final_success_register_message_etd = 'final_success_register_message_etd'
    final_success_register_message_gbe = 'final_success_register_message_gbe'
    final_success_register_message_hs = 'final_success_register_message_hs'
    register_validation_message_alb = 'register_validation_message_alb'
    final_success_register_message_alb = 'final_success_register_message_alb'
    final_success_login_message_amb = 'final_success_login_message_amb'
    final_success_login_message_alb = 'final_success_login_message_alb'
    first_register_message_amb = 'first_register_message_amb'
    first_register_message_alb = 'first_register_message_alb'
    success_validation_message_alb = 'success_validation_message_alb'
    password_signin_validation_message_alb = 'password_signin_validation_message_alb'
    register_validation_message_squ = 'register_validation_message_squ'
    final_success_register_message_squ = 'final_success_register_message_squ'
    final_success_login_message_squ = 'final_success_login_message_squ'
    first_register_message_squ = 'first_register_message_squ'
    success_validation_message_squ = 'success_validation_message_squ'
    password_signin_validation_message_squ = 'password_signin_validation_message_squ'
    register_validation_message_ocb = 'register_validation_message_ocb'
    final_success_register_message_ocb = 'final_success_register_message_ocb'
    final_success_login_message_ocb = 'final_success_login_message_ocb'
    first_register_message_ocb = 'first_register_message_ocb'
    success_validation_message_ocb = 'success_validation_message_ocb'
    password_signin_validation_message_ocb = 'password_signin_validation_message_ocb'
    register_validation_message_tca = 'register_validation_message_tca'
    final_success_register_message_tca = 'final_success_register_message_tca'
    final_success_login_message_tca = 'final_success_login_message_tca'
    first_register_message_tca = 'first_register_message_tca'
    success_validation_message_tca = 'success_validation_message_tca'
    password_signin_validation_message_tca = 'password_signin_validation_message_tca'
    register_validation_message_mbd = 'register_validation_message_mbd'
    final_success_register_message_mbd = 'final_success_register_message_mbd'
    final_success_login_message_mbd = 'final_success_login_message_mbd'
    first_register_message_mbd = 'first_register_message_mbd'
    success_validation_message_mbd = 'success_validation_message_mbd'
    password_signin_validation_message_mbd = 'password_signin_validation_message_mbd'
    register_validation_message_ibq = 'register_validation_message_ibq'
    final_success_register_message_ibq = 'final_success_register_message_ibq'
    final_success_login_message_ibq = 'final_success_login_message_ibq'
    first_register_message_ibq = 'first_register_message_ibq'
    success_validation_message_ibq = 'success_validation_message_ibq'
    password_signin_validation_message_ibq = 'password_signin_validation_message_ibq'
    register_validation_message_mce = 'register_validation_message_mce'
    final_success_register_message_mce = 'final_success_register_message_mce'
    final_success_login_message_mce = 'final_success_login_message_mce'
    first_register_message_mce = 'first_register_message_mce'
    success_validation_message_mce = 'success_validation_message_mce'
    password_signin_validation_message_mce = 'password_signin_validation_message_mce'
    register_validation_message_elf = 'register_validation_message_elf'
    final_success_register_message_elf = 'final_success_register_message_elf'
    final_success_login_message_elf = 'final_success_login_message_elf'
    first_register_message_elf = 'first_register_message_elf'
    success_validation_message_elf = 'success_validation_message_elf'
    password_signin_validation_message_elf = 'password_signin_validation_message_elf'
    register_validation_message_ncb = 'register_validation_message_ncb'
    final_success_register_message_ncb = 'final_success_register_message_ncb'
    final_success_login_message_ncb = 'final_success_login_message_ncb'
    first_register_message_ncb = 'first_register_message_ncb'
    success_validation_message_ncb = 'success_validation_message_ncb'
    password_signin_validation_message_ncb = 'password_signin_validation_message_ncb'
    register_validation_message_sst = 'register_validation_message_sst'
    final_success_register_message_sst = 'final_success_register_message_sst'
    final_success_login_message_sst = 'final_success_login_message_sst'
    first_register_message_sst = 'first_register_message_sst'
    success_validation_message_sst = 'success_validation_message_sst'
    password_signin_validation_message_sst = 'password_signin_validation_message_sst'
    register_validation_message_pse = 'register_validation_message_pse'
    final_success_register_message_pse = 'final_success_register_message_pse'
    final_success_login_message_pse = 'final_success_login_message_pse'
    first_register_message_pse = 'first_register_message_pse'
    success_validation_message_pse = 'success_validation_message_pse'
    password_signin_validation_message_pse = 'password_signin_validation_message_pse'
    register_validation_message_saab = 'register_validation_message_saab'
    final_success_register_message_saab = 'final_success_register_message_saab'
    final_success_login_message_saab = 'final_success_login_message_saab'
    first_register_message_saab = 'first_register_message_saab'
    success_validation_message_saab = 'success_validation_message_saab'
    password_signin_validation_message_saab = 'password_signin_validation_message_saab'
    register_validation_message_jre = 'register_validation_message_jre'
    final_success_register_message_jre = 'final_success_register_message_jre'
    final_success_login_message_jre = 'final_success_login_message_jre'
    first_register_message_jre = 'first_register_message_jre'
    success_validation_message_jre = 'success_validation_message_jre'
    password_signin_validation_message_jre = 'password_signin_validation_message_jre'
    register_validation_message_ome = 'register_validation_message_ome'
    final_success_register_message_ome = 'final_success_register_message_ome'
    final_success_login_message_ome = 'final_success_login_message_ome'
    first_register_message_ome = 'first_register_message_ome'
    success_validation_message_ome = 'success_validation_message_ome'
    password_signin_validation_message_ome = 'password_signin_validation_message_ome'
    register_validation_message_bcl = 'register_validation_message_bcl'
    final_success_register_message_bcl = 'final_success_register_message_bcl'
    final_success_login_message_bcl = 'final_success_login_message_bcl'
    first_register_message_bcl = 'first_register_message_bcl'
    success_validation_message_bcl = 'success_validation_message_bcl'
    password_signin_validation_message_bcl = 'password_signin_validation_message_bcl'
    register_validation_message_hut = 'register_validation_message_hut'
    final_success_register_message_hut = 'final_success_register_message_hut'
    final_success_login_message_hut = 'final_success_login_message_hut'
    first_register_message_hut = 'first_register_message_hut'
    success_validation_message_hut = 'success_validation_message_hut'
    password_signin_validation_message_hut = 'password_signin_validation_message_hut'
    register_validation_message_due = 'register_validation_message_due'
    final_success_register_message_due = 'final_success_register_message_due'
    final_success_login_message_due = 'final_success_login_message_due'
    first_register_message_due = 'first_register_message_due'
    success_validation_message_due = 'success_validation_message_due'
    password_signin_validation_message_due = 'password_signin_validation_message_due'
    register_validation_message_dut = 'register_validation_message_dut'
    final_success_register_message_dut = 'final_success_register_message_dut'
    final_success_login_message_dut = 'final_success_login_message_dut'
    first_register_message_dut = 'first_register_message_dut'
    success_validation_message_dut = 'success_validation_message_dut'
    password_signin_validation_message_dut = 'password_signin_validation_message_dut'
    register_validation_message_aje = 'register_validation_message_aje'
    final_success_register_message_aje = 'final_success_register_message_aje'
    final_success_login_message_aje = 'final_success_login_message_aje'
    first_register_message_aje = 'first_register_message_aje'
    success_validation_message_aje = 'success_validation_message_aje'
    password_signin_validation_message_aje = 'password_signin_validation_message_aje'
    register_validation_message_zin = 'register_validation_message_zin'
    final_success_register_message_zin = 'final_success_register_message_zin'
    final_success_login_message_zin = 'final_success_login_message_zin'
    first_register_message_zin = 'first_register_message_zin'
    success_validation_message_zin = 'success_validation_message_zin'
    password_signin_validation_message_zin = 'password_signin_validation_message_zin'
    register_validation_message_tvx = 'register_validation_message_tvx'
    final_success_register_message_tvx = 'final_success_register_message_tvx'
    final_success_login_message_tvx = 'final_success_login_message_tvx'
    first_register_message_tvx = 'first_register_message_tvx'
    success_validation_message_tvx = 'success_validation_message_tvx'
    password_signin_validation_message_tvx = 'password_signin_validation_message_tvx'
    register_validation_message_hs = 'register_validation_message_hs'
    final_success_login_message_hs = 'final_success_login_message_hs'
    first_register_message_hs = 'first_register_message_hs'
    success_validation_message_hs = 'success_validation_message_hs'
    password_signin_validation_message_hs = 'password_signin_validation_message_hs'
    register_validation_message_bme = 'register_validation_message_bme'
    final_success_login_message_bme = 'final_success_login_message_bme'
    first_register_message_bme = 'first_register_message_bme'
    success_validation_message_bme = 'success_validation_message_bme'
    password_signin_validation_message_bme = 'password_signin_validation_message_bme'
    register_validation_message_ded = 'register_validation_message_ded'
    final_success_login_message_ded = 'final_success_login_message_ded'
    first_register_message_ded = 'first_register_message_ded'
    success_validation_message_ded = 'success_validation_message_ded'
    password_signin_validation_message_ded = 'password_signin_validation_message_ded'
    register_validation_message_etd = 'register_validation_message_etd'
    final_success_login_message_etd = 'final_success_login_message_etd'
    first_register_message_etd = 'first_register_message_etd'
    success_validation_message_etd = 'success_validation_message_etd'
    password_signin_validation_message_etd = 'password_signin_validation_message_etd'
    password_signin_validation_message_amb = 'password_signin_validation_message_amb'
    register_validation_message_cbe = 'register_validation_message_cbe'
    final_success_login_message_cbe = 'final_success_login_message_cbe'
    first_register_message_cbe = 'first_register_message_cbe'
    success_validation_message_cbe = 'success_validation_message_cbe'
    password_signin_validation_message_cbe = 'password_signin_validation_message_cbe'
    register_validation_message_gbe = 'register_validation_message_gbe'
    final_success_login_message_gbe = 'final_success_login_message_gbe'
    first_register_message_gbe = 'first_register_message_gbe'
    success_validation_message_gbe = 'success_validation_message_gbe'
    password_signin_validation_message_gbe = 'password_signin_validation_message_gbe'
    signin_validation_message_qia = 'signin_validation_message_qia'
    register_validation_message_qia = 'register_validation_message_qia'
    final_success_register_message_qia = 'final_success_register_message_qia'
    final_success_login_message_qia = 'final_success_login_message_qia'
    first_register_message_qia = 'first_register_message_qia'
    success_validation_message_qia = 'success_validation_message_qia'
    password_signin_validation_message_qia = 'password_signin_validation_message_qia'
    signin_validation_message_spr = 'signin_validation_message_spr'
    register_validation_message_spr = 'register_validation_message_spr'
    final_success_register_message_spr = 'final_success_register_message_spr'
    final_success_login_message_spr = 'final_success_login_message_spr'
    first_register_message_spr = 'first_register_message_spr'
    success_validation_message_spr = 'success_validation_message_spr'
    password_signin_validation_message_spr = 'password_signin_validation_message_spr'
    offers_pinged_to_me = 'offers_pinged_to_me'
    top_merchant_total_saving = 'top_merchant_total_saving'
    included_in_mobile_product_not_yet_purchased = 'included_in_mobile_product_not_yet_purchased'
    pinged = 'pinged'
    already_redeemed = 'already_redeemed'
    purchased_available_from = 'purchased_available_from'
    valid_from = 'valid_from'
    the_offer_has_expired = 'the_offer_has_expired'
    initial_validate_amb = 'initial_validate_amb'
    initial_validate_bme = 'initial_validate_bme'
    initial_validate_etd = 'initial_validate_etd'
    initial_validate_gbe = 'initial_validate_gbe'
    initial_validate_hs = 'initial_validate_hs'
    initial_validate_ibq = 'initial_validate_ibq'
    initial_validate_eca = 'initial_validate_eca'
    initial_validate_era = 'initial_validate_era'
    initial_validate_entertainer = 'initial_validate_entertainer'
    initial_validate_ded = 'initial_validate_ded'
    initial_validate_mce = 'initial_validate_mce'
    initial_validate_squ = 'initial_validate_squ'
    initial_validate_ocb = 'initial_validate_ocb'
    initial_validate_due = 'initial_validate_due'
    initial_validate_alb = 'initial_validate_alb'
    initial_validate_tca = 'initial_validate_tca'
    initial_validate_elf = 'initial_validate_elf'
    initial_validate_ome = 'initial_validate_ome'
    initial_validate_hut = 'initial_validate_hut'
    initial_validate_dut = 'initial_validate_dut'
    initial_validate_spr = 'initial_validate_spr'
    initial_validate_qia = 'initial_validate_qia'
    initial_validate_tvx = 'initial_validate_tvx'
    initial_validate_aje = 'initial_validate_aje'
    initial_validate_zin = 'initial_validate_zin'
    old_email_not_linked = 'old_email_not_linked'
    new_email_aready_exist = 'new_email_aready_exist'
    signin_validation_message_btl = 'signin_validation_message_btl'
    register_validation_message_btl = 'register_validation_message_btl'
    final_success_register_message_btl = 'final_success_register_message_btl'
    final_success_login_message_btl = 'final_success_login_message_btl'
    first_register_message_btl = 'first_register_message_btl'
    success_validation_message_btl = 'success_validation_message_btl'
    password_signin_validation_message_btl = 'password_signin_validation_message_btl'
    initial_validate_btl = 'initial_validate_btl'
    signin_validation_message_mto = 'signin_validation_message_mto'
    register_validation_message_mto = 'register_validation_message_mto'
    final_success_register_message_mto = 'final_success_register_message_mto'
    final_success_login_message_mto = 'final_success_login_message_mto'
    first_register_message_mto = 'first_register_message_mto'
    success_validation_message_mto = 'success_validation_message_mto'
    password_signin_validation_message_mto = 'password_signin_validation_message_mto'
    initial_validate_mto = 'initial_validate_mto'
    signin_validation_message_cbq = 'signin_validation_message_cbq'
    register_validation_message_cbq = 'register_validation_message_cbq'
    final_success_register_message_cbq = 'final_success_register_message_cbq'
    final_success_login_message_cbq = 'final_success_login_message_cbq'
    first_register_message_cbq = 'first_register_message_cbq'
    success_validation_message_cbq = 'success_validation_message_cbq'
    password_signin_validation_message_cbq = 'password_signin_validation_message_cbq'
    initial_validate_cbq = 'initial_validate_cbq'
    valid_to = 'valid_to'
    expired_offer = 'expired_offer'
    user_account_frozen = 'user_account_frozen'
    user_account_frozen_blocked = 'user_account_frozen_blocked'
    device_blacklisted = 'device_blacklisted'
    this_is_a_bundled_product = 'this_is_a_bundled_product'
    this_product_is_no_more_purchasable = 'this_product_is_no_more_purchasable'
    happy_birthday_title = 'happy_birthday_title'
    customer_with_this_email_address_already_exists = 'customer_with_this_email_address_already_exists'
    you_have_already_activated_this_key = 'you_have_already_activated_this_key'
    you_have_successfully_activated_the_key = 'you_have_successfully_activated_the_key'
    you_have_successfully_activated_the_key_with_branch = 'you_have_successfully_activated_the_key_with_branch'
    you_are_not_allowed_to_subscribe_multiple_keys = 'you_are_not_allowed_to_subscribe_multiple_keys'
    you_have_already_activated_the_app_for_multiple_keys_not_allowed = 'you_have_already_activated_the_app_for_multiple_keys_not_allowed'  # noqa:E501
    key_is_required = 'key_is_required'
    user_creation_failed = 'user_creation_failed'
    parent_id_is_required = 'parent_id_is_required'
    emp_code_is_required = 'emp_code_is_required'
    user_already_exisit_gems_message = 'user_already_exisit_gems_message'
    user_already_registered_gems_message = 'user_already_registered_gems_message'
    gems_user_id_and_password_is_required = 'gems_user_id_and_password_is_required'
    gems_more_to_enjoy = 'gems_more_to_enjoy'
    gems_featured_heading = 'gems_featured_heading'
    savings_message_home = 'savings_message_home'
    savings_message_welcome_guest = 'savings_message_welcome_guest'
    hsbc_more_to_enjoy = 'hsbc_more_to_enjoy'
    hsbc_more_to_enjoy_group2 = 'hsbc_more_to_enjoy_group2'
    qgi_more_to_enjoy = 'qgi_more_to_enjoy'
    NOT_AUTHORIZE_TO_ACCESS_USER = 'NOT_AUTHORIZE_TO_ACCESS_USER'

    tab_name_all_offers = 'tab_name_all_offers'
    tab_name_new = 'tab_name_new'
    tab_name_monthly = 'tab_name_monthly'
    tab_name_delivery = 'tab_name_delivery'
    tab_name_cheers = 'tab_name_cheers'
    tab_name_more_sa = 'tab_name_more_sa'
    tab_name_buy_more = 'tab_name_buy_more'
    tab_name_hsbc_fine_dining = 'tab_name_hsbc_fine_dining'
    tab_name_locked_offers = 'tab_name_locked_offers'
    tab_name_more_africa = 'tab_name_more_africa'
    SUCCESS = 'SUCCESS'
    FAILURE = 'FAILURE'
    MONTHLY_LIMIT_MESSAGE = "MONTHLY_LIMIT_MESSAGE"
    NOT_ALLOWED = 'NOT_ALLOWED'

    tab_name_all_offers_GEMS = 'tab_name_all_offers_gems'
    tab_name_all_offers_KELLOGGS = 'tab_name_all_offers_kelloggs'
    tab_name_all_offers_JGE = 'tab_name_all_offers_jge'
    tab_name_all_offers_CRG = 'tab_name_all_offers_crg'
    tab_name_all_offers_LANDMARK_GROUP = 'tab_name_all_offers_landmark_group'
    tab_name_HSBC = 'tab_name_HSBC'
    tab_name_BNE = 'tab_name_BNE'

    success = 'success'
    profile_not_updated = 'profile_not_updated'
    password_reset_link_sent_message = 'password_reset_link_sent_message'
    password_email_not_found_message = 'password_email_not_found_message'
    invalid_request = "invalid_request"
    gems_points_reflect_message = "gems_points_reflect_message"

    invoice_validation_success_message = "invoice_validation_success_message"
    invoice_validation_success_message_upgraded = "invoice_validation_success_message_upgraded"
    invoice_validation_invalid_message = "invoice_validation_invalid_message"
    invoice_validation_invalid_message_wrong_amount = "invoice_validation_invalid_message_wrong_amount"
    invoice_validation_invalid_code_message = "invoice_validation_invalid_code_message"

    invoice_validation_already_linked_message = "invoice_validation_already_linked_message"
    invoice_validation_outdated_invoice = "invoice_validation_outdated_invoice"

    card_validation_success_message = "card_validation_success_message"
    card_validation_invalid_message = "card_validation_invalid_message"
    card_validation_already_linked_message = "card_validation_already_linked_message"
    please_enter_valid_user_id_message = "please_enter_valid_user_id_message"
    Home_Screen_Getaway_Section_Heading = 'Home_Screen_Getaway_Section_Heading'
    Home_Screen_Getaway_Section_Heading_member = 'Home_Screen_Getaway_Section_Heading_member'

    MOMTHS_NAME_LIST = "MOMTHS_NAME_LIST"
    FOOD_AND_DRINK = "FOOD_AND_DRINK"
    BODY = "BODY"
    LEISURE = "LEISURE"
    NAVIGATE_AWAY_FROM_ENTERTAINER_GETAWAYS = 'Are you sure you want to navigate away from ENTERTAINER getaways?'
    ALL = 'All'
    TYPE_TITLE = 'type_title'
    CUISINE = "Cuisine"
    top_cuisines = 'top_cuisines'
    EXTRA = 'EXTRA'
    FEATURED = 'FEATURED'
    FOR_THE_WEEKEND = 'FOR_THE_WEEKEND'
    BIRTHDAY_OFFER = 'BIRTHDAY OFFER'
    FASHION_AND_RETAIL = "FASHION_AND_RETAIL"
    SERVICES = "SERVICES"
    TRAVEL = "TRAVEL"
    HOTELS_WORLDWIDE = 'HOTELS WORLDWIDE'
    HOTELS = 'HOTELS'
    NO = "NO"
    YES = "YES"
    OUTLET_SPECIFIC = "OUTLET_SPECIFIC"
    HOME_SAVINGS_MESSAGE_0_0 = "HOME_SAVINGS_MESSAGE_0_0"
    MESSAGES_WHEN_SAVINGS_FROM_1_TO_500 = "MESSAGES_WHEN_SAVINGS_FROM_1_TO_500"
    MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500 = "MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500"
    MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000 = "MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000"
    MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000 = "MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000"
    Ping_Count_Left_To_Receive = 'Ping_Count_Left_To_Receive'
    Ping_Quota_Left_To_Receive_For_Recipient = 'Ping_Quota_Left_To_Receive_For_Recipient'
    Ping_Count_Left_To_Send = 'Ping_Count_Left_To_Send'
    Ping_Offer_Error_Message = 'Ping_Offer_Error_Message'
    Ping_Offer_Success_Message = 'Ping_Offer_Success_Message'
    Ping_Quota_Finished_To_Receive = 'Ping_Quota_Finished_To_Receive'
    Ping_Quota_Finished_To_Receive_For_Recipient = 'Ping_Quota_Finished_To_Receive_For_Recipient'
    Ping_Quota_Finished_To_Send = 'Ping_Quota_Finished_To_Send'
    Ping_Sender_Cant_Be_Recipient = 'Ping_Sender_Cant_Be_Recipient'
    Ping_Recipient_Cant_Be_Family_Member = 'Ping_Recipient_Cant_Be_Family_Member'
    Ping_Quota_Left_To_Receive_For_Recipient_Single = 'Ping_Quota_Left_To_Receive_For_Recipient_Single'
    Ping_Quota_Left_To_Receive_For_Recipient_Multiple = 'Ping_Quota_Left_To_Receive_For_Recipient_Multiple'
    Ping_Count_Left_To_Send_Single = 'Ping_Count_Left_To_Send_Single'
    Ping_Count_Left_To_Send_Multiple = 'Ping_Count_Left_To_Send_Multiple'
    Ping_Count_Left_To_Receive_Single = 'Ping_Count_Left_To_Receive_Single'
    Ping_Count_Left_To_Receive_Multiple = 'Ping_Count_Left_To_Receive_Multiple'
    Invalid_Authentication_token_For_Social_Platform = 'Invalid_Authentication_token_For_Social_Platform'
    PING_TO_MESSAGE = 'PING_TO_MESSAGE'
    PING_BY_MESSAGE = 'PING_BY_MESSAGE'
    Ping_Count_Left_To_Receive_Unlimited = 'Ping_Count_Left_To_Receive_Unlimited'

    LOCALE_CN_RESET_PASSWORD = "重設密碼的連結已發送到您的電郵信箱!"
    LOCALE_AR_RESET_PASSWORD = "تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني الخاص!"
    UPGRADE_APP = 'upgrade_app'
    tab_name_monthly_offers = 'tab_name_monthly_offers'

    VALID_UNTIL_TEXT_EN = 'valid until'
    VALID_UNTIL_TEXT_AR = 'صالح لغاية'
    VALID_UNTIL_TEXT_CN = '有效期至'
    VALID_UNTIL_TEXT_EL = 'Ισχύει έως'
    OFFER_OUT_OF_CUSTOM_CODES = 'OFFER_OUT_OF_CUSTOM_CODES'
    OFFER_RESTRICTION_MESSAGE = 'OFFER_RESTRICTION_MESSAGE'
    OOPS_TEXT = 'OOPS_TEXT'
    PING_COUNT_LEFT_TO_RECEIVE = 'ping_count_left_to_receive'
    PING_QUOTA_LEFT_TO_RECEIVE_FOR_RECIPIENT = 'ping_quota_left_to_receive_for_recipient'
    PING_COUNT_LEFT_TO_SEND = 'ping_count_left_to_send'
    PING_OFFER_ERROR_MESSAGE = 'ping_offer_error_message'
    PING_OFFER_SUCCESS_MESSAGE = 'ping_offer_success_message'
    PING_QUOTA_FINISHED_TO_RECEIVE = 'ping_quota_finished_to_receive'
    PING_QUOTA_FINISHED_TO_RECEIVE_FOR_RECIPIENT = 'ping_quota_finished_to_receive_for_recipient'
    PING_QUOTA_FINISHED_TO_SEND = 'ping_quota_finished_to_send'
    PING_SENDER_CANT_BE_RECIPIENT = 'ping_sender_cant_be_recipient'
    PING_RECIPIENT_CANT_BE_FAMILY_MEMBER = 'ping_recipient_cant_be_family_member'
    PING_QUOTA_LEFT_TO_RECEIVE_FOR_RECIPIENT_SINGLE = 'ping_quota_left_to_receive_for_recipient_single'
    PING_QUOTA_LEFT_TO_RECEIVE_FOR_RECIPIENT_MULTIPLE = 'ping_quota_left_to_receive_for_recipient_multiple'
    PING_COUNT_LEFT_TO_SEND_SINGLE = 'ping_count_left_to_send_single'
    PING_COUNT_LEFT_TO_SEND_MULTIPLE = 'ping_count_left_to_send_multiple'
    PING_COUNT_LEFT_TO_RECEIVE_SINGLE = 'ping_count_left_to_receive_single'
    PING_COUNT_LEFT_TO_RECEIVE_MULTIPLE = 'ping_count_left_to_receive_multiple'
    INVALID_AUTHENTICATION_TOKEN_FOR_SOCIAL_PLATFORM = 'invalid_authentication_token_for_social_platform'

    PROMOTIONAL_SECTION_FOOD_TITLE = "promotional_section_food_title"
    PROMOTIONAL_SECTION_FOOD_DESCRIPTION = "promotional_section_food_description"
    PROMOTIONAL_SECTION_BODY_TITLE = "promotional_section_body_title"
    PROMOTIONAL_SECTION_BODY_DESCRIPTION = "promotional_section_body_description"
    PROMOTIONAL_SECTION_LEISURE_TITLE = "promotional_section_leisure_title"
    PROMOTIONAL_SECTION_LEISURE_DESCRIPTION = "promotional_section_leisure_description"
    PROMOTIONAL_SECTION_RETAIL_TITLE = "promotional_section_retail_title"
    PROMOTIONAL_SECTION_RETAIL_DESCRIPTION = "promotional_section_retail_description"
    PROMOTIONAL_SECTION_SERVICES_TITLE = "promotional_section_services_title"
    PROMOTIONAL_SECTION_SERVICES_DESCRIPTION = "promotional_section_services_description"

    _translations = {
        'upgrade_app': {
            'en': 'UPGRADE APP',
            'ar': 'UPGRADE APP',
            'el': 'UPGRADE APP',
            'cn': 'UPGRADE APP'
        },
        'FOOD_AND_DRINK': {
            "en": "FOOD & BEVERAGES",
            'ar': "المطاعم",
            'el': "Φαγητό & Ποτό",
            'cn': "飲食",
        },
        'BODY': {
            'en': "BEAUTY & FITNESS",
            'ar': "اللياقة والجمال",
            'el': "Ομορφιά & Ευεξία",
            'cn': "美容及健身",
        },
        'LEISURE': {
            'en': "ATTRACTIONS & LEISURE",
            'ar': "الوجهات الترفيهية",
            'el': "Θεάματα & Αναψυχή",
            'cn': "景點及消閒"
        },
        'FASHION_AND_RETAIL': {
            'en': "FASHION & RETAIL",
            'ar': "الموضة والتجزئة",
            'el': "Εμπόριο & Υπηρεσίες",
            'cn': "時尚&零售"
        },
        'SERVICES': {
            'en': "EVERYDAY SERVICES",
            'ar': "الخدمات اليومية",
            'el': "Εμπόριο & Υπηρεσίες",
            'cn': "零售及服務"
        },
        'TRAVEL': {
            'en': "TRAVEL",
            'ar': "السفر",
            'el': "Ταξιδέψτε",
            'cn': "旅遊"
        },
        'HOTELS WORLDWIDE': {
            'en': "HOTELS WORLDWIDE",
            'ar': "فناق عالمية",
            'el': "Ξενοδοχεία Διεθνώς",
            'cn': "全球酒店"
        },
        'HOTELS': {
            'en': "HOTELS",
            'ar': "فناق عالمية",
            'el': "Ξενοδοχεία Διεθνώς",
            'cn': "全球酒店"
        },
        "MOMTHS_NAME_LIST": {
            "en": ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
                   'October', 'November', 'December'],
            "ar": ['يناير', 'فبراير', 'مارس', 'أبريل', 'قد', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر',
                   'اكتوبر ', 'تشرين الثاني', 'ديسمبر'],
            "el": ['Ιανουάριος', 'Φεβρουάριος', 'Μάρτιος', 'Απρίλιος', 'Μάιος', 'Ιούνιος', 'Ιούλιος',
                   'Αύγουστος', 'Σεπτέμβριος', 'Οκτώβριος', 'Νοέμβριος', 'Δεκέμβριος'],
            "cn": ['年 1 月', '年 2 月', '年 3 月', '年 4 月', '年 5 月', '年 6 月', '年 7 月', '年 8 月', '年 9 月',
                   '年 10 月', '年 11 月', '年 12 月']
        },
        "HOME_SAVINGS_MESSAGE_0_0": {
            "en": "Haven't started saving yet? Use your offers today - Go __UserName__! "
                  "You have 0 savings __UserName__. Let's change that today, shall we? Hey __UserName__, "
                  "today looks like a good day to start saving!",
            "ar": "  ألم تبدأ بالتوفير بعد؟ ماذا تنتظر؟ استخدم عروضك اليوم واستمتع بالتوفير __UserName__!"
                  "  لم توفر شيئاً حتى الآن __UserName__. غيّر هذا الأسلوب اليوم! "
                  "  مرحباً __UserName__. يبدو اليوم مناسباً جداً لتبدأ بالتوفير!",
            "cn": "今天立即開始兌換優惠，累積更高節省金額吧，__UserName__! "
                  "__UserName__，你的節省金額是0，今天一起來一個零的突破吧！"
                  "__UserName__，你兌換了沒有？今天就是個好日子，好開始！",
            "el": "Δεν ξεκίνησες ακόμα? Χρησιμοποίησε τις προσφορές σου σήμερα- πάμε "
                  "__UserName__! Έχεις 0 εξοικονόμηση "
                  "__UserName__. Πάμε να το αλλάξουμε αυτό σήμερα, τι λες? "
                  "__UserName__, σήμερα είναι μία καλή μέρα να ξεκινήσεις να κερδίζεις!"
        },
        "MESSAGES_WHEN_SAVINGS_FROM_1_TO_500": {
            "en": "You’re off to a great start with __SAVINGS_VALUE__ saved. Keep at it __UserName__! "
                  "Yay - you’ve saved __SAVINGS_VALUE__ so far! Carry on using your offers __UserName__! "
                  "Woo-hoo, __SAVINGS_VALUE__ is in the bag!  Save some more today __UserName__! "
                  "You’re on a roll with __SAVINGS_VALUE__ saved up. More savings coming your way __UserName__! "
                  "Congratulations for saving __SAVINGS_VALUE__! Here’s to more milestones with your offers.",
            "ar": "  بدايتك ممتازة. فقد وفرت __SAVINGS_VALUE__ حتى الآن. تابع تقدمك __UserName__!"
                  " ممتاز! لقد وفرت __SAVINGS_VALUE__ حتى الآن. استخدم العروض أكثر __UserName__!"
                  "جيد جداً! أصبحت قيمة التوفير __SAVINGS_VALUE__! وفر المزيد اليوم بعد   __UserName__!"
                  "لا شيء يقف في وجهك. فقد وفرت __SAVINGS_VALUE__ حتى الآن. وفر المزيد  __UserName__!"
                  "مبروك! لقد نجحت في توفير __SAVINGS_VALUE__ حتى الآن. نتمنى لك المزيد من الإنجازات مع عروضك. ",
            "cn": "你節省了__SAVINGS_VALUE__！繼續加油__UserName__！"
                  "你知道自己已經節省了__SAVINGS_VALUE__！快為自己鼓掌吧__UserName__！"
                  "嘩！節省了__SAVINGS_VALUE__！其實要省錢非常容易__UserName__！"
                  "已經節省了__SAVINGS_VALUE__，立即發掘更多優惠啦__UserName__！恭喜你，節省了__SAVINGS_VALUE__！",
            "el": "Έχεις κάνει τέλειο ξεκίνημα με __SAVINGS_VALUE__ εξοικονόμηση. Συνέχισε έτσι __UserName__! "
                  "Ουάου - εξοικονόμησες __SAVINGS_VALUE__ ήδη! "
                  "Συνέχισε να χρησιμοποιείς τις προσφορές σου __UserName__! "
                  "Ναι, __SAVINGS_VALUE__ είναι στην τσέπη σου! "
                  "Εξοικονόμησε περισσότερα σήμερα __UserName__! "
                  "Κερδίζεις με __SAVINGS_VALUE__ που εξοικονόμησες! "
                  "Έρχονται περισσότερα κέρδη __UserName__! "
                  "Συγχαρητήρια, εξοικονόμησες __SAVINGS_VALUE__! Χάρη στις φανταστικές προσφορές σου."
        },
        "MESSAGES_WHEN_SAVINGS_FROM_501_TO_2500": {
            "en": "You’ve saved __SAVINGS_VALUE__ so far! Great going __UserName__!"
                  "Savings worth __SAVINGS_VALUE__ in the bag! Keep at it __UserName__!"
                  "Woot – you’re on to good things with __SAVINGS_VALUE__ saved so far!"
                  "Yay – You’ve saved __SAVINGS_VALUE__ so far! Don’t stop now __UserName__!"
                  "It’s raining __CURRENCY__ __UserName__ – you’ve saved __SAVINGS_VALUE__ so far, well done!",
            "ar": "لقد وفرت  __SAVINGS_VALUE__ حتى الآن. أحسنت  __UserName__!"
                  "قيمة التوفير بلغت   __SAVINGS_VALUE__. واصل التقدم على هذا النحو __UserName__!"
                  "إنّك تسير في الطريق الصحيح حتماً. فقد وفرت   __SAVINGS_VALUE__ حتى الآن!"
                  "غير معقول! بلغت قيمة التوفير   __SAVINGS_VALUE__! استخدم المزيد من العروض للتوفير أكثر بعد __UserName__!"  # noqa 501
                  "لقد وفرت الكثير الكثير __UserName__! فقيمة التوفير بلغت  __SAVINGS_VALUE__ حتى الآن. أحسنت! ",
            "el": "Εξοικονόμησες __SAVINGS_VALUE__ ήδη! Τα πας τέλεια __UserName__!"
                  "Η εξοικονόμησή σου είναι __SAVINGS_VALUE__ στην τσέπη! Συνέχισε έτσι __UserName__!"
                  "Βρίσκεσαι στον δρόμο για υπέροχα πράγματα με __SAVINGS_VALUE__ που εξοικονόμησες ήδη!"
                  "Εξοικονόμησες __SAVINGS_VALUE__ ήδη! Μην σταματάς τώρα __UserName__!"
                  "Βρέχει κέρδη __UserName__ -εξοικονόμησες __SAVINGS_VALUE__ ήδη, μπράβο!",
            "cn": "你已經節省了__SAVINGS_VALUE__！精彩優惠陸續更新__UserName__！"
                  "現在已經節省了__SAVINGS_VALUE__！繼續節省更多吧__UserName__！"
                  "哇！要節省__SAVINGS_VALUE__真的無難度！"
                  "太好了！能為你節省__SAVINGS_VALUE__！繼續享受省錢帶來的喜悅吧__UserName__！"
                  "節省總額一直上升，你現在已經有__SAVINGS_VALUE__！__UserName__把握機會再下一城吧！"
        },
        "MESSAGES_WHEN_SAVINGS_FROM_2501_TO_5000": {
            "en": "Ka-ching! You’ve saved __SAVINGS_VALUE__ so far, way to go __UserName__!"
                  "__SAVINGS_VALUE__ saved so far! You’re on fire __UserName__!"
                  "Whoa, __SAVINGS_VALUE__ worth SAVINGS! You should be proud of yourself __UserName__."
                  "Ooh, your savings worth __SAVINGS_VALUE__ look so good! Keep 'em coming __UserName__!"
                  "Where’s the party at __UserName__!? Cheers for saving __SAVINGS_VALUE__!",
            "ar": "ما هذا __UserName__؟ وفرت  __SAVINGS_VALUE__ حتى الآن. ممتاز!"
                  "قيمة التوفير الحالية هي  __SAVINGS_VALUE__. عظيم __UserName__!"
                  "ماذا تفعل يا __UserName__؟ قيمة التوفير الحالية هي __SAVINGS_VALUE__. يجب أن تكون فخوراً بنفسك. "
                  "وفرت __SAVINGS_VALUE__ حتى الآن والآتي أعظم __UserName__!"
                  "أين تحتفل يا  __UserName__؟ احتفل بنجاحك في توفير  __SAVINGS_VALUE__ حتى الآن!",
            "el": "Εξοικονόμησες __SAVINGS_VALUE__ ήδη, κι έχει κι άλλο __UserName__!"
                  "Εξοικονόμησες ήδη __SAVINGS_VALUE__?! Σκίζεις __UserName__!"
                  "Τα κέρδη σου αξίζουν __SAVINGS_VALUE__?! Θα πρέπει να είσαι πολύ περήφανος __UserName__!"
                  "Η εξοικονόμηση που έκανες αξίζει __SAVINGS_VALUE__ και φαίνεται τόσο τέλεια! "
                  "Συνέχισε έτσι __UserName__!"
                  "Που γίνεται το πάρτυ του/της __UserName__!? Μπράβο, κέρδισες __SAVINGS_VALUE__!",
            "cn": "注意！你的節省總額已達到[CUC][AMOUNT]！繼續衝刺吧！"
                  "不敢相信你已經節省了__SAVINGS_VALUE__！__UserName__太厲害啦！"
                  "你知道自己已經節省了__SAVINGS_VALUE__嗎？快為自己鼓掌吧__UserName__！"
                  "節省總額達到__SAVINGS_VALUE__真的不錯！下次想好兌換那個優惠了沒有__UserName__？"
                  "__UserName__，你已經節省了__SAVINGS_VALUE__！"
        },
        "MESSAGES_WHEN_SAVINGS_FROM_5001_TO_1000000000": {
            "en": "Word’s out that you’re a rainmaker with __SAVINGS_VALUE__ saved up. Way to go __UserName__!"
                  "Holla __UserName__! __SAVINGS_VALUE__ in savings is something to brag about. Great going!"
                  "Whoa - you’ve saved __SAVINGS_VALUE__ so far! Take a bow __UserName__."
                  "Congratulations & celebrations for saving __SAVINGS_VALUE__ __UserName__!"
                  "Cue the confetti – you’ve saved __SAVINGS_VALUE__! Cheers __UserName__!",
            "ar": "يبدو أنّك تجيد التوفير فعلاً __UserName__. فقيمة التوفير بلغت   __SAVINGS_VALUE__ حتى الآن!"
                  "مستحيل! وفرت  __SAVINGS_VALUE__ حتى الآن __UserName__! ممتاز!"
                  "افتخر بنفسك __UserName__، فقد وفرت __SAVINGS_VALUE__ حتى الآن! "
                  "هنيئاً لك ومبروك عليك توفير __SAVINGS_VALUE__ __UserName__",
                  "لا كلام نقوله لك __UserName__! ممتاز فعلاً. قيمة التوفير بلغت __SAVINGS_VALUE__!"
            "el": "Λέγεται ότι σκίζεις με εξοικονόμηση __SAVINGS_VALUE__?! Συνέχισε __UserName__!"
                  "Γειά σου __UserName__! Με __SAVINGS_VALUE__ κέρδη θα πρέπει να καυχιέσαι πολύ!Τέλεια!"
                  "Εξοικονόμησες ήδη __SAVINGS_VALUE__! Μπράβο __UserName__!"
                  "Συγχαρητήρια για την εξοικονόμησή σου __SAVINGS_VALUE__ __UserName__!"
                  "Άνοιξε σαμπάνιες - εξοικονόμησες __SAVINGS_VALUE__! Στην υγειά σου __UserName__!",
            "cn": "目前為止，你已經節省了高達__SAVINGS_VALUE__！"
                  "__UserName__，快告訴朋友你已經有__SAVINGS_VALUE__節省總額啦！"
                  "哇！節省了__SAVINGS_VALUE__！真的嗎？為你鼓掌__UserName__。"
                  "恭喜你，節省了__SAVINGS_VALUE__！想好了去那裡慶祝嗎__UserName__？"
                  "誰能像你一樣節省那麼多，一共有__SAVINGS_VALUE__！"
        },
        "please_enter_valid_user_id_message": {
            "en": "Please enter a valid User ID",
            "ar": "Please enter a valid User ID",
            "el": "Please enter a valid User ID",
            "cn": "Please enter a valid User ID",
            "de": "Please enter a valid User ID"
        },
        "MONTHLY_LIMIT_MESSAGE": {
            'en': "Sorry. Monthly offers have a maximum limit of {MONTHLY_LIMIT} redemptions "
                  "per {MONTHLY_HOURS} hours.",
            'ar': "عذراً، يمكن استخدام {MONTHLY_LIMIT} من العروض الشهرية كحد أقصى كل {MONTHLY_HOURS} ساعة.",
            'cn': "對不起! 每月優惠於{MONTHLY_HOURS}小時內最多可兌換{MONTHLY_LIMIT}次。",
            'el': "Συγγνώμη. Οι Μηνιαίες προσφορές έχουν όριο τις {MONTHLY_LIMIT} εξαργυρώσεις μέσα σε "
                  "{MONTHLY_HOURS} ώρες."
        },
        "NOT_ALLOWED": {
            "en": "You are not allowed to access this application.",
            "ar": "غير مسموح لك استخدام هذا التطبيق",
            "cn": "You are not allowed to access this application.",
            "el": "You are not allowed to access this application.",
            "de": "You are not allowed to access this application."
        },
        "Home_Screen_Getaway_Section_Heading": {
            "en": 'Start saving up to 60% on hotel bookings',
            "ar": 'ابدأ بتوفير ما يصل إلى %60 على الحجوزات الفندقية ',
            "cn": '開始為旅程住宿節省高達4折優惠',
            "el": 'Αρχίστε να εξοικονομείτε μέχρι 60% στις κρατήσεις ξενοδοχείων',
            "de": 'Save up to 60% off your next stay.'
        },
        "Home_Screen_Getaway_Section_Heading_member": {
            "en": 'Save up to 60% on your next hotel stay',
            "ar": 'وفّر ما يصل إلى %60 على إقامتك الفندقية القادمة ',
            "cn": '為下次旅程住宿節省高達4折優惠',
            "el": 'Εξοικονομήστε έως 60% στην επόμενη διαμονή σας στο ξενοδοχείο',
            "de": 'Save up to 60% off your next stay.'
        },
        "card_validation_already_linked_message": {
            "en": "Sorry! You have already added this card number",
            "ar": "Sorry! You have already added this card number",
            "el": "Sorry! You have already added this card number",
            "cn": "Sorry! You have already added this card number",
            "de": "Sorry! You have already added this card number"
        },
        "card_validation_invalid_message": {
            "en": "Uh oh!\n\n You need to put in a valid card number to continue.",
            "ar": "يجب عليك إدخال رقم فاتورة صالح للمتابعة",
            "el": "Uh oh!\n\n You need to put in a valid card number to continue.",
            "cn": "Uh oh!\n\n You need to put in a valid card number to continue.",
            "de": "Uh oh!\n\n You need to put in a valid card number to continue.",
        },
        "card_validation_success_message": {
            "en": "Congratulations! Your card number has been added.",
            "ar": "Congratulations! Your card number has been added.",
            "el": "Congratulations! Your card number has been added.",
            "cn": "Congratulations! Your card number has been added.",
            "de": "Congratulations! Your card number has been added."
        },
        "invoice_validation_already_linked_message": {
            "en": "Uh oh!\n\n This Emax Code is already used!",
            "ar": "Uh oh!\n\n This Emax Code is already used!",
            "el": "Uh oh!\n\n This Emax Code is already used!",
            "cn": "Uh oh!\n\n This Emax Code is already used!",
            "de": "Uh oh!\n\n This Emax Code is already used!"
        },
        "invoice_validation_invalid_message": {
            "en": "Uh oh!\n\n You need to put in a valid invoice number to continue.",
            "ar": "يجب عليك إدخال رقم فاتورة صالح للمتابعة",
            "el": "Uh oh!\n\n You need to put in a valid invoice number to continue.",
            "cn": "Uh oh!\n\n You need to put in a valid invoice number to continue.",
            "de": "Uh oh!\n\n You need to put in a valid invoice number to continue.",
        },
        "invoice_validation_invalid_message_wrong_amount": {
            "en": "Uh oh!\n\n You need to put in a valid invoice number and amount to continue.",
            "ar": "Uh oh!\n\n You need to put in a valid invoice number and amount to continue.",
            "el": "Uh oh!\n\n You need to put in a valid invoice number and amount to continue.",
            "cn": "Uh oh!\n\n You need to put in a valid invoice number and amount to continue.",
            "de": "Uh oh!\n\n You need to put in a valid invoice number and amount to continue.",
        },
        "invoice_validation_invalid_code_message": {
            "en": "Uh oh!\n\n You need to put in a valid Emax Code to continue.",
            "ar": "يجب عليك إدخال رقم فاتورة صالح للمتابعة",
            "el": "Uh oh!\n\n You need to put in a valid Emax Code to continue.",
            "cn": "Uh oh!\n\n You need to put in a valid Emax Code to continue.",
            "de": "Uh oh!\n\n You need to put in a valid Emax Code to continue.",
        },
        "invoice_validation_success_message": {
            "en": "Congratulations! Your invoice has been added.",
            "ar": "تهانينا! تمت إضافة فاتورتك",
            "el": "Congratulations! Your invoice has been added.",
            "cn": "Congratulations! Your invoice has been added.",
            "de": "Congratulations! Your invoice has been added."
        },
        "invoice_validation_success_message_upgraded": {
            "en": "Congratulations! Your invoice has been added. We’ve also upgraded your account, and you have new offers!",  # noqa:E501
            "ar": "Congratulations! Your invoice has been added. We’ve also upgraded your account, and you have new offers!",  # noqa:E501
            "el": "Congratulations! Your invoice has been added. We’ve also upgraded your account, and you have new offers!",  # noqa:E501
            "cn": "Congratulations! Your invoice has been added. We’ve also upgraded your account, and you have new offers!",  # noqa:E501
            "de": "Congratulations! Your invoice has been added. We’ve also upgraded your account, and you have new offers!"   # noqa:E501
        },
        "invoice_validation_outdated_invoice": {
            "en": "Uh oh!\n\n The invoice has expired.",
            "ar": "Uh oh!\n\n The invoice has expired.",
            "el": "Uh oh!\n\n The invoice has expired.",
            "cn": "Uh oh!\n\n The invoice has expired.",
            "de": "Uh oh!\n\n The invoice has expired.",
        },
        "gems_points_reflect_message": {
            "en": "GEMS Points will reflect in your account in 45 days",
            "ar": "GEMS Points will reflect in your account in 45 days",
            "el": "GEMS Points will reflect in your account in 45 days",
            "cn": "GEMS Points will reflect in your account in 45 days",
            "de": "GEMS Points will reflect in your account in 45 days"
        },
        "NOT_AUTHORIZE_TO_ACCESS_USER": {
            "en": "You are not authorized to access this user",
            "ar": "لست مخولاً للوصول إلى هذا المستخدم",
            "cn": "您未經授權使用這用家的帳戶。",
            "el": "You are not authorized to access this user",
            "de": "You are not authorized to access this user"
        },
        'savings_message_welcome_guest': {
            'en': 'welcome guest',
            'ar': 'ترحيب ضيف',
            'el': 'welcome guest',
            'cn': 'welcome guest'
        },
        "SUCCESS": {
            "en": "success",
            "ar": "success",
            "el": "success",
            "cn": "success",
            "de": "success"
        },
        "FAILURE": {
            "en": "failure",
            "ar": "failure",
            "el": "failure",
            "cn": "failure",
            "de": "failure"
        },
        'tab_name_all_offers_crg': {
            'en': 'Cleveland Clinic Offers',
            'ar': 'عروض تطبيق Cleveland Clinic',
            'el': 'Cleveland Clinic Offers',
            'cn': 'Cleveland Clinic Offers'
        },
        'tab_name_all_offers_jge': {
            'en': 'JGE Entertainer Offers',
            'ar': 'JGE Entertainer Offers',
            'el': 'JGE Entertainer Offers',
            'cn': 'JGE Entertainer Offers'
        },
        'tab_name_all_offers_landmark_group': {
            'en': 'Landmark ENTERTAINER Offers',
            'ar': 'عروض تطبيق Landmark ENTERTAINER',
            'el': 'Landmark ENTERTAINER Offers',
            'cn': 'Landmark ENTERTAINER Offers'
        },
        'tab_name_BNE': {
            'en': 'BeNawah ENTERTAINER Offers',
            'ar': 'BeNawah ENTERTAINER عروض تطبيق',
            'el': 'BeNawah ENTERTAINER Offers',
            'cn': 'BeNawah ENTERTAINER Offers'
        },
        'tab_name_HSBC': {
            'en': 'HSBC OFFERS',
            'ar': 'HSBC عروض تطبيق',
            'el': 'HSBC OFFERS',
            'cn': 'HSBC OFFERS'
        },
        "tab_name_all_offers": {
            "en": 'YOUR OFFERS',
            "ar": 'العروض الخاصة بك',
            "cn": '你的優惠',
            "el": 'ΟΙ ΠΡΟΣΦΟΡΕΣ ΣΑΣ',
            "de": 'YOUR OFFERS'
        },
        'tab_name_locked_offers': {
            "en": 'LOCKED OFFERS',
            "ar": 'العروض المقفلة',
            "cn": '已鎖優惠',
            "el": 'ΚΛΕΙΔΩΜΕΝΕΣ ΠΡΟΣΦΟΡΕΣ',
            "de": 'LOCKED OFFERS'
        },
        'tab_name_more_africa': {
            "en": 'MORE AFRICA',
            "ar": 'عروض أفريقيا',
            "cn": 'MORE AFRICA',
            "el": 'Περισσότερα Προσφορές Αφρική',
            "de": 'MORE AFRICA'
        },
        'tab_name_new': {
            'en': 'NEW',
            'ar': ' العروض الجديدة',
            'el': 'Νέες',
            'cn': '最新優惠'
        },
        'tab_name_monthly': {
            'en': 'MONTHLY',
            'ar': 'العروض الشهرية',
            'el': 'ΜΗΝΙΑΙΕΣ',
            'cn': '每月優惠'
        },
        'tab_name_delivery': {
            'en': 'DELIVERY',
            'ar': 'التوصيل',
            'el': 'DELIVERY',
            'cn': 'DELIVERY'
        },
        'tab_name_cheers': {
            'en': 'CHEERS',
            'ar': 'شيرز',
            'el': 'CHEERS',
            'cn': 'CHEERS'
        },
        'tab_name_more_sa': {
            'en': 'MORE AFRICA',
            'ar': 'MORE AFRICA',
            'el': 'MORE AFRICA',
            'cn': 'MORE AFRICA'
        },
        'tab_name_buy_more': {
            'en': 'BUY More',
            'ar': 'BUY More',
            'el': 'BUY More',
            'cn': 'BUY More'
        },
        'tab_name_hsbc_fine_dining': {
            'en': 'FINE DINING',
            'ar': 'FINE DINING',
            'el': 'FINE DINING',
            'cn': 'FINE DINING'
        },
        'tab_name_all_offers_gems': {
            'en': 'UNLIMITED',
            'ar': 'UNLIMITED',
            'el': 'UNLIMITED',
            'cn': 'UNLIMITED'
        },
        'tab_name_all_offers_kelloggs': {
            'en': "Kellogg's ENTERTAINER Offers",
            'ar': "عروض Kellogg's ENTERTAINER",
            'el': "Kellogg's ENTERTAINER Offers",
            'cn': "Kellogg's ENTERTAINER Offers"
        },
        'gems_featured_heading': {
            'en': 'The GEMS Experience',
            'ar': 'The GEMS Experience',
            'el': 'The GEMS Experience',
            'cn': 'The GEMS Experience'
        },
        'gems_more_to_enjoy': {
            'en': 'More Ways to Save',
            'ar': 'More Ways to Save',
            'el': 'More Ways to Save',
            'cn': 'More Ways to Save'
        },
        'hsbc_more_to_enjoy': {
            'en': 'More from HSBC',
            'ar': 'لمزيد من HSBC',
            'el': 'More from HSBC',
            'cn': 'More from HSBC'
        },
        'hsbc_more_to_enjoy_group2': {
            'en': 'Travel and Lifestyle',
            'ar': 'السفر ونمط الحياة',
            'el': 'Travel and Lifestyle',
            'cn': 'Travel and Lifestyle'},
        'qgi_more_to_enjoy': {
            'en': 'More about QGIRCO',
            'ar': 'المزيد عن QGIRCO',
            'el': 'More about QGIRCO',
            'cn': 'More about QGIRCO'
        },
        'gems_user_id_and_password_is_required': {
            'en': 'GEMS username and password is required',
            'ar': 'GEMS username and password is required',
            'el': 'GEMS username and password is required',
            'cn': 'GEMS username and password is required'
        },
        'user_already_exisit_gems_message': {
            'en': "This  email already exists as an Entertainer user. Please sign in, using the Gems username and the Entertainer password.",  # noqa:E501
            'ar': "This  email already exists as an Entertainer user. Please sign in, using the Gems username and the Entertainer password.",  # noqa:E501
            'el': "This  email already exists as an Entertainer user. Please sign in, using the Gems username and the Entertainer password.",  # noqa:E501
            'cn': "This  email already exists as an Entertainer user. Please sign in, using the Gems username and the Entertainer password."  # noqa:E501
        },
        'user_already_registered_gems_message': {
            'en': "This email is already registered. Please sign in.",
            'ar': "This email is already registered. Please sign in.",
            'el': "This email is already registered. Please sign in.",
            'cn': "This email is already registered. Please sign in."
        },
        'parent_id_is_required': {
            'en': 'Username is required',
            'ar': 'Username is required',
            'el': 'Username is required',
            'cn': 'Username is required'
        },
        'emp_code_is_required': {
            'en': 'User ID is required',
            'ar': 'User ID is required',
            'el': 'User ID is required',
            'cn': 'User ID is required'
        },
        'SAVED_THIS_YEAR_LABEL': {
            'en': 'SAVED THIS YEAR',
            'ar': 'قيمة التوفير لهذا العام',
            'el': 'ΕΞΟΙΚΟΝΟΜΗΣΑΤΕ ΑΥΤO ΤΟ ΕΤΟΣ',
            'cn': '今年已節省金額'
        },
        'OUTLET_COUNT_SINGULAR': {
            'en': 'Outlet',
            'ar': 'المنفذ',
            'el': 'ΚΑΤΑΣΤΗΜΑ',
            'cn': '間分店'
        },
        'OUTLET_COUNT_PLURAL': {
            'en': 'Outlets',
            'ar': 'المنافذ',
            'el': 'Καταστήματα',
            'cn': '間分店'
        },
        'TRAVEL_LOCATION': {
            'en': '1 Location',
            'ar': 'موقع 1',
            'el': 'Τοποθεσία',
            'cn': '1 位置'
        },
        'email_required': {
            "en": "Email must not be empty.",
            "ar": "يجب ألا يكون حقل العنوان الإلكتروني فارغاً",
            "cn": "必須填寫電郵地址。",
            "el": "Email must not be empty.",
            "de": "Email must not be empty."
        },
        'email_password_required': {
            "en": "Email and password must not be empty.",
            "ar": "يجب ألا يكون حقلا العنوان الإلكتروني وكلمة المرور فارغين",
            "cn": "必須填寫電郵地址及密碼。",
            "el": "Email and password must not be empty.",
            "de": "Email and password must not be empty."
        },
        'invalid_vip_key': {
            "en": "Invalid VIP Key.",
            "ar": "الرمز الخاص غير صحيح",
            "cn": "VIP 代號無效。",
            "el": "Invalid VIP Key.",
            "de": "Invalid VIP Key."
        },
        'email_not_exist': {
            "en": "Email not exist.",
            "ar": "العنوان الإلكتروني غير موجود",
            "cn": "電郵地址不存在。",
            "el": "Email not exist.",
            "de": "Email not exist."
        },
        'linked_entertainer_account_to_facebook': {
            "en": "We’ve linked your existing Entertainer account XXX1 with this facebook account",
            "ar": "لقد ربطنا حساب إنترتينر الخاص بك XXX1 بحسابك على فيسبوك",
            "cn": "我們已將您現時 The Entertainer 的帳戶 XXX1 連接到這個 Facebook 帳戶。",
            "el": "We’ve linked your existing Entertainer account XXX1 with this facebook account",
            "de": "We’ve linked your existing Entertainer account XXX1 with this facebook account"
        },
        'wrong_device_install_token': {
            "en": "Wrong device_install_token",
            "ar": "جهاز خاطئ_تثبيت_قسيمة ",
            "cn": "裝置錯誤_安裝_代幣",
            "el": "Wrong device_install_token",
            "de": "Wrong device_install_token"
        },
        'wrong_session_token': {
            "en": "Wrong session_token",
            "ar": "خطأ في الصفحة_قسيمة",
            "cn": "會話錯誤_代幣",
            "el": "Wrong session_token",
            "de": "Wrong session_token"
        },
        'problems_with_saving_of_family_member_info': {
            "en": "Problems with saving of the family member info.', 'errors': XXX1",
            "ar": "توجد مشاكل في حفظ فرد العائلة. ', 'أخطاء': XXX1",
            "cn": "儲存家庭成員資料出現問題，「錯誤」: XXX1",
            "el": "Problems with saving of the family member info.', 'errors': XXX1",
            "de": "Problems with saving of the family member info.', 'errors': XXX1"
        },
        'vip_key_already_used': {
            "en": "This VIP key has already been used.",
            "ar": "سبق أن تمّ استخدام هذا الرقم الخاص من قبل",
            "cn": "這 VIP 代號已被使用。",
            "el": "This VIP key has already been used.",
            "de": "This VIP key has already been used."
        },
        'success_vip_key_applied_and_product_unlocked': {
            "en": "Success! The VIP Key has been applied and the product will now be unlocked.",
            "ar": "تمّت العملية بنجاح! لقد تمّ تطبيق الرمز الخاص وسوف يتم تحرير المنتج الآن",
            "cn": "成功！已應用了 VIP 代號，上鎖產品即將被解開。",
            "el": "Επιτυχία! Ο κωδικός VIP λειτούργησε και το προϊόν θα ξεκλειδωθεί.",
            "de": "Success! The VIP Key has been applied and the product will now be unlocked."
        },
        'invalid_email_address': {
            "en": "Invalid email address",
            "ar": "العنوان الإلكتروني غير صالح",
            "cn": "電郵地址無效",
            "el": "Invalid email address",
            "de": "Invalid email address"
        },
        'not_implemented': {
            "en": "Not Implemented.",
            "ar": "غير منفّذ",
            "cn": "尚未執行。",
            "el": "Not Implemented.",
            "de": "Not Implemented."
        },
        'social_id_not_tied_to_magento_customer_account': {
            "en": "The provided social ID is not tied to a particular Magento customer account.",
            "ar": "إنّ بطاقة التعريف الاجتماعية المقدمة ليست مرتبطة بحساب عميل ماجنتو محدّد",
            "cn": "您提供的 Social ID 尚未連接到特定的 Magento 顧客帳戶。",
            "el": "The provided social ID is not tied to a particular Magento customer account.",
            "de": "The provided social ID is not tied to a particular Magento customer account."
        },
        'not_authorized_to_access_user': {
            "en": "You are not authorized to access this user",
            "ar": "لست مخولاً للوصول إلى هذا المستخدم",
            "cn": "您未經授權使用這用家的帳戶。",
            "el": "You are not authorized to access this user",
            "de": "You are not authorized to access this user"
        },
        'not_authorized_to_access_key': {
            "en": "You are not authorize you access this key",
            "ar": "لست مخولاً لاستخدام هذا الرمز ",
            "cn": "您未經授權使用這代號。",
            "el": "You are not authorize you access this key",
            "de": "You are not authorize you access this key"
        },
        'problems_with_your_submission': {
            "en": "Problems with your submission",
            "ar": "توجد مشاكل في ما ترسله",
            "cn": "提交過程出現問題。",
            "el": "Problems with your submission",
            "de": "Problems with your submission"
        },
        'you_are_not_authorized_to_access_this_user': {
            "en": "You are not authorized to access this user",
            "ar": "لست مخولاً للوصول إلى هذا المستخدم",
            "cn": "您未經授權以使用這用家的帳戶。",
            "el": "You are not authorized to access this user",
            "de": "You are not authorized to access this user"
        },
        'customer_with_this_email_address_exists': {
            "en": "A customer with this email address exists.",
            "ar": "يوجد عميل آخر مسجّل بهذا العنوان اللكتروني",
            "cn": "已有一位顧客使用這電郵地址。",
            "el": "A customer with this email address exists.",
            "de": "A customer with this email address exists."
        },
        'customer_register_success': {
            "en": "customer_register_success",
            "ar": "عميل_تسجيل_نجاح",
            "cn": "顧客_註冊_成功",
            "el": "customer_register_success",
            "de": "customer_register_success"
        },
        'activation_of_trial': {
            "en": "Activation of Trial",
            "ar": "تفعيل الفترة التجريبية",
            "cn": "啟動使用期",
            "el": "Activation of Trial",
            "de": "Activation of Trial"
        },
        'merchant_does_not_exist': {
            "en": "Merchant does not exist.",
            "ar": "هذا التاجر غير موجود",
            "cn": "商戶不存在。",
            "el": "Merchant does not exist.",
            "de": "Merchant does not exist."
        },
        'offer_does_not_exist': {
            "en": "Offer does not exist.",
            "ar": "هذا العرض غير موجود",
            "cn": "優惠不存在。",
            "el": "Offer does not exist.",
            "de": "Offer does not exist."
        },
        'offer_does_not_exist_or_inactive': {
            "en": "Offer {} does not exist or is Inactive.",
            "ar": "العرض {} غير موجود أو غير مفعّل",
            "cn": "優惠 {} 不存在或不能使用。",
            "el": "Offer {} does not exist or is Inactive.",
            "de": "Offer {} does not exist or is Inactive."
        },
        'customer_has_already_redeemed_offer_x_the_maximum_allowed_times': {
            "en": "Customer has already redeemed Offer XXX1 the maximum allowed times.",
            "ar": "سبق أن استخدم العميل العرض XXX1 لعدد المرات الأقصى المسموح به ",
            "cn": "顧客兌換此優惠 XXX1 的次數已到了上限。",
            "el": "Customer has already redeemed Offer XXX1 the maximum allowed times.",
            "de": "Customer has already redeemed Offer XXX1 the maximum allowed times."
        },
        'customer_does_not_own_offer_x': {
            "en": "Customer does not own Offer XXX1",
            "ar": "لا يملك العميل العرض XXX1",
            "cn": "顧客尚未擁有優惠 XXX1。",
            "el": "Customer does not own Offer XXX1",
            "de": "Customer does not own Offer XXX1"},

        'offer_x_is_not_available_at_outlet_y': {
            "en": "Offer XXX1 is not available at Outlet XXX2",
            "ar": "العرض XXX1 غير متاح في المنفذ XXX2",
            "cn": "優惠 XXX1 在此分店 XXX2 無效。",
            "el": "Offer XXX1 is not available at Outlet XXX2",
            "de": "Offer XXX1 is not available at Outlet XXX2"
        },
        'offer_can_be_redeemed_a_maximum_of_x_times_you_requested_y_times': {
            "en": "Offer XXX1 can be redeemed a maximum of XXX2 times. You requested to redeemed it XXX3 times.",
            "ar": "يمكن استخديمكن استخدام العرض XXX1 XXX2  مرات كحد أقصى. لقد طلبت الاستفادة منه XXX3 مرة",
            "cn": "優惠 XXX1 最多只可兌換 XXX2 次。您已要求兌換了 XXX3 次。",
            "el": "Offer XXX1 can be redeemed a maximum of XXX2 times. You requested to redeemed it XXX3 times.",
            "de": "Offer XXX1 can be redeemed a maximum of XXX2 times. You requested to redeemed it XXX3 times."
        },
        'no_offers_specified': {
            "en": "No offers specified.",
            "ar": "لا توجد عروض محددة",
            "cn": "沒有指名具體優惠。",
            "el": "No offers specified.",
            "de": "No offers specified."
        },
        'offers_must_belong_to_the_same_merchant': {
            "en": "Offers must belong to the same Merchant.",
            "ar": "يجب أن تعود العروض للتاجر نفسه",
            "cn": "優惠必須屬於同一家商戶。",
            "el": "Offers must belong to the same Merchant.",
            "de": "Offers must belong to the same Merchant."
        },
        'invalid_merchant_pin': {
            "en": "Invalid merchant PIN",
            "ar": "رمز التعريف الشخصي الخاص بالتاجر غير صحيح",
            "cn": "商戶私人密碼無效。",
            "el": "Λάθος ΡΙΝ Εμπόρου",
            "de": "Invalid merchant PIN"
        },
        'informatica_error': {
            "en": "informatica_error",
            "ar": "معلومات _خطأ",
            "cn": "資料_錯誤",
            "el": "informatica_error",
            "de": "informatica_error"
        },
        'for_given_key_values_are_not_found': {
            "en": "For given key values ​​are not found.",
            "ar": "لم يتم العثور على الأحرف الأربعة التي يتألّف منها الرمز الخاص",
            "cn": "未能找到您輸入的數值代碼。",
            "el": "For given key values ​​are not found.",
            "de": "For given key values ​​are not found."
        },
        'there_is_no_such_record': {
            "en": "There is no such record.",
            "ar": "لا وجود لهذا البند",
            "cn": "尚未有此紀錄。",
            "el": "There is no such record.",
            "de": "There is no such record."
        },
        'you_are_not_authorized_to_delete_this_customer_devices_record': {
            "en": "You are not authorized to delete this customer devices record",
            "ar": "لست مخوّلاً لمحو جهاز العميل المسجّل هذا ",
            "cn": "您未經授權刪除這顧客裝置上的紀錄。",
            "el": "You are not authorized to delete this customer devices record",
            "de": "You are not authorized to delete this customer devices record"
        },
        'there_are_no_customer_devices_belonging_to_the_specified_customer': {
            "en": "There are no customer devices belonging to the specified customer.",
            "ar": "لا يوجد أي جهاز خاص بالعميل المحدد",
            "cn": "沒有裝置是屬於這特定的顧客。",
            "el": "There are no customer devices belonging to the specified customer.",
            "de": "There are no customer devices belonging to the specified customer."
        },
        'problems_with_customer_devices_record_deleting': {
            "en": "Problems with customer devices record deleting.', 'errors': XXX1",
            "ar": "المشاكل في أجهزة العميل تسجّل الإلغاء. 'أخطاء': XXX1",
            "cn": "刪除顧客裝置上的紀錄出現問題。「錯誤」: XXX1",
            "el": "Problems with customer devices record deleting.', 'errors': XXX1",
            "de": "Problems with customer devices record deleting.', 'errors': XXX1"
        },
        'email_and_key_required': {
            "en": "Email and Key must not be empty.",
            "ar": "يجب ألا يكون حقلا العنوان الإلكتروني والرمز فارغين",
            "cn": "電郵及代號必須填寫。",
            "el": "Email and Key must not be empty.",
            "de": "Email and Key must not be empty."
        },
        'you_are_not_authorized_to_access_this_key': {
            "en": "You are not authorized to access this key",
            "ar": "لست مخولاً لاستعمال هذا الرمز",
            "cn": "您未經授權使用這代號。",
            "el": "You are not authorized to access this key",
            "de": "You are not authorized to access this key"
        },
        'invalid_login_or_password': {
            "en": "Invalid email or password",
            "ar": " العنوان الإلكتروني أو كلمة المرور غير صحيحة",
            "cn": "資料未有紀錄",
            "el": "Invalid email or password",
            "de": "Invalid email or password"
        },

        'invalid_password': {
            "en": "Invalid Password.",
            "ar": "كلمة المرور غير صحيحة",
            "cn": "Invalid Password.",
            "el": "Invalid Password.",
            "de": "Invalid Password."
        },
        'access_restricted_to_application_gems': {
            "en": "This App is exclusive to GEMS parents and staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "ar": "This App is exclusive to GEMS parents and staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "cn": "This App is exclusive to GEMS parents and staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "el": "This App is exclusive to GEMS parents and staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "de": "This App is exclusive to GEMS parents and staff. Please ensure you are using the credentials we sent you by email."  # noqa:E501
        },
        'access_restricted_to_application_crg': {
            "en": "This App is exclusive to Caregiver staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "ar": "This App is exclusive to Caregiver staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "cn": "This App is exclusive to Caregiver staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "el": "This App is exclusive to Caregiver staff. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "de": "This App is exclusive to Caregiver staff. Please ensure you are using the credentials we sent you by email."  # noqa:E501
        },
        'access_restricted_to_application_nma': {
            "en": "This App is exclusive to NAMAA ENTERTAINER. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "ar": "هذا التطبيق خاص بموظفي NAMAA. يرجى التأكد من استخدام تفاصيل الحساب التي أرسلناها إليك بالبريد الإلكتروني.",  # noqa:E501
            "cn": "This App is exclusive to NAMAA ENTERTAINER. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "el": "This App is exclusive to NAMAA ENTERTAINER. Please ensure you are using the credentials we sent you by email.",  # noqa:E501
            "de": "This App is exclusive to NAMAA ENTERTAINER. Please ensure you are using the credentials we sent you by email."  # noqa:E501
        },
        'access_restricted_to_application_dpr': {
            "en": "This App is exclusive to Dubai Entertainments employees. Please use your employee ID and date of birth to register.",  # noqa:E501
            "ar": "This App is exclusive to Dubai Entertainments employees. Please use your employee ID and date of birth to register.",  # noqa:E501
            "cn": "This App is exclusive to Dubai Entertainments employees. Please use your employee ID and date of birth to register.",  # noqa:E501
            "el": "This App is exclusive to Dubai Entertainments employees. Please use your employee ID and date of birth to register.",  # noqa:E501
            "de": "This App is exclusive to Dubai Entertainments employees. Please use your employee ID and date of birth to register."  # noqa:E501
        },
        'you_are_not_allowed_to_access_this_application': {
            "en": "You are not allowed to access this application.",
            "ar": "غير مسموح لك استخدام هذا التطبيق",
            "cn": "You are not allowed to access this application.",
            "el": "You are not allowed to access this application.",
            "de": "You are not allowed to access this application."
        },
        'you_are_not_allowed_to_access_this_application_due': {
            "en": "You are not allowed to access this application.",
            "ar": "You are not allowed to access this application.",
            "cn": "You are not allowed to access this application.",
            "el": "You are not allowed to access this application.",
            "de": "You are not allowed to access this application."
        },
        'you_are_not_allowed_to_access_this_application_dut': {
            "en": "Sorry, we do not recognize the information you have entered. "
                  "This app is for use by du Premium Customers only. "
                  "Please check your details and try again, alternatively you can call du Contact Center at 800155.",
            "ar": "Sorry, we do not recognize the information you have entered. "
                  "This app is for use by du Premium Customers only. "
                  "Please check your details and try again, alternatively you can call du Contact Center at 800155.",
            "cn": "Sorry, we do not recognize the information you have entered. "
                  "This app is for use by du Premium Customers only. "
                  "Please check your details and try again, alternatively you can call du Contact Center at 800155.",
            "el": "Sorry, we do not recognize the information you have entered. "
                  "This app is for use by du Premium Customers only. "
                  "Please check your details and try again, alternatively you can call du Contact Center at 800155.",
            "de": "Sorry, we do not recognize the information you have entered. "
                  "This app is for use by du Premium Customers only. "
                  "Please check your details and try again, alternatively you can call du Contact Center at 800155."
        },
        'player_not_found': {
            "en": "Player not found.",
            "ar": "Player not found. arabic",
            "cn": "Player not found.",
            "el": "Player not found.",
            "de": "Player not found."
        },

        'player_not_created': {
            "en": "Player not created.",
            "ar": "Player not created.arabic",
            "cn": "Player not created.",
            "el": "Player not created.",
            "de": "Player not created."
        },

        'player_answers_not_saved': {
            "en": "Player answers not saved.",
            "ar": "Player answers not saved. arabic",
            "cn": "Player answers not saved.",
            "el": "Player answers not saved.",
            "de": "Player answers not saved."
        },

        'reward_definition_not_found': {
            "en": "Reward definition not found.",
            "ar": "Reward definition not found. arabic",
            "cn": "Reward definition not found.",
            "el": "Reward definition not found.",
            "de": "Reward definition not found."
        },

        'no_data_available': {
            "en": "No data available.",
            "ar": "No data available.",
            "cn": "No data available.",
            "el": "No data available.",
            "de": "No data available."
        },

        'you_have_exceeded_your_devices_limit': {
            "en": "Sorry you’ve reached your device limit for this account. Please contact customer services.",
            "ar": "Sorry you’ve reached your device limit for this account. Please contact customer services.",
            "cn": "Sorry you’ve reached your device limit for this account. Please contact customer services.",
            "el": "Sorry you’ve reached your device limit for this account. Please contact customer services.",
            "de": "Sorry you’ve reached your device limit for this account. Please contact customer services."
        },

        'vip_key_validation_is_unavailable_temporarily': {
            "en": "VIP Key validation is temporarily unavailable. Please try signing in without your VIP Key now … you can always add it later within your settings",  # noqa:E501
            "ar": "VIP Key validation is temporarily unavailable. Please try signing in without your VIP Key now … you can always add it later within your settings",  # noqa:E501
            "cn": "VIP Key validation is temporarily unavailable. Please try signing in without your VIP Key now … you can always add it later within your settings",  # noqa:E501
            "el": "VIP Key validation is temporarily unavailable. Please try signing in without your VIP Key now … you can always add it later within your settings",  # noqa:E501
            "de": "VIP Key validation is temporarily unavailable. Please try signing in without your VIP Key now … you can always add it later within your settings"  # noqa:E501
        },

        'social_sign_in_not_available_at_the_moment': {
            "en": "Social sign in currently unavailable.",
            "ar": "Social sign in currently unavailable.",
            "cn": "Social sign in currently unavailable.",
            "el": "Social sign in currently unavailable.",
            "de": "Social sign in currently unavailable."
        },

        'functionality_not_available_in_offline_mode': {
            "en": "Sorry, this feature is temporarily unavailable. Please try again later.",
            "ar": "Sorry, this feature is temporarily unavailable. Please try again later.",
            "cn": "Sorry, this feature is temporarily unavailable. Please try again later.",
            "el": "Sorry, this feature is temporarily unavailable. Please try again later.",
            "de": "Sorry, this feature is temporarily unavailable. Please try again later."
        },

        'upgrade_your_app': {
            "en": "Please upgrade to the latest version of the Entertainer App from the App Store. It has some amazing new features which you have to try!",  # noqa:E501
            "ar": "Please upgrade to the latest version of the Entertainer App from the App Store. It has some amazing new features which you have to try!",  # noqa:E501
            "cn": "Please upgrade to the latest version of the Entertainer App from the App Store. It has some amazing new features which you have to try!",  # noqa:E501
            "el": "Please upgrade to the latest version of the Entertainer App from the App Store. It has some amazing new features which you have to try!",  # noqa:E501
            "de": "Please upgrade to the latest version of the Entertainer App from the App Store. It has some amazing new features which you have to try!"  # noqa:E501
        },

        'please_Select_Log_in_as_a_different_user_to_access_your_2016_offers': {
            "en": "Please Select 'Log in as a different user' to access your 2016 offers (you can use the same email)",
            "ar": "Please Select 'Log in as a different user' to access your 2016 offers (you can use the same email)",
            "cn": "Please Select 'Log in as a different user' to access your 2016 offers (you can use the same email)",
            "el": "Please Select 'Log in as a different user' to access your 2016 offers (you can use the same email)",
            "de": "Please Select 'Log in as a different user' to access your 2016 offers (you can use the same email)"
        },

        'bin_key_is_not_valid': {
            "en": "Incorrect number entered. Please enter the first 8 digits of your MasterCard® card.",
            "ar": "Incorrect number entered. Please enter the first 8 digits of your MasterCard® card.",
            "cn": "Incorrect number entered. Please enter the first 8 digits of your MasterCard® card.",
            "el": "Incorrect number entered. Please enter the first 8 digits of your MasterCard® card.",
            "de": "Incorrect number entered. Please enter the first 8 digits of your MasterCard® card."
        },

        'bin_already_registered': {
            "en": "Your account is linked with another MasterCard® card. Please contact buy1get1@mastercard.com.",
            "ar": "Your account is linked with another MasterCard® card. Please contact buy1get1@mastercard.com.",
            "cn": "Your account is linked with another MasterCard® card. Please contact buy1get1@mastercard.com.",
            "el": "Your account is linked with another MasterCard® card. Please contact buy1get1@mastercard.com.",
            "de": "Your account is linked with another MasterCard® card. Please contact buy1get1@mastercard.com."
        },

        'invalid_dob': {
            "en": "Invalid date of birth",
            "ar": "Invalid date of birth",
            "cn": "Invalid date of birth",
            "el": "Invalid date of birth",
            "de": "Invalid date of birth"
        },

        'invalid_dates_selected': {
            "en": "Invalid dates selected",
            "ar": "Invalid dates selected",
            "cn": "Invalid dates selected",
            "el": "Invalid dates selected",
            "de": "Invalid dates selected"
        },

        'limit_exceeded_to_verify_the_code': {
            "en": "This is awkward, limit exceeded to verify the code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "ar": "This is awkward, limit exceeded to verify the code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "cn": "This is awkward, limit exceeded to verify the code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "el": "This is awkward, limit exceeded to verify the code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "de": "This is awkward, limit exceeded to verify the code. Please contact Customer Services on customerservice@theentertainerme.com."  # noqa:E501
        },

        'phone_number_has_already_been_verified_with_some_other_account': {
            "en": "This phone number has already been verified with some other account. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "ar": "This phone number has already been verified with some other account. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "cn": "This phone number has already been verified with some other account. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "el": "This phone number has already been verified with some other account. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "de": "This phone number has already been verified with some other account. Please contact Customer Services on customerservice@theentertainerme.com."  # noqa:E501
        },

        'verification_code_request_limit_exceeded': {
            "en": "This is awkward, we’re having issues getting the code to you. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "ar": "This is awkward, we’re having issues getting the code to you. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "cn": "This is awkward, we’re having issues getting the code to you. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "el": "This is awkward, we’re having issues getting the code to you. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "de": "This is awkward, we’re having issues getting the code to you. Please contact Customer Services on customerservice@theentertainerme.com."  # noqa:E501
        },

        'merchant_details_not_found': {
            "en": "Merchant details not found.",
            "ar": "Merchant details not found.",
            "cn": "Merchant details not found.",
            "el": "Merchant details not found.",
            "de": "Merchant details not found."
        },

        'failed_to_send_verification_code': {
            "en": "Failed to send verification code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "ar": "Failed to send verification code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "cn": "Failed to send verification code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "el": "Failed to send verification code. Please contact Customer Services on customerservice@theentertainerme.com.",  # noqa:E501
            "de": "Failed to send verification code. Please contact Customer Services on customerservice@theentertainerme.com."  # noqa:E501
        },

        'invalid_verification_code': {
            "en": "Invalid verification code. Please try again.",
            "ar": "Invalid verification code. Please try again.",
            "cn": "Invalid verification code. Please try again.",
            "el": "Invalid verification code. Please try again.",
            "de": "Invalid verification code. Please try again."
        },

        'cheers_offer_message_for_ping_for_app_upgrade': {
            "en": "Pinged! Your friend will need the latest version of the app to use this ping",
            "ar": "Pinged! Your friend will need the latest version of the app to use this ping",
            "cn": "Pinged! Your friend will need the latest version of the app to use this ping",
            "el": "Pinged! Your friend will need the latest version of the app to use this ping",
            "de": "Pinged! Your friend will need the latest version of the app to use this ping"
        },

        'cheers_vip_key_app_upgrade_message': {
            "en": "Please update your app to use this VIP key",
            "ar": "Please update your app to use this VIP key",
            "cn": "Please update your app to use this VIP key",
            "el": "Please update your app to use this VIP key",
            "de": "Please update your app to use this VIP key"
        },

        'sign_in_failed': {
            "en": "Sign in failed.",
            "ar": "Sign in failed.",
            "cn": "請輸入最少6位數字的密碼。",
            "el": "Sign in failed.",
            "de": "Sign in failed."
        },

        'dob_minimum_value_error': {
            "en": "Sorry but our app is just for big kids and grownups. You need to be over 13 years old",
            "ar": "عذراً، تطبيقنا مخصص للأولاد الكبار والبالغين. يجب أن يكون عمرك أكثر من 13 عاماً",
            "cn": "Sorry but our app is just for big kids and grownups. You need to be over 13 years old",
            "el": "Sorry but our app is just for big kids and grownups. You need to be over 13 years old",
            "de": "Sorry but our app is just for big kids and grownups. You need to be over 13 years old"
        },

        'du_product_purchase_success_message': {
            "en": "Thank you for your purchase! Your du Premier app offers are now activated. "
                  "You can enjoy thousands of exciting 2 for 1 Offers from du! Happy Saving!",
            "ar": "شكرا لك على الشراء!لقد تم تفعيل العروض الخاصة بتطبيق DU يمكنك الإستمتاع بألاف العروض 2 بسعر 1 من DU توفير سعيد!",  # noqa:E501
            "cn": "Thank you for your purchase! Your du Premier app offers are now activated. "
                  "You can enjoy thousands of exciting 2 for 1 Offers from du!Happy Saving!",
            "el": "Thank you for your purchase! Your du Premier app offers are now activated. "
                  "You can enjoy thousands of exciting 2 for 1 Offers from du! Happy Saving!",
            "de": "Thank you for your purchase! Your du Premier app offers are now activated. "
                  "You can enjoy thousands of exciting 2 for 1 Offers from du! Happy Saving!"
        },

        'du_failed_product_purchase': {
            "en": "Product purchase failed. For assistance, please contact customer care at 800 155.",
            "ar": "لم تنجح عملية شراء المنتج . للحصول على المساعدة ، يرجى الاتصال بخدمة العملاء على الرقم 800 515 .",
            "cn": "Product purchase failed. For assistance, please contact customer care at 800 155.",
            "el": "Product purchase failed. For assistance, please contact customer care at 800 155.",
            "de": "Product purchase failed. For assistance, please contact customer care at 800 155."
        },

        'customer_details_not_found': {
            "en": "Customer details not found",
            "ar": "Customer details not found",
            "cn": "Customer details not found",
            "el": "Customer details not found",
            "de": "Customer details not found"
        },

        'Open_to_be_used': {
            "en": "Open to be Used",
            "ar": "Open to be Used",
            "cn": "Open to be Used",
            "el": "Open to be Used",
            "de": "Open to be Used"
        },

        'key_required': {
            "en": "Key must not be empty.",
            "ar": "Key must not be empty.",
            "cn": "Key must not be empty.",
            "el": "Key must not be empty.",
            "de": "Key must not be empty."
        },

        'invalid_wl_key': {
            "en": "The Key is not Valid",
            "ar": "الرمز غير صالح",
            "cn": "The Key is not Valid",
            "el": "The Key is not Valid",
            "de": "The Key is not Valid"
        },

        'invalid_wl_key_with_branch': {
            "en": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "ar": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "cn": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "el": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "de": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience"  # noqa:E501
        },

        'invalid_link': {
            "en": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "ar": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "cn": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "el": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience",  # noqa:E501
            "de": "Oops! Something went wrong. Contact us at info@theentertainerme.com to help us improve your experience"  # noqa:E501
        },

        'imie_number_not_valid': {
            "en": "The imie number is not valid",
            "ar": "The imie number is not valid",
            "cn": "The imie number is not valid",
            "el": "The imie number is not valid",
            "de": "The imie number is not valid"
        },

        'imie_number_is_required': {
            "en": "The imie number is required",
            "ar": "The imie number is required",
            "cn": "The imie number is required",
            "el": "The imie number is required",
            "de": "The imie number is required"
        },

        'du_otp_message': {
            "en": "Dear Customer, Your One Time Password (OTP) for activating your 2 for 1 offers from du is XXXXXX. If you did not initiate this request, Please call us on 800 155.",  # noqa:E501
            "ar": "عزيزي العميل ، كلمة المرور لمرة واحدة (OTP )  الخاصة بتفعيل عروض 2 بسعر واحد من DU هي XXXXXX .إذا لم تطلب هذا الطلب يرجى الإتصال بنا على الرقم 800155",  # noqa:E501
            "cn": "Dear Customer, Your One Time Password (OTP) for activating your 2 for 1 offers from du is XXXXXX. If you did not initiate this request, Please call us on 800 155.",  # noqa:E501
            "el": "Dear Customer, Your One Time Password (OTP) for activating your 2 for 1 offers from du is XXXXXX. If you did not initiate this request, Please call us on 800 155.",  # noqa:E501
            "de": "Dear Customer, Your One Time Password (OTP) for activating your 2 for 1 offers from du is XXXXXX. If you did not initiate this request, Please call us on 800 155."  # noqa:E501
        },

        'elf_pop_up_screen_upon_successful_activation': {
            "en": "Thank you for activating your Entertainer Life App, "
                  "which provides a guide for buy one get one free offers to the best dining, activities, attractions, "
                  "spas and hotels. With your activation, you have been enrolled as a member until 30 December 2017. "
                  "The merchant offers will be subject to change or replacement during the subscription.",
            "ar": "Thank you for activating your Entertainer Life App, "
                  "which provides a guide for buy one get one free offers to the best dining, activities, attractions, "
                  "spas and hotels. With your activation, you have been enrolled as a member until 30 December 2017. "
                  "The merchant offers will be subject to change or replacement during the subscription.",
            "cn": "多謝您啓動Entertainer Life應用程式！現在您可以享用各項飲食、活動、景點、"
                  "水療按摩及酒店的買一送一優惠，您的會籍有效期至2017年12月30日。本公司有權變更或取代使用期內的商戶優惠。",
            "el": "Thank you for activating your Entertainer Life App, "
                  "which provides a guide for buy one get one free offers to the best dining, activities, attractions, "
                  "spas and hotels. With your activation, you have been enrolled as a member until 30 December 2017. "
                  "The merchant offers will be subject to change or replacement during the subscription.",
            "de": "Thank you for activating your Entertainer Life App, "
                  "which provides a guide for buy one get one free offers to the best dining, activities, attractions, "
                  "spas and hotels. With your activation, you have been enrolled as a member until 30 December 2017. "
                  "The merchant offers will be subject to change or replacement during the subscription."
        },

        'friend_referral_message': {

            "en": "Refer a friend and earn SMILES",
            "ar": "بادر بإحالة صديق لكسب SMILES",
            "cn": "介紹朋友及獲取SMILES",
            "el": "ΣΥΣΤΗΣΤΕ ΕΝΑN ΦΙΛΟ ΚΑΙ ΚΕΡΔΙΣΤΕ SMILES",
            "de": "Refer a friend and earn SMILES"
        },

        'friend_connect_message': {
            "en": "Have friends who also use the Entertainer? Invite them to connect with you and track your savings on a leader board.",  # noqa:E501
            "ar": "هل لديك أصدقاء يستخدمون إنترتينر؟ يمكنك أن تدعوهم للتواصل معك وتعقب قيمة التوفير التي تحققها من خلال لوحة المتصدرين.",  # noqa:E501
            "cn": "可邀請亦是ENTERTAINER會員的朋友互相加入排行榜，追蹤彼此節省額。",
            "el": "Έχεις φίλους που χρησιμοποιούν το Entertainer? Προσκάλεσέ τους να συνδεθούν μαζί σου και ακολούθησε τις οικονομίες σου στον πίνακα",  # noqa:E501
            "de": "Have friends who also use the Entertainer? Invite them to connect with you and track your savings on a leader board."  # noqa:E501
        },

        'transaction_succeeded': {
            "en": "Transaction succeeded",
            "ar": "Transaction succeeded",
            "cn": "Transaction succeeded",
            "el": "Transaction succeeded",
            "de": "Transaction succeeded"
        },

        'transaction_failed': {
            "en": "Transaction failed",
            "ar": "Transaction failed",
            "cn": "Transaction failed",
            "el": "Transaction failed",
            "de": "Transaction failed"
        },

        'smiles_burn_buy_back_offer_scuccess': {
            "en": "Congratulations on your purchase: @voucher_merchant@",
            "ar": "مبروك لما اشتريته: @voucher_merchant@",
            "cn": "恭喜你，已經成功購買: @voucher_merchant@",
            "el": "Congratulations on your purchase: @voucher_merchant@",
            "de": "Congratulations on your purchase: @voucher_merchant@"
        },

        'smiles_burn_purchase_pings_scuccess': {
            "en": "Congratulations on your purchase: Set of 10 Pings.",
            "ar": "مبروك لما اشتريته: باقة مكونة من 10 عروض مرسلة",
            "cn": "恭喜你，已經成功購買: 增加10個轉贈優惠功能",
            "el": "Congratulations on your purchase: Set of 10 Pings.",
            "de": "Congratulations on your purchase: Set of 10 Pings."
        },

        'smiles_burn_purchase_promotional_app_scuccess': {
            "en": "Congratulations on your purchase: @product_name@",
            "ar": "مبروك لما اشتريته: @product_name@ ",
            "cn": "恭喜你，已經成功購買: @product_name@",
            "el": "Congratulations on your purchase: @product_name@",
            "de": "Congratulations on your purchase: @product_name@"
        },

        'unfriend_successfully': {
            "en": "Connection removed successfully",
            "ar": "Connection removed successfully",
            "cn": "Connection removed successfully",
            "el": "Επαφή Διαγράφηκε Επιτυχώς",
            "de": "Connection removed successfully"
        },

        'unfriend_failed': {
            "en": "Failed to remove connection",
            "ar": "Failed to remove connection",
            "cn": "Failed to remove connection",
            "el": "Failed to remove connection",
            "de": "Failed to remove connection"
        },

        'product_buy_screen_product_supplement_title': {
            "en": "Product Supplements",
            "ar": "Product Supplements",
            "cn": "Product Supplements",
            "el": "Product Supplements",
            "de": "Product Supplements"
        },
        'product_buy_screen_merchant_section_title': {
            "en": "Top Merchants",
            "ar": "Top Merchants",
            "cn": "Top Merchants",
            "el": "Top Merchants",
            "de": "Top Merchants"
        },
        'delivery_offers_remaining': {
            "en": "Offer(s) Remaining",
            "ar": "عدد العروض المتبقية",
            "cn": "Offer(s) Remaining",
            "el": "Offer(s) Remaining",
            "de": "Offer(s) Remaining"
        },
        'du_error_encountered_verifying_code': {
            "en": "An error encountered while verifying the code",
            "ar": "حدث خطأ أثناء التحقق من الرمز",
            "cn": "An error encountered while verifying the code",
            "el": "An error encountered while verifying the code",
            "de": "An error encountered while verifying the code"
        },
        'du_invalid_code_entered': {
            "en": "Invalid code entered",
            "ar": "رمز غير صالح للإدخال",
            "cn": "Invalid code entered",
            "el": "Invalid code entered",
            "de": "Invalid code entered"
        },
        'du_exceeded_limit_verify_code': {
            "en": "You have exceeded limit to verify code",
            "ar": "لقد تجاوزت الحد الأقصى للتحقق من الرمز",
            "cn": "You have exceeded limit to verify code",
            "el": "You have exceeded limit to verify code",
            "de": "You have exceeded limit to verify code"
        },

        'du_phone_number_already_verified': {
            "en": "Phone number already verified",
            "ar": "تم التحقق من رقم الهاتف",
            "cn": "Phone number already verified",
            "el": "Phone number already verified",
            "de": "Phone number already verified"
        },

        'du_phone_number_not_found': {
            "en": "Phone number not found",
            "ar": "لم يتم العثور على رقم الهاتف",
            "cn": "Phone number not found",
            "el": "Phone number not found",
            "de": "Phone number not found"
        },
        'Ping_Count_Left_To_Receive_Single': {
            "en": "You can receive __offer_count__ more ping",
            "ar": "يمكنك استلام __offer_count__ عرض إضافي",
            "el": "Μπορείτε να λάβετε __offer_count__ επιπλέον ping",
            "cn": "你可以多獲得__offer_count__個轉贈數量",
            "de": "You can receive __offer_count__ more ping"
        },
        "Ping_Count_Left_To_Receive_Multiple": {
            "en": "You can receive __offer_count__ pings",
            "ar": "You can receive __offer_count__ pings",
            "el": "You can receive __offer_count__ pings",
            "cn": "You can receive __offer_count__ pings",
            "de": "You can receive __offer_count__ pings"
        },
        'Ping_Quota_Left_To_Receive_For_Recipient_Single': {
            "en": "Sorry, the recipient can receive __offer_count__ more offer only.",
            "ar": "عذراً، يمكن للمستلم استقبال عرض إضافي واحد فقط",
            "el": "Λυπούμαστε, ο παραλήπτης μπορεί να λάβει μόνο 1 προσφορά",
            "cn": "對不起！對方只能多獲得1個優惠",
            "de": "Sorry, the recipient can receive __offer_count__ more offer only."
        },
        'Ping_Quota_Left_To_Receive_For_Recipient_Multiple': {
            "en": "Sorry, the recipient can receive __offer_count__ more offers only.",
            "ar": "عذراً، يمكن للمستلم استقبال __offer_count__ عرض إضافي فقط",
            "el": "Δυστυχώς, ο παραλήπτης μπορεί να λάβει μόνο __offer_count__άλλες προσφορές",
            "cn": "對不起！對方只能多獲得__offer_count__個優惠",
            "de": "Sorry, the recipient can receive __offer_count__ more offers only."
        },
        'Ping_Count_Left_To_Send_Single': {
            "en": "You can send __offer_count__ more offer",
            "ar": "يمكنك إرسال __offer_count__ عرض إضافي",
            "el": "Μπορείτε να στείλετε __offer_count__ ακόμη προσφορά",
            "cn": "你可以多送出__offer_count__個優惠",
            "de": "You can send __offer_count__ more offer"
        },
        'Ping_Count_Left_To_Send_Multiple': {
            "en": "You can send __offer_count__ more offers",
            "ar": "يمكنك إرسال __offer_count__ عروض إضافية",
            "el": "Μπορείτε να στείλετε άλλες __offer_count__προσφορές",
            "cn": "你可以多送出__offer_count__個優惠",
            "de": "You can send __offer_count__ more offers"
        },
        'Ping_Offer_Success_Message': {
            "en": "Ping(s) sent successfully",
            "ar": "تم إرسال وحدات مشاركة العروض",
            "cn": "轉贈成功發送",
            "el": "Τα ping (s) στάλθηκαν με επιτυχία",
            "de": "Ping(s) sent successfully"
        },
        'Ping_Quota_Finished_To_Receive': {
            "en": "You cannot receive any more pings",
            "ar": "لا يمكن استلام عروض إضافية",
            "el": "Δεν μπορείτε να λάβετε άλλα pings",
            "cn": "未能獲得更多轉贈數量",
            "de": "You cannot receive any more pings"
        },
        'Ping_Quota_Finished_To_Receive_For_Recipient': {
            "en": "Sorry, the account you are tyring to send pings cannot receive any more pings",
            "ar": "عذراً، الحساب الذي تحاول إرسال العروض إليه لا يمكنه استلام المزيد",
            "el": "Λυπούμαστε, ο λογαριασμός που προσπαθείτε να στείλετε pings δεν μπορεί να λάβει άλλα pings",
            "cn": "對不起！你要發送轉贈功能的帳戶不適用獲得更多轉贈數量",
            "de": "Sorry, the account you are tyring to send pings cannot receive any more pings"
        },
        'Ping_Quota_Finished_To_Send': {
            "en": "You cannot send any more pings",
            "ar": "لا يمكنك إرسال المزيد من العروض",
            "el": "Δεν μπορείτε να στείλετε άλλα pings",
            "cn": "未能轉贈更多",
            "de": "You cannot send any more pings"
        },
        'Ping_Sender_Cant_Be_Recipient': {
            "en": "Sorry, you can't send pings to yourself",
            "ar": "عذراً، لا يمكنك إرسال العروض لنفسك",
            "el": "Δυστυχώς, δεν μπορείτε να στείλετε pings στον εαυτό σας",
            "cn": "對不起！你不能向自己發送轉贈數量",
            "de": "Sorry, you can't send pings to yourself"
        },
        'Ping_Recipient_Cant_Be_Family_Member': {
            "en": "Sorry, you can't send pings to a family member",
            "ar": "Sorry, you can't send pings to a family member",
            "el": "Sorry, you can't send pings to a family member",
            "cn": "Sorry, you can't send pings to a family member",
            "de": "Sorry, you can't send pings to a family member"
        },
        'offers_pinged_to_me': {
            "en": "Offers Pinged to me",
            "ar": "العروض المرسلة إلي",
            "cn": "轉贈給自己的優惠",
            "el": "Προσφορές που έλαβα με Ping",
            "de": "Offers Pinged to me"
        },

        'included_in_mobile_product_not_yet_purchased': {
            "en": "INCLUDED IN MOBILE PRODUCT NOT YET PURCHASED",
            "ar": "مدرج في منتج المحمول ولم يتم شراؤه بعد",
            "cn": "包含在未購買的流動產品",
            "el": "ΠΕΡΙΛΑΜΒΑΝΕΤΑΙ ΣΕ ΠΡΟΪΟΝ ΓΙΑ ΚΙΝΗΤΑ ΠΟΥ ΔΕΝ ΕΧΕΙ ΑΓΟΡΑΣΤΕΙ ΑΚΟΜΗ",
            "de": "INCLUDED IN MOBILE PRODUCT NOT YET PURCHASED"
        },

        'pinged': {
            "en": "PINGED",
            "ar": "أًرسل",
            "cn": "轉贈",
            "el": "Εστάλη με Ping",
            "de": "PINGED"
        },
        "Ping_Count_Left_To_Receive_Unlimited": {
            "en": "You can receive unlimited pings",
            "ar": "You can receive unlimited pings",
            "el": "You can receive unlimited pings",
            "cn": "You can receive unlimited pings",
            "de": "You can receive unlimited pings"
        },
        "Ping_Accepted_Message": {
            "en": "Ping accepted!",
            "ar": "تم قبول العرض المُرسَل!",
            "cn": "己接受轉贈優惠!",
            "de": "Μήνυμα αποδεκτό!"
        },
        "Reject_Ping_Title": {
            "en": "Reject Ping",
            "ar": "رفض العرض المُرسَل",
            "cn": "不接受轉贈優惠",
            "de": "Απορρίψτε το Μήνυμα"
        },
        "Reject_Ping_Message": {
            "en": "Are you sure want to reject this ping?",
            "ar": "متأكّد من رغبتك برفض العرض المُرسَل؟",
            "cn": "您確定不接受優惠?",
            "de": "Είστε βέβαιοι ότι θέλετε να απορρίψετε αυτό το μήνυμα?"
        },
        "Recall_Ping_Title": {
            "en": "Recall Ping",
            "ar": "استرجاع العرض المُرسَل",
            "cn": "重新接受轉贈優惠",
            "de": "Ανακαλέστε Μήνυμα"
        },
        "Recall_Ping_Message": {
            "en": "Are you sure want to recall this ping?",
            "ar": "متأكّد من رغبتك باسترجاع العرض المُرسَل؟",
            "cn": "您確定重新接受此轉贈優惠嗎？",
            "de": "Είστε βέβαιοι ότι θέλετε να ανακαλέσετε αυτό το μήνυμα?"
        },
        "Ping_Recalled_Title": {
            "en": "Recalled",
            "ar": "تم الاسترجاع",
            "el": "Ανακαλέστηκε"
        },
        "Ping_Recalled_Text": {
            "en": "This ping has been recalled.",
            "ar": ".تم استرجاع العرض المُرسَل",
            "el": "Αυτό το μήνυμα έχει ανακαλεστεί"
        },
        'already_redeemed': {
            "en": "ALREADY REDEEMED",
            "ar": "تم استخدامه",
            "cn": "已兌換",
            "el": "ΕΧΕΙ ΗΔΗ ΕΞΑΡΓΥΡΩΘΕΙ",
            "de": "ALREADY REDEEMED"
        },
        'purchased_available_from': {
            "en": "PURCHASED, AVAILABLE FROM APP_DATE",
            "ar": "تم شراؤه، متوافر من APP_DATE",
            "cn": "已購買，由APP_DATE開始適用",
            "el": "ΕΧΕΙ ΑΓΟΡΑΣΤΕΙ, ΔΙΑΘΕΣΙΜΟ ΣΤΟ APP_DATE",
            "de": "PURCHASED, AVAILABLE FROM APP_DATE"
        },
        'valid_to': {
            "en": "VALID TO APP_DATE",
            "ar": "APP_DATE صالح حتى",
            "cn": "有效期至APP_DATE",
            "el": "ΙΣΧΥΕΙ ΕΩΣ APP_DATE",
            "de": "VALID TO APP_DATE"
        },
        'expired_offer': {
            "en": "This offer has expired",
            "ar": "ها العرض منتهي",
            "cn": "此優惠已到期",
            "el": "Αυτή η προσφορά έχει λήξει",
            "de": "This offer has expired"
        },
        'user_account_frozen': {
            "en": "User Account Frozen",
            "ar": "تم تجيمد حسابك",
            "cn": "帳戶已被凍結",
            "el": "Ο λογαριασμός σας είναι περιορισμένος",
            "de": "User Account Frozen"
        },
        'user_account_frozen_blocked': {
            "en": "User Account is Frozen/Blocked",
            "ar": "تم تجيمد حسابك",
            "cn": "帳戶已被凍結",
            "el": "Ο λογαριασμός σας είναι περιορισμένος",
            "de": "User Account is Frozen/Blocked"
        },
        'user_blacklisted': {
            "en": "Oops! There’s a problem with your account, please contact customer service at customerservices@theentertainerme.com",  # noqa:E501
            "ar": "عذراً، ثمة مشكلة في حسابك. يرجى منك التواصل مع قسم خدمة العملاء عبر العنوان التالي: customerservices@theentertainerme.com",  # noqa:E501
            "cn": "噢！登入途中遇上問題，請聯絡我們的客戶服務部 : customerservices@theentertainerme.com",
            "el": "Ωχ! Υπάρχει ένα πρόβλημα με το λογαριασμό σας, παρακαλούμε επικοινωνήστε με το τμήμα εξυπηρέτησης πελατών στο customerservices@theentertainerme.com",  # noqa:E501
            "de": "Oops! There’s a problem with your account, please contact customer service at customerservices@theentertainerme.com"  # noqa:E501
        },
        'device_blacklisted': {
            "en": "Oops! There’s a problem with your device, please contact customer service at customerservices@theentertainerme.com",  # noqa:E501
            "ar": "عذراً، ثمة مشكلة في جهازك . يرجى منك التواصل مع قسم خدمة العملاء عبر العنوان التالي: customerservices@theentertainerme.com",  # noqa:E501
            "cn": "噢~使用的裝置出現問題，請聯絡客戶服務部customerservices@theentertainerme.com",
            "el": "Ωχ! Υπάρχει ένα πρόβλημα με το συσκευή σας, παρακαλούμε επικοινωνήστε με το τμήμα εξυπηρέτησης πελατών στο customerservices@theentertainerme.com",  # noqa:E501
            "de": "Oops! There’s a problem with your device, please contact customer service at customerservices@theentertainerme.com"  # noqa:E501
        },
        'this_is_a_bundled_product': {
            "en": "Bundled product - Not available for purchase",
            "ar": "هذا منتج ضمن باقة",
            "cn": "此產品為非賣品",
            "el": "Αυτό το προϊόν δεν πωλείται μεμονωμένα",
            "de": "Bundled product - Not available for purchase"
        },
        'this_product_is_no_more_purchasable': {
            "en": "This product is no longer available for purchase",
            "ar": "بعض من المنتجات المدرجة غير متوفرة للشراء حالياً",
            "cn": "其中包含不作銷售的產品。",
            "el": "Μερικά από τα προϊόντα που συμπεριλαμβάνονται δεν είναι πλέον διαθέσιμα για αγορά.",
            "de": "This product is no longer available for purchase"
        },
        'happy_birthday_title': {
            "en": "Your%20Birthday%20Offers",
            "ar": "Your%20Birthday%20Offers",
            "cn": "Your%20Birthday%20Offers",
            "el": "Your%20Birthday%20Offers",
            "de": "Your%20Birthday%20Offers"
        },
        'customer_with_this_email_address_already_exists': {
            "en": "Customer with this email address already exists",
            "ar": "Customer with this email address already exists",
            "cn": "Customer with this email address already exists",
            "el": "Customer with this email address already exists",
            "de": "Customer with this email address already exists"
        },
        'you_have_already_activated_this_key': {
            "en": "you have already activated this key",
            "ar": "لقد قمت بالفعل بتفعيل هذا الرمز",
            "cn": "you have already activated this key",
            "el": "you have already activated this key",
            "de": "you have already activated this key"
        },
        'you_have_successfully_activated_the_key': {
            "en": "You have successfully activated the key",
            "ar": "لقد قمت بتفعيل الرمز بنجاح",
            "cn": "You have successfully activated the key",
            "el": "You have successfully activated the key",
            "de": "You have successfully activated the key"
        },

        'you_have_successfully_activated_the_key_with_branch': {
            "en": "Awesome. You’re account has been upgraded. Enjoy your offers",
            "ar": "Awesome. You’re account has been upgraded. Enjoy your offers",
            "cn": "Awesome. You’re account has been upgraded. Enjoy your offers",
            "el": "Awesome. You’re account has been upgraded. Enjoy your offers",
            "de": "Awesome. You’re account has been upgraded. Enjoy your offers"
        },
        'you_are_not_allowed_to_subscribe_multiple_keys': {
            "en": "you are not allowed to subscribe multiple keys",
            "ar": "you are not allowed to subscribe multiple keys",
            "cn": "you are not allowed to subscribe multiple keys",
            "el": "you are not allowed to subscribe multiple keys",
            "de": "you are not allowed to subscribe multiple keys"
        },
        'you_have_already_activated_the_app_for_multiple_keys_not_allowed': {
            "en": "Hey! You've activated the app previously. Enjoy your offers",
            "ar": "Hey! You've activated the app previously. Enjoy your offers",
            "cn": "Hey! You've activated the app previously. Enjoy your offers",
            "el": "Hey! You've activated the app previously. Enjoy your offers",
            "de": "Hey! You've activated the app previously. Enjoy your offers",
        },
        'key_is_required': {
            "en": "Key is Required",
            "ar": "Key is Required",
            "cn": "Key is Required",
            "el": "Key is Required",
            "de": "Key is Required"
        },
        'user_creation_failed': {
            "en": "User creation failed",
            "ar": "User creation failed",
            "cn": "User creation failed",
            "el": "User creation failed",
            "de": "User creation failed"
        },
        'email_not_linked_message': {
            "en": "Thanks. We’ve just sent you an email with instructions on how to register for the App. In case it slips by you, make sure you check your junk/spam folder.",  # noqa:E501
            "ar": "شكراً. قمنا للتو بإرسال رسالة إلكترونية مع التوجيهات اللازمة لكيفية التسجيل في التطبيق. إذا فوّتَ رسالتنا، تأكّد أن تتفقد مجلد الرسائل الغير مرغوب بها في بريدك الإلكتروني",  # noqa:E501
            "cn": "Thanks. We’ve just sent you an email with instructions on how to register for the App. In case it slips by you, make sure you check your junk/spam folder.",  # noqa:E501
            "el": "Thanks. We’ve just sent you an email with instructions on how to register for the App. In case it slips by you, make sure you check your junk/spam folder.",  # noqa:E501
            "de": "Thanks. We’ve just sent you an email with instructions on how to register for the App. In case it slips by you, make sure you check your junk/spam folder."  # noqa:E501
        },
        'savings_message_home': {
            "en": "__username__ you've saved __saved_amount__  so far!",
            "ar": "__username__ you've saved __saved_amount__  so far!",
            "cn": "__username__ you've saved __saved_amount__  so far!",
            "el": "__username__ you've saved __saved_amount__  so far!",
            "de": "__username__ you've saved __saved_amount__  so far!"
        },
        "VOUCHER_TYPE_BUY_ONE_GET_ONE_FREE": {
            'en': 'Buy 1 Get 1 Free',
            'ar': 'Buy 1 Get 1 Free',
            'el': 'Buy 1 Get 1 Free',
            'cn': 'Buy 1 Get 1 Free',
            'de': 'Buy 1 Get 1 Free'
        },
        "VOUCHER_TYPE_PACKAGE": {
            'en': 'Package',
            'ar': 'Package',
            'el': 'Package',
            'cn': 'Package',
            'de': 'Package'
        },
        "VOUCHER_TYPE_FIX_PRICE_OFF": {
            'en': '_discount_value_ Off',
            'ar': '_discount_value_ Off',
            'el': '_discount_value_ Off',
            'cn': '_discount_value_ Off',
            'de': '_discount_value_ Off'
        },
        "VOUCHER_TYPE_PERCENTAGE_OFF": {
            'en': '_percentage_value_% Off',
            'ar': '_percentage_value_% Off',
            'el': '_percentage_value_% Off',
            'cn': '_percentage_value_% Off',
            'de': '_percentage_value_% Off'
        },
        "VOUCHER_TYPE_SPEND_THIS_GET_THIS": {
            'en': 'Spend _spend_value_ Get _reward_value_',
            'ar': 'Spend _spend_value_ Get _reward_value_',
            'el': 'Spend _spend_value_ Get _reward_value_',
            'cn': 'Spend _spend_value_ Get _reward_value_',
            'de': 'Spend _spend_value_ Get _reward_value_'
        },
        "VOUCHER_TYPE_BUY_ONE_GET_ONE_FREE_141": {
            'en': 'Buy 1 Get 1 Free',
            'ar': 'Buy 1 Get 1 Free',
            'el': 'Buy 1 Get 1 Free',
            'cn': 'Buy 1 Get 1 Free',
            'de': 'Buy 1 Get 1 Free'
        },
        "voucher_restriction_1_valid_for_dine_in_and_takeaway": {
            "en": 'Valid for Dine-in and Take-Away',
            "ar": 'Valid for Dine-in and Take-Away',
            "cn": 'Valid for Dine-in and Take-Away',
            "el": 'Valid for Dine-in and Take-Away',
            "de": 'Valid for Dine-in and Take-Away'
        },
        "voucher_restriction_2_excluding_friday_brunch": {
            "en": 'Excluding Friday Brunch',
            "ar": 'Excluding Friday Brunch',
            "cn": 'Excluding Friday Brunch',
            "el": 'Excluding Friday Brunch',
            "de": 'Excluding Friday Brunch'
        },
        "voucher_restriction_3_advance_booking_is_required": {
            "en": 'Advance Booking is Required',
            "ar": 'Advance Booking is Required',
            "cn": 'Advance Booking is Required',
            "el": 'Advance Booking is Required',
            "de": 'Advance Booking is Required'
        },
        "voucher_restriction_4_delivery_only": {
            "en": 'Delivery only',
            "ar": 'Delivery only',
            "cn": 'Delivery only',
            "el": 'Delivery only',
            "de": 'Delivery only'
        },
        "voucher_restriction_5_dine_in_only": {
            "en": 'Dine-in only',
            "ar": 'Dine-in only',
            "cn": 'Dine-in only',
            "el": 'Dine-in only',
            "de": 'Dine-in only'
        },
        "voucher_restriction_6_excluding_brunch": {
            "en": 'Excluding Brunch',
            "ar": 'Excluding Brunch',
            "cn": 'Excluding Brunch',
            "el": 'Excluding Brunch',
            "de": 'Excluding Brunch'
        },
        "voucher_restriction_7_food_only": {
            "en": 'Food only',
            "ar": 'Food only',
            "cn": 'Food only',
            "el": 'Food only',
            "de": 'Food only'
        },
        "voucher_restriction_8_no_corkage_allowed": {
            "en": 'No Corkage Allowed',
            "ar": 'No Corkage Allowed',
            "cn": 'No Corkage Allowed',
            "el": 'No Corkage Allowed',
            "de": 'No Corkage Allowed'
        },
        "voucher_restriction_9_not_valid_on_delivery": {
            "en": 'Not Valid on Delivery',
            "ar": 'Not Valid on Delivery',
            "cn": 'Not Valid on Delivery',
            "el": 'Not Valid on Delivery',
            "de": 'Not Valid on Delivery'
        },
        "voucher_restriction_10_not_valid_on__holidays": {
            "en": 'Not Valid on  Holidays',
            "ar": 'Not Valid on  Holidays',
            "cn": 'Not Valid on  Holidays',
            "el": 'Not Valid on  Holidays',
            "de": 'Not Valid on  Holidays'
        },
        "voucher_restriction_11_rack_rate_applies": {
            "en": 'Rack Rate Applies',
            "ar": 'Rack Rate Applies',
            "cn": 'Rack Rate Applies',
            "el": 'Rack Rate Applies',
            "de": 'Rack Rate Applies'
        },
        "voucher_restriction_12_to_redeem_you_must_be_of_legal_drinking_age_and_non_muslim": {
            "en": 'To redeem you must be of legal drinking age and non-Muslim',
            "ar": 'To redeem you must be of legal drinking age and non-Muslim',
            "cn": 'To redeem you must be of legal drinking age and non-Muslim',
            "el": 'To redeem you must be of legal drinking age and non-Muslim',
            "de": 'To redeem you must be of legal drinking age and non-Muslim'
        },
        "voucher_restriction_13_valid_on_all_packages": {
            "en": 'Valid on All Packages',
            "ar": 'Valid on All Packages',
            "cn": 'Valid on All Packages',
            "el": 'Valid on All Packages',
            "de": 'Valid on All Packages'
        },
        "voucher_restriction_14_valid_on_delivery": {
            "en": 'Valid on Delivery',
            "ar": 'Valid on Delivery',
            "cn": 'Valid on Delivery',
            "el": 'Valid on Delivery',
            "de": 'Valid on Delivery'
        },
        'NO': {
            'en': 'No',
            'ar': 'لا',
            'el': 'ΟΧΙ',
            'cn': '沒有'
        },
        'YES': {
            'en': 'Yes',
            'ar': 'نعم',
            'el': 'ΝΑΙ',
            'cn': '是'
        },
        'OUTLET_SPECIFIC': {
            'en': 'Outlet Specific',
            'ar': 'محدد من المنفذ',
            'el': 'Συγκεκριμένο Κατάστημα',
            'cn': '視乎分店'
        },
        "success": {
            "en": 'success',
            "ar": 'success',
            "cn": 'success',
            "el": 'success',
            "de": 'success'
        },
        "profile_not_updated": {
            "en": 'Profile not updated',
            "ar": 'Profile not updated',
            "cn": 'Profile not updated',
            "el": 'Profile not updated',
            "de": 'Profile not updated'
        },
        "password_reset_link_sent_message": {
            "en": 'Password reset link sent to your email address!',
            "ar": 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني الخاص!',
            "cn": '重設密碼的連結已發送到您的電郵信箱!',
            "el": 'Password reset link sent to your email address!',
            "de": 'Password reset link sent to your email address!'
        },
        "password_email_not_found_message": {
            "en": 'Email address not found.',
            "ar": 'Email address not found.',
            "cn": 'Email address not found.',
            "el": 'Email address not found.',
            "de": 'Email address not found.'
        },
        "invalid_request": {
            "en": 'Invalid Request',
            "ar": 'Invalid Request',
            "cn": 'Invalid Request',
            "el": 'Invalid Request',
            "de": 'Invalid Request'
        },
        "top_merchant_total_saving": {
            "en": 'Estimated Savings: {total_savings}',
            "ar": "القيمة المقدرة للمبالغ الموفّرة: {total_savings}",
            "cn": '估計節省金額: {total_savings}',
            "el": 'Εκτιμώμενη εξοικονόμηση: {total_savings}',
            "de": 'Estimated Savings: {total_savings}'
        },
        "top_cuisines": {
            "en": ["American", "Arabic", "Chinese", "Indian", "Italian"],
            "ar": ["مأكولات أميركية", "مأكولات عربية", "مأكولات صينية", "مأكولات هندية", "مأكولات إيطالية"],
            "cn": ["美國菜", "阿拉伯菜", "中菜", "印度菜", "意國菜"],
            "el": ["Αμερικανική", "Αραβική", "Κινέζικη", "Ινδική", "Ιταλική"],
            "de": ["American", "Arabic", "Chinese", "Indian", "Italian"]
        },
        "type_title": {
            'en': 'Star Rating',
            'ar': "عدد النجوم",
            'el': "Αξιολόγηση με Αστέρια",
            'cn': "酒店評級",
            'de': 'Star Rating'
        },
        "All": {
            "en": "All",
            "ar": "كافة العروض",
            "el": "Όλα",
            "cn": "所有",
            "de": "All"
        },
        "Cuisine": {
            "en": "Cuisine",
            "ar": "نوع المطبخ",
            "el": "Είδος κουζίνας",
            "cn": "菜式",
            "de": "Cuisine"
        },
        #######################
        # Heading translations
        #######################
        "Two_People": {
            "en": "2 PEOPLE",
            "ar": "2 PEOPLE",
            "el": "2 PEOPLE",
            "cn": "2 PEOPLE",
            "de": "2 PEOPLE"
        },
        "EXTRA": {
            'en': "More to enjoy",
            'ar': "المزيد",
            'el': "Περισσότερα για να απολαύσετε",
            'cn': "更多"
        },
        "FOR_THE_WEEKEND": {
            'en': "For the weekend",
            'ar': "لعطلة نهاية الأسبوع",
            'el': "Για το Σαββατοκύριακο",
            'cn': "週末使用"
        },
        "FEATURED": {
            'en': "Featured",
            'ar': "عروض أساسية",
            'el': "Προτεινόμενα",
            'cn': "精選"
        },
        "JUST_FOR_YOU": {
            'en': "Just For You",
            'ar': "عروض أساسية",
            'el': "Προτεινόμενα",
            'cn': "精選"
        },
        "ping_count_left_to_receive": {
            "en": "You can receive {offer_count} more ping(s).",
            "ar": "You can receive {offer_count} more ping(s).",
            "el": "You can receive {offer_count} more ping(s).",
            "cn": "You can receive {offer_count} more ping(s).",
            "de": "You can receive {offer_count} more ping(s)."
        },
        "ping_quota_left_to_receive_for_recipient": {
            "en": "Sorry, the recipient can receive {offer_count} more offer(s) only.",
            "ar": "Sorry, the recipient can receive {offer_count} more offer(s) only.",
            "el": "Sorry, the recipient can receive {offer_count} more offer(s) only.",
            "cn": "Sorry, the recipient can receive {offer_count} more offer(s) only.",
            "de": "Sorry, the recipient can receive {offer_count} more offer(s) only."
        },
        "ping_count_left_to_send": {
            "en": "You can send {offer_count} more offer(s).",
            "ar": "You can send {offer_count} more offer(s).",
            "el": "You can send {offer_count} more offer(s).",
            "cn": "You can send {offer_count} more offer(s).",
            "de": "You can send {offer_count} more offer(s)."
        },
        'ping_count_left_to_receive_single': {
            "en": "You can receive {offer_count} more ping",
            "ar": "يمكنك استلام {offer_count} عرض إضافي",
            "el": "Μπορείτε να λάβετε {offer_count} επιπλέον ping",
            "cn": "你可以多獲得__offer_count__個轉贈數量",
            "de": "You can receive {offer_count} more ping"
        },
        "ping_count_left_to_receive_multiple": {
            "en": "You can receive {offer_count} pings",
            "ar": "You can receive {offer_count} pings",
            "el": "You can receive {offer_count} pings",
            "cn": "You can receive {offer_count} pings",
            "de": "You can receive {offer_count} pings"
        },
        'ping_quota_left_to_receive_for_recipient_single': {
            "en": "Sorry, the recipient can receive {offer_count} more offer only.",
            "ar": "عذراً، يمكن للمستلم استقبال عرض إضافي واحد فقط",
            "el": "Λυπούμαστε, ο παραλήπτης μπορεί να λάβει μόνο 1 προσφορά",
            "cn": "對不起！對方只能多獲得1個優惠",
            "de": "Sorry, the recipient can receive {offer_count} more offer only."
        },
        'ping_quota_left_to_receive_for_recipient_multiple': {
            "en": "Sorry, the recipient can receive {offer_count} more offers only.",
            "ar": "عذراً، يمكن للمستلم استقبال {offer_count} عرض إضافي فقط",
            "el": "Δυστυχώς, ο παραλήπτης μπορεί να λάβει μόνο __offer_count__άλλες προσφορές",
            "cn": "對不起！對方只能多獲得__offer_count__個優惠",
            "de": "Sorry, the recipient can receive {offer_count} more offers only."
        },
        'ping_count_left_to_send_single': {
            "en": "You can send {offer_count} more offer",
            "ar": "يمكنك إرسال {offer_count} عرض إضافي",
            "el": "Μπορείτε να στείλετε {offer_count} ακόμη προσφορά",
            "cn": "你可以多送出__offer_count__個優惠",
            "de": "You can send {offer_count} more offer"
        },
        'ping_count_left_to_send_multiple': {
            "en": "You can send {offer_count} more offers",
            "ar": "يمكنك إرسال {offer_count} عروض إضافية",
            "el": "Μπορείτε να στείλετε άλλες __offer_count__προσφορές",
            "cn": "你可以多送出__offer_count__個優惠",
            "de": "You can send {offer_count} more offers"
        },
        'ping_offer_success_message': {
            "en": "Ping(s) sent successfully",
            "ar": "تم إرسال وحدات مشاركة العروض",
            "cn": "轉贈成功發送",
            "el": "Τα ping (s) στάλθηκαν με επιτυχία",
            "de": "Ping(s) sent successfully"
        },
        'ping_quota_finished_to_receive': {
            "en": "You cannot receive any more pings",
            "ar": "لا يمكن استلام عروض إضافية",
            "el": "Δεν μπορείτε να λάβετε άλλα pings",
            "cn": "未能獲得更多轉贈數量",
            "de": "You cannot receive any more pings"
        },
        'ping_quota_finished_to_receive_for_recipient': {
            "en": "Sorry, the account you are tyring to send pings cannot receive any more pings",
            "ar": "عذراً، الحساب الذي تحاول إرسال العروض إليه لا يمكنه استلام المزيد",
            "el": "Λυπούμαστε, ο λογαριασμός που προσπαθείτε να στείλετε pings δεν μπορεί να λάβει άλλα pings",
            "cn": "對不起！你要發送轉贈功能的帳戶不適用獲得更多轉贈數量",
            "de": "Sorry, the account you are tyring to send pings cannot receive any more pings"
        },
        'ping_quota_finished_to_send': {
            "en": "You cannot send any more pings",
            "ar": "لا يمكنك إرسال المزيد من العروض",
            "el": "Δεν μπορείτε να στείλετε άλλα pings",
            "cn": "未能轉贈更多",
            "de": "You cannot send any more pings"
        },
        'ping_sender_cant_be_recipient': {
            "en": "Sorry, you can't send pings to yourself",
            "ar": "عذراً، لا يمكنك إرسال العروض لنفسك",
            "el": "Δυστυχώς, δεν μπορείτε να στείλετε pings στον εαυτό σας",
            "cn": "對不起！你不能向自己發送轉贈數量",
            "de": "Sorry, you can't send pings to yourself"
        },
        'ping_recipient_cant_be_family_member': {
            "en": "Sorry, you can't send pings to a family member",
            "ar": "Sorry, you can't send pings to a family member",
            "el": "Sorry, you can't send pings to a family member",
            "cn": "Sorry, you can't send pings to a family member",
            "de": "Sorry, you can't send pings to a family member"
        },
        "promotional_section_food_title": {
            "en": "Hungry?",
            "ar": "جوعان؟",
            "cn": "Hungry?",
            "el": "Πεινασμένος?",
            "de": "Hungry?"
        },
        "promotional_section_food_description": {
            "en": "All you need to is buy the ENTERTAINER and you'll see heaps of delicious offers here",
            "ar": "ما عليك سوى شراء إنترتينر للتمتع بأشهى العروض المتاحة",
            "cn": "All you need to is buy the ENTERTAINER and you'll see heaps of delicious offers here",
            "el": "Το μόνο που χρειάζεστε είναι να αγοράσετε το ENTERTAINER και θα δείτε πολλές εύγευστες προσφορές εδώ",
            "de": "All you need to is buy the ENTERTAINER and you'll see heaps of delicious offers here"
        },
        "promotional_section_body_title": {
            "en": "Had a stressful week?",
            "ar": "مررت بأسبوع متعب؟",
            "cn": "Had a stressful week?",
            "el": "Είχατε μια αγχωτική εβδομάδα;",
            "de": "Had a stressful week?"
        },
        "promotional_section_body_description": {
            "en": "Get the ENTERTAINER to fill this space with offers for spas, massages and more",
            "ar": "Get the ENTERTAINER to fill this space with offers for spas, massages and more",
            "cn": "Get the ENTERTAINER to fill this space with offers for spas, massages and more",
            "el": "Get the ENTERTAINER to fill this space with offers for spas, massages and more",
            "de": "Get the ENTERTAINER to fill this space with offers for spas, massages and more"
        },
        "promotional_section_leisure_title": {
            "en": "Tired of doing the same thing?",
            "ar": "الروتين أصبح مملاً؟",
            "cn": "Tired of doing the same thing?",
            "el": "Κουρασμένος από τα ίδια και τα ίδια;",
            "de": "Tired of doing the same thing?"
        },
        "promotional_section_leisure_description": {
            "en": "We'll pack this space with loads of fun offers as soon as you get your ENTERTAINER",
            "ar": "أروع العروض بانتظارك بمجرد شرائك إنترتينر",
            "cn": "We'll pack this space with loads of fun offers as soon as you get your ENTERTAINER",
            "el": "Θα γεμίσουμε αυτόν τον χώρο με πολλές διασκεδαστικές προσφορές μόλις πάρετε το ENTERTAINER σας",
            "de": "We'll pack this space with loads of fun offers as soon as you get your ENTERTAINER"
        },
        "promotional_section_retail_title": {
            "en": "Want to look even more glamorous?",
            "ar": "حان الوقت لإطلالة جديدة؟",
            "cn": "Want to look even more glamorous?",
            "el": "Θέλετε να φαίνεστε ακόμα πιο λαμπεροί;",
            "de": "Want to look even more glamorous?"
        },
        "promotional_section_retail_description": {
            "en": "Get your ENTERTAINER to see loads of offers for fashion here",
            "ar": "مجموعة من عروض الموضة بانتظارك عند شراء إنتريتنر",
            "cn": "Get your ENTERTAINER to see loads of offers for fashion here",
            "el": "Πάρτε το ENTERTAINER σας για να δείτε πολλά προσφορές για μόδα εδώ",
            "de": "Get your ENTERTAINER to see loads of offers for fashion here"
        },
        "promotional_section_services_title": {
            "en": "Want to save on everyday stuff?",
            "ar": "بحاجة إلى التوفير على الخدمات اليومية؟",
            "cn": "Want to save on everyday stuff?",
            "el": "Θέλετε να γλιτώνετε χρήματα στα καθημερινά έξοδα;",
            "de": "Want to save on everyday stuff?"
        },
        "promotional_section_services_description": {
            "en": "Find loads of offers here as soon as you get your ENTERTAINER",
            "ar": "الكثير من العروض في تصرفك عند شراء إنترتينر",
            "cn": "Find loads of offers here as soon as you get your ENTERTAINER",
            "el": "Βρείτε πολλές προσφορές εδώ, μόλις πάρετε το ENTERTAINER σας",
            "de": "Find loads of offers here as soon as you get your ENTERTAINER"
        },
        'BOOK_A_TABLE': {
            "en": "BOOK A TABLE",
            "ar": "BOOK A TABLE",
            "el": "BOOK A TABLE",
            "cn": "BOOK A TABLE",
            "de": "BOOK A TABLE"
        },
        "NOT_YET_PURCHASED": {
            "en": "INCLUDED IN MOBILE PRODUCT NOT YET PURCHASED",
            "ar": "مدرج في منتج المحمول ولم يتم شراؤه بعد",
            "cn": "包含在未購買的流動產品",
            "el": "ΠΕΡΙΛΑΜΒΑΝΕΤΑΙ ΣΕ ΠΡΟΪΟΝ ΓΙΑ ΚΙΝΗΤΑ ΠΟΥ ΔΕΝ ΕΧΕΙ ΑΓΟΡΑΣΤΕΙ ΑΚΟΜΗ",
            "de": "INCLUDED IN MOBILE PRODUCT NOT YET PURCHASED"
        },
        "THIS_IS_A_BUNDLED_PRODUCT": {
            "en": "Bundled product - Not available for purchase",
            "ar": "هذا منتج ضمن باقة",
            "cn": "此產品為非賣品",
            "el": "Αυτό το προϊόν δεν πωλείται μεμονωμένα",
            "de": "Bundled product - Not available for purchase"
        },
        "People": {
            "en": "PEOPLE",
            "ar": "PEOPLE",
            "el": "PEOPLE",
            "cn": "PEOPLE",
            "de": "PEOPLE"
        },
        "Person": {
            "en": "PERSON",
            "ar": "PERSON",
            "el": "PERSON",
            "cn": "PERSON",
            "de": "PERSON"
        },
        "Persons": {
            "en": "PERSONS",
            "ar": "PERSONS",
            "el": "PERSONS",
            "cn": "PERSONS",
            "de": "PERSONS"
        },
        "REMOVE_FROM_FAMILY": {
            "en": "REMOVE FROM FAMILY",
            "ar": "الحذف من الحساب العائلي ",
            "cn": "於家庭共享帳戶中移除",
            "el": "Αφαιρέστε από την Οικογένεια"
        },
        "NO_FAMILY_SECONDARY_FOUND": {
            "en": "It looks like you haven’t joined a family yet.",
            "ar": "لم تنضم إلى عائلة بعد",
            "el": "Δεν έχετε ενώσει ακόμα μια οικογένεια",
            "cn": "你還沒有加入家庭",
            "de": "It looks like you haven’t joined a family yet."
        },
        "FAMILY_HEADER_TITLE": {
            "en": "Family Tree",
            "ar": "شجرة العائلة",
            "el": "Family Tree",
            "cn": "Family Tree",
            "de": "Family Tree"
        },
        "CONFIRM_LEAVE_PRIMARY": {
            "en": "Are you sure you want to close your ENTERTAINER family account?",
            "ar": "هل ترغب فعلاً بإغلاق الحساب العائلي من إنترتينر؟",
            "el": "Είσαι σίγουρος ότι θέλεις να κλείσεις τον οικογενειακό λογαριασμό ENTERTAINER σου;",
            "cn": "你肯定要關掉你的ENTERTAINER 家庭共享帳戶嗎?",
            "de": "Are you sure you want to close your ENTERTAINER family account?"
        },
        "CONFIRM_ACTIVE_REMOVE_MEMBER": {
            "en": "Are you sure you want to remove {name} from your ENTERTAINER family?",
            "ar": "هل ترغب فعلاً بحذف {name} من الحساب العائلي من إنترتينر؟",
            "el": "Είσαι σίγουρος ότι θέλεις να αφαιρέσεις τον/την {name} από την οικογένεια ENTERTAINER σου;",
            "cn": "你肯定要撤除{name} 的ENTERTAINER 家庭共享帳戶嗎?",
            "de": "Are you sure you want to remove {name} from your ENTERTAINER family?"
        },
        "CONFIRM_REMOVE_MEMBER": {
            "en": "Are you sure you don't want {name} to join your ENTERTAINER family?",
            "ar": "هل ترغب فعلاً بعدم ضم {name} إلى الحساب العائلي من إنترتينر؟",
            "el": "Είσαι σίγουρος ότι δεν θέλεις τον/την {name} να ενταχθεί στην οικογένεια ENTERTAINER σου;",
            "cn": "你肯定不加入{name} 的ENTERTAINER 家庭共享帳戶嗎?",
            "de": "Are you sure you don't want {name} to join your ENTERTAINER family?"
        },
        "CONFIRM_LEAVE_SECONDARY": {
            "en": "Are you sure you want to leave this awesome ENTERTAINER family?",
            "ar": "هل ترغب فعلاً بالانسحاب من الحساب العائلي الرائع من إنترتينر؟",
            "el": "Είσαι σίγουρος ότι θέλεις να φύγεις από αυτή την εκπληκτική οικογένεια ENTERTAINER;",
            "cn": "Are you sure you want to leave this awesome ENTERTAINER family?",
            "de": "Are you sure you want to leave this awesome ENTERTAINER family?"
        },
        "FAMILY_CLOSED": {
            "en": "Your family account has been closed",
            "ar": "تم إغلاق حسابك العائلي",
            "el": "Ο οικογενειακός σου λογαριασμός έχει κλείσει",
            "cn": "你家庭共享帳戶已經關掉",
            "de": "Your family account has been closed"
        },
        "LEAVED_SUCCESSFULLY": {
            "en": "You've successfully left your family",
            "ar": "لقد قمت بالانسحاب بنجاح من الحساب العائلي",
            "el": "Έχεις φύγει με επιτυχία από την οικογένεια σου",
            "cn": "你已成功離開你的「家庭」了",
            "de": "You've successfully left your family"
        },
        "INVITATION_CANCELLED": {
            "en": "You've successfully declined the invitation to join this family",
            "ar": "تم رفض الدعوة بنجاح للانضمام إلى الحساب العائلي",
            "el": "Έχεις απορρίψει επιτυχώς την πρόσκληση για συμμετοχή σε αυτήν την οικογένεια",
            "cn": "你已成功拒絕了加入「家庭」的邀請",
            "de": "You've successfully declined the invitation to join this family"
        },
        "MEET_YOUR_FAMILY_TITLE": {
            "en": "MEET YOUR FAMILY",
            "ar": "تعرَّف على أفراد الحساب العائلي ",
            "el": "Γνώρισε την οικογένεια σου",
            "cn": "跟家人見面吧",
            "de": "MEET YOUR FAMILY"
        },
        "WELCOME_MESSGAE": {
            "en": "Welcome to {name}'s Family",
            "ar": "مرحباً بك في الحساب العائلي لـ {name}",
            "el": "Καλώς ήρθες στην οικογένεια του/της {name}",
            "cn": "歡迎加入{name}的大家庭",
            "de": "Welcome to {name}'s Family"
        },
        "SUCCESS_INVITATION": {
            "en": "Your invite has been successfully sent.",
            "ar": "تم إرسال دعوتك بنجاح.",
            "el": "Η πρόσκληση σου έχει σταλεί με επιτυχία.",
            "cn": "你的邀請已成功發送。",
            "de": "Your invite has been successfully sent."
        },
        "MEMBER_NOT_ALLOWED": {
            "en": "Sorry, {name} has started their own ENTERTAINER family.",
            "ar": "عذراً، لدى {name} حساب عائلي آخر من إنترتينر.",
            "el": "Λυπούμαστε, ο/η [name] έχει ξεκινήσει τη δική του οικογένεια ENTERTAINER.",
            "cn": "對不起，{name} 已經開設了他自己的家庭共享帳戶。",
            "de": "Sorry, {name} has started their own ENTERTAINER family."
        },
        "JOIN_FAMILY_TITLE": {
            "en": "JOIN FAMILY",
            "ar": "الانضمام للحساب العائلي",
            "el": "Συνδέσου στην Οικογένεια ",
            "cn": "加入此家庭",
            "de": "JOIN FAMILY"
        },
        "FAMILY_ACCOUNT_EXPIRED": {
            "en": "Your family account has expired. Get our new product and share the love.",
            "ar": "- لقد انتهت صلاحية حسابك العائلي. احصل على منتج جديد وابدأ بالمشاركة.",
            "cn": "你的家庭帳戶已經無效，立即購買產品繼續和家人分享優惠",
            "el": "Ο οικογενειακός σας λογαριασμός έχει λήξει. Πάρτε το νέο μας προϊόν και μοιραστείτε την αγάπη."
        },
        "FAMILY_EXPIRED": {
            "en": "None of your family members can use your ENTERTAINER just yet.",
            "ar": "- لا يمكن لأي من أفراد عائلتك استخدام حسابك من إنترتينر حتى الآن. ",
            "cn": "暫時沒有任何家庭成員可以使用ENTERTAINER。",
            "el": "Κανένα από τα μέλη της οικογένειάς σας δεν μπορεί να χρησιμοποιήσει το ENTERTAINER σας ακόμα."
        },
        "REMOVED_FROM_FAMILY": {
            "en": "REMOVE FROM FAMILY",
            "ar": "الحذف من الحساب العائلي ",
            "cn": "於家庭共享帳戶中移除",
            "el": "Αφαιρέστε από την Οικογένεια"
        },
        "BUTTON_RESEND_TITLE": {
            "en": "RESEND INVITATION",
            "ar": "- إعادة إرسال الدعوة ",
            "cn": "重新發送邀請",
            "el": "Ξαναστείλτε Πρόσκληση"
        },
        "BUTTON_CANCEL_TITLE": {
            "en": "CANCEL INVITATION",
            "ar": "- إلغاء الدعوة ",
            "cn": "取消邀請",
            "el": "Ακύρωση Πρόσκλησης"
        },
        "BUTTON_CLOSE_FAMILY_TITLE": {
            "en": "CLOSE FAMILY ACCOUNT",
            "ar": "إغلاق الحساب العائلي ",
            "cn": "關閉家庭共享帳戶",
            "el": "Κλείσιμο Οικογενειακού Λογαριασμού"
        },
        "BUTTON_LEAVE_FAMILY_TITLE": {
            "en": "LEAVE FAMILY",
            "ar": "الانسحاب من الحساب العائلي ",
            "cn": "離開家庭共享帳戶",
            "el": "Αφήστε την Οικογένεια"
        },
        "BUTTON_BUY_NOW_TITLE": {
            "en": "BUY NOW",
            "ar": "الشراء الآن",
            "el": "Αγόρασε τώρα ",
            "cn": "立即購買",
            "de": "BUY NOW"
        },
        "OFFER_OUT_OF_CUSTOM_CODES": {
            "en": "No discount codes remaining, please contact your Entertainer Account Manager.",
            "ar": "No discount codes remaining, please contact your Entertainer Account Manager.",
            "cn": "No discount codes remaining, please contact your Entertainer Account Manager.",
            "el": "No discount codes remaining, please contact your Entertainer Account Manager.",
            "de": "No discount codes remaining, please contact your Entertainer Account Manager."
        },
        "offer_is_not_redeemable": {
            "en": "This offer is no longer available.",
            "ar": "هذا العرض لم يعد سارياً",
            "el": "Αυτή η προσφορά δεν είναι πιά διαθέσιμη",
            "cn": "此優惠已無效",
            "de": "This offer is no longer available."
        },
        "OFFER_RESTRICTION_MESSAGE": {
            "en": "The offer is valid only at the specified day and time",
            "ar": "العرض صالح في اليوم والموعد المُحدّدين",
            "el": "Η προσφορά ισχύει μόνο για τη συγκεκριμένη ημέρα και ώρα",
            "cn": "優惠有效於指定日期和時間",
            "de": "The offer is valid only at the specified day and time"
        },
        "OOPS_TEXT": {
            "en": "Oops!",
            "ar": "Oops!",
            "el": "Oops!",
            "cn": "Oops!",
            "de": "Oops!"
        },
        "PING_TO_MESSAGE": {
            'en': 'Pinged to',
            'ar': 'عرض مرسل إلى',
            'cn': '轉贈至',
            'el': 'Pinged to'
        },
        "PING_BY_MESSAGE": {
            'en': 'Pinged by',
            'ar': 'المرسل',
            'cn': '轉贈者',
            'el': 'Pinged από'
        },
        'USER_INACTIVE': {
            'en': 'User inactive',
            'de': 'Benutzer inaktiv',
            'ar': 'المستخدم غير نشط',
            'cn': '用户不活跃'
        }
    }
