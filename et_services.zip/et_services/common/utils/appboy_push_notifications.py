# -*- coding: utf-8 -*-
"""
App boy Push Notification manager.
"""
import json

import requests
from flask import current_app


def send_user_data(user_data):
    """
    Sends the notification to user
    """
    try:
        AAP_GROUP_ID = current_app.config.get('BRAZE_API_KEY')
        request_url = current_app.config.get('APPBOY_END_EXTEND_NOTIFICATION_URL')

        # Instantiate your attributes array using your previously
        # defined user maps.
        attributes = [user_data]

        # Organize the data to send to the API as another map
        # comprised of your previously defined variables.
        post_data = {'app_group_id': AAP_GROUP_ID, 'attributes': attributes}
        headers = {"Content-Type": "application/json"}
        # Create the context for the request
        push_notification = requests.post(url=request_url, headers=headers, data=json.dumps(post_data))
        if push_notification.ok:
            return {
                "message": "Push notification sent successfully.",
                "success": True,
                "status_code": push_notification.status_code
            }
        else:
            return {
                "message": push_notification.json().get('message', push_notification.json()),
                "success": False,
                "status_code": push_notification.status_code
            }
    except Exception as error:
        return {
            "message": str(error),
            "success": False,
            "status_code": 500
        }
