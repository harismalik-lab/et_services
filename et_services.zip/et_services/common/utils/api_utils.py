"""
This module contains api utility functions
"""
import base64
import datetime
import importlib
import json
import logging
import math
import os
import random
import re
import urllib.parse
import uuid
from ast import parse
from functools import cmp_to_key
from json import JSONDecodeError
from logging.handlers import TimedRotatingFileHandler

import requests
from _operator import itemgetter
from Crypto.Cipher import AES
from dateutil import tz
from elasticapm.contrib.flask import ElasticAPM
from elasticapm.handlers.logging import LoggingHandler
from flask import current_app, g, request
from flask_caching import Cache
from requests import codes
from shapely.geometry import Point
from werkzeug.exceptions import InternalServerError

from ..constants import (ALL, ANALYTICS_CATEGORY_CODES_DICT,
                         ARABIC_LOCATION_IDS, BADGE_CHEERS_IMAGE_URL,
                         BADGE_DELIVERY_IMAGE_URL, BADGE_MONTHLY_IMAGE_URL,
                         BADGE_MORE_SA_IMAGE_URL, BADGE_NEW_IMAGE_URL,
                         BADGE_PINGED_IMAGE_URL, BODY, CANTONESE_LOCATION_IDS,
                         CATEGORY_API_NAME_BODY, CATEGORY_API_NAME_KIDS,
                         CATEGORY_API_NAME_LEISURE,
                         CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                         CATEGORY_API_NAME_RETAIL, CATEGORY_API_NAME_SERVICES,
                         CATEGORY_API_NAME_TRAVEL, CATEGORY_BADGES,
                         CATEGORY_NAME_TRAVEL, COLOR_BODY, COLOR_LEISURE,
                         COLOR_RESTAURANTS_AND_BARS, COLOR_RETAIL,
                         COLOR_SERVICES, COLOR_TRAVEL,
                         DEFAULT_OFFER_EXPIRY_HOURS,
                         DEFAULT_OFFER_EXPIRY_MINUTES,
                         DEFAULT_OFFER_EXPIRY_SECONDS, EN, ENT_COMPANY_TYPE,
                         ENT_COMPANY_TYPE_FULL, FEATURED_RIBBON_IMAGE,
                         GREEK_LOCATION_IDS, HAPPY_BIRTHDAY_END_RANGE_DAYS,
                         HAPPY_BIRTHDAY_START_RANGE_DAYS,
                         HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM,
                         HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO, KIDS, LEISURE,
                         LOCATION_TIME_ZONE_MAP, OFFER_TYPE_MONTHLY,
                         RESTAURANTS_AND_BARS, RETAIL, SERVICES,
                         SUPPORTED_LOCALES, TRAVEL, TYPE_DEFAULT, TYPE_MEMBER,
                         ANALYTICS_CATEGORY_CODE_Body,
                         ANALYTICS_CATEGORY_CODE_Leisure,
                         ANALYTICS_CATEGORY_CODE_RestaurantsandBars,
                         ANALYTICS_CATEGORY_CODE_Retail,
                         ANALYTICS_CATEGORY_CODE_Services,
                         ANALYTICS_CATEGORY_CODE_Travel)
from ..models.api_configuration import ApiConfiguration
from ..models.category_home_screen_configurations import \
    CategoryHomeScreenConfiguration
from ..models.ent_customer_profile import EntCustomerProfile
from ..models.location_features import LocationFeature
from ..models.offer import Offer
from ..models.redemption import Redemption
from ..models.wl_invoice_header import WlInvoiceHeader
from ..utils.translation_manager import TranslationManager
from .new_relic_logger import NewRelicLogHandler

cache = g.cache

ICON_URL_BASE = "https://s3.amazonaws.com/entertainer-app-assets/icons/"
LOCKED_OUTLET_GOLDEN_IMAGE_URL = "{icon_base}locked_outlet_golden.png".format(icon_base=ICON_URL_BASE)
LOCKED_OUTLET_GREY_IMAGE_URL = "{icon_base}locked_outlet_grey.png".format(icon_base=ICON_URL_BASE)
BADGE_URL_DELIVERY = "https://s3.amazonaws.com/entertainer-app-assets/icons/badge_delivery.png"
BADGE_DELIVERY_COLOR = 'f47421'
BADGE_URL_DELIVERY_OFFERS_BORDER_LESS = "https://entertainer-app-assets.s3.amazonaws.com/ic_online_offers.png"


def get_function_from_string(function_string='', seperator='.'):
    function_info = {}
    if function_string:
        mod_name, func_name = function_string.rsplit(seperator, 1)
        mod = importlib.import_module(mod_name)
        func = getattr(mod, func_name)
        function_info['func_name'] = func_name
        function_info['func'] = func
    return function_info


def get_logger(filename='', name=''):
    """
    Return a logger with the specified name, creating it if necessary. If apm error logging is on then it also
    sends log to apm server otherwise it logs them in file.
    :param filename: log file name
    :param name: logger name
    :return:
    """
    parent_directory = os.path.dirname(filename)
    parent_directory = os.path.join(current_app.config.get('LOGS_PATH'), parent_directory)
    # create api log folders if not exist example outlet_api, country_api
    if parent_directory and not os.path.exists(parent_directory):
        os.makedirs(parent_directory)
    log_file_name = os.path.join(current_app.config.get('LOGS_PATH'), filename)
    logging_level = logging.ERROR
    formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s %(message)s')
    # if apm error logging is on then initialize flask elastic apm logging
    logger = logging.getLogger(name)  # or pass string to give it a name
    if current_app.config.get('GENERATE_APM_ERROR_LOGS', False):
        apm = ElasticAPM(current_app)
        handler = LoggingHandler(client=apm.client)
        logger.addHandler(handler)
    if current_app.config.get('GENERATE_NEW_RELIC_ERROR_LOGS', False):
        from newrelic.agent import NewRelicContextFormatter
        new_relic_handler = NewRelicLogHandler()
        new_relic_formatter = NewRelicContextFormatter()
        new_relic_handler.setFormatter(new_relic_formatter)
        logger.addHandler(new_relic_handler)
    # set TimedRotatingFileHandler for root, use very short interval for this example, typical
    # 'when' would be 'midnight' and no explicit interval
    handler = TimedRotatingFileHandler(log_file_name, when='midnight', backupCount=10)
    handler.suffix = "%Y-%m-%d"
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging_level)
    return logger


def get_locale(locale):
    """
    Returns valid locale
    :param str locale: passed locale
    :rtype: str
    """
    if locale in SUPPORTED_LOCALES:
        return locale
    return EN


def get_locale_for_messaging(locale):
    if locale in SUPPORTED_LOCALES:
        return locale


def get_locale_location_id(locale, location_id=0):
    """
    Gets location id on base of language
    :param str locale: language
    :param int location_id: location id
    :rtype: str
    """
    default_locale_english = 'en'
    try:
        location_id = int(location_id)
        if locale in SUPPORTED_LOCALES:
            if location_id > 0:
                if locale == 'ar' and location_id in ARABIC_LOCATION_IDS:
                    return locale
                elif locale == 'el' and location_id in GREEK_LOCATION_IDS:
                    return locale
                elif locale == 'cn' and location_id in CANTONESE_LOCATION_IDS:
                    return locale
                else:
                    return default_locale_english
            return locale
    except (TypeError, ValueError):
        pass
    return default_locale_english


def validate_invoice_number(invoice, is_for_sign_up_or_sign_in, invoice_amount=-1):
    """
    Validates invoice
    :param WlInvoiceHeader invoice: Invoice Object
    :param bool is_for_sign_up_or_sign_in: check is user sign in or sign up
    :param int invoice_amount: invoice amount
    :rtype: int
    """
    if is_for_sign_up_or_sign_in:
        validation_status = WlInvoiceHeader.Invoice_Status_Invalid_Transaction_Type
    else:
        validation_status = WlInvoiceHeader.INVALID_STATUS
    if invoice:
        if invoice.user_id == 0:
            transaction_type_length = len(invoice.transaction_type.replace('-', ''))
            is_valid_transaction_type = False
            if is_for_sign_up_or_sign_in:
                if transaction_type_length == 1:
                    is_valid_transaction_type = True
            else:
                if transaction_type_length > 1:
                    is_valid_transaction_type = True
            if is_valid_transaction_type:
                if isinstance(invoice.invoice_date, datetime.datetime):
                    invoice_cutoff_date = datetime.datetime.now()
                    invoice_cutoff_date = invoice_cutoff_date - datetime.timedelta(
                        days=WlInvoiceHeader.Invoice_Valid_For_Past_X_Days + 1
                    )
                    if invoice.invoice_date > invoice_cutoff_date:
                        if invoice_amount > 0:
                            invoice_amount = int(invoice.transaction_total_price)
                            amount_to_validate = int(invoice_amount)
                            diff = invoice_amount - amount_to_validate
                            if 0 <= diff <= 1:
                                validation_status = WlInvoiceHeader.VALID_STATUS
                            else:
                                validation_status = WlInvoiceHeader.Invoice_Status_Wrong_Amount
                        else:
                            validation_status = WlInvoiceHeader.VALID_STATUS
                    else:
                        validation_status = WlInvoiceHeader.Invoice_Status_Outdated_Invoice
            else:
                validation_status = WlInvoiceHeader.Invoice_Status_Invalid_Transaction_Type
        else:
            validation_status = WlInvoiceHeader.ALREADY_USED_STATUS
    return validation_status


def get_invoice_validation_message(validation_status, locale, is_user_upgraded=False):
    """
    Get invoice validation message
    :param validation_status: Validation status of invoice
    :param locale: Response language
    :param is_user_upgraded: Bool flag for user upgraded
    :return: validation status message
    """
    message = ""
    if validation_status:
        if validation_status == WlInvoiceHeader.VALID_STATUS:
            if is_user_upgraded:
                message = TranslationManager.get_translation(
                    TranslationManager.invoice_validation_success_message_upgraded,
                    locale
                )
            else:
                message = TranslationManager.get_translation(
                    TranslationManager.invoice_validation_success_message,
                    locale
                )
        elif validation_status == WlInvoiceHeader.ALREADY_USED_STATUS:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_already_linked_message,
                locale
            )
        elif validation_status == WlInvoiceHeader.Invoice_Status_Valid_Linking_Through_Profile_Only:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_invalid_message,
                locale
            )
        elif validation_status == WlInvoiceHeader.Invoice_Status_Valid_For_Sign_In_Sign_Up_Only:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_invalid_message,
                locale
            )
        elif validation_status == WlInvoiceHeader.Invoice_Status_Outdated_Invoice:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_outdated_invoice,
                locale
            )
        elif validation_status == WlInvoiceHeader.Invoice_Status_Invalid_Transaction_Type:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_invalid_code_message,
                locale
            )
        elif validation_status == WlInvoiceHeader.Invoice_Status_Wrong_Amount:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_invalid_message_wrong_amount,
                locale
            )
        else:
            message = TranslationManager.get_translation(
                TranslationManager.invoice_validation_invalid_message,
                locale
            )
    return message


def get_user_group_based_on_spend(emax_user_group, user_spend):
    """
    Gets user group based on spend
    :param int emax_user_group: emax user group
    :param int user_spend: user spend
    :rtype: int
    """
    calculated_user_group = 1
    if user_spend <= 3900:
        calculated_user_group = 1
    elif 4000 <= user_spend <= 9999:
        calculated_user_group = 2
    elif user_spend >= 10000:
        calculated_user_group = 3
    return max(calculated_user_group, int(emax_user_group))


def generate_unique_id(prefix, length):
    """
    Generate unique id
    """
    prefix = prefix + str(uuid.uuid4())[:length]
    return ''.join(random.choice(prefix) for _ in range(length))


def bool_validator(_bool):
    """
    Boolean formatter
    :param int|str|bool _bool: flag
    """
    return _bool in ['True', 'true', True, 1, '1']


def calculate_offer_redeemability_for_customer(
        session_data,
        offer,
        redemption_quantities,
        purchasable_product_ids=None):
    """
    Calculate offer redeemability for customer
    :param dict session_data: Session data
    :param dict offer: offer
    :param dict redemption_quantities: redemption quantities
    :param list purchasable_product_ids: purchasable product ids
    :rtype: dict
    """
    from ..models.offer_wl_active import OfferWlActive
    if purchasable_product_ids is None:
        purchasable_product_ids = []
    product_ids = session_data['product_ids']
    is_redeemable = False
    if not session_data.get('is_user_logged_in'):
        return {
            'is_redeemable': is_redeemable,
            'redeemability': Redemption.NOT_REDEEMABLE,
            'is_purchased': False,
            'is_offer_valid_in_future': False,
            'is_offer_expired': False,
            'quantity_redeemable': 0,
            'quantity_redeemed': 0,
            'quantity_not_redeemable': offer['quantity'],
            'is_show_purchase_button': False
        }

    current_datetime = datetime.datetime.now()
    date_from = current_datetime + datetime.timedelta(hours=Redemption.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM)
    date_to = current_datetime + datetime.timedelta(hours=Redemption.HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)

    num_purchased = 0
    num_redemptions = 0

    is_offer_valid_in_future = False
    is_offer_expired = False
    allowed_onboarding = False

    offer['quantity_display'] = offer.get('quantity')

    is_purchasable = offer['product_id'] in purchasable_product_ids
    is_purchased = offer['product_id'] in product_ids

    # Need to check
    if redemption_quantities:
        check = "{}_{}".format(offer.get('id'), offer.get('product_id'))
        if redemption_quantities.get(check):
            num_redemptions = redemption_quantities.get(check)
        else:
            num_redemptions = 0

    if offer['valid_from_date'] > date_from:
        is_offer_valid_in_future = True

    if offer['expiration_date'] < date_to:
        is_offer_expired = True

    if session_data.get('non_depletable_offers_app') and is_purchasable:
        num_redemptions = 0
        num_purchased = 1
    else:
        num_purchased += int((product_ids.count(offer.get('product_id', 0)) *
                              int(offer.get('quantity', 0))))

    if offer['type'] == OfferWlActive.TYPE_MEMBER and is_purchased:
        num_purchased = int(num_redemptions) + 1

    if (
            not is_offer_valid_in_future and
            not is_offer_expired and
            int(num_purchased) > int(num_redemptions) and
            int(num_purchased) > 0
    ):
        is_redeemable = True
        if offer['type'] == OfferWlActive.TYPE_DEFAULT:
            redeemability_value = Redemption.REDEEMABLE
        else:
            redeemability_value = Redemption.REUSABLE

    elif int(num_redemptions) >= int(num_purchased) > 0:
        redeemability_value = Redemption.REDEEMED
    else:
        redeemability_value = Redemption.NOT_REDEEMABLE

    is_show_purchase_button = False

    redeemability = {
        'is_redeemable': is_redeemable,
        'redeemability': redeemability_value,
        'is_purchased': is_purchased,
        'is_offer_valid_in_future': is_offer_valid_in_future,
        'is_offer_expired': is_offer_expired,
        'quantity_redeemable': offer.get('quantity') if redeemability_value == Redemption.REUSABLE else
        max(0, int(num_purchased) - int(num_redemptions)),
        'quantity_redeemed': 0 if redeemability_value == Redemption.REUSABLE else num_redemptions,
        'quantity_not_redeemable': offer.get('quantity') if not is_purchased and not allowed_onboarding else 0,
        'is_show_purchase_button': is_show_purchase_button
    }
    return redeemability


def get_analytics_codes_against_categories(categories):
    """
    Gets analytics codes against given categories
    """
    codes = []
    for category in categories:
        value_against_category = ANALYTICS_CATEGORY_CODES_DICT.get(category.lower())
        if value_against_category:
            codes.append(value_against_category)
    return ','.join(codes)


def get_analytics_category_code(category):
    """
    :returns corresponding category code
    """
    if category == CATEGORY_API_NAME_BODY:
        return ANALYTICS_CATEGORY_CODE_Body

    if category == CATEGORY_API_NAME_LEISURE:
        return ANALYTICS_CATEGORY_CODE_Leisure

    if category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
        return ANALYTICS_CATEGORY_CODE_RestaurantsandBars

    if category == CATEGORY_API_NAME_RETAIL:
        return ANALYTICS_CATEGORY_CODE_Retail

    if category == CATEGORY_API_NAME_SERVICES:
        return ANALYTICS_CATEGORY_CODE_Services

    if category == CATEGORY_API_NAME_TRAVEL:
        return ANALYTICS_CATEGORY_CODE_Travel

    return ''


def get_category_codes_for_analytics(categories):
    """
    Gets and reformat category codes for analytics
    :param list categories: Categories
    :rtype: str
    """
    categories_analytics = []
    if not categories:
        return categories_analytics
    for category in categories:
        analytics_category_code = get_analytics_category_code(category)
        if analytics_category_code:
            categories_analytics.append(analytics_category_code)
    return ','.join(categories_analytics)


def get_configured_sku_by_company(company):
    company = company.lower()
    skus = {
        'gem': [
            'L18DBGEPE',
            'L19DBGEPE',
            'L18ADGEPE',
            'L19ADGEPE',
            'L18TRGEPE',
            'L19TRGEPE',
            'L18DBGESE',
            'L19DBGESE',
            'L18ADGESE',
            'L19ADGESE',
            'L18TRGESE',
            'L19TRGESE'
        ]
    }
    return skus.get(company, [])


def compare(a, b):
    """
    Compare 2 values
    """
    try:
        return (a > b) - (a < b)
    except TypeError:
        return -1


def multi_key_sort(items, columns, functions={}, getter=itemgetter):
    """
    Sort a list of dictionary objects or objects by multiple keys bidirectionally.
    Keyword Arguments:
    items -- A list of dictionary objects or objects
    columns -- A list of column names to sort by. Use -column to sort in descending order
    functions -- A Dictionary of Column Name -> Functions to normalize or process each column value
    getter -- Default "getter" if column function does not exist
              operator.itemgetter for Dictionaries
              operator.attrgetter for Objects
    usage: https://gist.github.com/malero/418204
    """
    comparers = []
    for col in columns:
        column = col[1:] if col.startswith('-') else col
        if column not in functions:
            functions[column] = getter(column)
        comparers.append((functions[column], 1 if column == col else -1))

    def comparer(left, right):
        for func, polarity in comparers:
            result = compare(func(left), func(right))
            if result:
                return polarity * result
        else:
            return 0

    return sorted(items, key=cmp_to_key(comparer))


def row2dict(row):
    """
    This method converts sql model class instance to python dict object.
    :param row: Sqlalchemy model class instance.
    """
    data = {}
    for column in row.__table__.columns:
        data[column.name] = getattr(row, column.name)

    return data


def category_title_to_lower(api_name):
    """
    Gets the category title in lower caps.
    :rtype: str
    """
    categories_title_mapping = {
        CATEGORY_API_NAME_BODY: BODY,
        CATEGORY_API_NAME_KIDS: KIDS,
        CATEGORY_API_NAME_LEISURE: LEISURE,
        CATEGORY_API_NAME_RESTAURANTS_AND_BARS: RESTAURANTS_AND_BARS,
        CATEGORY_API_NAME_RETAIL: RETAIL,
        CATEGORY_API_NAME_SERVICES: SERVICES,
        CATEGORY_API_NAME_TRAVEL: TRAVEL
    }
    return categories_title_mapping.get(api_name, None)


def get_formatted_date(date, fmt=None):
    if isinstance(date, datetime.datetime):
        if fmt:
            date = datetime.datetime.strftime(date, fmt)
        else:
            date = datetime.datetime.strftime(date, '%Y-%m-%dT%H:%M:%S+0400')
    if isinstance(date, datetime.date):
        if fmt:
            date = datetime.date.strftime(date, fmt)
        else:
            date = datetime.date.strftime(date, '%Y-%m-%d')
    return date


def get_api_configurations(company, environment, config_group=None):
    """
    get api configurations and set its key value
    :param str config_group: Config Group
    :param str company: Company
    :param str environment: App Env
    :return: configurations
    :rtype: dict
    """
    # getting api_configurations
    configs = {}
    api_configs = ApiConfiguration.get_configuration_by_company(company, environment, config_group)
    if api_configs:
        # creating a new dict by setting config_key as dict key and
        # config_value as value for its corresponding key
        for config in api_configs:
            if config.config_value == 'true':
                configs[config.config_key] = True
            elif config.config_value == 'false':
                configs[config.config_key] = False
            else:
                configs[config.config_key] = config.config_value
    if company.startswith('entertainer'):
        configs['company_type'] = ENT_COMPANY_TYPE
    else:
        configs['company_type'] = company

    return configs


def get_category_message_key(category):
    category_key = re.sub(r"[^A-Za-z0-9\-]", " ", category)
    category_key = re.sub(" +", "_", category_key.lower())
    return category_key


def pkcs7_padding(b_string, k=16):
    """
    Pad an input byte string according to PKCS#7
    """
    length = len(b_string)
    val = k - (length % k)
    return b_string + bytearray([val] * val)


def convert_api_config_value_to_list(config_value: str):
    """
    converts comma separated config value str to list
    :param config_value:
    :return: list of config values
    """
    return [value.strip() for value in config_value.split(",")]


def make_to_two_decimal(number):
    """
    Make decimal number to two decimal points

    :param float number: number to convert
    return float
    """
    if number:
        number = float(number)
        return '{:0.2f}'.format(number)
    else:
        return '0.00'


def generic_boolean_conversion(instance_value):
    """
    Converts the bit | int | str | byte to boolean
    """
    if isinstance(instance_value, int):
        return bool(instance_value)
    elif isinstance(instance_value, str) and instance_value.isdigit():
        return bool(int(instance_value))
    elif isinstance(instance_value, bytearray):
        return bool(int(instance_value))


def encode_params(key, salt, mode, encoded_params):
    """
    Decodes params
    :param str mode: Decryption mode
    :param str key: Decryption key
    :param str salt: 16 bit salt
    :param byte encoded_params: Encoded params
    :rtype: str
    """
    encoded_params = pkcs7_padding(encoded_params, 16)
    aes = AES.new(key, mode=mode, IV=salt)
    decrypted_str = aes.encrypt(encoded_params)
    return base64.b64encode(decrypted_str)


def calculate_distance(lat1, lng1, lat2, lng2, unit='KM'):
    """
    Calculates distance between two sets of lat and lng and returns result in given unit.
    Default unit: Kilometers.

    Possible values for unit: KM (Kilometers), M (Metres), MI (Miles).

    :rtype: int
    """
    distance = math.acos(
        math.cos(math.radians(90.0 - lat1)) * math.cos(math.radians(90.0 - lat2)) +
        math.sin(math.radians(90.0 - lat1)) * math.sin(math.radians(90.0 - lat2)) *
        math.cos(math.radians((lng1 - lng2)))
    ) * 6371.0 * 1000.0

    if unit == 'KM':
        return round(distance)
    elif unit == 'M':
        return round(distance * 1000)
    elif unit == 'MI':
        return round(distance * 0.621371)


def decode_params(key, salt, mode, encoded_params, add_padding=True):
    """
    Decodes params
    :param bool add_padding: Add padding or not
    :param str mode: Decryption mode
    :param str key: Decryption key
    :param str salt: 16 bit salt
    :param byte encoded_params: Encoded params
    :rtype: str
    """
    aes = AES.new(key, mode=mode, IV=salt)
    if add_padding:
        decrypted_str = aes.decrypt(pkcs7_padding(encoded_params, 16))
        decrypted_str = decrypted_str.decode(errors='ignore')
        if '}' in decrypted_str:
            found = decrypted_str.rfind('\n}') + 2
            if found < 2:
                found = decrypted_str.rfind('"}') + 2
            decrypted_str = decrypted_str[:found]
        else:
            found = decrypted_str.find('\n')
            if found > 0:
                decrypted_str = decrypted_str[0:found]
    else:
        decrypted_str = aes.decrypt(encoded_params)
        decrypted_str = decrypted_str.decode(errors='ignore')
    return decrypted_str


def list_to_str_tuple(characters_list=[]):
    return "({})".format(str(characters_list).strip('[]'))


def decrypt_params():
    """
    Decrypts parameters of incoming request.
    """
    key = current_app.config['PARAM_ENCRYPTION_KEY']
    salt = current_app.config['PARAM_ENCRYPTION_SALT']
    mode = current_app.config['PARAM_ENCRYPTION_MODE']
    data = ""
    try:
        if request.method.lower() != 'get':
            if request.data:
                temp = request.data.decode()
                try:
                    data = json.loads(temp)
                    data = data.get('params')
                except JSONDecodeError:
                    parsed_qs = urllib.parse.parse_qs(temp)
                    if parsed_qs.get('params'):
                        data = parsed_qs['params'][0]
            elif request.form:
                data = request.form.get('params')
            if data:
                request.original_data = data
                data = data.translate(str.maketrans('-_,', '+/='))
                param = base64.b64decode(data)
                decrypted_str = decode_params(key, salt, mode, param)
                request.data = decrypted_str.encode()
                # request.form = json.loads(decrypted_str)
                request.is_encoded = True
    except Exception as exception_occured:
        logger = get_logger(filename='logs/decryption_logs/decryption.log', name='decryption')
        logger.exception(
            "Error occurred while decrypting: {exception}\n url: {url}\n data:{data}".format(
                exception=exception_occured,
                url=request.full_path,
                data=request.data if request.data else request.form.to_dict()
            ),
            extra={'status_code': getattr(exception_occured, 'code', 500)}
        )
        for handler in logger.handlers[:]:
            if not current_app.config.get('GENERATE_APM_ERROR_LOGS', False):
                handler.stream.close()
            logger.removeHandler(handler)
        raise InternalServerError("Something went wrong")


def encrypt_params(data):
    """
    Encrypt parameters in response generated by the request.
    :param str data: Response generated by the API call.
    :return: The modified response of the request.
    :rtype: dict
    """
    key = current_app.config['PARAM_ENCRYPTION_KEY']
    salt = current_app.config['PARAM_ENCRYPTION_SALT']
    mode = current_app.config['PARAM_ENCRYPTION_MODE']
    data = encode_params(key, salt, mode, data)
    return data.decode(errors='ignore')


def sort_categories(categories):
    """
    Sort categories
    :param categories: categories types
    :return: categories list
    """
    categories_array = []

    if CATEGORY_API_NAME_RESTAURANTS_AND_BARS in categories:
        categories_array.append(CATEGORY_API_NAME_RESTAURANTS_AND_BARS)

    if CATEGORY_API_NAME_BODY in categories:
        categories_array.append(CATEGORY_API_NAME_BODY)

    if CATEGORY_API_NAME_LEISURE in categories:
        categories_array.append(CATEGORY_API_NAME_LEISURE)

    if CATEGORY_API_NAME_RETAIL in categories:
        categories_array.append(CATEGORY_API_NAME_RETAIL)

    if CATEGORY_API_NAME_SERVICES in categories:
        categories_array.append(CATEGORY_API_NAME_SERVICES)

    if CATEGORY_API_NAME_TRAVEL in categories:
        categories_array.append(CATEGORY_API_NAME_TRAVEL)

    return categories_array


def parse_list(__categories, cuisine=False):
    _categories_processed = []
    try:
        _categories = __categories.split(';')
        for _category in _categories:
            if _category:
                _categories_processed.append(_category)
    except Exception:
        return []
    if cuisine:
        return _categories_processed
    _categories_processed = sort_categories(_categories_processed)
    return _categories_processed


def outlets_array_processing(outlets, category):
    hashed_outlets = {}
    merchant_fields = [
        'id', 'name', 'name_for_outlet', 'cuisine',
        'digital_section', 'ad_travel_country', 'ad_active_status',
        'logo_url', 'logo_small_url', 'photo_url', 'photo_small_url'
    ]

    for outlet_obj in outlets:
        outlet = outlet_obj._asdict()
        outlet['cuisines'] = parse_list(outlet['merchant_cuisines'], cuisine=True)
        outlet['categories'] = parse_list(category)

        merchant = {
            'merchant_categories_analytics': ANALYTICS_CATEGORY_CODES_DICT.get(
                category.lower(), ''
            )
        }
        for field in merchant_fields:
            merchant[field] = outlet['merchant_{}'.format(field)]
            del outlet['merchant_{}'.format(field)]

        if outlet.get('name') and 'Ritz-Carlton' not in outlet.get('name'):
            outlet_name_parts = outlet['name'].split('-')
            outlet['name'] = outlet_name_parts[-1].strip()
        merchant['name_for_outlet'] = merchant['name']
        outlet['merchant_name'] = merchant['name']
        merchant['category'] = category
        merchant['categories'] = outlet['categories']
        outlet['merchant'] = merchant
        outlet['distance'] = 0
        outlet['tripadvisor_id'] = str(outlet['tripadvisor_id'])
        hashed_outlets[outlet['id']] = outlet
    return outlets, hashed_outlets


@cache.memoize(timeout=3600)
def get_delivery_enabled_location_ids_against_company(company):
    """
    Returns tuple of location ids against company where delivery cashless is active.
    :rtype: list
    """
    return [location.location_id for location in LocationFeature.get_delivery_cashless_location_ids(company)]


@cache.memoize(timeout=3600)
def get_takeaways_enabled_location_ids_against_company(company):
    """
    Returns tuple of location ids against company where Takeaways is active.
    :rtype: list
    """
    return [location.location_id for location in LocationFeature.get_take_away_location_ids(company)]


@cache.memoize(timeout=3600)
def get_table_booking_enabled_location_ids_against_company(company):
    """
    Returns tuple of location ids against company where table booking is active.
    :rtype: list
    """
    return [location.location_id for location in LocationFeature.get_table_booking_location_ids(company)]


@cache.memoize(timeout=3600)
def get_dc_prospect_enabled_location_ids_against_company(company):
    """
    Returns tuple of location ids against company where DC prospect and DC is active.
    :rtype: list
    """
    return [location.location_id for location in LocationFeature.get_dc_enabled_prospect_location_ids(company)]


def get_geo_points_against_location_id(location_id):
    """
    Static mapping of geo-points against location ids.
    :param int location_id: id of location we need central GeoPoint for.
    """
    geo_point_mapping = {
        # Dubai
        1: Point(55.307709, 25.300579),
        # Abu Dhabi
        2: Point(54.362671, 24.534632),
        # Qatar
        9: Point(51.521652, 25.296234)

    }
    if location_id:
        return geo_point_mapping.get(location_id)
    return None


def get_current_time_of_location(location_id):
    """
    Return current native datetime as per location.

    :param int location_id: user selected location id
    :return datetime: native datetime obj
    """
    location_utc_offset = LOCATION_TIME_ZONE_MAP.get(location_id, 1)
    utc_offset = 'UTC{offset}'.format(offset=location_utc_offset)
    location_current_time = datetime.datetime.now(tz.gettz(utc_offset))
    # convert timezone aware datetime to native datetime because in our app
    # we are using native datetime at all places
    location_current_time = location_current_time.replace(tzinfo=None)
    return location_current_time


def convert_timedelta_to_datetime(timedelta, location_current_time):
    """
    Convert timedelta object to datetime obj w.r.t user selected location.

    Problem:
        dateutil.parser.parse convert time string to datetime obj. date will be server/dubai date.
        qatar merchant delivery time in dm_delivery_timings is 10pm - 11:59pm.
        it means merchant will be online at 10pm - 11:59pm qatar time and 11pm-12:59am server/dubai time.
        Let assume that current date is 25 November 2019.
        logically time slot will be ===> 2019-11-25 23:00:00 -  2019-11-26 00:59:00
        but dateutil.parser.parse gives following time slot
            1. 2019-11-25 23:00:00 -  2019-11-26 00:59:00 (before dubai next day, qatar and dubai date are same)
            2. 2019-11-26 23:00:00 -  2019-11-26 00:59:00 (after dubai next day, qatar and dubai date are different)
        second case is the issue in which parse add date of next day in start time.

    Solution:
        convert time string to datetime obj via dateutil.parser.parse
        after that replace day,month and year with day,month and year of :param location_current_time


    :param datetime.timedelta,str timedelta: datetime timedelta obj or time string
    :param datetime location_current_time: current time of user selected location
    :return datetime: native datetime obj as per user location
    """
    user_location_time = parse(str(timedelta)).replace(
        day=location_current_time.day, month=location_current_time.month, year=location_current_time.year
    )
    return user_location_time


def get_birthday_offer_validity_in_days(birth_date):
    """
    Returns number of days for which we have to show birthday offers.

    If birthday feature is enabled, we show birthday offers for 8 days before and 21 days after his birthday.

    :param date birth_date: date of birth to find birthday validity days against.
    :return: -1 if invalid, number of days for which we have to show offers for, if valid.
    :rtype: int
    """
    current_date = datetime.datetime.now().date()
    try:
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=birth_date.day
        )
    except ValueError:  # For 29th Feb on non leap year
        birthday_period = birth_date.replace(
            year=current_date.year,
            month=birth_date.month,
            day=28
        )
    birthday_start_period = birthday_period + datetime.timedelta(days=HAPPY_BIRTHDAY_START_RANGE_DAYS)
    birthday_end_period = birthday_period + datetime.timedelta(days=HAPPY_BIRTHDAY_END_RANGE_DAYS)
    if birthday_start_period <= current_date <= birthday_end_period:
        return (birthday_end_period - current_date).days
    return -1


def redeemed_quantities_for_customer(customer_id,
                                     primary_user_id=0,
                                     family_id=0,
                                     is_onboarding=False,
                                     offer_id=0,
                                     company=None,
                                     is_secondary_customer=False):
    """
    Gets redeemed quantities for a customer.

    :param int customer_id: id of customer.
    :param int primary_user_id: id of primary user.
    :param int family_id: id of family.
    :param bool is_onboarding: if customer is on-boarding.
    :param int offer_id: id/ids of offer if we want to get redeemed quantities for specific offers.
    :param str company: company of customer.
    :param bool is_secondary_customer: True if customer is not primary, else False.
    """
    from ..models.redemption import Redemption
    redemption_quantities = {}

    if is_secondary_customer:
        redemption_results = Redemption.get_birthday_redeemed_quantities_for_secondary_customer(
            customer_id=customer_id,
            is_onboarding=is_onboarding,
            offer_id=offer_id,
            company=company
        )
    else:
        redemption_results = Redemption.get_redeemed_quantities_for_customer(
            customer_id=customer_id,
            primary_user_id=primary_user_id,
            family_id=family_id,
            is_onboarding=is_onboarding,
            offer_id=offer_id,
            company=company
        )

    for redemption in redemption_results:
        redemption_quantities[redemption.offer_id] = int(redemption.qty)

    return redemption_quantities


def fix_expiration_date(date_):
    """
    Format the passed date's time to 12:00:00.
    :param (datetime, str) date_: date to format the time for.
    """
    if isinstance(date_, str):
        date_ = datetime.datetime.strptime(date_, '%Y-%m-%dT%H:%M:%S')
    return date_.replace(
        hour=DEFAULT_OFFER_EXPIRY_HOURS,
        minute=DEFAULT_OFFER_EXPIRY_MINUTES,
        second=DEFAULT_OFFER_EXPIRY_SECONDS
    )


@cache.memoize(3600)
def get_extended_trial_rules(rule_ids=None, location_id=None):
    """
    Cached method of getting extended trial rules from DB and format them as needed.

    :param list rule_ids: ids of specific rules to get from db. If not passed, all rules are processed.
    :param int location_id: id of location for which we are getting extended trial rules.
    :rtype: dict
    """
    from ..models.extended_trial_rules import ExtendedTrialRule

    extended_trial_rules_sql = ExtendedTrialRule.extended_trial_rules(extended_trail_group_ids=rule_ids)

    extended_trail_rules = []
    for rule in extended_trial_rules_sql:
        if rule.location_id == location_id:
            extended_trail_rules.append(rule)
        elif rule.category.lower() == TRAVEL and not rule.location_id:
            # As Travel doesn't have location id.
            extended_trail_rules.append(rule)
    rules = dict()
    rules['categories'] = []
    rules['category_info'] = {}
    rules['getaways_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_travel_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_cheers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_delivery_info'] = {'enabled': False, 'saving_estimates': []}
    rules['cashless_delivery_enabled_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_monthly_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_more_sa_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_merlin_offer_info'] = {'enabled': False, 'saving_estimates': []}
    rules['has_cinema_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_bonus_offers_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_johor_bahru_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_product_info'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fine_dining_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_family_product'] = {'enabled': False, 'saving_estimates': []}
    rules['is_core_fitness_product'] = {'enabled': False, 'saving_estimates': []}
    for rule in extended_trail_rules:
        category = ''
        if rule.category:
            category = rule.category

        rules['categories'].append(category)
        try:
            rules['category_info'][category]
        except KeyError:
            rules['category_info'][category] = dict()
            rules['category_info'][category]['saving_estimates'] = []
            rules['category_info'][category]['sub_rules'] = False
            rules['category_info'][category]['rules'] = dict()
            rules['category_info'][category]['rules']['is_more_sa'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_travel'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_cheers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_delivery'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['cashless_delivery_enabled'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_merlin_offer'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_monthly'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_bonus_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['has_cinema_offers'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fine_dining_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_family_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_core_fitness_product'] = {
                'enabled': False, 'saving_estimates': []
            }
            rules['category_info'][category]['rules']['is_johor_bahru'] = {
                'enabled': False, 'saving_estimates': []
            }
        rules['category_info'][category]['saving_estimates'].append(rule.max_savings_estimate_cap)

        if rule.enabled_cheer_offers:
            rules['is_cheers_info']['enabled'] = True
            rules['is_cheers_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_cheers']['enabled'] = True
            rules['category_info'][category]['rules']['is_cheers']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_delivery_offers:
            rules['is_delivery_info']['enabled'] = True
            rules['is_delivery_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_delivery']['enabled'] = True
            rules['category_info'][category]['rules']['is_delivery']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_monthly_offers:
            rules['is_monthly_info']['enabled'] = True
            rules['is_monthly_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_monthly']['enabled'] = True
            rules['category_info'][category]['rules']['is_monthly']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_more_offers:
            rules['is_more_sa_info']['enabled'] = True
            rules['is_more_sa_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_more_sa']['enabled'] = True
            rules['category_info'][category]['rules']['is_more_sa']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_merlin_offers:
            rules['is_merlin_offer_info']['enabled'] = True
            rules['is_merlin_offer_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['enabled'] = True
            rules['category_info'][category]['rules']['is_merlin_offer']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_cinema_offers:
            rules['has_cinema_offers_info']['enabled'] = True
            rules['has_cinema_offers_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['enabled'] = True
            rules['category_info'][category]['rules']['has_cinema_offers']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_bonus_offers:
            rules['is_bonus_offers_info']['enabled'] = True
            rules['is_bonus_offers_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['enabled'] = True
            rules['category_info'][category]['rules']['is_bonus_offers']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_johor_baru_offers:
            rules['is_johor_bahru_info']['enabled'] = True
            rules['is_johor_bahru_info']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['enabled'] = True
            rules['category_info'][category]['rules']['is_johor_bahru']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_core_product_fine_dining_offers:
            rules['is_core_fine_dining_product']['enabled'] = True
            rules['is_core_fine_dining_product']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fine_dining_product']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_core_product_family_offers:
            rules['is_core_family_product']['enabled'] = True
            rules['is_core_family_product']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_family_product']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
        if rule.enabled_core_product_fitness_offers:
            rules['is_core_fitness_product']['enabled'] = True
            rules['is_core_fitness_product']['saving_estimates'].append(rule.max_savings_estimate_cap)
            rules['category_info'][category]['sub_rules'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['enabled'] = True
            rules['category_info'][category]['rules']['is_core_fitness_product']['saving_estimates'].append(
                rule.max_savings_estimate_cap
            )
    return rules


def rule_engine(category='', offer={}, rules={}, rule_key=None):
    """
    Rule engine for trail extended based on category and saving estimate

    :param str category: name of category to get rules of.
    :param dict offer: offer key, value hash-map.
    :param dict rules: rules key, value hash-map.
    :param str rule_key: key of rules dictionary to get specific category rules.
    :rtype: bool
    """
    rule_passed = False
    offer_estimate = offer.get('savings_estimate', 0)
    category_rules = rules.get('category_info', {}).get(category, [])
    if rule_key:
        category_rules = rules.get(rule_key, {})
    category_max_saving_estimate = max(category_rules.get('saving_estimates', []), default=0)
    if (
            offer_estimate and
            category_max_saving_estimate and
            offer_estimate <= category_max_saving_estimate
    ):
        if category_rules.get('sub_rules'):
            for single_rule in category_rules.get('rules', {}).keys():
                if (
                        category_rules.get('rules', {}).get(single_rule, {}).get('enabled', False) and
                        offer.get(single_rule)
                ):
                    rule_max_saving_estimate = max(
                        category_rules.get('rules', {}).get(single_rule).get('saving_estimates', []), default=0
                    )
                    if offer_estimate <= rule_max_saving_estimate:
                        rule_passed = True
                        break
        elif category:
            rule_passed = False
    return rule_passed


def offer_redeemability_for_extended_trial(category=None, offer=None, rules=None):
    """
    Check offer redeemability based on rules.
    :param str category: str
    :param dict offer: offer key, value hash-map.
    :param dict rules: rules key, value hash-map.
    :rtype: bool
    """
    other_conditions = False
    if offer and rules:
        if category is None:
            category = ''
        # checking rule passed for specific category
        if category in rules.get('categories', []):
            other_conditions = rule_engine(category=category, offer=offer, rules=rules)
        # # checking rule passed without category
        # if not other_conditions:
        #     other_conditions = self.rule_engine(category='', offer=offer, rules=rules)
    return other_conditions


def calculate_offer_redeemability_for_customer_details(
        offer,
        savings_estimate,
        category,
        customer,
        location_id,
        shared_count_sent,
        redemptions_quantities=0,
        shared_offer_receive=0,
        shared_count_receive=0,
        top_up_offer=False,
        top_up_count=0,
        is_user_onboard=False,
        offer_redeemability='redeemable',
        invoked_by="Outlet_Controller",
        shared_redemptions_count_records={},
        customer_redemptions_records={},
        member_group=0,
        shared_offers_received_family=list(),
        is_active_family_member=False,
        primary_user_id=0,
        personal_shared_redemptions_count_records={},
        personal_shared_count_receive=0,
        rules={}
):
    """
    Calculates offer redeemability.

    :param dict offer: offer whose redeemability we need to check.
    :param int savings_estimate: estimate of how much the customer has saved.
    :param str category: category the offer belongs to.
    :param dict customer: key-value hash-map containing customer details.
    :param int location_id: location id of customer.
    :param int shared_count_sent: number of offers the customer has shared.
    :param dict redemptions_quantities: number of redemptions the customer has made.
    :param list shared_offer_receive: offers the customer has received.
    :param int shared_count_receive: number of offers the customer has received.
    :param bool top_up_offer: if the offer is a top-up offer.
    :param int top_up_count: count of top up offers. (not used)
    :param bool is_user_onboard: if the customer is on board or still on trial. (not used)
    :param str offer_redeemability: redeemability text. (not used)
    :param str invoked_by: where was the function invoked by.
    :param dict shared_redemptions_count_records: all shared offers' redemptions hash-map.
    :param dict customer_redemptions_records: all customer offers' redemptions hash-map.
    :param int member_group: member status of customer.
    :param list shared_offers_received_family: shared offers received by family.
    :param bool is_active_family_member: if the customer is a member.
    :param int primary_user_id: id of primary user. (not used)
    :param dict personal_shared_redemptions_count_records: all personal shared offers' redemptions hash-map.
    :param int personal_shared_count_receive: count of all personal shared offers count.
    :param dict rules: rules by which we need to calculate redeemability.
    :rtype: dict
    """
    from common.models.ent_customer_profile import EntCustomerProfile

    redeemability_value = Redemption.NOT_REDEEMABLE
    if not customer:
        return {
            'redeemability': redeemability_value,
            'times_redeemed': 0,
            'quantity_redeemable': 0,
            'quantity_purchased': 0,
            'is_purchased': False
        }
    num_purchased = 0
    now = datetime.datetime.now()
    date_from = now + datetime.timedelta(hours=HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM)
    date_to = now + datetime.timedelta(hours=HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO)

    if shared_offers_received_family:
        shared_redemptions_count = shared_redemptions_count_records.get(offer['id'], 0)
        shared_count_receive -= shared_redemptions_count
    if shared_offer_receive:
        shared_redemptions_count = personal_shared_redemptions_count_records.get(offer['id'], 0)
        personal_shared_count_receive -= shared_redemptions_count

    if isinstance(redemptions_quantities, dict):
        num_redemptions = 0
        if redemptions_quantities.get(offer['id'], None):
            num_redemptions = redemptions_quantities.get(offer['id'], 0)
    else:
        num_redemptions = customer_redemptions_records.get(offer['id'], 0)

    is_within_validity_period = False
    if offer['valid_from_date'] <= date_from and offer['expiration_date'] >= date_to:
        is_within_validity_period = True

    if shared_offers_received_family:
        num_purchased += shared_count_receive

    if shared_offer_receive:
        num_purchased += personal_shared_count_receive

    if shared_count_sent:
        num_purchased = num_purchased - shared_count_sent

    if offer.get('product_id'):
        num_purchased += customer['product_ids'].count(offer['product_id']) * offer['quantity']

    is_on_trial = customer.get('is_using_trial', False)
    is_using_trail_extended = False
    if customer.get('is_member_on_trial') and customer.get('is_using_extended_trial'):
        is_using_trail_extended = True
        redeemability_conditions = False
        if (
                is_within_validity_period and not offer['is_for_members_only']
        ):
            # Handling global search where category is "All" instead of a specific category.
            if category.lower() == ALL:
                category = offer.get('merchant_category', '')
            redeemability_conditions = offer_redeemability_for_extended_trial(
                offer=offer,
                category=category,
                rules=rules
            )
    else:
        redeemability_conditions = (
            offer.get('merchant_category', '').lower() == RESTAURANTS_AND_BARS and
            offer['type'] == TYPE_DEFAULT and
            is_within_validity_period and
            not offer['is_cheers'] and
            not offer['is_for_members_only'] and
            savings_estimate and
            savings_estimate <= 100
        )

    if offer['valid_from_date'] > date_from:
        if is_on_trial and is_using_trail_extended and rule_engine(
                offer={'saving_estimate': offer.get('savings_estimate', 0)},
                rules=rules,
                rule_key='is_travel_info'
        ):
            redeemability_for_future_offers = {
                'redeemability': redeemability_value,
                'times_redeemed': 0,
                'quantity_redeemable': 0,
                'quantity_purchased': offer.get('quantity', 0),
                'is_purchased': True
            }
        else:
            redeemability_for_future_offers = {
                'redeemability': redeemability_value,
                'times_redeemed': 0,
                'quantity_redeemable': 0,
                'quantity_purchased': num_purchased,
                'is_purchased': offer['product_id'] in customer['product_ids']
            }

        #  In case of Travel we are making the offers redeemable.
        #  It helps the customer to book it at advance even if the offer validity date is in the future.
        if (
                category.lower() == TRAVEL and
                invoked_by == 'Outlet_Controller' and
                redeemability_for_future_offers['is_purchased']
        ):
            redeemability_for_future_offers['redeemability'] = Redemption.REDEEMABLE
        return redeemability_for_future_offers

    if is_within_validity_period:
        # Member offers can be redeemed as long as they are active
        if all([
            offer['type'] == TYPE_MEMBER,
            member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_active_family_member,
            offer['product_id'] in customer['product_ids']
        ]):
            num_purchased = num_redemptions + 1

    if top_up_offer and num_redemptions:
        # as per the business logic, the value of topUpCount is 1
        num_redemptions -= 1  # topUpCount

    if is_on_trial and redeemability_conditions:
        redeemability_value = Redemption.REDEEMABLE
        num_purchased = offer['quantity']
    elif is_within_validity_period and num_purchased and num_purchased > num_redemptions:
        if offer['type'] == TYPE_MEMBER:
            redeemability_value = Redemption.REUSABLE
        else:
            redeemability_value = Redemption.REDEEMABLE
    elif num_purchased and num_redemptions >= num_purchased:
        redeemability_value = Redemption.REDEEMED
    else:
        redeemability_value = Redemption.NOT_REDEEMABLE

    is_redeemable = redeemability_value in (Redemption.REUSABLE, Redemption.REDEEMABLE)
    quantity_redeemable = max(0, num_purchased - num_redemptions)
    if redeemability_value == Redemption.REUSABLE:
        quantity_redeemable = 999

    return {
        'is_redeemable': is_redeemable,
        'redeemability': redeemability_value,
        'times_redeemed': num_redemptions,
        'quantity_redeemable': quantity_redeemable,
        'quantity_purchased': num_purchased,
        'is_purchased': offer['product_id'] in customer['product_ids']
    }


def get_outlet_attr_status(offer, offer_level_attr_name, outlet_level_attr_name, offer_level_attr_value, outlet=None):
    """
    Return outlet attr status.

    Check if an outlet has a specific attribute set e.g. if an outlet is 'is_monthly' etc.

    :param str offer_level_attr_name: offer data level attr name.
    :param str outlet_level_attr_name: outlet data level attr name.
    :param int, bool, str offer_level_attr_value: offer data level attr value
    :param dict offer: offer data
    :param dict, None outlet: outlet data
    :return: outlet attr status
    :rtype: bool
    """
    if not outlet:
        outlet = {}
    if offer.get(offer_level_attr_name) == offer_level_attr_value or outlet.get(outlet_level_attr_name, False):
        return True
    return False


def count_offer_redemptions_by_customer_shared_offers(
        customer_id,
        offer_id=None,
        group_by=False,
        count=False,
        primary_user_id=0,
        is_active_family_member=False,
        company=None
):
    """
    Gets the count of redemptions made by customer for shared offers.

    :param int customer_id: id of customer to get redeemed quantities for.
    :param int, list offer_id: id/ids of offer if we want to get redeemed quantities for specific offers.
    :param int count: if we want the count of redemptions.
    :param bool group_by: True if we want to group results by offer.
    :param int primary_user_id: id of primary user.
    :param bool is_active_family_member: True if customer is a member.
    :param company company: name of company.
    """

    redemptions_count_dict = {}

    records = Redemption.count_offer_redemptions_by_customer_shared_offers(
        customer_id=customer_id,
        offer_id=offer_id,
        group_by=group_by,
        primary_user_id=primary_user_id,
        is_active_family_member=is_active_family_member,
        company=company
    )
    if records and group_by:
        redemptions_count_dict = {record.offer_id: record.quantity for record in records}

    if not isinstance(offer_id, list) and count:
        return int(redemptions_count_dict.get(offer_id, 0))

    return redemptions_count_dict


def get_offer_monthly_status(offer, show_monthly_offers_product_wise=True):
    """
    Return offer is_monthly status.

    If show_monthly_offers_product_wise flag is ON then set offer monthly status on the basis of ismember key value
    If show_monthly_offers_product_wise flag is OFF then set offer monthly status on the basis of type key value

    :param dict offer: offer data
    :param bool show_monthly_offers_product_wise: flag to show monthly offers product wise
    :return bool: offer is_monthly status
    """
    if show_monthly_offers_product_wise:
        is_monthly = bool(offer.get('ismember', False))
    else:
        is_monthly = offer.get('type') == OFFER_TYPE_MONTHLY
    return is_monthly


def get_current_date_time(get_end_date=False):
    """
    Returns current datetime object. If get_end_date passed, returns tuple of current date and 14 days ahead.

    :param dict get_end_date: If True, returns tuple of current date, current date + 14 days.
    :rtype: datetime, (datetime, datetime)
    """
    current_date = datetime.datetime.now()
    current_date = current_date.replace(microsecond=0)
    end_date = None
    if get_end_date:
        end_date = current_date + datetime.timedelta(days=14)
        end_date = end_date.strftime('%Y-%m-%d %H:%M:%S')
    current_date = datetime.datetime.strftime(current_date, '%Y-%m-%d %H:%M:%S')
    if get_end_date:
        return current_date, end_date
    return current_date


def get_products_ids_list(product_ids):
    """
    Gets the list of product ids of user, if not then returns empty list.
    :param product_ids: product ids in session of user
    :rtype: list
    """
    if isinstance(product_ids, list):
        return product_ids
    if isinstance(product_ids, str) and product_ids:
        return product_ids.split(',')
    else:
        return []


def format_company(company):
    """
    Returns 'entertainer' as customer's company to generalize all entertainer-vx.xx versions.
    :param str company: name of customer's company.
    :rtype: str
    """
    if ENT_COMPANY_TYPE_FULL in company:
        return ENT_COMPANY_TYPE_FULL

    if ENT_COMPANY_TYPE == company:
        return ENT_COMPANY_TYPE_FULL

    return company


def get_featured_merchants(
        location_id,
        category,
        featured_category,
        company,
        billing_country='',
        locale=EN,
        is_cheers=False,
        is_customer_own_cheers_for_location=False,
        add_future_check=True
):
    """
    Gets all featured merchants of a certain category for a location id.

    :param int location_id: location id of customer.
    :param str category: category of offers of merchant.
    :param str featured_category: featured category of FeaturedMerchant.
    :param str company: name of customer's company.
    :param str billing_country: name of customer's billing country.
    :param str locale: locale to get results in.
    :param bool is_cheers: if the offers are cheers.
    :param bool is_customer_own_cheers_for_location: if cheers offers are enabled for the location passed.
    :param bool add_future_check: if we want to check validity of FeaturedMerchant.
    :rtype: list
    """
    from ..models.merchant import Merchant
    outlet_label_plural = ''
    featured_merchants = []

    records = Merchant.get_featured_merchants(
        location_id,
        category,
        featured_category,
        company,
        billing_country,
        locale,
        is_cheers,
        is_customer_own_cheers_for_location,
        add_future_check
    )

    if category == CATEGORY_NAME_TRAVEL:
        outlet_label_singular = TranslationManager.get_translation(TranslationManager.TRAVEL_LOCATION, locale)
    else:
        outlet_label_singular = TranslationManager.get_translation(
            TranslationManager.OUTLET_COUNT_SINGULAR,
            locale
        )
        outlet_label_plural = TranslationManager.get_translation(
            TranslationManager.OUTLET_COUNT_PLURAL,
            locale
        )

    for record in records:
        if record:
            if record.category == CATEGORY_API_NAME_TRAVEL:
                record.outlets_info = outlet_label_singular
            elif record.outlets_count > 0:
                record.outlets_info = '{outlets_count} {label}'.format(
                    outlets_count=record.outlets_count,
                    label=outlet_label_singular if record.outlets_count == 1 else outlet_label_plural
                )
            featured_merchants.append(record)
    return featured_merchants


def get_geo_point_from_lat_lng(lat, lng, location_id, company):
    """
    Get shapely geo point from latitude and longitude
    :param lat: latitude of geo-point.
    :param lng: longitude of geo-point.
    :param location_id: location id of geo-point.
    :param company: name of company.
    :return: geo point
    """

    delivery_enabled_locations = get_delivery_enabled_location_ids_against_company(company)
    lat_lng_point = None
    try:
        if lat and lng:
            lat_lng_point = Point(float(lng), float(lat))
        elif (
                not lat_lng_point and
                location_id in delivery_enabled_locations
        ):
            lat_lng_point = get_geo_points_against_location_id(location_id)

    except Exception:
        pass
    return lat_lng_point


def get_category_color_code(category):
    """
    Gets color on base of category
    :param str category: category. e.g: Restaurants and Bars
    :rtype: str
    """
    if not category:
        return ""
    elif category == CATEGORY_API_NAME_BODY:
        return COLOR_BODY
    elif category == CATEGORY_API_NAME_LEISURE:
        return COLOR_LEISURE
    elif category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
        return COLOR_RESTAURANTS_AND_BARS
    elif category == CATEGORY_API_NAME_RETAIL:
        return COLOR_RETAIL
    elif category == CATEGORY_API_NAME_SERVICES:
        return COLOR_SERVICES
    elif category == CATEGORY_API_NAME_TRAVEL:
        return COLOR_TRAVEL
    return ""


def offer_redeemability_for_extended_trail(category='', offer=None, rules={}):
    """
    Check offer redeemability based on rules
    :param category: str
    :param offer: offer object (dict)
    :param rules: rules object (dict)
    :return: boolean
    """
    other_conditions = False
    if offer and rules:
        if category is None:
            category = ''
        # checking rule passed for specific category
        if category in rules.get('categories', []):
            other_conditions = rule_engine(category=category, offer=offer, rules=rules)
        # # checking rule passed without category
        # if not other_conditions:
        #     other_conditions = self.rule_engine(category='', offer=offer, rules=rules)
    return other_conditions


def calculate_dc_prospect_offer_redeemability(offer, member_group, location_id, company, take_away_enabled):
    """
    Calculates dc prospect offer redeemability

     1. If user is not a member and takeaways is not enabled
     2. delivery cashless offer is enabled and is 25% off offer.
     3. merchant is supporting dc_prospect and location is with in dc_prospect location_feature enabled
    """
    return (
        offer.get('type', 0) == TYPE_MEMBER and
        not take_away_enabled and
        offer.get('cashless_delivery_enabled') and
        offer.get('is_delivery_cashless_offer') and
        member_group != EntCustomerProfile.MEMBERSTATUS_MEMBER and
        location_id in get_dc_prospect_enabled_location_ids_against_company(company) and
        offer.get('dc_prospect_enabled', False)
    )


def get_monthly_section(locale):
    """
    Returns monthly offers section.

    :param str locale: language locale
    :return dict: monthly section data dict
    """
    return {
        "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_MONTHLY,
        "name": TranslationManager.get_translation(TranslationManager.tab_name_monthly_offers, locale),
        "params": {
            "redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
            "show_offers_of_type[]": Offer.OFFER_TYPE_MONTHLY
        }
    }


def get_category_home_screen_tabs(section_for, is_take_away=False, is_delivery=False, locale='en'):
    """
    Gets category home screen tabs
    :param section_for: section_for e.g: delivery, cheers, monthly etc
    :param is_take_away: is_take_away boolean flag
    :param is_delivery: is_delivery boolean flag
    :param locale: language
    :rtype: list of dict
    """
    from ..models.redemption import Redemption
    if section_for == CategoryHomeScreenConfiguration.SECTION_FOR_ALL_OUTLETS:
        return [
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_ALL_OFFERS,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_all_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE}
            },
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_LOCKED,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_locked_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_NOT_REDEEMABLE}
            }
        ]
    elif section_for == CategoryHomeScreenConfiguration.SECTION_FOR_CUISINE:
        return [
            {
                "section_type": CategoryHomeScreenConfiguration.vTAB_SECTION_TYPE_ID_ALL_OFFERS,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_all_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE}
            },
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_LOCKED,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_locked_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_ALL}
            }
        ]
    elif section_for == CategoryHomeScreenConfiguration.SECTION_FOR_SUB_CATEGORY:
        return [
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_ALL_OFFERS,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_all_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE}
            },
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_LOCKED,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_locked_offers, locale),
                "params": {"redeemability": Redemption.REDEEMABILITY_NOT_REDEEMABLE}
            }
        ]
    elif section_for == CategoryHomeScreenConfiguration.SECTION_FOR_CHEERS:
        return [
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_CHEERS,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_cheers, locale),
                "params": {
                    "redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
                    "is_cheers": "true"
                }
            },
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_LOCKED,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_locked_offers, locale),
                "params": {
                    "redeemability": Redemption.REDEEMABILITY_NOT_REDEEMABLE,
                    "is_cheers": "true"
                }
            }
        ]
    elif section_for == CategoryHomeScreenConfiguration.SECTION_FOR_DELIVERY:
        # we will check if take_away and delivery enabled we will send two sections,
        # in take_away only take_away section previous flow will work accordingly.
        if is_take_away and is_delivery:
            # if both delivery and take_away locations are enabled
            return [
                {
                    "name": "Delivery",
                    "params": {},
                    "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_DELIVERY
                },
                {
                    "name": "Takeaways",
                    "params": {
                        "is_take_away": True
                    },
                    "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_TAKE_AWAY
                }
            ]
        elif is_take_away and not is_delivery:
            # if takeaways is enabled and delivery is disabled.
            return [
                {
                    "name": "Takeaways",
                    "params": {
                        "is_take_away": True
                    },
                    "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_TAKE_AWAY
                }
            ]
        else:
            # if only delivery but not enabled.
            return [
                {
                    "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_DELIVERY,
                    "name": TranslationManager.get_translation(TranslationManager.tab_name_delivery, locale),
                    "params": {
                        "redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
                        "is_delivery": "true"
                    }
                },
                {
                    "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_LOCKED,
                    "name": TranslationManager.get_translation(TranslationManager.tab_name_locked_offers, locale),
                    "params": {
                        "redeemability": Redemption.REDEEMABILITY_NOT_REDEEMABLE,
                        "is_delivery": "true"
                    }
                }
            ]
    if section_for == CategoryHomeScreenConfiguration.SECTION_FOR_MONTHLY:
        return [get_monthly_section(locale=locale)]
    if section_for == CategoryHomeScreenConfiguration.SECTION_FOR_MORE_AFRICA:
        return [
            {
                "section_type": CategoryHomeScreenConfiguration.TAB_SECTION_TYPE_ID_MORE_AFRICA,
                "name": TranslationManager.get_translation(TranslationManager.tab_name_more_africa, locale),
                "params": {
                    "redeemability": Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
                    "is_more_sa": "true"
                }
            }
        ]
    return []


def get_category_badge(category):
    """
    Returns badge against category
    :param str category: Category Name
    :rtype: str
    """
    return CATEGORY_BADGES.get(category, "")


def set_image_and_attributes(outlet, selected_category=''):
    """
    Sets images and attributes
    :param outlet: outlet
    :param selected_category: selected category
    :rtype: list
    """
    outlet['attributes'] = []
    try:
        if outlet.get('is_new'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_NEW_IMAGE_URL
            })
        if outlet.get('is_monthly'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_MONTHLY_IMAGE_URL
            })
        if outlet.get('is_cheers'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_CHEERS_IMAGE_URL
            })
        if outlet.get('is_delivery'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_DELIVERY_IMAGE_URL
            })
        if outlet.get('is_more_sa'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_MORE_SA_IMAGE_URL
            })
        if outlet.get('is_shared'):
            outlet['attributes'].append({
                "type": "image",
                "value": BADGE_PINGED_IMAGE_URL
            })

        if not outlet.get('is_featured'):
            for category in outlet.get('categories', []):
                if category != selected_category:
                    outlet['attributes'].append({
                        "type": "image",
                        "value": get_category_badge(category)
                    })
                if category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
                    if outlet.get('cuisines'):
                        for cuisine in outlet['cuisines']:
                            outlet['attributes'].append({
                                "type": "text",
                                "value": cuisine  # get translation
                            })
                    else:
                        for cuisine in outlet['merchant'].get('cuisines', []):
                            outlet['attributes'].append({
                                "type": "text",
                                "value": cuisine  # get translation
                            })
                if category == CATEGORY_API_NAME_TRAVEL:
                    if outlet['sub_categories'].get(category):
                        outlet['attributes'].append({
                            "type": "text",
                            "value": outlet['sub_categories'][category][0]
                        })
        if outlet.get('is_featured'):
            outlet['attributes'].append({
                "type": "image",
                "value": FEATURED_RIBBON_IMAGE.get(outlet['category'], ""),
                "is_featured": True
            })
        if not outlet.get('is_redeemable'):
            if outlet.get('is_purchased'):
                outlet['locked_image_url'] = LOCKED_OUTLET_GOLDEN_IMAGE_URL
            else:
                outlet['locked_image_url'] = LOCKED_OUTLET_GREY_IMAGE_URL
    except Exception:
        pass


def get_filter_item(
        uid, api_param_name, analytics_param_name, analytics_value, key, title='',
        image_url='', image_url_selected='', category_id=0, selection_type=0
):
    """
    Returns the dict of all parameters
    """
    return {
        'uid': uid,
        'api_param_name': api_param_name,
        'analytics_param_name': analytics_param_name,
        'analytics_value': analytics_value,
        'key': key,
        'name': title,
        'category_id': category_id,
        'selection_type': selection_type,
        'image_url': image_url,
        'image_url_selected': image_url_selected
    }


def count_offer_redemptions_by_customer(
        customer_id, company, offer_id=None, group_by=False, is_shared=None, primary_user_id=None
):
    """
    Counts offer redemptions by customer
    :param int customer_id: customer id
    :param str company: company name
    :param list offer_id: offer id
    :param bool group_by: group by boolean flag
    :param bool is_shared: is_shared boolean flag
    :param int primary_user_id: primary user id
    """
    records = Redemption.count_offer_redemptions_by_customer(
        customer_id,
        company,
        offer_id,
        group_by,
        is_shared,
        primary_user_id
    )

    if records:
        if group_by:
            return {record.offer_id: record.quantity for record in records}
        else:
            return records[0].quantity or 0
    return records


def send_push_notification(url, data={}, headers={}):
    """
    Sends push notification for any request
    :param url: Url
    :param data: Request Data
    :param headers: Request Header
    :rtype: bool
    """
    if not headers:
        headers = {
            "Content-Type": "application/json"
        }
    try:
        response = requests.post(
            url=url,
            data=json.dumps(data),
            headers=headers
        )
        if response.status_code in [codes.OK, codes.CREATED]:
            return True
    except Exception:
        pass
    return False


def filter_outlet_time_slots(outlets, current_time):
    """
    Filters outlets on basis of nearest possible time slot

    :param outlets: outlets
    :param current_time: current time
    :return return outlet with selected time slot
    :rtype: dict
    """
    outlets_time_diff = {}
    for index, outlet in enumerate(outlets):
        outlet_slot_total_minutes = outlet.total_minutes or 0
        outlet_delivery_end_time = outlet.delivery_start_time + datetime.timedelta(
            minutes=outlet_slot_total_minutes
        )
        time_diff_in_secs = find_time_difference_in_seconds(
            outlet_delivery_end_time,
            current_time
        )
        outlets_time_diff[time_diff_in_secs] = index
    index_of_selected_outlet = 0
    if len(outlets_time_diff) > 1:
        index_of_selected_outlet = get_outlet_nearest_time_slot_index(outlets_time_diff)
    return outlets[index_of_selected_outlet]


def find_time_difference_in_seconds(outlet_delivery_end_time, current_time):
    """
    Converts outlet delivery slot end time and current time to seconds and then returns difference of both

    :param outlet_delivery_end_time: end time of outlet time slot
    :param current_time: current time
    :return difference between current time and outlet delivery ending time in seconds
    :rtype: float
    """
    outlet_delivery_end_time_in_secs = outlet_delivery_end_time.seconds
    current_time_in_secs = datetime.timedelta(
        hours=current_time.hour,
        minutes=current_time.minute,
        seconds=current_time.second
    ).total_seconds()
    diff_from_current_time = outlet_delivery_end_time_in_secs - current_time_in_secs
    return diff_from_current_time


def filter_positive_number(number):
    """
    Filters the number, is number positive or not.

    :param number: int
    :rtype: bool
    :returns: true or false if number is greater than 0 or not respectively.
    """
    if number and number > 0:
        return True
    return False


def get_outlet_nearest_time_slot_index(slots_delievery_end_time):
    """
    Gets index of picked slot from dict of diff between end time of slot with current time.

                    Sample Input                      ==>    Sample Output
    -------------------------------------------------------------------------
    {'1000': 0, '3000': 1, '6000': 2, '8000': 3}      ==>   0 (All Future)
    {'-8000': 0, '-6000': 1, '-3000': 2, '-1000': 3}  ==>   3 (All Past)
    {'-1000': 0, '-3000': 1, '2000': 2, '4000': 3}    ==>   2 (Some Future, some Past)

    :param slots_delievery_end_time: dict
    :rtype: int
    :return: index of picked slot
    """
    slots_delievery_end_time_keys = slots_delievery_end_time.keys()
    min_value = min(slots_delievery_end_time)
    # For all future time slots case
    if min_value > 0:
        return slots_delievery_end_time[min_value]
    max_value = max(slots_delievery_end_time)
    # For all past or present time slots case
    if max_value <= 0:
        return slots_delievery_end_time[max_value]
    # For some future and some past time slots
    if min_value <= 0 < max_value:
        get_positive_slot = list(filter(filter_positive_number, slots_delievery_end_time_keys))
        min_positive = min(get_positive_slot)
        return slots_delievery_end_time[min_positive]


@cache.memoize(timeout=1800)
def get_currencies(locale='en'):
    """
    Gets currencies
    :rtype: list
    """
    currencies = []
    if locale == "ar":
        currencies.append({
            "id": "AED",
            "name": "درهم إماراتي ",
            "translated_currency": "AED"
        })
        currencies.append({
            "id": "BHD",
            "name": "دينار بحريني ",
            "translated_currency": "BHD"
        })
        currencies.append({
            "id": "EGP",
            "name": "جنيه مصري ",
            "translated_currency": "EGP"
        })
        currencies.append({
            "id": "EUR",
            "name": "يورو",
            "translated_currency": "EUR"
        })
        currencies.append({
            "id": "GBP",
            "name": "جنيه استرليني",
            "translated_currency": "GBP"
        })
        currencies.append({
            "id": "HKD",
            "name": "دولار هونغ كونغي ",
            "translated_currency": "HKD"
        })
        currencies.append({
            "id": "JOD",
            "name": "دينار أردني",
            "translated_currency": "JOD"
        })
        currencies.append({
            "id": "KWD",
            "name": "دينار كويتي ",
            "translated_currency": "KWD"
        })
        currencies.append({
            "id": "LBP",
            "name": "ليرة لبنانية",
            "translated_currency": "LBP"
        })
        currencies.append({
            "id": "MYR",
            "name": "رينغيت ماليزي ",
            "translated_currency": "MYR"
        })
        currencies.append({
            "id": "OMR",
            "name": "ريال عماني",
            "translated_currency": "OMR"
        })
        currencies.append({
            "id": "QAR",
            "name": "ريال قطري",
            "translated_currency": "QAR"
        })
        currencies.append({
            "id": "SAR",
            "name": "ريال سعودي",
            "translated_currency": "SAR"
        })
        currencies.append({
            "id": "SGD",
            "name": "دولار سنغافوري",
            "translated_currency": "SGD"
        })
        currencies.append({
            "id": "USD",
            "name": "دولار أميركي ",
            "translated_currency": "USD"
        })
        currencies.append({
            "id": "ZAR",
            "name": "راند جنوب أفريقي ",
            "translated_currency": "ZAR"
        })
    else:
        currencies.append({
            "id": "AED",
            "name": "UAE Dirham",
            "translated_currency": "AED"
        })
        currencies.append({
            "id": "BHD",
            "name": "Bahraini Dinar",
            "translated_currency": "BHD"
        })
        currencies.append({
            "id": "EGP",
            "name": "Egyptian Pound",
            "translated_currency": "EGP"
        })
        currencies.append({
            "id": "EUR",
            "name": "Euro",
            "translated_currency": "EUR"
        })
        currencies.append({
            "id": "GBP",
            "name": "British Pound",
            "translated_currency": "GBP"
        })
        currencies.append({
            "id": "HKD",
            "name": "Hong Kong Dollar",
            "translated_currency": "HKD"
        })
        currencies.append({
            "id": "JOD",
            "name": "Jordanian Dinar",
            "translated_currency": "JOD"
        })
        currencies.append({
            "id": "KWD",
            "name": "Kuwaiti Dinar",
            "translated_currency": "KWD"
        })
        currencies.append({
            "id": "LBP",
            "name": "Lebanese Pound",
            "translated_currency": "LBP"
        })
        currencies.append({
            "id": "MYR",
            "name": "Malaysian Ringgit",
            "translated_currency": "MYR"
        })
        currencies.append({
            "id": "OMR",
            "name": "Omani Rial",
            "translated_currency": "OMR"
        })
        currencies.append({
            "id": "QAR",
            "name": "Qatar Rial",
            "translated_currency": "QAR"
        })
        currencies.append({
            "id": "SAR",
            "name": "Saudi Arabian Riyal",
            "translated_currency": "SAR"
        })
        currencies.append({
            "id": "SGD",
            "name": "Singapore Dollar",
            "translated_currency": "SGD"
        })
        currencies.append({
            "id": "USD",
            "name": "U.S Dollar",
            "translated_currency": "USD"
        })
        currencies.append({
            "id": "ZAR",
            "name": "South African Rand",
            "translated_currency": "ZAR"
        })
    return currencies


def get_hotel_rating(sub_categories):
    """
    Extracts hotel rating from subcategories of offer.
    """

    if sub_categories:
        if '3 Star' in sub_categories:
            return 3
        if '4 Star' in sub_categories:
            return 4
        if '5 Star' in sub_categories:
            return 5

    return ''


def set_hours(date, hours=14):
    """
    Format hour attribute of date and return formatted ISO version with passed hr value.
    """
    if hours > 9:
        return date.strftime("%Y-%m-%dT{}:00:00+0400".format(hours))
    return date.strftime("%Y-%m-%dT0{}:00:00+0400".format(hours))


def get_context_cache():
    return Cache(current_app, config=current_app.config)
