from flask import current_app
from sqlalchemy import create_engine

from common.utils.helpers import stringify


def call_stored_procedure(schema, sp_name, params, is_master=False):
    """
    Calls the passed stored procedure with params.
    """
    if is_master:
        db_url = '{db_uri}/{schema}'.format(db_uri=current_app.config['MASTER_DATABASE_URI'], schema=schema)
    else:
        db_url = '{db_uri}/{schema}'.format(db_uri=current_app.config['SQLALCHEMY_DATABASE_URI'], schema=schema)

    raw_conn = create_engine(db_url).raw_connection()
    try:
        cursor = raw_conn.cursor()
        cursor.callproc(sp_name, params)
        results = list(cursor.fetchall())
        cursor.close()
        raw_conn.commit()
    finally:
        raw_conn.close()
    return results


def __create_params_string(params):

    return ','.join(map(stringify, params))


def execute_stored_procedure(schema, sp_name, params):
    """
    Executes the passed stored procedure with params.
    """
    db_url = '{db_uri}/{schema}'.format(db_uri=current_app.config['SQLALCHEMY_DATABASE_URI'], schema=schema)
    raw_conn = create_engine(db_url).raw_connection()
    try:
        cursor = raw_conn.cursor()
        query = 'CALL {sp}({params})'.format(sp=sp_name, params=__create_params_string(params))
        cursor.execute(query)
        raw_conn.commit()
    finally:
        raw_conn.close()



