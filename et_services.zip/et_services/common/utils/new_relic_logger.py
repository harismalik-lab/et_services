"""
This module implements all logging classes required to log messages and errors in New Relic UI.
It contains the following classes:
[1] NewRelicLogHandler
"""

__author__ = 'umari@theentertainerasia.com'

import logging

import newrelic.agent


class NewRelicLogHandler(logging.Handler):
    """
    Implements a log handler so we can log handled exceptions in NewRelic as errors.
    """

    def emit(self, record):
        """
        Uses the 'record_exception' method which logs custom errors.
        Any key-word argument can be passed in params to view in NewRelic UI.
        """
        newrelic.agent.record_exception(params=record.__dict__)
