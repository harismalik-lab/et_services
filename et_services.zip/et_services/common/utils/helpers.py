"""
General helper functions.
"""
import time


def get_current_time_in_seconds():

    return int(time.time())


def stringify(in_str):

    if not isinstance(in_str, str):
        return str(in_str)
    else:
        return '"{}"'.format(in_str)
