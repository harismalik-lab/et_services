"""
This module contains inter service tcp communicator
"""
import json

import requests
from flask import request
from werkzeug.exceptions import InternalServerError

from ..utils.api_utils import get_logger


class Communicator:

    logger = get_logger('communicator/communicator.log', 'communicator_logger')

    @classmethod
    def get_standard_headers(cls):
        """
        Returns standard API headers
        :rtype: dict
        """
        headers = {
            'Authorization': request.environ.get('HTTP_AUTHORIZATION'),
            'Content-Type': 'application/json'
        }
        return headers

    def communicate(self, endpoint, method_type, params=None, payload=None):
        response = None
        try:
            if method_type.upper() in ('GET', 'POST', 'PUT'):
                method = getattr(requests, method_type.lower())
                headers = self.get_standard_headers()
                response = method(endpoint, params=params, headers=headers, data=json.dumps(payload), verify=False)
                response.raise_for_status()
            else:
                self.logger.exception("Invalid 'method_type': {} passed for {} with {}".format(
                    method_type,
                    endpoint,
                    payload
                ))
                raise InternalServerError('Unsupported method_type')
        except requests.exceptions.RequestException as e:
            self.logger.exception("Error occurred while making request to {} with {}: {}".format(
                endpoint,
                params or payload,
                e
            ))
            raise
        return response


communicator = Communicator()
