"""
Helper methods for HTTP requests.
"""
import base64
import json

import requests


def make_get_request(api_url, auth_headers, api_params):

    api_response = requests.get(
        api_url,
        headers=auth_headers,
        params=api_params
    )
    return {
        'status_code': api_response.status_code,
        'response': json.loads(api_response.text)
    }


def make_post_request(api_url, auth_headers, api_body):

    api_response = requests.post(
        api_url,
        headers=auth_headers,
        data=api_body
    )
    return {
        'status_code': api_response.status_code,
        'response': json.loads(api_response.text)
    }


def get_auth_headers(usr=None, pwd=None, bearer=None):
    """
    Creates authentication header to be used in an HTTP request.

    :param usr: Username for basic authentication.
    :param pwd: Password for basic authentication.
    :param bearer: JWT token for bearer authentication.
    :rtype: dict
    """
    if bearer:
        auth_type = 'Bearer'
        auth_str = bearer

    elif usr and pwd:
        auth_type = 'Basic'
        usr_pwd = "{user}:{password}".format(user=usr, password=pwd)
        auth_str = base64.b64encode(usr_pwd.encode()).decode()

    else:
        raise Exception("Authentication not provided.")

    return {"Authorization": "{auth_type} {auth_str}".format(auth_type=auth_type, auth_str=auth_str)}
