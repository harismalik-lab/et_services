"""
Common utilites to be used in all services.
"""
import datetime

from flask import g

from common.constants import ANALYTICS_CATEGORY_CODES_DICT
from common.models.ent_customer_profile import EntCustomerProfile
from common.models.location_features import LocationFeature
from common.models.purchased_offer_pings import PurchasedOfferPing
from common.models.redemption import Redemption
from common.models.share_offer import ShareOffer
from common.models.user_info import UserInfo

cache = g.cache


class SharedUtil(object):

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_delivery_enabled_location_ids_against_company(company):
        """
        Returns tuple of location ids against company where delivery cashless is active.
        :rtype: list
        """
        return [location.location_id for location in LocationFeature.get_delivery_cashless_location_ids(company)]

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_takeaways_enabled_location_ids_against_company(company):
        """
        Returns tuple of location ids against company where Takeaways is active.
        :rtype: list
        """
        return [location.location_id for location in LocationFeature.get_take_away_location_ids(company)]

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_table_booking_enabled_location_ids_against_company(company):
        """
        Returns tuple of location ids against company where table booking is active.
        :rtype: list
        """
        return [location.location_id for location in LocationFeature.get_table_booking_location_ids(company)]

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_dc_prospect_enabled_location_ids_against_company(company):
        """
        Returns tuple of location ids against company where DC prospect and DC is active.
        :rtype: list
        """
        return [location.location_id for location in LocationFeature.get_dc_enabled_prospect_location_ids(company)]

    @staticmethod
    def redeemed_quantities_for_customer(**kwargs):
        """
        Gets redeemed quantities for a customer.
        """
        is_secondary_customer = kwargs.get('is_secondary_customer')
        customer_id = kwargs.get('customer_id')
        is_onboarding = kwargs.get('is_onboarding')
        offer_id = kwargs.get('offer_id')
        company = kwargs.get('company')
        primary_user_id = kwargs.get('primary_user_id')
        family_id = kwargs.get('family_id')

        redemption_quantities = {}

        if is_secondary_customer:
            redemption_results = Redemption.get_birthday_redeemed_quantities_for_secondary_customer(
                customer_id=customer_id,
                is_onboarding=is_onboarding,
                offer_id=offer_id,
                company=company
            )
        else:
            redemption_results = Redemption.get_redeemed_quantities_for_customer(
                customer_id=customer_id,
                primary_user_id=primary_user_id,
                family_id=family_id,
                is_onboarding=is_onboarding,
                offer_id=offer_id,
                company=company
            )

        for redemption in redemption_results:
            redemption_quantities[redemption.offer_id] = int(redemption.qty)

        return redemption_quantities

    @staticmethod
    def get_ping_section():
        """
        Returns ping section dict
        :rtype: dict
        """
        return {
            'is_sender_info': False,
            'is_recipient_info': False,
            'can_user_ping': False,
            'can_user_receive_ping': False,
            'total_quota_to_send_pings': 0,
            'total_quota_to_receive_pings': 0,
            'total_pings_sent': 0,
            'total_pings_received': 0,
            'message': '',
            'background_color': ''
        }

    @staticmethod
    def get_number_of_allowed_pings(**kwargs):
        """
        This returns number of allowed pings.
        - get customer ping limit.
        - get customer purchased pings.
        :return: number_of_allowed_pings
        :rtype: int
        """
        user_id = kwargs['user_id']
        customer_ping_offer_limit = UserInfo.get_ping_offer_limit(user_id)

        purchased_pings = PurchasedOfferPing.get_purchased_pings(user_id, datetime.datetime.now().year)
        if customer_ping_offer_limit:
            if purchased_pings:
                return purchased_pings + customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES
            return customer_ping_offer_limit + ShareOffer.MAX_ALLOWED_SHARES

        number_of_allowed_pings = ShareOffer.MAX_ALLOWED_SHARES
        if purchased_pings:
            number_of_allowed_pings += purchased_pings
        return number_of_allowed_pings

    def get_ping_details(
            self,
            user_id,
            is_member,
            user_products,
            is_sender,
            is_family_member=False,
            primary_user_id=None
    ):

        ping_details = self.get_ping_section()
        if user_id:
            user_quota_to_send_pings = 0
            if is_member or is_family_member:
                user_quota_to_send_pings = self.get_number_of_allowed_pings(
                    user_id=user_id,
                    product_id_owned=user_products
                )
            total_offers_pinged = ShareOffer.get_shared_offers_by_sender_count(
                sender_id=user_id, primary_sender_user_id=primary_user_id
            )
            ping_details.update({
                'is_sender_info': is_sender,
                'is_recipient_info': not is_sender,
                'can_user_ping': user_quota_to_send_pings > total_offers_pinged,
                'total_quota_to_send_pings': user_quota_to_send_pings,
                'total_pings_sent': total_offers_pinged
            })
        return ping_details

    @staticmethod
    def get_analytics_codes_against_categories(categories):
        """
        Gets analytics codes against given categories.
        """
        codes = []
        for category in categories:
            value_against_category = ANALYTICS_CATEGORY_CODES_DICT.get(category.lower())
            if value_against_category:
                codes.append(value_against_category)
        return ','.join(codes)
