"""
Dynamic model selector on basis of config keys,
for example it will automatically selects appropriate models for desired companies
"""
from ..models.offer_translation_wl_active import OfferTranslationWlActive
from ..models.offer_wl_active import OfferWlActive
from ..models.product_offer_wl_active import ProductOfferWlActive
from ..models.product_wl_active import ProductWlActive


class DynamicModelSelector(object):
    ent_company_type = 'ent'
    model_mapper = {
        'product_ent_active': ProductWlActive,
        'offer_ent_active': OfferWlActive,
        'offer_translation_ent_active': OfferTranslationWlActive,
        'product_offer_ent_active': ProductOfferWlActive
    }

    @classmethod
    def get_model(cls, model_name, company_type, default=None):
        """
        Returns model according to the api_configurations
        :param Class default: Default Model class
        :param Class model_name: Model Name
        :param str company_type: Company type configuration key
        """
        if company_type == cls.ent_company_type:
            return default or model_name
        return cls.model_mapper[model_name]
