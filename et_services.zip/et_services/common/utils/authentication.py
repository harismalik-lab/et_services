"""
This module contains authentication logic
"""
import datetime
import json
import time
from base64 import b64decode
from collections import Counter

from dateutil.parser import parse
from flask import current_app, request
from flask_jwt_extended.exceptions import InvalidHeaderError, NoAuthorizationError
from flask_jwt_extended.view_decorators import ctx_stack, wraps
from jwt import InvalidAlgorithmError, decode
from jwt.exceptions import InvalidSignatureError
from werkzeug.exceptions import BadRequest, Forbidden, Unauthorized

from ..constants import (
    ENT_COMPANY_TYPE, INVALID_JWT, INVALID_TOKEN, JWT_HEADER_ERROR_MESSAGE, JWT_SIGNATURE_MISMATCH,
    MISSING_JWT_ERROR_MESSAGE, SESSION_EXPIRED_STATUS_CODE
)
from ..exceptions import EmailNotVerifiedException
from ..models.api_configuration import ApiConfiguration
from ..models.customer_social_acc import CustomerSocialAcc
from ..models.ent_customer_profile import EntCustomerProfile
from ..models.extended_trial_activation import ExtendedTrialActivation
from ..models.family import Family
from ..models.family_member import FamilyMember
from ..models.product import Product
from ..models.product_ent_active import ProductEntActive
from ..models.session import Session
from ..models.user import User
from ..models.vip_group_key import VipGroupKey
from ..models.wl_company_api_configuration import WlCompanyApiConfiguration
from ..models.wl_product import WlProduct
from ..models.wl_user_group import WlUserGroup
from ..models.wl_validation import Wlvalidation
from ..utils.api_utils import get_api_configurations, get_current_date_time, get_products_ids_list, \
    get_birthday_offer_validity_in_days


def token_decorator(fn):
    @wraps(fn)
    def validator(self, *args, **kwargs):
        return jwt_token_required_wl(fn)(self, *args, **kwargs)
    return validator


def token_decorator_v3(fn):
    @wraps(fn)
    def validator(self, *args, **kwargs):
        return jwt_token_required_v3(fn)(self, *args, **kwargs)
    return validator


def get_current_customer():
    """
    Return the customer's session-data.
    """
    return getattr(ctx_stack.top, 'session_data', {})


def get_jw_token_identity():
    """
    Returns JWT identity
    """
    return getattr(ctx_stack.top, 'jwt_identity', {})


def get_company():
    """
     Return company name
    """
    return get_jw_token_identity().get('company').lower()


def get_family_details(user_profile, session_data, api_configs):
    """
    Returns family_information related details
    """
    family_data = {
        'owns_cheer_products': False,
        'user_in_family_ever': False,
        'is_active_family_member': False,
    }
    family_member = FamilyMember.find_family_member(
        filters={'user_id': user_profile.user_id},
        not_equal_filters={'member_since': None}
    )
    if family_member:
        family_data['user_in_family_ever'] = True

        if family_member.status == FamilyMember.ACCEPTED and family_member.is_active:
            family_data['family_member_info'] = family_member
            family_information = Family.get_active_by_id(family_member.family_id)
            family_data['family_info'] = family_information
            primary_member_profile = User.get_active_by_id(family_information.user_id)
            if family_information:
                if family_information.status == Family.ON_GRACE_PERIOD:
                    family_data['on_grace_period'] = True
                if family_information.status == Family.EXPIRED:
                    family_data['family_expired'] = True
                family_data['is_user_in_family'] = True
                family_data['is_primary'] = family_member.is_primary
                if (
                        primary_member_profile and
                        primary_member_profile.status == EntCustomerProfile.STATUS_BLACKLISTED
                ):
                    family_data['family_is_active'] = False
                    family_data['is_user_in_family'] = False
                else:
                    family_data['family_is_active'] = family_information.status in (Family.ACTIVE, Family.ON_GRACE_PERIOD)
                    family_data['is_user_in_family'] = True
                    family_data['is_primary'] = bool(family_member.is_primary)

        if family_data['is_primary']:
            family_data['primary_member_info'] = family_member
        if not family_data['is_user_in_family']:
            if not family_data['user_in_family_ever']:
                family_data['is_using_trial'] = is_customer_on_trial(customer_profile=user_profile)
                family_data['is_member_on_trial'] = family_data['is_using_trial']
            if not family_data['is_member_on_trial'] and user_profile.new_member_group not in (
                    EntCustomerProfile.MEMBERSTATUS_MEMBER,
                    EntCustomerProfile.MEMBERSTATUS_REPROSPECT
            ):
                changes = {
                    'onboarding_status': EntCustomerProfile.ONBOARDING_FINISHED,
                    'member_group': EntCustomerProfile.MEMBERSTATUS_PROSPECT,
                    'new_member_group': EntCustomerProfile.MEMBERSTATUS_PROSPECT,
                    'onboarding_enddate': get_current_date_time()
                }
                user_profile.update_customer_profile(customer_id=user_profile.user_id, changes=changes)

        if family_data['is_user_in_family'] and not family_data['is_primary']:
            primary_family_member_info = FamilyMember.find_family_member(
                filters={
                    'is_primary': 1,
                    'family_id': family_data['family_info'].id,
                    'is_active': 1,
                    'user_id': family_data['family_info'].user_id,
                }
            )
            if primary_family_member_info:
                family_data['primary_member_info'] = primary_family_member_info
                primary_member_session = Session.find_latest_token_by_user_id(
                    primary_family_member_info.user_id,
                    family_data.get('company'),
                    isactive=False
                )
                family_data['product_ids'] = list(
                    map(int, (filter(None, primary_member_session.product_ids.split(','))))
                )
                if api_configs.get(ApiConfiguration.ENABLE_CHEERS):
                    cheers_products = Product.get_cheers_product_by_product_ids(
                        company_type=session_data['company_type'],
                        company=session_data['company'],
                        product_ids=family_data['product_ids'],
                        convert_to_string=True
                    )
                    filtered_product_ids = list(map(int, ([product.id for product in cheers_products])))
                    if cheers_products:
                        family_data['owns_cheer_products'] = True
                        family_data['cheers_product_ids'] = filtered_product_ids

        if family_data['family_info'] and family_data['family_info'].status == Family.ACTIVE:
            if (
                    family_data['is_user_in_family'] and
                    family_data['family_is_active'] and
                    family_data['primary_member_info'].is_primary
            ):
                if family_data['is_primary']:
                    primary_customer_profile = user_profile
                else:
                    primary_customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(
                        family_data['primary_member_info'].user_id
                    )
                family_data['primary_member_membership_status'] = primary_customer_profile.new_member_group

                if primary_customer_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_REPROSPECT:
                    update_family_data = {'status': Family.ON_GRACE_PERIOD}
                    family_data['family_info'].update_family(
                        filters={'id': family_data['family_info'].id},
                        data=update_family_data
                    )

            family_data['on_grace_period'] = family_data['family_info'].status == Family.ON_GRACE_PERIOD
            family_data['family_expired'] = family_data['family_info'].status == Family.EXPIRED

        if family_data['family_info']:
            family_info_update_date = family_data['family_info'].date_updated
            if family_data['family_expired']:
                Family.check_family_expired_and_grace_period(session_data=family_data)
            if family_data['on_grace_period']:
                if (
                        family_data['is_user_in_family'] and
                        family_data['family_is_active'] and
                        family_data['primary_member_info'].is_primary and
                        (datetime.datetime.now() - family_info_update_date).days > Family.GRACE_PERIOD_EXPIRED_DAYS_LIMIT
                ):
                    Family.check_family_expired_and_grace_period(session_data=family_data)
                    primary_customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(
                        family_data['primary_member_info'].user_id
                    )
                    family_data['primary_member_membership_status'] = primary_customer_profile.new_member_group
                    if primary_customer_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_REPROSPECT:
                        update_family_data = {'status': Family.EXPIRED, 'is_active': 0}
                        family_data['family_info'].update_family(
                            filters={'id': family_data['family_info'].id},
                            data=update_family_data
                        )
                        FamilyMember.update_member(
                            filters={'family_id': family_data['family_info'].id},
                            data={'is_active': 0}
                        )
                        family_data['family_member_info']['is_active'] = 0
                        family_data['primary_member_info']['is_active'] = 0
                        family_data['is_user_in_family'] = False
                        family_data['family_is_active'] = False

        family_data['is_active_family_member'] = family_data['is_user_in_family'] and family_data['family_is_active']

    return family_data


def user_email_verification(user_profile):
    """
    Validates that whether user has verified his/her email
    :param EntCustomerProfile user_profile: User Profile
    :rtype:
    """
    user_created_at_delta = user_profile.create_time + datetime.timedelta(hours=24)
    current_time = datetime.datetime.now().replace(microsecond=0)
    if current_time > user_created_at_delta:
        user = User.get_active_by_id(user_id=user_profile.user_id)
        if not user:  # If user is not active
            raise Forbidden(
                'You are not allowed to access this resource.'
            )
        facebook_login = CustomerSocialAcc.get_facebook_login_by_customer_id(user.id)
        if not facebook_login and not user.is_email_verified:
            raise EmailNotVerifiedException()


def is_customer_on_trial(customer_profile):
    """
    Determines is customer on trial
    :param EntCustomerProfile customer_profile: User Profile
    :rtype: bool
    """
    is_using_trial = False
    trial_redemption_limit = customer_profile.onboarding_redemptions_limit or 0
    if not trial_redemption_limit:
        trial_redemption_limit = EntCustomerProfile.TRAIL_REDEMPTIONS_LIMIT

    is_member_on_trial = all([
        customer_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_ONBOARDING,
        # trails_days_remaining <= customer_repo_instance.TRIAL_DAYS + 1,
        # trails_days_remaining > 0,
        customer_profile.onboarding_redemptions_count or 0 < trial_redemption_limit
    ])
    if is_member_on_trial and customer_profile.onboarding_status == 1:
        is_using_trial = True
    return is_using_trial


def token_required_white_label(fn):
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        try:
            jw_data = ctx_stack.top.jwt_identity
            if getattr(self, 'strict_token', False):
                if not jw_data.get('session_token'):
                    raise Forbidden(
                        'A valid "session_token" is required.'
                    )
            if not getattr(self, 'required_token', True):
                return fn(self, *args, **kwargs)

            company = jw_data['company']
            session_token = jw_data.get('session_token')

            session_data = dict()
            session_data['company'] = company
            session_data['is_user_logged_in'] = False
            session_data['is_using_trial'] = False
            session_data['user_id'] = 0
            session_data['customer_id'] = 0

            if session_token:
                if not company:
                    data = INVALID_TOKEN
                    self.status_code = 403
                    self.code = 403
                    self.send_response_flag = True
                    self.process_request_exception(code=self.code, status_code=self.status_code, message=data)
                    self.remove_logger_handlers()
                    return self.send_response(data, self.status_code)
                session = Session.get_by_company_and_session_token(company=company, session_token=session_token)
                if not session:
                    raise Forbidden("Invalid 'session_token' provided.")
                user_id = session.customer_id
                refresh_required = session.refresh_required
                product_ids = session.product_ids
                if refresh_required:
                    try:
                        user_groups = Wlvalidation.get_user_groups(company, session.customer_id)
                        if not user_groups:
                            user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                        product_ids = WlProduct.get_configured_product_ids(company, user_groups)
                        session.product_ids = ','.join(map(str, product_ids))
                        if product_ids:
                            session.date_cached = time.time()
                            session.refresh_required = 0
                            session.update_record()
                    except Exception:
                        raise
                session_data['is_user_logged_in'] = True
                session_data['id'] = session.id
                session_data['session_token'] = session.session_token
                session_data['user_id'] = user_id
                session_data['customer_id'] = user_id
                session_data['new_member_group'] = EntCustomerProfile.MEMBERSTATUS_PROSPECT
                if product_ids:
                    session_data['new_member_group'] = EntCustomerProfile.MEMBERSTATUS_MEMBER
                customer_profile = EntCustomerProfile.load_customer_profile_by_user_id(user_id)
                session_data['member_type'] = EntCustomerProfile.get_member_type(
                    customer_profile.new_member_group
                )
                session_data['member_type_id'] = customer_profile.new_member_group
                session_data['product_ids'] = list(
                    map(int, session.product_ids.split(','))) if session.product_ids else []
            ctx_stack.top.session_data = session_data
            return fn(self, *args, **kwargs)
        except BadRequest as bad_request_exception:
            return self.process_bad_request(exception_raised=bad_request_exception)
        except Exception as exception_raised:
            return self.process_request_exception(exception_raised=exception_raised)
        # finally:
        #     if close_connection:
        #         self.close_connections()
    return wrapper


def refresh_customer_session_ent(customer_profile, company):
    """
    Refreshes customer session data based on business rules
    :param str company: Company
    :param EntCustomerProfile customer_profile: Customer Profile
    """
    extended_trail_group_ids = []
    if is_customer_on_trial(customer_profile):
        extended_trail_group_ids = [
            group.extended_trial_group_id for group in
            ExtendedTrialActivation.get_group_id_by_user_id(customer_profile.user_id)
        ]

    orders = User.get_customer_orders_with_product_pairing(customer_profile.user_id, company)
    purchased_skus = [order.product_sku for order in orders]

    vip_key_products = VipGroupKey.get_by_user_id(customer_profile.user_id)
    for vip_key in vip_key_products:
        purchased_skus.append(vip_key.product_sku)
    # Todo: Test
    if purchased_skus:
        all_bundled_skus = []
        bundled_product_skus = ProductEntActive.get_bundled_products_against_skus(purchased_skus)
        purchased_skus_count = Counter(bundled_product_skus)
        for sku in bundled_product_skus:
            if sku.bundled_product_sku and sku.sf_id:
                all_bundled_skus += sku.bundled_product_sku.split(',') * purchased_skus_count.get(sku.sf_id)
        purchased_skus.extend(all_bundled_skus)
    product_expiration_date = Product.get_product_expiration_date(purchased_skus)
    product_details = Product.get_product_details(purchased_skus)

    purchased_product_ids = []
    is_all_taster_products = True
    for product_detail in product_details:
        purchased_product_ids.append(product_details.id)
        if product_detail.is_purchaseable and not product_detail.is_taster_product:
            is_all_taster_products = False

    product_expiration_date_timestamp = 0
    if product_expiration_date:
        product_expiration_date_timestamp = time.mktime(product_expiration_date.timetuple())

    current_time = time.time()

    if product_expiration_date != customer_profile.membership_expiry and product_expiration_date_timestamp != 0:
        customer_profile.membership_expiry = product_expiration_date

    if customer_profile.new_member_group != EntCustomerProfile.MEMBERSTATUS_MEMBER and \
            product_expiration_date_timestamp > current_time:
        customer_profile.new_member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER
        customer_profile.member_group = EntCustomerProfile.MEMBERSTATUS_MEMBER
    elif customer_profile.new_member_group == EntCustomerProfile.MEMBERSTATUS_MEMBER and \
            product_expiration_date_timestamp < current_time:
        customer_profile.new_member_group = EntCustomerProfile.MEMBERSTATUS_REPROSPECT
        customer_profile.member_group = EntCustomerProfile.MEMBERSTATUS_REPROSPECT

    customer_profile.membership_sub_group = EntCustomerProfile.INACTIVE_MEMBERSHIP_SUB_GROUP
    if product_details:
        if is_all_taster_products:
            customer_profile.membership_sub_group = EntCustomerProfile.ACTIVE_MEMBERSHIP_SUB_GROUP
        else:
            pass  # Deactivation case was un reachable according to the code logic
    customer_profile.update_record()

    date_created = datetime.datetime.now()
    date_created = date_created.replace(tzinfo=datetime.timezone.utc).timestamp()
    session_changes = {
        'date_cached': date_created,
        'refresh_required': 0,
        'product_ids': ','.join(map(str, purchased_product_ids)),
        'extended_trail_group_ids': ','.join(map(str, extended_trail_group_ids))
    }
    Session.update_customer_sessions_with_changes_dict(customer_profile.user_id, company, session_changes)


def get_customer_details(session, customer_profile, user_obj, api_configs):
    customer_details = {
        'customer_id': session.customer_id,
        'primary_user_id': session.customer_id,
        'firstname': customer_profile.firstname,
        'lastname': customer_profile.lastname,
        'date_of_birth': customer_profile.birthdate,
        'membership_sub_group': customer_profile.membership_sub_group,
        'member_type_id': EntCustomerProfile.MEMBERSTATUS_PROSPECT,
        'is_primary': True,
        'is_member': False,
        'is_on_trial': False,
        'is_onboarding': False,
        'is_account_frozen': False,
        'is_active_family_member': False,
        'has_birthday_month': False,
        'owns_cheer_products': False,
        'show_cheers_offers': False,
        'product_ids': [],
        'user_in_family_ever': False,
        'primary_member_membership_status': EntCustomerProfile.MEMBERSTATUS_PROSPECT,
        'on_grace_period': False,
        'is_user_in_family': False,
        'family_info': {},
        'family_expired': False,
        'family_identifier': None
    }

    product_ids = session.product_ids.split(',') if session.product_ids else []
    if product_ids:
        customer_details['member_type_id'] = EntCustomerProfile.MEMBERSTATUS_MEMBER
        customer_details['is_member'] = True

    customer_details['member_type'] = EntCustomerProfile.get_member_type(customer_details['member_type_id'])
    customer_details['is_onboarding'] = customer_details['member_type_id'] == EntCustomerProfile.MEMBERSTATUS_ONBOARDING
    customer_details['onboarding_status'] = customer_profile.onboarding_status or 0
    customer_details['onboarding_redemptions_count'] = customer_profile.onboarding_redemptions_count or 0
    customer_details['onboarding_redemptions_limit'] = (
            customer_profile.onboarding_redemptions_limit or
            EntCustomerProfile.ONBOARDING_LIMIT
    )
    customer_details['onboarding_status'] = customer_profile.onboarding_status or 0

    customer_details['is_on_trial'] = (
            customer_details['is_onboarding'] and
            customer_details['onboarding_status'] == EntCustomerProfile.ONBOARDING_INPROGRESS and
            customer_details['onboarding_redemption_count'] < customer_details['onboarding_redemption_limit']
    )

    customer_details['is_account_frozen'] = user_obj.status in (
        EntCustomerProfile.STATUS_FROZEN,
        EntCustomerProfile.STATUS_BLACKLISTED,
        EntCustomerProfile.STATUS_TEMPORARILY_WHITELISTED
    )

    customer_details['product_ids'] = list(map(int, filter(None, product_ids)))
    # TODO: Add cheers product ids if cheers enabled.

    if api_configs.get(ApiConfiguration.ENABLE_BIRTHDAY_FEATURE):
        if customer_details['is_member'] or customer_details['is_active_family_member']:
            birth_date = customer_profile.birthdate
            if birth_date:
                number_of_birthday_validity_days = get_birthday_offer_validity_in_days(birth_date)
                if number_of_birthday_validity_days > -1:
                    customer_details['has_birthday_month'] = True

    return customer_details


def token_required_v3(fn):
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        try:
            jw_data = ctx_stack.top.jwt_identity
            if getattr(self, 'strict_token', False):
                if not jw_data.get('session_token'):
                    raise Forbidden(
                        'A valid "session_token" is required.'
                    )
            if not getattr(self, 'required_token', True):
                return fn(self, *args, **kwargs)

            company = jw_data['company']
            session_token = jw_data.get('session_token')
            session_data = {
                'company': company,
                'is_user_logged_in': False,
                'is_using_trial': False,
                'user_id': 0,
                'customer_id': 0
            }

            api_configs = get_api_configurations(company, current_app.config['ENV'].lower())
            session_data['api_configs'] = api_configs

            if session_token:
                if api_configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE:
                    session = Session.get_by_company_and_session_token_with_like_operator(
                        company=company,
                        session_token=session_token
                    )
                else:
                    session = Session.get_by_company_and_session_token(company=company, session_token=session_token)
                if not session:
                    raise Forbidden(
                        'Invalid "session_token" provided.'
                    )
                user_profile = EntCustomerProfile.get_by_user_id(session.customer_id)
                user_obj = User.get_active_by_id(user_id=session.customer_id)
                session_data.update({'company_type': api_configs.get(ApiConfiguration.COMPANY_TYPE)})

                session_data['is_user_logged_in'] = True
                session_data['id'] = session.id
                session_data['session_token'] = session.session_token
                session_data.update(get_customer_details(session, user_profile, user_obj, api_configs))

                if api_configs.get(ApiConfiguration.ENABLE_USER_EMAIL_VERIFICATION):
                    try:
                        user_email_verification(user_profile)
                    except EmailNotVerifiedException:
                        data = {
                            "resend_invite_section": {
                                "title": "Verify your email",
                                "message": "Looks like you failed to verify your e-mail address. Please verify "
                                           "your e-mail address or contact customer services at "
                                           "customerservice@theentertainerme.com for further help.",
                                'email': user_profile.user_id,  # TODO: There should be Email ?
                                "button_text": "RESEND"
                            }
                        }
                        data['message'] = data['resend_invite_section']['message']
                        self.status_code = SESSION_EXPIRED_STATUS_CODE
                        self.code = SESSION_EXPIRED_STATUS_CODE
                        self.send_response_flag = True
                        return self.send_response(data, self.status_code)

                if api_configs.get(ApiConfiguration.ENABLE_FAMILY_FEATURE):
                    session_data.update(get_family_details(user_profile, session_data, api_configs))

                refresh_required = session.refresh_required
                if session.date_cached == 1 and api_configs.get(ApiConfiguration.COMPANY_TYPE) == ENT_COMPANY_TYPE:
                    refresh_customer_session_ent(user_profile, company)
                    session = Session.get_by_company_and_session_token_with_like_operator(company, session_token)
                elif refresh_required and api_configs.get(ApiConfiguration.COMPANY_TYPE) != ENT_COMPANY_TYPE:
                    try:
                        user_groups = Wlvalidation.get_user_groups(company, session.customer_id)
                        if not user_groups:
                            user_groups = [WlUserGroup.DEFAULT_USER_GROUP]
                        product_ids = WlProduct.get_configured_product_ids(company, user_groups)
                        session.product_ids = ','.join(map(str, product_ids))
                        if product_ids:
                            session.date_cached = time.time()
                            session.refresh_required = 0
                            session.update_record()
                    except Exception:
                        raise
            ctx_stack.top.session_data = session_data
            return fn(self, *args, **kwargs)
        except BadRequest as bad_request_exception:
            return self.process_bad_request(exception_raised=bad_request_exception)
        except Exception as exception_raised:
            return self.process_request_exception(exception_raised=exception_raised)
    return wrapper


def jwt_token_required_wl(fn):
    """
    If you decorate a vew with this, it will ensure that the requester has a
    valid JWT before calling the actual view. This does not check the freshness
    of the token.
    See also: fresh_jwt_required()
    :param fn: The view function to decorate
    """

    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        if not hasattr(ctx_stack.top, 'jwt_identity'):
            jwt_data = decode_jwt_from_header()
            ctx_stack.top.jwt_identity = jwt_data
        data = get_jw_token_identity()
        if data and data.get('company') and data.get('api_token'):
            return token_required_white_label(fn)(self, *args, **kwargs)
        elif data and data.get('error_msg'):
            exception_to_be_raised = Unauthorized("Unauthorized")
            data = data.get('error_msg')
            self.status_code = 401
            self.code = 401
            self.send_response_flag = True
            self.process_request_exception(
                code=self.code,
                status_code=self.status_code,
                message=data,
                exception_raised=exception_to_be_raised
            )
            self.remove_logger_handlers()
            return self.send_response(data, self.status_code)
        # if token is inactive or wrong token
        data = INVALID_JWT
        self.status_code = 403
        self.code = 403
        self.send_response_flag = True
        exception_to_be_raised = Forbidden("You are not allowed to access this application")
        self.process_request_exception(
            code=self.code,
            status_code=self.status_code,
            message=data,
            exception_raised=exception_to_be_raised
        )
        self.remove_logger_handlers()
        return self.send_response(data, self.status_code)

    return wrapper


def jwt_token_required_v3(fn):
    """
    If you decorate a vew with this, it will ensure that the requester has a
    valid JWT before calling the actual view. This does not check the freshness
    of the token.
    See also: fresh_jwt_required()
    :param fn: The view function to decorate
    """

    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        if not hasattr(ctx_stack.top, 'jwt_identity'):
            jwt_data = decode_jwt_from_header()
            ctx_stack.top.jwt_identity = jwt_data
        data = get_jw_token_identity()
        if data and data.get('company') and data.get('api_token'):
            return token_required_v3(fn)(self, *args, **kwargs)
        elif data and data.get('error_msg'):
            exception_to_be_raised = Unauthorized("Unauthorized")
            data = data.get('error_msg')
            self.status_code = 401
            self.code = 401
            self.send_response_flag = True
            self.process_request_exception(
                code=self.code,
                status_code=self.status_code,
                message=data,
                exception_raised=exception_to_be_raised
            )
            self.remove_logger_handlers()
            return self.send_response(data, self.status_code)
        # if token is inactive or wrong token
        data = INVALID_JWT
        self.status_code = 403
        self.code = 403
        self.send_response_flag = True
        exception_to_be_raised = Forbidden("You are not allowed to access this application")
        self.process_request_exception(
            code=self.code,
            status_code=self.status_code,
            message=data,
            exception_raised=exception_to_be_raised
        )
        self.remove_logger_handlers()
        return self.send_response(data, self.status_code)

    return wrapper


def get_verified_jwt_payload():
    jwt_bearer = request.environ.get('HTTP_AUTHORIZATION')
    if jwt_bearer:
        jwt_bearer = jwt_bearer.split(' ')[1]
        payload = decode(jwt_bearer, verify=False)
        header = b64decode(jwt_bearer.split('.')[0])
        jwt_algorithm = json.loads(header.decode()).get('alg')
        api_token = payload.get('api_token')
        if not api_token:
            raise Exception("Expected 'api_token' non provided.")
        company_info = WlCompanyApiConfiguration.validate_company(api_token)
        if company_info:
            secret_key = company_info.secret_key
            data = decode(jwt_bearer, secret_key, algorithms=[jwt_algorithm])
            data['company_limit'] = company_info.per_minute
            data['company'] = company_info.company_code
            return data
        raise InvalidSignatureError
    raise InvalidHeaderError


def decode_jwt_from_header():
    """
    Decodes JWT from authorization header and get identity
    :return: JWT identity or exception if raised
    """
    try:
        data = get_verified_jwt_payload()
    # except BadRequest as bad_request_exception:
    #     error = process_exception(bad_request_exception)
    #     data = {'error_msg': error}
    except InvalidHeaderError:
        data = {'error_msg': JWT_HEADER_ERROR_MESSAGE}
    except NoAuthorizationError:
        data = {'error_msg': MISSING_JWT_ERROR_MESSAGE}
    # except DecodeError as error:
    #     data = {'error_msg': error.args[0]}
    except (InvalidSignatureError, InvalidAlgorithmError):
        data = {'error_msg': JWT_SIGNATURE_MISMATCH}
    except Exception as exception_raised:
        error = process_exception(exception_raised)
        data = {'error_msg': error}
    return data


def process_exception(exception_raised, message="Unable to authorize"):
    if getattr(exception_raised, 'data', None):
        message = exception_raised.data.get('message', exception_raised.data)
    elif getattr(exception_raised, 'description', None):
        message = exception_raised.description
    elif getattr(exception_raised, 'args', []):
        message = exception_raised.args[0]
    return message
