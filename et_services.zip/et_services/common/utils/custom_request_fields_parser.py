"""
This module contains custom request parameter validators
"""
import datetime

from validate_email import validate_email

from ..constants import SUPPORTED_LOCALES, VALID_CURRENCIES


def language(value):
    """
    Validates that provided language is among supported locales
    :param str value: Locale
    :rtype: str
    """
    if isinstance(value, str):
        if not value or value.lower() in SUPPORTED_LOCALES:
            return value.lower()
        raise ValueError("Invalid language '{}'".format(value))


def currency(value):
    """
    Validates that provided currency is among supported currencies
    :param str value: Currency
    :rtype: str
    """
    if isinstance(value, str):
        if not value or value.upper() in VALID_CURRENCIES:
            return value
        raise ValueError('Invalid currency "{}"'.format(value))


def email(_email):
    """
    Validates provided email
    :param str _email: Email to be validated
    :rtype: str
    """
    if validate_email(_email):
        return _email
    else:
        raise ValueError('Invalid Email "{}"'.format(_email))


def device_list_for_sign_up(device_os):
    """
    Checks that the device os is android or ios or blackberry or wp
    """
    if isinstance(device_os, str):
        device_os_lower = device_os.lower()
        if device_os_lower in ['ios', 'android', 'web', ""]:
            return device_os_lower
        raise ValueError('{} is not a valid device os'.format(device_os))
    raise ValueError('Invalid __platform type, expected string got {}'.format(type(device_os)))


def validate_gender(gender):
    """
    Validates that user is male or female
    """
    if isinstance(gender, str):
        gender = gender.lower()
        if gender in ['', 'male', 'female']:
            return gender
        raise ValueError('{} is not a valid gender'.format(gender))
    raise ValueError('"{}" is not of type string'.format(gender))


def marital_status(status):
    status = status.lower()
    if status in ('married', 'unmarried', ""):
        return status
    else:
        raise ValueError('"{}" is not a valid marital_status'.format(status))


def date_validator(_date):
    """
    Formats date
    :param str _date: Datetime str
    """
    try:
        return datetime.datetime.strptime(_date, "%Y-%m-%d")
    except:
        raise ValueError('"{}" is invalid date '.format(_date))


def boolean(value):
    """Parse the string ``"true"`` or ``"false"`` as a boolean (case
    insensitive). Also accepts ``"1"`` and ``"0"`` as ``True``/``False``
    (respectively). If the input is from the request JSON body, the type is
    already a native python boolean, and will be passed through without
    further parsing.
    """
    if isinstance(value, bool):
        return value

    if value is None:
        raise ValueError("boolean type must be not-null")
    value = str(value).lower()
    if value in ('true', '1', 1, 'True'):
        return True
    if value in ('false', '0', 0, '', 'False'):
        return False
    raise ValueError("Invalid literal for boolean(): {0}".format(value))


def custom_dict_parser(_dict, schema):
    """
    Validates _dict according to the schema
    :param dict _dict: Dict
    :param dict schema: Schema dict
    """
    for key, value in schema.items():
        if value['required'] and \
                _dict.get(key) is None \
                and not (value.get('optional_composite_key') and
                         _dict.get(value.get('optional_composite_key'))):
            raise ValueError("missing '{}'".format(key))
        if _dict.get(key):
            if not isinstance(_dict[key], value['type']):
                raise ValueError("Invalid type of '{}', expected '{}' got '{}'".format(
                    key, value['type'],
                    type(_dict[key]))
                )
        else:
            _dict[key] = schema.get('default')


def validate_platform(platform):
    """
    Validates that __platform is valid
    """
    if isinstance(platform, str):
        platform = platform.lower()
        if platform in ['ios', 'android', 'web']:
            return platform
        raise ValueError('{} is not a valid platform'.format(platform))
    raise ValueError('{} is not a of type string'.format(platform))
