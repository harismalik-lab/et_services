"""
Custom Exceptions
"""
from werkzeug.exceptions import HTTPException


class InvalidConfigResource(Exception):
    """
    Raises when BaseResource configs are missing or invalid.
    """
    pass


class EmailNotVerifiedException(HTTPException):
    """
    Raises when a user's email isn't verified.
    """
    pass


class PrioException(Exception):
    """
    Raised in case of invalid prio product.
    """
    def __bool__(self):
        return False
