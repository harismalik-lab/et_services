"""
Package table of Entertainer Travel schema.
"""
import datetime

from sqlalchemy import Column, DateTime, Float, Integer, String, Text, text

from ..constants import ENTERTAINER_TRAVEL
from ..models.db import db
from ..models.mixin import Mixin


class Package(db.Model, Mixin):
    __tablename__ = 'packages'
    __table_args__ = {'schema': ENTERTAINER_TRAVEL}

    id = Column(Integer, primary_key=True)
    merchant_id = Column(Integer, index=True)
    outlet_id = Column(Integer, index=True)
    offer_id = Column(Integer)
    short_name = Column(String(50))
    description = Column(String(100))
    price = Column(Float)
    currency = Column(String(4))
    discounted_price = Column(Float)
    discounted_currency = Column(String(4))
    room_type_id = Column(Integer)
    inclusions = Column(Text)
    terms = Column(Text)
    is_best_offer = Column(Integer, server_default=text("'0'"))
    is_refundable = Column(Integer, server_default=text("'0'"))
    is_dine = Column(Integer, server_default=text("'0'"))
    is_relax = Column(Integer, server_default=text("'0'"))
    is_brunch = Column(Integer, server_default=text("'0'"))
    is_play = Column(Integer, server_default=text("'0'"))
    cancellation_percent_off = Column(Float)
    days_before_checkin = Column(Integer)
    no_of_nights = Column(Integer, default=1)
    cancellation_notes = Column(String(300))
    is_active = Column(Integer, index=True, server_default=text("'1'"))
    validity_date = Column(DateTime)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @classmethod
    def get_cheapest_package(cls, merchant_id, outlet_id, offer_ids):
        """
        Returns outlet package price which is cheapest.

        :param int merchant_id: ID of the HWW instant booking merchant.
        :param int outlet_id: ID of the HWW instant booking outlet.
        :param list offer_ids: ID of the HWW instant booking offer.
        :rtype: tuple
        """
        query = cls.query.with_entities(cls.discounted_price, cls.no_of_nights)
        query = query.filter(
            cls.merchant_id == merchant_id,
            cls.outlet_id == outlet_id,
            cls.offer_id.in_(offer_ids),
            cls.is_active == 1,
            cls.validity_date > datetime.datetime.now()
        )
        query = query.order_by(cls.discounted_price.asc()).all()
        if len(query):
            query = query[0]
            return query.discounted_price, query.no_of_nights
        return 0, ''
