"""
Top Up Offer Model class
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, DateTime, Float, String, or_
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class TopUpOffer(db.Model):
    __tablename__ = 'top_up_offers'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    TYPE_VIRTUAL_CURRENCY = 1

    id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(11), index=True)
    primary_user_id = Column(INTEGER(11), index=True)
    location_id = Column(INTEGER(11), index=True)
    type = Column(TINYINT(1), default=1)
    offer_id = Column(INTEGER(11), index=True)
    merchant_id = Column(INTEGER(11))
    product_id = Column(INTEGER(11), index=True)
    amount = Column(Float)
    active = Column(TINYINT(1), default=1)
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    activation_type = Column(String(10))
    activation_type_id = Column(INTEGER(11))
    expiration_date = Column(DateTime)

    @classmethod
    def get_top_up_offers(cls, user_id, location_id, merchant_id, offer_type=1, offer_ids=None, primary_user_id=None):
        """
        Returns topped up offers against provided criteria
        :param int primary_user_id: Family owner user id
        :param int user_id: User Id
        :param int location_id: Location Id
        :param int merchant_id: Merchant Id
        :param int offer_type: Offer Type
        :param list offer_ids: Offer ids
        """
        query = cls.query.with_entities(cls.offer_id, cls.merchant_id, cls.product_id, cls.amount).filter(
            cls.active == 1,
            cls.type == offer_type
        )
        if primary_user_id == user_id or not primary_user_id:
            query = query.filter(
                cls.customer_id == user_id,
                or_(
                    coalesce(cls.primary_user_id, 0) == 0,
                    cls.primary_user_id == user_id
                )
            )
        elif primary_user_id:
            query = query.filter(
                cls.primary_user_id == primary_user_id
            )

        if location_id:
            query = query.filter(cls.location_id == location_id)

        if merchant_id:
            query = query.filter(cls.merchant_id == merchant_id)

        if offer_ids:
            query = query.filter(cls.offer_id.in_(offer_ids))

        return query.all()
