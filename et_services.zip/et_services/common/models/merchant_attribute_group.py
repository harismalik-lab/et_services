"""
This module contains Merchant Attribute Group and Merchant Attribute Group Translation Model
"""
from sqlalchemy import Column, String, and_
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant_attribute_group_translation import MerchantAttributeGroupTranslation
from ..models.mixin import Mixin


class MerchantAttributeGroup(db.Model, Mixin):
    __tablename__ = 'merchant_attribute_group'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    category_id = Column(INTEGER(11), nullable=False)
    name = Column(String(100), nullable=False)
    order_id = Column(TINYINT(1))

    @classmethod
    def get_by_locale(cls, locale=EN):
        """
        Returns merchant attribute groups against locale
        :param str locale: Locale
        """
        return cls.query.with_entities(
            cls.id,
            cls.category_id,
            MerchantAttributeGroupTranslation.name,
            cls.order_id
        ).join(
            MerchantAttributeGroupTranslation,
            and_(
                cls.id == MerchantAttributeGroupTranslation.attribute_group_id,
                MerchantAttributeGroupTranslation.locale == locale
            )
        ).all()
