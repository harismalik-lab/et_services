"""
Company Home Screen Branding model
"""
from flask import g
from sqlalchemy import TIMESTAMP, Column, String, text
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from .. import constants
from ..constants import EN
from ..models.category_home_screen_configurations_translation import CategoryHomeScreenConfigurationsTranslation
from ..models.db import db
from ..models.mixin import Mixin

cache = g.cache


class CategoryHomeScreenConfiguration(db.Model, Mixin):
    __tablename__ = 'category_home_screen_configurations'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    SECTION_TYPE_OUTLET_LISTING = "outlet_listing"
    SECTION_TYPE_MERCHANTS_LISTING = "merchant_listing"
    SECTION_FOR_ALL_OUTLETS = "all"
    SECTION_FOR_MONTHLY = "monthly"
    SECTION_FOR_CHEERS = "cheers"
    SECTION_FOR_DELIVERY = "delivery"
    SECTION_FOR_CUISINE = "cuisine"
    SECTION_FOR_SUB_CATEGORY = "sub_category"
    SECTION_FOR_FEATURED_MERCHANTS = "featured_merchants"
    SECTION_TYPE_BUTTON = "button"
    SECTION_TYPE_FILTER = "filter"
    SECTION_FOR_MORE_AFRICA = "more_africa"
    ONLINE_DELIVERY_TITLE = "Online Delivery"
    ONLINE_DELIVERY_BUTTON_TITLE = "ONLINE DELIVERY"
    ONLINE_DELIVERY_TAKEAWAYS_TITLE = "Order Online"
    ONLINE_TAKEAWAYS_TITLE = "Order Takeaways"
    ONLINE_DELIVERY_TAKEAWAYS_OFFERS_BUTTON_TITLE = "Order Online"
    ONLINE_TAKEAWAY_OFFERS_BUTTON_TITLE = "Order Takeaways"

    SECTION_ID_ALL_OUTLETS = 1
    SECTION_ID_MONTHLY = 2
    SECTION_ID_CHEERS = 3
    SECTION_ID_DELIVERY = 4
    SECTION_ID_CUISINE = 5
    SECTION_ID_SUB_CATEGORY = 6
    SECTION_ID_FEATURED_MERCHANTS = 7
    SECTION_ID_MORE_AFRICA = 8

    SECTION_ID_FOR_SECTION = {
        SECTION_FOR_ALL_OUTLETS: SECTION_ID_ALL_OUTLETS,
        SECTION_FOR_MONTHLY: SECTION_ID_MONTHLY,
        SECTION_FOR_CHEERS: SECTION_ID_CHEERS,
        SECTION_FOR_DELIVERY: SECTION_ID_DELIVERY,
        SECTION_FOR_SUB_CATEGORY: SECTION_ID_SUB_CATEGORY,
        SECTION_FOR_FEATURED_MERCHANTS: SECTION_ID_FEATURED_MERCHANTS,
        SECTION_FOR_MORE_AFRICA: SECTION_ID_MORE_AFRICA,
        SECTION_FOR_CUISINE: SECTION_ID_CUISINE
    }

    TAB_SECTION_TYPE_ID_ALL_OFFERS = 1
    TAB_SECTION_TYPE_ID_DELIVERY = 2
    TAB_SECTION_TYPE_ID_CHEERS = 3
    TAB_SECTION_TYPE_ID_MONTHLY = 4
    TAB_SECTION_TYPE_ID_HOT_SUMMER_NIGHTS = 5
    TAB_SECTION_TYPE_ID_MORE_AFRICA = 6
    TAB_SECTION_TYPE_ID_LOCKED = 7
    TAB_SECTION_TYPE_ID_TAKE_AWAY = 8

    id = Column(INTEGER(11), primary_key=True)
    location_id = Column(TINYINT(1), index=True)
    company = Column(String(20))
    company_id = Column(INTEGER(11))
    category = Column(String(45), index=True)
    category_id = Column(TINYINT(1))
    title = Column(String(45))
    section_type = Column(String(45))
    section_for = Column(String(45))
    identifier = Column(String(50))
    rendering_mode = Column(String(50))
    type = Column(TINYINT(1))
    show_view_all_button = Column(BIT(1))
    display_order = Column(TINYINT(1), nullable=False, server_default=text("'50'"))
    item_limit = Column(INTEGER(11), server_default=text("'0'"))
    api_params = Column(String(500), server_default=text("'0'"))
    is_active = Column(BIT(1), nullable=False)
    header_background_color = Column(String(10))
    background_color = Column(String(10))
    date_created = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    date_updated = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_category_home_screen_configurations(location_id, category, company, locale=EN):
        """
        Gets category home screen configurations
        :param int location_id: location id
        :param str category: home screen categories, e.g: 'restaurants and bars'
        :param str company: company name
        :param str locale: language
        :rtype: list
        """
        query = CategoryHomeScreenConfiguration.query.join(
            CategoryHomeScreenConfigurationsTranslation,
            CategoryHomeScreenConfiguration.id == CategoryHomeScreenConfigurationsTranslation.config_id
        )
        query = query.with_entities(
            CategoryHomeScreenConfiguration.id,
            CategoryHomeScreenConfiguration.category_id,
            CategoryHomeScreenConfiguration.identifier,
            CategoryHomeScreenConfiguration.rendering_mode,
            CategoryHomeScreenConfiguration.type,
            CategoryHomeScreenConfiguration.section_type,
            CategoryHomeScreenConfiguration.section_for,
            CategoryHomeScreenConfiguration.display_order,
            CategoryHomeScreenConfiguration.header_background_color,
            CategoryHomeScreenConfiguration.background_color,
            CategoryHomeScreenConfiguration.show_view_all_button,
            CategoryHomeScreenConfiguration.item_limit,
            coalesce(CategoryHomeScreenConfigurationsTranslation.title).label('title'),
            coalesce(CategoryHomeScreenConfigurationsTranslation.title_locked).label('title_locked')
        )
        query = query.filter(
            CategoryHomeScreenConfiguration.location_id == location_id,
            CategoryHomeScreenConfiguration.is_active == 1,
            CategoryHomeScreenConfiguration.company == company,
            CategoryHomeScreenConfiguration.category == category,
            CategoryHomeScreenConfigurationsTranslation.locale == locale
        )
        query = query.order_by(CategoryHomeScreenConfiguration.display_order.asc())
        return query.all()
