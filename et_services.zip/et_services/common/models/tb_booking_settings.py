"""
Tb Booking Settings Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class TbBookingSetting(db.Model):
    __tablename__ = 'tb_booking_settings'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    party_size_1 = Column(TINYINT(1))
    party_size_2 = Column(TINYINT(1))
    party_size_3 = Column(TINYINT(1))
    party_size_4 = Column(TINYINT(1))
    time_zone = Column(String(50))
    is_published = Column(TINYINT(1), nullable=False, index=True, default=0)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_date = Column(DateTime, nullable=False, default=datetime.datetime.now)
    updated_by = Column(INTEGER(11))
    lead_time = Column(TINYINT(1), default=1)
    group_size = Column(SMALLINT(10), default=1)
    disabled = Column(TINYINT(1), nullable=False, default=0)
    cancel_lead_time = Column(TINYINT(1), default=0)
    setting_for_all = Column(BIT(1))
