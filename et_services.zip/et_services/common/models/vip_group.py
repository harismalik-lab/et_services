"""
Vip Group Model Class
"""
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class VipGroup(db.Model):
    __tablename__ = 'vip_group'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    name = Column(String(100))
    active = Column(BIT(1))
    auto_from_web = Column(INTEGER(11))
    isreusable = Column(BIT(1))
    expiry_date = Column(DateTime)
    usage_limit = Column(INTEGER(11))
    is_email_to_send = Column(TINYINT(1))
    is_slice = Column(TINYINT(1))
    company_id = Column(INTEGER(11))
    is_cheers_product_included = Column(TINYINT(1))
    earn_through_smiles = Column(TINYINT(1))
    create_date = Column(DateTime)
