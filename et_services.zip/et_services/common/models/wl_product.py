"""
WL Products Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.location import Location
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class WlProduct(db.Model, Mixin):
    __tablename__ = 'wlproducts'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    product_sku = Column(String(20), index=True)
    wl_company = Column(String(6))
    location_id = Column(INTEGER(11))
    istravel = Column(BIT(1), nullable=False, default=0)
    active = Column(BIT(1), nullable=False, default=1)
    isnew = Column(BIT(1), nullable=False, default=0)
    ismember = Column(BIT(1), nullable=False, default=0)
    user_group = Column(TINYINT(1), default=1)
    is_cheers = Column(BIT(1), default=0)
    is_delivery = Column(BIT(1), default=0)
    is_more_sa = Column(BIT(1), default=0)

    @classmethod
    def get_configured_products(cls, company, user_groups=None, location_id=0):
        """
        Gets the configured products
        :param int location_id: Location Id
        :param str company: Company of the user
        :param list|None user_groups: user groups
        :rtype: list
        """
        from ..models.product import Product
        results = []
        try:
            if user_groups:
                query = cls.query.join(
                    Product, Product.sf_id == cls.product_sku
                ).with_entities(
                    Product.id, cls.user_group
                ).filter(
                    Product.isactive,
                    cls.wl_company == company,
                    cls.user_group.in_(user_groups),
                )
                if location_id:
                    query = query.filter(cls.location_id == location_id)
                results = query.all()
        except Exception as e:
            print("Error occurred while getting configured products : {0}".format(str(e)))
        finally:
            return results

    @classmethod
    def get_configured_product_ids(cls, company, user_groups=None, location_id=0):
        """
        Get configured product ids
        :param int location_id: Location Id
        :param str company: Company
        :param user_groups:
        :return:
        """
        product_ids = []
        group_products = {}
        results = cls.get_configured_products(company, user_groups, location_id)
        if results:
            for result in results:
                if not group_products.get(result[1]):
                    group_products[result[1]] = [result[0]]
                else:
                    group_products[result[1]].append(result[0])
            for user_group in user_groups:
                product_ids.extend(group_products.get(user_group, []))
        return product_ids

    @classmethod
    def get_active_by_company_and_skus(cls, company, skus):
        """
        Returns WlProducts against company and provided skus list
        :param str company: Company code
        :param list skus: Skus list
        """
        return cls.query.with_entities(
            cls.product_sku,
            cls.location_id,
            cls.user_group
        ).filter(
            cls.wl_company == company,
            cls.product_sku.in_(skus),
            cls.active == 1
        ).all()

    @classmethod
    def get_active_by_company(cls, company):
        """
        Returns WlProducts against company and provided skus list
        :param str company: Company code
        """
        return cls.query.with_entities(
            cls.id,
            cls.product_sku,
            cls.location_id,
            Location.flag.label('iso_code'),
            cls.user_group,
            cls.is_cheers,
            cls.is_delivery,
            cls.is_more_sa,
            cls.ismember.label('is_member'),
            cls.istravel.label('is_travel'),
            cls.isnew.label('is_new')
        ).join(
            Location, cls.location_id == Location.id
        ).filter(
            cls.wl_company == company,
            cls.active == 1
        ).all()

    @classmethod
    def get_user_groups_against_location_id_and_company(cls, location_id, company):
        """
        Returns user_group ids against location id and company
        :param int location_id: Location id
        :param str company: Company
        """
        return cls.query.with_entities(cls.user_group).filter(
            cls.active == 1,
            cls.location_id == location_id,
            cls.wl_company == company
        ).all()
