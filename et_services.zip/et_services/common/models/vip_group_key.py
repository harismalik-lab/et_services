"""
Vip Group Key Model class
"""
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.product_ent_active import ProductEntActive
from ..models.vip_group import VipGroup
from ..models.vip_group_product import VipGroupProduct


class VipGroupKey(db.Model):
    __tablename__ = 'vip_group_key'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    group_id = Column(INTEGER(11))
    vip_key = Column(String(20))
    email = Column(String(255))
    user_id = Column(INTEGER(11))
    isused = Column(BIT(1))
    active = Column(BIT(1))
    activation_date = Column(DateTime)
    deactivation_date = Column(DateTime)

    @classmethod
    def get_by_user_id(cls, user_id):
        """
        Returns vips keys with group and product_sku against provided user_id
        :param int user_id: User Id
        """
        return cls.query.with_entities(
            VipGroup.id.label('group_id'),
            VipGroupProduct.product_sku,
            VipGroupKey.activation_date
        ).join(
            VipGroup,
            cls.group_id == VipGroup.id
        ).join(
            VipGroupProduct,
            VipGroup.id == VipGroupProduct.group_id
        ).join(
            ProductEntActive,
            VipGroupProduct.product_sku == ProductEntActive.sf_id
        ).filter(
            VipGroupKey.active == 1,
            VipGroup.active == 1,
            VipGroupKey.user_id == user_id,
            VipGroupProduct.active == 1,
            ProductEntActive.isactive == 1
        ).all()
