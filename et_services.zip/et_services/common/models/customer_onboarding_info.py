"""
Customer Onboarding Info Model
"""
from sqlalchemy import TIMESTAMP, Column, String, func, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class CustomerOnboardingInfo(db.Model, Mixin):
    __tablename__ = 'customer_onboarding_info'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(10), index=True)
    device = Column(String(10))
    device_key = Column(String(128), index=True)
    insert_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    is_primary = Column(TINYINT(1), index=True, server_default=text("'0'"))

    @classmethod
    def number_of_primary_devices(cls, customer_id):
        """
        Calculate the number of primary devices of the user
        :param int customer_id: id of customer
        :rtype: int
        """
        number_of_primary_devices = 0
        if customer_id:
            query = cls.query.with_entities(func.count(cls.is_primary).label("primary_devices"))
            query = query.filter(
                cls.customer_id == customer_id,
                cls.is_primary == 1
            )
            number_of_primary_devices = query.one().primary_devices

        return number_of_primary_devices
