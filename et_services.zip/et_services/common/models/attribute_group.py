"""
Attribute Group Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class AttributeGroup(db.Model):
    __tablename__ = 'attribute_group'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    type = Column(TINYINT(1), nullable=False, comment='1 for merchant, 2 for offer, 3 for outlet')
    category_id = Column(INTEGER(11), nullable=False)
    name = Column(String(100), nullable=False)
    order_id = Column(TINYINT(1), default=1)
