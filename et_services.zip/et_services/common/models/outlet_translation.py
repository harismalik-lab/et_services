"""
Outlet Translations Model
"""
from sqlalchemy import TIMESTAMP, Column, ForeignKey, Index, String, Text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.outlet import Outlet


class OutletTranslation(db.Model, Mixin):
    __tablename__ = 'outlet_translation'
    __table_args__ = (
        Index('idx_translation', 'outlet_id', 'locale'),
        {"schema": ENTERTAINER_WEB}
    )

    id = Column(INTEGER(11), primary_key=True)
    outlet_id = Column(ForeignKey(Outlet.id, ondelete='CASCADE', onupdate='CASCADE'), nullable=False, index=True)
    locale = Column(String(5), default='en')
    name = Column(String(255))
    description = Column(Text)
    human_location = Column(String(255))
    neighborhood = Column(String(255))
    mall = Column(String(255))
    hotel = Column(String(255))
    amz_update_time = Column(TIMESTAMP)

    # outlet = relationship('Outlet')
