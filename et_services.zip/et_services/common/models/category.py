"""
Category Model class
"""

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR

from common.models.attribute import Attribute
from common.models.attribute_translation import AttributeTranslation

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant_attribute_group import MerchantAttributeGroup
from ..models.merchant_attribute_group_translation import \
    MerchantAttributeGroupTranslation


class Category(db.Model):
    __tablename__ = 'category'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    ALL = 'All'
    BODY = 'Body'
    KIDS = 'Kids'
    LEISURE = 'Leisure'
    RESTAURANTS_AND_BARS = 'Restaurants and Bars'
    SERVICES = 'Services'
    RETAIL = 'Retail'
    TRAVEL = 'Travel'

    id = Column(INTEGER(11), primary_key=True)
    name = Column(VARCHAR(500))
    label = Column(String(50))

    @classmethod
    def get_all(cls):
        """
        Returns All categories
        :rtype: list
        """
        return cls.query.with_entities(cls.name.label("category_name"), cls.id.label("category_id")).all()

    @classmethod
    def get_merchant_attribute_groups(cls, category, locale=EN):
        """
        Returns merchant attribute groups
        :param category:
        :param str locale:
        """
        query = cls.query.join(MerchantAttributeGroup, cls.id == MerchantAttributeGroup.category_id)
        query = query.join(
            MerchantAttributeGroupTranslation,
            MerchantAttributeGroup.id == MerchantAttributeGroupTranslation.attribute_group_id
        )
        query = query.with_entities(
            MerchantAttributeGroup.id,
            MerchantAttributeGroup.category_id,
            MerchantAttributeGroup.order_id,
            MerchantAttributeGroupTranslation.name
        )
        query = query.filter(
            cls.name == category, MerchantAttributeGroupTranslation.locale == locale
        )
        return query.all()

    @classmethod
    def get_merchant_attributes(cls, category, locale=EN):
        """
        returns merchant attributes
        :param category:
        :param locale:
        :return:
        """
        query = cls.query.join(Attribute, cls.id == Attribute.category_id)
        query = query.join(
            AttributeTranslation,
            Attribute.id == AttributeTranslation.attribute_id
        )
        query = query.with_entities(
            Attribute.attribute_group_id,
            Attribute.attribute_key.label('key'),
            Attribute.attribute_type.label('type'),
            Attribute.image_url,
            AttributeTranslation.attribute_title.label('name'),
        )
        query = query.filter(
            Attribute.is_active == 1,
            AttributeTranslation.locale == locale,
            cls.name == category
        )
        query = query.order_by(Attribute.order_id.asc())
        return query.all()
