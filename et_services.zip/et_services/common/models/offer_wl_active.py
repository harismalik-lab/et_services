"""
Offer Wl Active Model
"""
from flask import g
from sqlalchemy import Column, DateTime, Index, String, func, or_
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT

from ..constants import CATEGORY_API_NAME_TRAVEL, EN, ENTERTAINER_WEB
from ..models.country_translation import CountryTranslation
from ..models.db import db
from ..models.merchant import Merchant
from ..models.merchant_translation import MerchantTranslation
from ..models.mixin import Mixin
from ..models.product import Product
from ..models.product_offer import ProductOffer
from ..models.wl_product import WlProduct

cache = g.cache


class OfferWlActive(db.Model, Mixin):
    __tablename__ = 'offer_wl_active'
    __table_args__ = (
        Index('idx_offer_status_type', 'status', 'type'),
        Index('idx_member_trial_promotion', 'type', 'promoted_from', 'promoted_to', 'status'),
        Index('idx_validity', 'valid_from', 'valid_to', 'status'),
        Index('idx_relevant', 'valid_from', 'valid_to', 'status', 'type', 'promoted_from', 'promoted_to'),
        {"schema": ENTERTAINER_WEB}
    )
    # Constants
    # -12 to -8 is set to narrow down the offer visibility.
    # Offer will be available 4 hours before its valid from date in GST (Gulf standard time)
    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM = -8
    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO = -18
    HOURS_ADJUSTMENT_FOR_OFFER_VALID_FROM = 4
    HOURS_ADJUSTMENT_FOR_OFFER_VALID_TO = 14

    TYPE_DEFAULT = 0
    TYPE_TRIAL = 1
    TYPE_MEMBER = 2
    TYPE_BOTH = 3
    TYPE_NEW_OFFER = 4
    TYPE_FEATURED_OFFER = 5  # Both New and Monthly

    NOT_REDEEMABLE = 0
    REDEEMED = 1
    REDEEMABLE = 2
    REUSABLE = 3

    SECTION_REDEEMABLE = 1
    SECTION_REDEEMED = 2
    SECTION_PINGED = 3
    SECTION_NOT_REDEEMABLE = 4
    SORT_REDEEMABLE = 1
    SORT_PURCHASED_AVAILABLE_IN_FUTURE = 2
    SORT_REDEEMED = 3
    SORT_PINGED = 4
    SORT_NOT_REDEEMABLE = 5
    SORT_EXPIRED = 6
    OFFER_TYPE_VALUE_DEFAULT = 0
    OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
    OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
    OFFER_TYPE_VALUE_GIFT = 3
    OFFER_TYPE_VALUE_PACKAGE = 4
    OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

    OFFER_TYPE_TEXT_BUY_ONE_GET_ONE_FREE = "Buy One Get One Free"
    OFFER_TYPE_TEXT_SPEND_THIS_GET_THIS = "Spend This Get That"
    OFFER_TYPE_TEXT_PERCENTAGE_OFF = "% Off"
    OFFER_TYPE_TEXT_GIFT = "Gift"
    OFFER_TYPE_TEXT_PACKAGE = "Package"
    OFFER_TYPE_TEXT_FIX_PRICE_OFF = "Fixed Price Off"

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    sf_id = Column(String(20), unique=True, comment='Salesforce ID')
    merchant_id = Column(INTEGER(11), nullable=False, index=True)
    valid_from = Column(DateTime)
    valid_to = Column(DateTime)
    savings_estimate = Column(INTEGER(11), default=0, comment='Savings estimate is in AED.')
    offer_sequence = Column(TINYINT(1), default=0)
    type = Column(
        SMALLINT(6),
        index=True,
        default=0,
        comment='Types:\\n\\n0 = default, normal offer (belongs to a product, purchasable in book or bundles)\\'
                'n1 = trial offer (given to trial members for free, does not need to belong to a product)\\'
                'n2 = member offer (give to full members for free, does not need to belong to a  /* comment '
                'truncated */ /*product)*/'
    )
    voucher_type = Column(SMALLINT(6))
    spend = Column(SMALLINT(6), default=0)
    reward = Column(SMALLINT(6), default=0)
    percentage_off = Column(TINYINT(1), default=0)
    no_of_people = Column(TINYINT(1), default=0)
    voucher_restrictions = Column(String(255))
    voucher_restriction1 = Column(SMALLINT(6))
    voucher_restriction2 = Column(SMALLINT(6))
    promoted_from = Column(DateTime)
    promoted_to = Column(DateTime)
    status = Column(
        String(20),
        index=True,
        default='Active',
        comment='Draft, Approved, Active, Inactive'
    )
    quota = Column(INTEGER(11), default=0)
    quantity = Column(INTEGER(11), default=1)
    has_red_custom_code = Column(BIT(1))
    redemptions_limit_in_x_hours = Column(
        SMALLINT(6),
        default=4,
        comment='This is to apply a cap on monthly offers'
    )
    hours_to_consider_for_redemption_cap = Column(
        SMALLINT(6),
        default=24,
        comment='Number of hours to restrict limit on redemption'
    )
    merchant_email = Column(String(255))
    merchant_website = Column(String(255))
    merchant_telephone = Column(String(45))
    merchant_fax = Column(String(45))
    merchant_cuisine = Column(String(255))
    merchant_category = Column(String(255), index=True)
    sub_category = Column(String(255))
    digital_section = Column(String(255))
    group_sf_id = Column(String(20))
    group_telephone = Column(String(45))
    group_website = Column(String(255))
    merchant_instagram = Column(String(255))
    inactive_reason = Column(String(255))
    local_currency = Column(String(10))
    savings_estimate_local_currency = Column(INTEGER(11), default=0)
    item_code = Column(String(45))
    is_point_based_offer = Column(TINYINT(1), default=0)
    gems_points = Column(INTEGER(11))

    @classmethod
    def get_merchant_offers(cls, locale, bundled_product_skus, location_id=None, return_query_object=False):
        """
        get merchant offers
        :param bool return_query_object: Return query object
        :param int location_id: Location Id
        :param str locale:
        :param [list] bundled_product_skus:
        :return:
        """
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer

        query = cls.query.join(ProductOffer, cls.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(MerchantTranslation, MerchantTranslation.merchant_id == Merchant.id)
        query = query.filter(Outlet.active == 1, MerchantTranslation.locale == locale)
        query = query.with_entities(
            Merchant.id,
            Merchant.category,
            Merchant.logo_retina_url.label('logo_url'),
            Merchant.logo_non_retina_url,
            Merchant.logo_offer_retina_url,
            Merchant.logo_offer_non_retina_url,
            Merchant.photo_retina_url.label('photo_url'),
            Merchant.photo_non_retina_url,
            Merchant.digital_section,
            MerchantTranslation.name,
            MerchantTranslation.cuisine,
            MerchantTranslation.description,
            func.group_concat(Outlet.id).label('outlet_ids'),
            func.max(Product.is_cheers).label('is_cheers'),
            func.max(Product.delivery_enabled).label('is_delivery'),
            func.max(Product.is_more_sa).label('is_more_sa'),
            func.max(Product.ismember).label('is_member'),
        )

        if bundled_product_skus:
            query = query.filter(Product.sf_id.in_(bundled_product_skus))

        if location_id:
            # TODO: Add Blue offers check here
            query = query.filter(Product.location_id == location_id)

        query = query.group_by(Merchant.id)
        query = query.order_by(MerchantTranslation.name.asc())
        return query.all() if not return_query_object else query

    @classmethod
    def get_by_offer_and_product_id(cls, offer_id, product_id):
        """
        Returns offer against offer and product ids
        :param int offer_id: Offer Id
        :param int product_id: Product Id
        :rtype: OfferWlActive
        """
        return cls.query.with_entities(
            cls.id,
            cls.valid_from,
            cls.valid_to,
            cls.type,
            cls.quantity,
            ProductOffer.product_id.label('product_id'),
            cls.merchant_id,
            cls.hours_to_consider_for_redemption_cap,
            cls.redemptions_limit_in_x_hours,
            cls.savings_estimate_local_currency,
            cls.sf_id
        ).join(
            ProductOffer, cls.id == ProductOffer.offer_id
        ).join(
            Product, ProductOffer.product_id == Product.id
        ).filter(
            cls.id == offer_id, Product.id == product_id
        ).first()

    @classmethod
    def get_by_offer_ids_and_product_ids(cls, offer_ids, product_ids):
        """
        Returns offer against offer and product ids
        :param list offer_ids: Offer Id
        :param list product_ids: Product Id
        :rtype: list
        """
        return cls.query.with_entities(
            cls.id,
            cls.valid_from,
            cls.valid_to,
            cls.type,
            cls.quantity,
            ProductOffer.product_id.label('product_id')
        ).join(
            ProductOffer, cls.id == ProductOffer.offer_id
        ).join(
            Product, ProductOffer.product_id == Product.id
        ).filter(
            cls.id.in_(offer_ids), Product.id.in_(product_ids)
        ).all()

    @classmethod
    def get_outlet_attribute_values(cls, company, attribute, location_id=0, locale='en', search_keyword="",
                                    category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.

        :param str company: Company code
        :param str attribute: Outlet attribute name
        :param int location_id: Id of location
        :param str locale: Language
        :param str search_keyword: search string to find in attribute
        :param str category: Merchant category

        :rtype list: Containing the attribute values
        """
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation

        query = cls.query.join(ProductOffer, cls.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletOffer.outlet_id == OutletTranslation.outlet_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(WlProduct, WlProduct.product_sku == Product.sf_id)
        query = query.with_entities(getattr(OutletTranslation, attribute))
        query = query.filter(OutletTranslation.locale == locale,
                             Product.isactive == 1,
                             WlProduct.wl_company == company)

        if category:
            query = query.filter(Merchant.category == category)

        if location_id:
            query = query.filter(Product.location_id == location_id)

        if search_keyword:
            query = query.filter(getattr(OutletTranslation, attribute).like('%{}%'.format(search_keyword)))

        query = query.filter(cls.status == 'Active').order_by(getattr(OutletTranslation, attribute))
        query = query.distinct()
        return query.all()

    @classmethod
    def get_attribute_values(cls, attribute, product_ids, location_id=False, locale='en', search_keyword="",
                             category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation

        query = cls.query.join(ProductOffer, cls.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletOffer.outlet_id == OutletTranslation.outlet_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.with_entities(getattr(OutletTranslation, attribute))
        query = query.filter(OutletTranslation.locale == locale, Product.isactive == 1, cls.status == 'Active')

        if category:
            query = query.filter(Merchant.category == category)

        if location_id:
            query = query.filter(Product.location_id == location_id)

        if search_keyword:
            query = query.filter(getattr(OutletTranslation, attribute).like('%{}%'.format(search_keyword)))

        if product_ids:
            query = query.filter(Product.id.in_(product_ids))

        query = query.order_by(getattr(OutletTranslation, attribute))
        query = query.distinct()
        return query.all()

    @classmethod
    def get_country_hotels(cls, product_sku, locale='en', search_keyword=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.
        """
        from ..models.country import Country
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation

        query = cls.query.join(ProductOffer, cls.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletOffer.outlet_id == OutletTranslation.outlet_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.filter(
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
            Merchant.category == CATEGORY_API_NAME_TRAVEL,
            Product.isactive == 1
        )

        if search_keyword:
            query = query.filter(OutletTranslation.hotel.like('%{}%'.format(search_keyword)))

        query = query.filter(cls.status == 'Active')
        query = query.filter(Product.sf_id.in_(product_sku))
        query.with_entities(
            func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name).distinct().label('item'),
            OutletTranslation.hotel,
            CountryTranslation.name
        )
        query = query.order_by(func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name))
        query = query.distinct()
        return query.all()

    @classmethod
    def get_country_areas(cls, location_id=False, locale='en', search_keyword="", category="", product_sku=None):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that
        are assigned for the supplied Location.
        """
        from ..models.country import Country
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation

        query = cls.query.join(ProductOffer, cls.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletOffer.outlet_id == OutletTranslation.outlet_id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.filter(
            cls.status == 'Active',
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
            Merchant.category == CATEGORY_API_NAME_TRAVEL,
            Product.isactive == 1
        )

        if product_sku:
            query = query.filter(Product.sf_id.in_(product_sku))
        # Determine bundled Product if we're supplied a Location
        # Bundled Products are usually Travel books/bundle given for free with a regular Product
        # Remember: Travel Products have NULL for location_id
        if category.lower() != 'all':
            query = query.filter(Merchant.category == category)
        if location_id:
            query = query.filter(Outlet.location_id == location_id, Product.location_id == location_id)
        if search_keyword:
            query = query.filter(OutletTranslation.neighborhood.like('%{}%'.format(search_keyword)))

        query.with_entities(
            func.concat(OutletTranslation.neighborhood, ', ', CountryTranslation.name).distinct().label('item'),
            OutletTranslation.neighborhood,
            CountryTranslation.name
        )
        query = query.order_by(func.concat(OutletTranslation.neighborhood, ', ', CountryTranslation.name))
        query = query.distinct()
        return query.all()

    @classmethod
    def any_offer_monthly_or_not_pingable(cls, offer_ids):
        """
        Returns True if any offer is monthly or it's merchant doesn't allow pings
        :param list offer_ids: Offer Ids
        :rtype: bool
        """
        if offer_ids:
            query = cls.query.with_entities(cls.id)
            query = query.join(Merchant, cls.merchant_id == Merchant.id)
            query = query.filter(cls.id.in_(offer_ids))
            query = query.filter(
                or_(
                    Merchant.is_pingable != 1,
                    cls.type == cls.TYPE_MEMBER
                )
            )
            return bool(query.count())
        return False

    @classmethod
    def get_offer_quantities(cls, offer_ids):
        """
        Returns offer quantities
        :param list offer_ids: Offer Ids
        :rtype: dict
        """
        quantities = {}
        if offer_ids:
            query = cls.query.with_entities(cls.id, cls.quantity)
            offers = query.filter(cls.id.in_(offer_ids)).all()
            quantities = {}
            for offer in offers:
                quantities.update({
                    offer.id: quantities.get(offer.id, 0) + offer.quantity
                })
        return quantities

    @classmethod
    @cache.memoize(3600)
    def get_cuisines_by_locale(cls, locale=EN):
        """
        Returns cuisines for merchant attributes
        :param str locale: locale
        """
        # mt = aliased(MerchantTranslation, name='mt')
        return db.session.bind.execute(
            "SELECT DISTINCT mt.cuisine FROM {entertainer_web}.offer_wl_active as o "
            "INNER JOIN {entertainer_web}.product_offer_wl_active AS po ON o.id=po.id "
            "INNER JOIN {entertainer_web}.product AS p ON po.product_id=p.id "
            "INNER JOIN {entertainer_web}.wlproducts AS wl ON  wl.product_sku=p.sf_id "
            "INNER JOIN {entertainer_web}.merchant AS m ON o.merchant_id=m.id "
            "INNER JOIN {entertainer_web}.merchant_translation AS mt ON m.id=mt.merchant_id AND mt.locale=%s "
            "WHERE mt.cuisine IS NOT NULL AND mt.cuisine != '' ORDER BY mt.cuisine ASC".format(
                entertainer_web=ENTERTAINER_WEB),
            (locale,)
        )
