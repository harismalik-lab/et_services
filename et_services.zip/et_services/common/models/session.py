"""
Session Model
"""
import datetime
import time

from sqlalchemy import TIMESTAMP, Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.mixin import Mixin


class Session(db.Model, Mixin):
    __tablename__ = 'session'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    session_token = Column(String(100))
    customer_id = Column(INTEGER(10), nullable=False)
    member_type = Column(TINYINT(1))
    primary_user_id = Column(INTEGER(11))
    family_id = Column(INTEGER(11))
    include_cheers = Column(BIT(1))
    data = Column(String(5120))
    date_cached = Column(INTEGER(10))
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    last_activity_date = Column(TIMESTAMP, default=datetime.datetime.now)
    refresh_required = Column(BIT(1))
    guest_email = Column(String(255))
    guest_nickname = Column(String(255))
    guest_relationship = Column(String(255))
    isactive = Column(BIT(1), nullable=False, default=1)
    company = Column(String(20), default='entertainer')
    isagreed = Column(BIT(1))
    date_agreed = Column(DateTime)
    ping_offer_limit = Column(INTEGER(10), default=10)
    app_version = Column(String(255))
    product_ids = Column(String(2500))
    extended_trail_group_ids = Column(String(300))

    @classmethod
    @with_master
    def get_by_company_and_session_token(cls, company, session_token):
        """
        Returns active session against company and session_token
        :param str company: Company
        :param str session_token: Session Token
        :rtype: Session
        """
        return cls.query.filter(
            cls.company == company,
            cls.session_token == session_token,
            cls.isactive
        ).first()

    @classmethod
    @with_master
    def get_by_company_and_session_token_with_like_operator(cls, company, session_token):
        """
        Commits changes
        :return:
        """
        db.session.commit()

    @classmethod
    def get_by_company_and_session_token_with_like_operator(cls, company, session_token):
        """
        Returns active session against company and session_token
        :param str company: Company
        :param str session_token: Session Token
        :rtype: Session
        """
        return cls.query.filter(
            cls.company.like('{}%'.format(company)),
            cls.session_token == session_token,
            cls.isactive
        ).first()

    @classmethod
    @with_master
    def deactivate_sessions(cls, company, customer_id):
        """
        Marks sessions inactive against company and customer_id
        :param str company: Company
        :param int customer_id: User Id
        :rtype: bool
        """
        cls.query.filter(
            cls.company == company,
            cls.customer_id == customer_id
        ).update(
            {
                'isactive': 0
            }
        )
        db.session.commit()
        return True

    def to_dict(self):
        """
        convert session obj into dict
        :return: dict
        """
        from ..models.ent_customer_profile import EntCustomerProfile

        return {
            "id": self.id,
            "session_token": self.session_token,
            "is_using_trial": False,
            "user_id": self.customer_id,
            "customer_id": self.customer_id,
            "new_member_group": EntCustomerProfile.MEMBERSTATUS_PROSPECT,
            "company": self.company
        }

    @classmethod
    @with_master
    def mark_all_sessions_for_customer_date_cached(cls, customer_id, company):
        """
        Marks is active flag as 1
        :param int customer_id: id of the customer
        :param str company: company of the user
        """
        cls.query.filter(cls.company == company,
                         cls.customer_id == customer_id,
                         cls.isactive == 1
                         ).update({'date_cached': 1})
        db.session.commit()
        return True

    @classmethod
    @with_master
    def update_all_sessions_for_customer(cls, customer_id, product_ids, company):
        """
        Updates all the sessions of the customer on the base of the company and id
        :param int customer_id: id of customer
        :param str product_ids: joined str of product ids
        :param str company: company of the customer
        """
        date_cached = time.time()

        changes = {'date_cached': date_cached,
                   'refresh_required': 1
                   }
        if product_ids:
            changes.update({'product_ids': product_ids})

        cls.query.filter(cls.company == company,
                                  cls.customer_id == customer_id,
                                  ).update(changes)
        db.session.commit()
        return True

    @classmethod
    @with_master
    def deactivate_against_session_token(cls, session_token):
        """
        Deactivates provided session token
        :param str session_token: Session Token
        :rtype: bool
        """
        cls.query.filter(
            cls.session_token == session_token,
            cls.isactive
        ).update(
            {
                'isactive': 0
            }
        )
        db.session.commit()
        return True

    @classmethod
    def update_customer_sessions_with_changes_dict(cls, customer_id, company, changes):
        """
        Update sessions with changes dict against customer_id and company
        :param int customer_id: Customer Id
        :param str company: Company
        :param dict changes:
        """
        cls.query.filter(
            cls.customer_id == customer_id,
            cls.company.like('%{}%'.format(company))
        ).update(
            changes
        )
        cls.update_record()
        return True

    @classmethod
    def find_latest_token_by_user_id(cls, user_id=None, company=None, isactive=True, wild_card_search=False):
        """
        Finds the latest token by the user id
        """
        session = {}
        if user_id:
            _query = cls.query

            _query = _query.filter(cls.customer_id == user_id)
            if isactive:
                _query = _query.filter(cls.isactive == isactive)

            if wild_card_search:
                if 'entertainer' in company:
                    _query = _query.filter(cls.company.like('%entertainer%'))
                else:
                    company = '%{company}%'.format(company=company)
                    _query = _query.filter(cls.company.like(company))
            else:
                if 'entertainer' in company:
                    _query = _query.filter(cls.company.like('entertainer%'))
                else:
                    company = '{company}%'.format(company=company)
                    _query = _query.filter(cls.company.like(company))

            _query.order_by(cls.id.desc())
            session = _query.first()
        return session

    @classmethod
    def deactivate_extended_trial(cls, customer_id=0):
        """
        Deactivates extended trial for specific user
        :param int customer_id: customer id
        :rtype: bool
        """
        if customer_id:
            session_changes = {'extended_trail_group_ids': ''}
            cls.query.filter(
                cls.customer_id == customer_id,
                cls.isactive == 1
            ).update(
                session_changes
            )
            cls.update_record()
            return True
        else:
            return False
