from sqlalchemy import Column, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class DmMerchantOrderStatus(db.Model, Mixin):
    __tablename__ = 'dm_merchant_order_status'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    title = Column(String(255))
    short_title = Column(String(255))
    label = Column(String(255))
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    is_deletable = Column(TINYINT(1), server_default=text("'0'"))
    is_editable = Column(TINYINT(1), server_default=text("'0'"))
    is_sub_status = Column(TINYINT(1), server_default=text("'0'"))

    @classmethod
    def get_filter_status(cls, filters=None, single=True):
        """
        Get filter status

        :param dict filters: data to filter from db
        :param bool single: single
        :return orm obj: query set result
        """
        query = cls.query.filter(cls.is_active == 1)
        if filters.get('id'):
            query = query.filter(
                cls.id == filters.get('id')
            )
        else:
            query = query.filter(
                cls.short_title == filters.get('short_title')
            )
        return query.first()
