"""
WlApiConfiguration Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class WlCompanyApiConfiguration(db.Model, Mixin):
    __tablename__ = 'wl_company_api_configuration'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    COMPANY_CODE_ENTERTAINER_EMAX = "emx"

    id = Column(INTEGER(11), primary_key=True)
    company_code = Column(String(255), nullable=False)
    api_token = Column(String(100))
    secret_key = Column(String(500), nullable=False)
    per_minute = Column(INTEGER(11))
    is_active = Column(TINYINT(1), default=1)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now)
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def validate_company(cls, api_token):
        """
        Returns company configuration object against api_token
        :param str api_token: Api Token
        :rtype: WlCompanyApiConfiguration
        """
        return cls.query.filter(cls.api_token == api_token, cls.is_active == 1).first()
