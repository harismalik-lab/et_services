"""
GuestTypes table of Entertainer Tours schema.
"""
from sqlalchemy import Column, DateTime, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_TOURS
from ..models.db import db
from ..models.mixin import Mixin


class TourGuestTypes(db.Model, Mixin):
    __tablename__ = 'guest_types'
    __table_args__ = {'schema': ENTERTAINER_TOURS}

    id = Column(INTEGER(11), primary_key=True)
    tour_id = Column(INTEGER(11))
    guest_type_name = Column(String(50), nullable=False)
    age_range = Column(String(255), server_default=text("''"))
    actual_price = Column(Float(12), server_default=text("'0.0000'"))
    discounted_price = Column(Float(12), server_default=text("'0.0000'"))
    created_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime)
