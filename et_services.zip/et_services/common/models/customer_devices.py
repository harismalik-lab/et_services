"""
Customer Device Model
"""
from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, session, with_slave
from ..models.mixin import Mixin
from ..models.session import Session
from ..utils import get_dubai_datetime


class CustomerDevice(db.Model, Mixin):
    __tablename__ = 'customer_devices'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    device_install_token = Column(String(23))
    device_model = Column(String(255))
    device_os = Column(String(255))
    device_first_used = Column(TIMESTAMP, default=get_dubai_datetime)
    customer_id = Column(INTEGER(11), index=True)
    session_id = Column(INTEGER(11), index=True)
    primary_device = Column(TINYINT(1), default=0)
    device_id = Column(String(100))
    amz_update_time = Column(TIMESTAMP, default=get_dubai_datetime)
    is_black_listed = Column(TINYINT(1), default=0)

    @classmethod
    def get_one_by_device_id_customer_id_and_company(cls, device_id, customer_id, company):
        """
        Returns customer device against provided customer_id, device_id and company
        :param str company: Company code
        :param int device_id: Device Id
        :param int customer_id: Customer Id
        :rtype: CustomerDevice
        """
        return cls.query.with_entities(
            cls.customer_id,
            cls.device_os,
            cls.device_model,
            cls.device_install_token,
            cls.device_id
        ).join(Session, cls.session_id == Session.id).filter(
            Session.company.like('%{}%'.format(company)),
            cls.customer_id == customer_id,
            cls.device_id == device_id,
            Session.isactive
        ).first()

    @classmethod
    def get_number_of_devices_by_customer_id_and_company(cls, customer_id, company):
        """
        Returns number of customer devices
        :param int customer_id: Customer Id
        :param str company: Company code
        :rtype int:
        """
        return cls.query.with_entities(cls.device_id).join(Session, cls.session_id == Session.id)\
            .filter(
            Session.company.like('%{}%'.format(company)),
            cls.customer_id == customer_id,
            Session.isactive
        ).count()
