"""
Product Offer Ent Active Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class ProductOfferEntActive(db.Model):
    __tablename__ = 'product_offer_ent_active'
    __table_args__ = {
        "schema": ENTERTAINER_WEB
    }

    id = Column(INTEGER(11), primary_key=True)
    offer_id = Column(INTEGER(11), index=True)
    product_id = Column(INTEGER(11), index=True)
    root_code = Column(String(20))
    year = Column(String(10))
    currency = Column(String(5))
    qr_code_url = Column(String(255))
    name = Column(String(255))
    digital_category = Column(String(255))
    book_category = Column(String(255))
    is_active = Column(BIT(1))
