"""
WL User Group Model
"""
from sqlalchemy import Date, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class WlUserGroup(db.Model):
    __tablename__ = 'wl_user_group'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    # Constants
    GROUP_ID_DU_STAFF = 1
    GROUP_ID_DU_CUSTOMER = 2
    DEFAULT_USER_GROUP = 1

    # Columns
    id = db.Column(INTEGER(11), primary_key=True)
    wl_company = db.Column(String(45))
    user_group = db.Column(INTEGER(11))
    name = db.Column(String(45))
    code = db.Column(String(5))
    logo = db.Column(String(250))
    number_of_offers = db.Column(INTEGER(11), default=0)
    expiration_date = db.Column(Date)
    hierarchy = db.Column(INTEGER(11), default=0)
    keys_expire_in_days = db.Column(INTEGER(11), default=0)
    is_primary_group = db.Column(TINYINT(1), default=1)

    @classmethod
    def get_group_info(cls, user_group, wl_company):
        """
         Returns the group info of company
        :param int user_group: user_group
        :param str wl_company: wl_company
        :rtype: WlUserGroup
        """
        return cls.query.filter(cls.user_group == user_group, cls.wl_company == wl_company).first()
