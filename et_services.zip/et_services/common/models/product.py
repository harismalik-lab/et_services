"""
Product Model
"""
from sqlalchemy import VARCHAR, DateTime, Float, ForeignKey, String, and_, func
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import (CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                         CATEGORY_API_NAME_TRAVEL, ENT_COMPANY_TYPE,
                         ENTERTAINER_WEB)
from ..models.db import db
from ..models.location import Location
from ..models.wl_product import WlProduct


class Product(db.Model):
    __tablename__ = 'product'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    MORE_SA_PRODUCT_SKU = 'D19CTMACP'
    PRODUCT_SKU_HOT_SUMMMER_NIGHTS = 'D19TRSCCP'
    PRODUCT_TYPE_BIRTHDAY = 1
    MORE_SA_LOCATION_IDS = (4, 14, 20)

    id = db.Column(INTEGER(11), primary_key=True)
    sf_id = db.Column(String(20), unique=True)
    magento_product_id = db.Column(String(10))
    location_id = db.Column(ForeignKey(Location.id, ondelete='SET NULL', onupdate='CASCADE'), index=True)
    type = db.Column(String(40), comment='Print Book, Digital Book, Digital Bundle')
    root_code = db.Column(String(40), comment='Print Book, Digital Book, Digital Bundle')
    edition = db.Column(String(40))
    valid_to = db.Column(DateTime, comment="Needed for CMS. Sync'd from Magento. Product expiration db.Date.")
    price = db.Column(Float)
    prices = db.Column(String(512), comment='Serialized PHP array of product prices in various currencies.')
    default_name = db.Column(String(255))
    default_description = db.Column(VARCHAR)
    also_text = db.Column(String(512))
    categories = db.Column(String(512), comment='Serialized array of products categories')
    featured = db.Column(String(40), index=True, default='Web')
    bundled_product_sku = db.Column(String(500))
    isactive = db.Column(TINYINT(1), default=0)
    istravel = db.Column(TINYINT(1), default=0)
    isnew = db.Column(TINYINT(1), default=0)
    ismember = db.Column(TINYINT(1), default=0)
    istest = db.Column(TINYINT(1), default=0)
    isconnect = db.Column(TINYINT(1), default=0)
    is_ent = db.Column(TINYINT(1), default=0)
    is_slice = db.Column(TINYINT(1), default=0)
    sequence = db.Column(INTEGER(11), default=0)
    gift_id = db.Column(INTEGER(11))
    image = db.Column(String(500))
    show_buy_mobile = db.Column(TINYINT(1), default=0)
    show_buy_web = db.Column(TINYINT(1), default=0)
    company = db.Column(String(45), default='entertainer')
    price_lsp = db.Column(Float)
    price_rrp = db.Column(Float)
    currency = db.Column(String(5))
    is_cheers = db.Column(TINYINT(1), default=0)
    is_purchaseable = db.Column(TINYINT(1), default=0)
    color_code = db.Column(String(100))
    sf_key = db.Column(String(50))
    title_color = db.Column(String(100))
    is_dummy_product = db.Column(TINYINT(1), default=0)
    tile_image = db.Column(String(500))
    delivery_enabled = db.Column(TINYINT(1), default=0)
    pmprice = db.Column(Float)
    pmstartdate = db.Column(DateTime)
    pmenddate = db.Column(DateTime)
    purchase_product_id = db.Column(INTEGER(11), nullable=False, default=0)
    product_type = db.Column(TINYINT(1), comment='1 = Birthday Sku')
    is_more_sa = db.Column(TINYINT(1), default=0)
    is_johor_bahru = db.Column(TINYINT(1))
    show_offers_if_purchased = db.Column(TINYINT(1), default=0)
    is_freemium = db.Column(TINYINT(1), default=0)
    has_merlin_offers = db.Column(BIT(1))
    cashless_delivery_enabled = db.Column(TINYINT(1))
    has_ego_free_offers = db.Column(TINYINT(1), default=0)
    has_cinema_offers = db.Column(BIT(1))
    is_core_product = db.Column(BIT(1))
    is_core_fine_dining_product = db.Column(BIT(1))
    is_core_family_product = db.Column(BIT(1))
    is_core_fitness_product = db.Column(BIT(1))
    has_bonus_offers = db.Column(BIT(1))
    is_taster_product = db.Column(BIT(1))
    nfc_enabled = db.Column(BIT(1))
    is_deals_product = db.Column(BIT(1))
    is_adrenaline_product = db.Column(TINYINT(1), default=0)
    offer_replenishment_enabled = db.Column(BIT(1))
    # location = relationship(Location)

    @classmethod
    def get_bundled_product(cls, product_sku):
        """
        returns bundled products corresponding with product_sku
        :param regex product_sku:
        :return: list of products
        """
        result = None
        if product_sku:
            query = cls.query.with_entities(cls.bundled_product_sku)
            result = query.filter(cls.sf_id == product_sku).first()
        return result

    @classmethod
    def get_product_price_details(cls, company, product_sku):
        """
        Gets the product's price details.
        :param str company: Company
        :param str product_sku: Product sku
        :rtype: dict
        """
        query = cls.query.with_entities(
            cls.id,
            cls.currency,
            cls.price
        )
        return query.filter(cls.sf_id == product_sku, cls.company == company).first()

    @classmethod
    def get_by_id(cls, product_id):
        """
        Returns the product by id.
        :param int product_id: Product Id
        :rtype: Product
        """
        return cls.query.filter(cls.id == product_id).first()

    @classmethod
    def get_delivery_enabled_by_id(cls, product_id):
        """
        Returns the product by id.
        :param int product_id: Product Id
        :rtype: Product
        """
        return cls.query.with_entities(cls.delivery_enabled).filter(cls.id == product_id).first()

    @classmethod
    def get_product_types(cls, company, category, location_id, is_cuckoo, product_ids):
        """

        :param company:
        :param category:
        :param location_id:
        :param is_cuckoo:
        :param product_ids:
        :return:
        """
        query = cls.query.join(WlProduct, WlProduct.product_sku == cls.sf_id)
        query = query.with_entities(
            func.max(cls.ismember).label('is_member'),
            func.max(cls.is_cheers).label('is_cheers'),
            func.max(cls.delivery_enabled).label('is_delivery'),
            func.max(cls.is_more_sa).label('is_more_sa')
        )
        if product_ids:
            query = query.filter(cls.id.in_(product_ids))

        query = query.filter(cls.isactive, WlProduct.active, WlProduct.wl_company == company)

        if category == CATEGORY_API_NAME_TRAVEL:
            query = query.filter(cls.location_id == 0)
        else:
            query = query.filter(cls.location_id == location_id)

        if is_cuckoo or category != CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
            query = query.filter(cls.is_cheers == 0)
            query = query.filter(cls.delivery_enabled == 0)

        return query.one()

    @classmethod
    def get_birthday_products_with_id(cls, location_id):
        """
        get birthday products ids with col `id`
        :param location_id:
        :return orm obj(product_ids):
        """
        query = cls.query.filter(cls.product_type == cls.PRODUCT_TYPE_BIRTHDAY)
        if location_id:
            query = query.filter(cls.location_id == location_id)
        return query.with_entities(cls.id, cls.sf_id).all()

    @classmethod
    def get_product_expiration_date(cls, skus):
        """
        Returns product max expiration date against provided product skus.
        :param list skus: SKUs for which we need to find the expiration date of any product against them.
        :rtype: datetime.datetime
        """
        return cls.query.with_entities(
            func.max(cls.valid_to).label('membership_expiry_date')
        ).filter(
            cls.sf_id.in_(skus),
            cls.is_freemium == 0
        ).first().membership_expiry_date

    @classmethod
    def get_product_details(cls, skus):
        """
        Returns product details against provided SKUs.
        :param list skus: SKUs for which we need to find product details for.
        """
        return cls.query.with_entities(
            cls.id,
            cls.sf_id,
            cls.is_taster_product,
            cls.is_purchaseable
        ).filter(
            cls.sf_id.in_(skus)
        ).all()

    @classmethod
    def get_root_code_by_offer(cls, offer_id):
        """
        Gets root code against provided offer id

        :param int|str offer_id: offer id
        """
        from ..models.product_offer import ProductOffer
        query = cls.query.join(
            ProductOffer, cls.id == ProductOffer.product_id
        ).filter(
            ProductOffer.offer_id == offer_id
        ).with_entities(
            ProductOffer.root_code
        )
        return query.first()

    @classmethod
    def find_bundled_product_skus_by_location(cls, company, location_id):
        """
        Gets a comma separated list of SKUs based on location id and company.

        :param str company: name of company.
        :param int location_id: id of location.
        """

        query = cls.query.with_entities(
            func.group_concat(cls.bundled_product_sku).label('bundled_product_sku')
        ).filter(cls.company == company)
        if location_id is not None:
            query = query.filter(cls.location_id == location_id)
        return query.one()

    @classmethod
    def get_cheers_products_count_against_product_ids_and_location_id(cls, product_ids, location_id, company, **kwargs):
        """
        Gets count of cheers products against product ids and location id.
        :param list product_ids: ids of products to look for cheer products in.
        :param int location_id: location id for which we need to find cheer products.
        :param str company: name of company
        """
        return cls.query.with_entities(cls.id).filter(
            cls.id.in_(product_ids),
            cls.is_cheers == 1,
            cls.location_id == location_id,
            cls.company == company
        ).count()

    @classmethod
    def get_birthday_products(cls, location_id, company, column_to_get=None, convert_to_string=False):
        """
        Gets birthday products in a location.

        :param int location_id: location id for which we need to find birthday products.
        :param str company: name of company.
        :param str column_to_get: column name of Product to return.
        :param bool convert_to_string: type casts column value to string if True, else keeps DB type.
        """

        if not column_to_get:
            column_to_get = 'sf_id'

        query = cls.query.with_entities(column_to_get).filter(
            cls.product_type == Product.PRODUCT_TYPE_BIRTHDAY,
            cls.company == company
        )

        if location_id:
            query = query.filter(cls.location_id == location_id)

        results = query.all()

        records = []
        for row in results:
            record = getattr(row, column_to_get, None)
            if record:
                records.append(str(record) if convert_to_string else record)

        return records

    @classmethod
    def get_location_ids_by_product_ids(cls, product_ids, company):
        """
        Returns location ids against provided Product ids.
        :param list product_ids: ids of products.
        :param str company: name of company.
        """

        if product_ids is None:
            product_ids = []
        return cls.query.with_entities(
            cls.location_id
        ).filter(
            cls.id.in_(product_ids),
            cls.company == company
        ).distinct().all()

    @classmethod
    def get_offer_types(cls, offer_ids, company_type, company):
        """
        Returns offer types against offers ids
        :param str company_type: company type
        :param str company: company
        :param list offer_ids: Offer ids
        :rtype: dict
        """
        from ..models.product_offer import ProductOffer
        from ..models.offer import Offer

        assert isinstance(offer_ids, list), "Invalid params; got {}".format(offer_ids)
        query = cls.query.with_entities(cls.is_cheers.label('type'), Offer.id)
        if company_type != 'ent':
            query = query.join(
                WlProduct,
                and_(cls.isactive == 1, cls.sf_id == WlProduct.product_sku, WlProduct.wl_company == company)
            )
        query = query.join(ProductOffer, cls.id == ProductOffer.product_id)
        query = query.join(Offer, ProductOffer.offer_id == Offer.id)
        query = query.filter(Offer.id.in_(offer_ids))
        rows = query.all()
        offers_types = {}
        for row in rows:
            offers_types.update({row.id: row.type})
        return offers_types

    @classmethod
    def get_product_by_offer_id(cls, offer_id):
        """
        Product by offer id

        :param offer_id: offer Id
        """
        from ..models.product_offer import ProductOffer

        query = cls.query.with_entities(
            cls.id,
            ProductOffer.offer_id
        ).join(
            ProductOffer, cls.id == ProductOffer.product_id
        )
        query = query.filter(ProductOffer.offer_id == offer_id)
        return query.first()

    @classmethod
    def get_product_id_by_offer_id(cls, offer_id, company_type, company, default=None):
        """
        Gets product id by provided offer id

        :param int|str offer_id: offer id
        :param str company_type: type of the company
        :param str company: company
        :param default
        """
        from ..models.product_offer import ProductOffer
        if not default:
            default = []
        query = cls.query.with_entities(cls.id, ProductOffer.offer_id)
        if company_type != ENT_COMPANY_TYPE:
            query = query.join(
                WlProduct,
                and_(cls.isactive == 1, cls.sf_id == WlProduct.product_sku, WlProduct.wl_company == company)
            )
        query = query.join(ProductOffer, cls.id == ProductOffer.product_id)
        if isinstance(offer_id, list):
            query = query.filter(ProductOffer.offer_id.in_(offer_id))
            record = query.all()
            record = {product.offer_id: product for product in record}
        else:
            query = query.filter(ProductOffer.offer_id == offer_id)
            record = query.first()
            if record:
                return record.id

        return record if record else default

    @classmethod
    def get_cheers_product_by_product_ids(cls, company_type, company, product_ids=[], convert_to_string=False):
        """
        This method returns location_ids against product_ids
        :param list product_ids: Product Id
        :param str company_type: company type
        :param str company: company
        :param bool convert_to_string:
        :rtype: list
        """
        filtered_product_ids = []
        product_ids = list(filter(None, product_ids))
        if product_ids:
            product_ids = list(set(map(int, filter(None, product_ids))))
            query = cls.query.with_entities(cls.id)
            if company_type != 'ent':
                query = query.join(
                    WlProduct,
                    and_(cls.isactive == 1, cls.sf_id == WlProduct.product_sku, WlProduct.wl_company == company)
                )
            query = query.filter(cls.is_cheers == 1)
            query = query.filter(cls.id.in_(product_ids))

            records = query.all()
            for record in records:
                product_id = record.id
                if convert_to_string:
                    product_id = str(product_id)
                filtered_product_ids.append(product_id)
        return filtered_product_ids
