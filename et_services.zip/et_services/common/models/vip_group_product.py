"""
VIP Group Product Model class
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class VipGroupProduct(db.Model):
    __tablename__ = 'vip_group_product'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    group_id = Column(INTEGER(11))
    product_sku = Column(String(10))
    active = Column(BIT(1))
