"""
Exchange Rate Model
"""
from sqlalchemy import Column, Float, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class ExchangeRate(db.Model, Mixin):
    __tablename__ = 'exchange_rate'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    currency = Column(String(50))
    rate = Column(Float)

    @classmethod
    def get_conversion_rate(cls, price, currency_from, currency_to):
        """
        Returns list of conversion rate
        :param str currency_from: currency to convert from
        :param int|float price: price
        :param str currency_to: currency to convert to
        :rtype: float
        """
        from_rate, to_rate = 1, 1
        if currency_from == currency_to:
            return price
        results = cls.query.all()
        for result in results:
            if result.currency == currency_from:
                from_rate = result.rate
            if result.currency == currency_to:
                to_rate = result.rate
        result = round(float(price) / from_rate * to_rate, 2)
        return result

    @classmethod
    def get_exchange_rates(cls):
        """
        Returns list of exchange rates
        :rtype: list
        """
        return cls.query.all()
