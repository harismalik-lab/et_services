"""
Merchant Translation Model
"""
from sqlalchemy import Column, ForeignKey, Index, String, Text
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, VARCHAR

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant
from ..models.mixin import Mixin


class MerchantTranslation(db.Model, Mixin):
    __tablename__ = 'merchant_translation'
    __table_args__ = (
        Index('idx_translation', 'merchant_id', 'locale'),
        {"schema": ENTERTAINER_WEB}
    )

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        index=True
    )
    locale = Column(String(5), index=True, default='en')
    name = Column(String(255))
    description = Column(Text)
    rules_of_use = Column(Text)
    terms_and_conditions = Column(Text)
    address = Column(String(255))
    opening_hours = Column(String(255))
    accreditation = Column(Text)
    category = Column(String(255))
    dress_code = Column(String(45), default='')
    book_section = Column(VARCHAR(255))
    digital_section = Column(String(255))
    fine_dining = Column(String(255))
    closest_air_port_name = Column(String(255))
    cuisine = Column(String(255), index=True)
    info_241 = Column(Text)
    amz_update_time = Column(TIMESTAMP, default="CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    how_to_book = Column(Text)
    directions = Column(Text)

    # merchant = relationship('Merchant')

    @classmethod
    def get_by_merchant_id(cls, merchant_id):
        """
        Returns translation against merchant_id
        :param int merchant_id: merchant id
        :rtype: MerchantTranslation
        """
        return cls.query.filter(cls.merchant_id == merchant_id, cls.locale == EN).first()
