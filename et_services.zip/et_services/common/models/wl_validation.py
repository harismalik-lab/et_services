"""
WLValidation Model
"""
import datetime
from itertools import repeat

from sqlalchemy import TIMESTAMP, DateTime, Index, String, func
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.mixin import Mixin


class Wlvalidation(db.Model, Mixin):
    __tablename__ = 'wlvalidation'
    __table_args__ = (
        Index('idx_email', 'email', 'wl_company'),
        Index('idx_active', 'active', 'isused'),
        Index('idx_key', 'wl_key', 'wl_company'),
        {"schema": ENTERTAINER_WEB}
    )
    # Constants
    INVALID_KEY_CUSTOMER_DOES_NOT_EXISTS = "00"
    INVALID_KEY_CUSTOMER_EXISTS = "01"
    VALID_KEY_CUSTOMER_DOES_NOT_EXISTS = "10"
    VALID_KEY_CUSTOMER_EXISTS = "11"
    FAQS_WEB_URL = "https://www.theentertainerme.com/{company}-FAQs"
    INACTIVE_KEY = -1
    INVALID_KEY = 0
    UNUSED_VALID_KEY = 1
    ALREADY_ACTIVATED_VALID_KEY = 2
    KEY_NOT_EXISTS = 3
    VALID_KEY = 4
    SECOND_GROUP = 2

    # Columns
    id = db.Column(INTEGER(11), primary_key=True)
    wl_key = db.Column(String(24), nullable=False)
    wl_company = db.Column(String(5), nullable=False)
    email = db.Column(String(255), nullable=False)
    isused = db.Column(BIT(1), nullable=False)
    customer_id = db.Column(INTEGER(11), index=True)
    activation_date = db.Column(DateTime)
    active = db.Column(BIT(1), nullable=False)
    is_expired = db.Column(BIT(1), index=True)
    existing = db.Column(BIT(1), nullable=False, default=True)
    user_group = db.Column(TINYINT(1), server_default=db.text("'1'"))
    expiry_date = db.Column(DateTime)
    deactivation_date = db.Column(DateTime)
    comments = db.Column(String(50))
    date_created = db.Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = db.Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    @with_master
    def get_active_by_company_and_email(cls, company, email):
        """
        Returns active record against company and email
        :param str company: Company
        :param str email: Email
        :rtype: Wlvalidation
        """
        return cls.query.filter(cls.wl_company == company, cls.email == email, cls.active).first()

    @classmethod
    @with_master
    def get_active_by_company_email_and_user_group(cls, company, email, user_group):
        """
        Returns active record against company and email
        :param int user_group: User Group
        :param str company: Company
        :param str email: Email
        :rtype: Wlvalidation
        """
        return cls.query.filter(
            cls.wl_company == company,
            cls.email == email,
            cls.active,
            cls.user_group == user_group,
        ).first()

    @classmethod
    @with_master
    def get_number_of_valid_keys(cls, company, email):
        """
        Gets the number of valid keys.
        :param str company: Company
        :param str email: Email
        :rtype: int
        """
        return cls.query.filter(cls.email == email, cls.wl_company == company, cls.active, cls.isused).count()

    @classmethod
    @with_master
    def validate_key(cls, wl_key, company='', email=''):
        """
        Validates a key.
        :param str | int wl_key: Key
        :param str company: Company
        :param str email: Email
        :rtype: int
        """

        validation_result = cls.INVALID_KEY
        result = cls.query.with_entities(cls.isused, cls.email)\
            .filter(cls.wl_key == wl_key, cls.wl_company == company, cls.active).first()
        if result:
            if not result.isused:
                validation_result = cls.UNUSED_VALID_KEY
            elif result.email.lower() == email.lower():
                validation_result = cls.ALREADY_ACTIVATED_VALID_KEY
        return validation_result

    @classmethod
    @with_master
    def assign_key_to_customer(cls, wl_key, company, email, is_customer_exists, customer_id):
        """
        Assigns a key to customer.
        :param str | int wl_key: Key
        :param str company: Company
        :param int customer_id: Customer id
        :param str email: Email
        :param int is_customer_exists: User exists or not
        :rtype: int
        """
        # TODO: see behaviour with None customer_id
        cls.query.filter(cls.wl_key == wl_key, cls.wl_company == company).update(
            {
                'email': email,
                'isused': True,
                'activation_date': datetime.datetime.now(),
                'existing': is_customer_exists,
                'customer_id': customer_id if is_customer_exists else None
            }
        )
        cls.update_record()
        return True

    @classmethod
    @with_master
    def update_customer_validation(cls, company, email, customer_id):
        """
        Updates the validation for customer.
        :param str company: Company
        :param str email: Email
        :param int customer_id: Customer ID
        :rtype: bool
        """
        cls.query.filter(cls.email == email, cls.wl_company == company).update({'customer_id': customer_id})
        cls.update_record()
        return True

    @classmethod
    @with_master
    def get_user_groups(cls, company, customer_id):
        """
        Gets the user Groups
        :param str company: Company
        :param int customer_id: Customer ID
        :rtype: list
        """
        results = cls.query.with_entities(cls.user_group, func.count(cls.user_group).label('quantity')).filter(
            cls.customer_id == customer_id,
            cls.wl_company == company,
            cls.active
        ).group_by(cls.user_group).all()
        user_groups = []
        for result in results:
            user_groups.extend(repeat(result[0], result[1]))
        return user_groups

    @classmethod
    @with_master
    def get_user_group(cls, company, customer_id):
        """
        Gets the user group
        :param str company: Company
        :param int customer_id: Customer ID
        :rtype: int
        """
        user_group = 0
        user_groups = cls.get_user_groups(company, customer_id)
        if user_groups:
            user_group = user_groups[-1]

        return user_group

    @classmethod
    @with_master
    def get_user_group_id_by_key(cls, wl_key, company=''):
        """
        Gets the user's group id by key.
        :param str | int wl_key: Key
        :param str company: Company
        :rtype: tuple
        """
        return cls.query.with_entities(cls.user_group).filter(cls.wl_key == wl_key, cls.wl_company == company).first()

    @classmethod
    @with_master
    def key_already_exists(cls, company, key):
        return cls.query.filter(cls.wl_company == company, cls.wl_key == key).count()
