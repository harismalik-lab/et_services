"""
Product Offer Model
"""
from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TIMESTAMP

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.offer import Offer
from ..models.product import Product


class ProductOffer(db.Model, Mixin):
    __tablename__ = 'product_offer'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    sf_id = Column(String(20))
    offer_id = Column(ForeignKey(Offer.id, ondelete='CASCADE', onupdate='CASCADE'), index=True)
    product_id = Column(ForeignKey(Product.id, ondelete='CASCADE', onupdate='CASCADE'), index=True)
    root_code = Column(String(20), index=True)
    year = Column(String(10))
    currency = Column(String(5))
    qr_code_url = Column(String(255))
    name = Column(String(255))
    digital_category = Column(String(255))
    book_category = Column(String(255))
    amz_update_time = Column(TIMESTAMP)
    is_active = Column(BIT(1))

    # offer = relationship('Offer')
    # product = relationship('Product')

    @classmethod
    def get_by_product_and_offer_id(cls, product_id, offer_id):
        """
        Gets the root code based on product_id and offer_id.
        :param int product_id: Id of product
        :param int offer_id: Id of offer
        :rtype: ProductOffer
        """
        return cls.query.filter(cls.product_id == product_id, cls.offer_id == offer_id).first()

    @classmethod
    def get_product_ids_against_offer_ids(cls, offer_ids):
        """
        Returns dict of product ids against offer ids
        :param list offer_ids: Offer ids
        :rtype: dict
        """
        product_offers_dict = {}
        if offer_ids:
            product_offers = cls.query.with_entities(
                cls.product_id, cls.offer_id).filter(cls.offer_id.in_(offer_ids)).all()
            for product_offer in product_offers:
                product_set = product_offers_dict.get(product_offer.offer_id)
                if product_set:
                    product_set.add(product_offer.product_id)
                else:
                    product_offers_dict[product_offer.offer_id] = {product_offer.product_id}
        return product_offers_dict
