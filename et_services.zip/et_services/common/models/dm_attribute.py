"""
Dm Attribute Model
"""
import datetime

from sqlalchemy import Column, Float, String
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.dm_attribute_translation import DmAttributeTranslation


class DmAttribute(db.Model):
    __tablename__ = 'dm_attribute'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    identifier = Column(String(200))
    dm_attribute_group_id = Column(INTEGER(11), index=True)
    attribute_price_field = Column(Float(8), default=0.00)
    sort_order = Column(SMALLINT(11))
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    is_deleted = Column(TINYINT(1), default=0)

    @classmethod
    def get_add_ons_by_attribute_id(cls, attr_ids=None):
        """
        Get add ons by attribute id
        :params list attr_ids: attribute ids
        :return query set result
        """
        if attr_ids:
            query = cls.query.with_entities(
                cls.id,
                cls.dm_attribute_group_id,
                cls.attribute_price_field,
                DmAttributeTranslation.name,
                DmAttributeTranslation.dm_attribute_id
            )
            query = query.join(DmAttributeTranslation, cls.id == DmAttributeTranslation.dm_attribute_id)
            if isinstance(attr_ids, list):
                query = query.filter(cls.id.in_(attr_ids))
            else:
                query = query.filter(cls.id == attr_ids)
            return query.all()
        return []
