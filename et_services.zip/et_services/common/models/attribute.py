"""
Attribute Translation Model
"""
from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class Attribute(db.Model):
    __tablename__ = 'attribute'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    ATTRIBUTE_TYPE_MERCHANT = 1

    id = Column(INTEGER(11), primary_key=True)
    type = Column(TINYINT(1), nullable=False, comment='1 for merchant, 2 for offer, 3 for outlet')
    category_id = Column(INTEGER(11), nullable=False, index=True)
    attribute_group_id = Column(INTEGER(11), nullable=False)
    attribute_key = Column(String(100), nullable=False)
    attribute_name = Column(String(100), nullable=False)
    attribute_type = Column(TINYINT(1), default=0)
    attribute_values = Column(Text)
    is_top_attribute = Column(TINYINT(1), default=0)
    order_id = Column(SMALLINT(6), default=1)
    image_url = Column(Text)
    image_url_default = Column(String(255))
    image_url_selected = Column(String(255))
    is_active = Column(BIT(1), nullable=False)
