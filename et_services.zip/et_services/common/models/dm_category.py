"""
Dm Category Model
"""
import datetime

from sqlalchemy import Column
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmCategory(db.Model):
    __tablename__ = 'dm_category'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    sort_order = Column(SMALLINT(1))
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    is_deleted = Column(TINYINT(1), default=0)
    dm_outlet_setting_id = Column(INTEGER(11), index=True)
