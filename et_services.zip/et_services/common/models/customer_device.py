"""
Customer Device Model
"""
import datetime

from sqlalchemy import TIMESTAMP, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.session import Session


class CustomerDevice(db.Model, Mixin):
    __tablename__ = 'customer_devices'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = db.Column(INTEGER(11), primary_key=True)
    device_install_token = db.Column(String(23))
    device_model = db.Column(String(255))
    device_os = db.Column(String(255))
    device_first_used = db.Column(TIMESTAMP, default=datetime.datetime.now)
    customer_id = db.Column(INTEGER(11), index=True)
    session_id = db.Column(INTEGER(11), index=True)
    primary_device = db.Column(TINYINT(1), default=0)
    device_id = db.Column(String(100))
    amz_update_time = db.Column(TIMESTAMP, default=datetime.datetime.now)
    is_black_listed = db.Column(TINYINT(1), default=0)

    @classmethod
    def get_one_by_device_id_customer_id_and_company(cls, device_id, customer_id, company):
        """
        Returns customer device against provided customer_id, device_id and company
        :param str company: Company code
        :param int device_id: Device Id
        :param int customer_id: Customer Id
        :rtype: CustomerDevice
        """
        return cls.query.with_entities(
            cls.customer_id,
            cls.device_os,
            cls.device_model,
            cls.device_install_token,
            cls.device_id
        ).join(Session, cls.session_id == Session.id).filter(
            Session.company.like('%{}%'.format(company)),
            cls.customer_id == customer_id,
            cls.device_id == device_id,
            Session.isactive
        ).first()

    @classmethod
    def get_number_of_devices_by_customer_id_and_company(cls, customer_id, company):
        """
        Returns number of customer devices
        :param int customer_id: Customer Id
        :param str company: Company code
        :rtype int:
        """
        if customer_id:
            return cls.query.with_entities(cls.device_id).join(Session, cls.session_id == Session.id)\
                .filter(
                Session.company.like('%{}%'.format(company)),
                cls.customer_id == customer_id,
                Session.isactive
            ).count()
