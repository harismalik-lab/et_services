"""
Top Up Offers Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, DateTime, Float, String, or_
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class TopUpOffer(db.Model, Mixin):
    __tablename__ = 'top_up_offers'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    TYPE_VIRTUAL_CURRENCY = 1

    id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(11), index=True)
    primary_user_id = Column(INTEGER(11), index=True)
    location_id = Column(INTEGER(11), index=True)
    type = Column(TINYINT(1), default=1, comment='1 against smiles/ virtual currency')
    offer_id = Column(INTEGER(11), index=True)
    merchant_id = Column(INTEGER(11), index=True)
    product_id = Column(INTEGER(11), index=True)
    amount = Column(Float)
    active = Column(TINYINT(1), default=1, comment='1 for Active\\n2 for Inactive')
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    activation_type = Column(String(10))
    activation_type_id = Column(INTEGER(11))
    expiration_date = Column(DateTime)

    @classmethod
    def get_top_up_offers(
            cls, customer_id, location_id, merchant_id=0, offer_type=1, offer_id=None, primary_user_id=0
    ):
        """
        Gets top up offers
        """
        query = cls.query.with_entities(cls.offer_id, cls.merchant_id, cls.product_id, cls.amount)
        if primary_user_id == customer_id:
            query = query.filter(
                cls.active == 1,
                cls.customer_id == primary_user_id,
                or_(cls.primary_user_id == primary_user_id,
                    or_(cls.primary_user_id == 0, cls.primary_user_id.is_(None)),
                    ),
                cls.type == offer_type
            )
        elif primary_user_id:
            query = query.filter(cls.active == 1, cls.primary_user_id == primary_user_id, cls.type == offer_id)
        else:
            query = query.filter(
                cls.active == 1,
                cls.type == offer_type,
                cls.customer_id == customer_id,
                or_(cls.primary_user_id.is_(None), cls.primary_user_id == 0)
            )
        if location_id:
            query = query.filter(cls.location_id == location_id)
        if merchant_id:
            query = query.filter(cls.merchant_id == merchant_id)
        if offer_id:
            query = query.filter(cls.offer_id == offer_id)
        return query.all()

    @classmethod
    def get_top_up_offers_primary(cls, customer_id, location_id, merchant_id=0, offer_type=1, offer_id=None):
        """
        Gets top up offers primary

        :param int customer_id: id of customer
        :param int location_id: location id
        :param int merchant_id: id of merchant
        :param int|bool offer_type: offer type
        :param bool offer_id: offer id
        """
        query = cls.query.with_entities(cls.offer_id, cls.merchant_id, cls.product_id, cls.amount)
        query = query.filter(cls.active == 1, cls.type == offer_type)
        query = query.filter(coalesce(cls.primary_user_id, cls.customer_id, 0) == customer_id)

        if location_id:
            query = query.filter(cls.location_id == location_id)
        if merchant_id:
            query = query.filter(cls.merchant_id == merchant_id)

        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        return query.all()
