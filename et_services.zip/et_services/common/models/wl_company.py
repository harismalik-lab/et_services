"""
WL Company Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, DateTime, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class WlCompany(db.Model, Mixin):
    __tablename__ = 'wl_company'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    # CONSTANTS
    LOCATION_VERSION_HSBC = 1
    COMPANY_CODE_MASTER_CARDS = "mce"
    COMPANY_CODE_MASTER_CARDS_ASIA = "mca"
    COMPANY_CODE_DU = "due"
    COMPANY_CODE_DUT = "dut"
    COMPANY_CODE_DHL = "dhl"
    COMPANY_CODE_ALBILAD = "alb"
    COMPANY_CODE_SAMSUNG = "smg"
    COMPANY_CODE_ENTERTAINER_LIFE = "elf"
    COMPANY_CODE_OLD_MUTUAL_ENTERTAINER = "ome"
    COMPANY_CODE_ENTERTAINER_HUT = "hut"
    COMPANY_CODE_ENTERTAINER_MTN = "mtn"
    COMPANY_CODE_ENTERTAINER_MOTO = "mto"
    COMPANY_CODE_ENTERTAINER_SGK = "sgk"
    COMPANY_CODE_ENTERTAINER_GEMS = "gem"
    COMPANY_CODE_ENTERTAINER_KEL = "kel"
    COMPANY_CODE_ENTERTAINER_JGE = "jge"
    COMPANY_CODE_ENTERTAINER_QGIRCO = "qgi"
    COMPANY_CODE_ENTERTAINER_LAND_MARK_GROUP = "lmk"
    COMPANY_CODE_ENTERTAINER_CRG = "crg"
    COMPANY_CODE_ENTERTAINER_HSBC = "hs"
    COMPANY_CODE_ENTERTAINER_HSBC_CUCKOO = "hss"
    COMPANY_CODE_ENTERTAINER_BNE = "bne"
    COMPANY_CODE_ENTERTAINER_SENSODYNE = "sns"
    COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER = "cng"
    COMPANY_CODE_ENTERTAINER_NAAMA = "nma"
    COMPANY_CODE_ENTERTAINER_BATELCO = "btl"
    COMPANY_CODE_ENTERTAINER_EMAX = "emx"
    COMPANY_CODE_DUBAI_ENTERTAINMENTS = "dpr"
    COMPANY_CODE_UAEEX_ENTERTAINER = "uex"
    COMPANY_CODE_MEETHAQ = "hfw"
    COMPANY_CODE_CHALHOUB = 'chb'
    COMPANY_CODE_AAG = "aag"
    COMPANY_CODE_LAK_ENTERTAINER = "lak"
    COMPANY_CODE_ZEINAH_ENTERTAINER = "zin"
    COMPANY_CODE_Commercial_Bank_ENTERTAINER = "cbq"
    COMPANY_CODE_ALJAWHAR_ENTERTAINER = "aje"
    COMPANY_CODE_ASALAH_ENTERTAINER = "bme"
    COMPANY_CODE_IGLOW_LIFESTYLE = "igl"
    company_code_HCS_Singapure = 6
    COMPANY_CODE_HCS_Singapure = "hcs"
    company_code_ENTERTAINER_VDF = "vdf"
    company_code_SOLIDATIRy = "sol"
    VALID_STATUS = 1
    ALREADY_USED_STATUS = 2
    INVALID_STATUS = 3
    INVOICE_STATUS_VALID_FOR_SIGN_IN_SIGN_UP_ONLY = 4
    INVOICE_STATUS_VALID_LINKING_THROUGH_PROFILE_ONLY = 5
    INVOICE_STATUS_OUTDATED_INVOICE = 6
    INVOICE_STATUS_INVALID_TRANSACTION_TYPE = 7
    INVOICE_STATUS_WRONG_AMOUNT = 8

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    name = Column(String(45))
    code = Column(String(45), index=True)
    default_key_prefix = Column(String(10))
    description = Column(String(200))
    logo = Column(String(250))
    total_redemptions = Column(INTEGER(11), default=0)
    total_savings = Column(INTEGER(11), default=0)
    total_registrations = Column(INTEGER(11), default=0)
    update_time = Column(TIMESTAMP, default=datetime.datetime.now)
    is_multiple_allowed = Column(TINYINT(4), default=0)
    is_active = Column(TINYINT(1), index=True, default=1)
    api_url = Column(String(250))
    app_store_url = Column(String(250))
    wl_key_length = Column(String(10), default=9)
    data_masked = Column(TINYINT(1), default=0)
    expiry_date = Column(DateTime)
    default_currency = Column(String(10), default='USD')
    locations_version = Column(INTEGER(11), default=1)
    is_kaligo_travel_enable = Column(TINYINT(1), default=0)
    is_upgrade_key_enabled = Column(TINYINT(1), default=0)
    upgrade_default_group = Column(INTEGER(11), default=0)
    is_downgrade_enabled = Column(TINYINT(1), default=0)
    custom_pwd_required = Column(TINYINT(1), default=1)
    enable_entertainer_get_aways = Column(TINYINT(1), default=0)
    show_travel_countries_only = Column(TINYINT(1), default=0)
    is_smiles_enabled = Column(TINYINT(1), default=0)
    business_id = Column(INTEGER(11))

    @classmethod
    def is_required_to_pick_name_from_lookup(cls, company=None):
        """
        Is required to pick first name and last name from lookup
        :param str company: White label client
        """
        return company in (
            cls.COMPANY_CODE_ENTERTAINER_CRG,
            cls.COMPANY_CODE_ENTERTAINER_NAAMA,
            cls.COMPANY_CODE_DUBAI_ENTERTAINMENTS
        )

    @classmethod
    def is_lookup_based_company(cls, company=None):
        """
        Checks company is lookup based or not
        :param str company: company
        :rtype: bool
        """
        is_lookup_based_company = False
        if company in (
                cls.COMPANY_CODE_ENTERTAINER_GEMS,
                cls.COMPANY_CODE_ENTERTAINER_CRG,
                cls.COMPANY_CODE_ENTERTAINER_NAAMA,
                cls.COMPANY_CODE_DUBAI_ENTERTAINMENTS,
                cls.COMPANY_CODE_DHL
        ):
            is_lookup_based_company = True
        return is_lookup_based_company

    @classmethod
    def get_by_id(cls, _id):
        """
        Gets the company name
        :param int _id: company's id
        :rtype: WlCompany|None
        """
        if _id:
            return cls.query.filter(cls.id == _id).first()

    @classmethod
    def get_by_code(cls, code):
        """
        Returns the company
        :param str code: company's id
        :rtype: WlCompany|None
        """
        if code:
            return cls.query.filter(cls.code == code).first()

    @classmethod
    def get_active_by_code(cls, code):
        """
        Returns the company
        :param str code: company's id
        :rtype: WlCompany|None
        """
        if code:
            return cls.query.filter(cls.code == code, cls.is_active == 1).first()

    @classmethod
    def get_by_code_and_business_id(cls, code, business_id):
        """
        Gets the company name
        :param int business_id: Business Id
        :param str code: company's id
        :rtype: WlCompany|None
        """
        if code and business_id:
            return cls.query.filter(cls.code == code, cls.business_id == business_id, cls.is_active == 1).first()

    @classmethod
    def get_device_limit_by_company(cls, company):
        """
        Get customer device limit required company
        :return: limit
        """
        # TODO:
        return cls.company_code_HCS_Singapure

    @classmethod
    def get_key_prefix_by_company(cls, company):
        """
        Gets key prefix by company
        :param company: Wl company name
        """
        company = company.lower()
        prefix = 'te'
        prefixes = {
            cls.COMPANY_CODE_ENTERTAINER_GEMS: 'ge',
            cls.COMPANY_CODE_ENTERTAINER_CRG: 'ce',
            cls.COMPANY_CODE_ENTERTAINER_NAAMA: 'nm',
            cls.COMPANY_CODE_ENTERTAINER_EMAX: 'em',
            cls.COMPANY_CODE_DUBAI_ENTERTAINMENTS: 'de',
            cls.COMPANY_CODE_DHL: 'dh'
        }
        try:
            return prefixes[company]
        except KeyError:
            return prefix

    @classmethod
    def get_location_version(cls, company='entertainer'):
        """
        Gets version of location
       :return:
        """
        location_version = 1
        if company and company == cls.COMPANY_CODE_ENTERTAINER_HSBC:
            location_version = cls.LOCATION_VERSION_HSBC
        return location_version

    @classmethod
    def is_analytics_enabled(cls, company):

        """
        Checks is analytics enabled or not?
        :param str company: company
        """
        return company in (
            cls.COMPANY_CODE_ENTERTAINER_SENSODYNE,
            cls.COMPANY_CODE_LAK_ENTERTAINER,
            cls.COMPANY_CODE_ENTERTAINER_KEL,
            cls.COMPANY_CODE_ENTERTAINER_LAND_MARK_GROUP,
            cls.COMPANY_CODE_ZEINAH_ENTERTAINER,
            cls.COMPANY_CODE_ENTERTAINER_BNE,
            cls.COMPANY_CODE_ENTERTAINER_CHANGI_REWARDS_ENTERTAINER,
            cls.COMPANY_CODE_ENTERTAINER_EMAX,
            cls.COMPANY_CODE_ENTERTAINER_BATELCO,
            cls.COMPANY_CODE_Commercial_Bank_ENTERTAINER,
            cls.COMPANY_CODE_ENTERTAINER_QGIRCO,
            cls.COMPANY_CODE_ALJAWHAR_ENTERTAINER,
            cls.COMPANY_CODE_ASALAH_ENTERTAINER,
            cls.COMPANY_CODE_ENTERTAINER_GEMS,
            cls.COMPANY_CODE_ALBILAD,
            cls.COMPANY_CODE_ENTERTAINER_HSBC,
            cls.COMPANY_CODE_ENTERTAINER_CRG,
            cls.COMPANY_CODE_ENTERTAINER_NAAMA,
            cls.COMPANY_CODE_IGLOW_LIFESTYLE,
            cls.COMPANY_CODE_ENTERTAINER_JGE
        )

    @classmethod
    def get_number_of_companies_by_business_id(cls, business_id):
        """
        Returns number of companies created by a business
        :param int business_id: Business ID
        :rtype: int
        """
        return cls.query.filter(cls.business_id == business_id, cls.is_active).count()

    @classmethod
    def get_active_companies_by_business_id(cls, business_id):
        """
        Returns number of companies created by a business
        :param int business_id: Business ID
        :rtype: list
        """
        return cls.query.with_entities(
            cls.code,
            cls.logo.label('logo_url'),
            cls.description,
            cls.api_url
        ).filter(
            cls.business_id == business_id,
            cls.is_active
        ).all()
