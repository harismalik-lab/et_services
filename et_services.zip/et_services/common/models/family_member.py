"""
Family Member Model
"""
import datetime

from common.models.mixin import Mixin
from common.utils.api_utils import list_to_str_tuple
from sqlalchemy import TIMESTAMP, Column, DateTime, String, or_
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.ent_customer_profile import EntCustomerProfile


class FamilyMember(db.Model, Mixin):
    __tablename__ = 'family_member'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    PENDING = 2
    ACCEPTED = 1
    REJECTED = 0
    CANCELLED = 3

    NO_FAMILY_FOUND = 'No Family Found'
    LEAVE_THE_FAMILY = 'LEAVE THE FAMILY'
    FAMILY_CLOSED = 'Family closed.'
    REMOVED_MESSAGE = 'Removed Successfully.'

    FAMILY_MEMBERS_LIMIT = 5
    INVITATION_LIMIT = FAMILY_MEMBERS_LIMIT - 1
    INVITATION_RECIEVE_COUNT = 5

    DEFAULT_RELATIONSHIP = 'Owner'
    BUTTON_COLOR = "c93a20"

    BUTTON_CANCEL_TITLE = "CANCEL INVITATION"
    BUTTON_CANCEL_COLOR = "c93a20"

    BUTTON_RESEND_TITLE = "RESEND INVITATION"
    BUTTON_RESEND_COLOR = "5d96cb"

    BUTTON_LEAVE_FAMILY_TITLE = "LEAVE THE FAMILY"
    BUTTON_CLOSE_FAMILY_TITLE = "CLOSE THE FAMILY"
    BUTTON_LEAVE_FAMILY_COLOR = "c93a20"
    BUTTON_CLOSE_FAMILY_COLOR = "c93a20"
    BUTTON_BUY_NOW_COLOR = "5d96cb"

    BUTTON_REACTIVATE_TITLE = "Reactivate Family Account"
    BUTTON_REACTIVATE_COLOR = "5d96cb"

    FAMILY_HEADER_TITLE = "Family Tree"
    LIMIT_TEXT = "5/5"

    INVITATION_ACCEPT_CONTENT_IMAGE = "https://s3.amazonaws.com/entertainer-app-assets/icons/family/friends_icon.png"
    INVITATION_MESSAGE = "You've now got access to all of their {location} 2019 and {location} Body 2019 offers."

    JOIN_FAMILY_BUTTON_COLOR = "5d96cb"

    DECLINE_FAMILY_TITLE = "DECLINE INVITE"
    DECLINE_FAMILY_BUTTON_COLOR = "ffffff"
    DECLINE_FAMILY_BORDER_COLOR = "989898"

    ACCOUNT_EXPIRE_TITLE = "Account expired on:"
    REMOVE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/icons/family/Rejected.png'
    STATUS_IMAGE = "https://s3.amazonaws.com/entertainer-app-assets/icons/family/Active.png"
    STATUS_IMAGE_PENDING = 'https://s3.amazonaws.com/entertainer-app-assets/icons/family/Pending.png'
    DELETE_IMAGE = 'https://s3.amazonaws.com/entertainer-app-assets/icons/family/delete_icon.png'

    STATUS_COLOR = {
        PENDING: 'e5a138',
        ACCEPTED: '95d241',
        REJECTED: 'cb3c20',
        CANCELLED: 'c93a20'
    }

    STATUS_TITLES = {
        PENDING: 'Pending',
        ACCEPTED: 'Active',
        REJECTED: 'Rejected',
        CANCELLED: 'Cancelled'
    }

    STATUS_IMAGES = {
        PENDING: STATUS_IMAGE_PENDING,
        ACCEPTED: STATUS_IMAGE,
        REJECTED: REMOVE_IMAGE
    }

    FAMILY_INVITATION_BUTTON_TITLE = "VIEW PENDING INVITATIONS"
    MALE_GENDER_TEXT = 'his'
    FEMALE_GENDER_TEXT = 'her'
    GENDER_FEMALE = 'female'
    GENDER_MALE = 'Male'
    FAMILY_INVITATION_TITLE = "{name} has added you to {gender} family"
    FAMILY_INVITATION_MESSAGE = "{email} has invited you to enjoy huge savings as part of {gender} ENTERTAINER family."

    FAMILY_EXPIRED_MESSAGE = "None of your family members can use your new ENTERTAINER just yet."
    FAMILY_BUY_MESSAGE = "Your family account has been expired.\nGet our new product and share the love."
    MEMBER_INVITATION_MESSAGE = "{name} ({email}) has invited you to join their ENTERTAINER family."
    CONSENT_CONFIRMATION_MESSAGE_WANT_CHEERS = "I confirm I am of legal drinking age in {location} & non-Muslim"
    CONSENT_CONFIRMATION_MESSAGE_WANT_CHEERS_NON_GCC = "I confirm I am of a legal drinking age in {location}"
    CONSENT_CONFIRMATION_MESSAGE_DONOT_WANT_CHEERS = "I do not want Cheers, but thanks anyway. Please note that you " \
                                                     "will not receive the Cheers product."
    MESSAGE_FOR_LEGAL_TERMS = 'In order to continue you must be of legal drinking age and understand this product may ' \
                              'contain references to alcohol.By continuing, you confirm that you understand this and ' \
                              'agree to our End User License Agreement.'
    CHHERS_SELECTION_ERROR_MESSAGE = "Please make a selection."

    ALREADY_MEMBER = "Sorry {name} is already part of another ENTERTAINER family."
    ALREADY_MEMBER_SELF = "Sorry already part of another ENTERTAINER family."
    NO_ENTERTAINER_FAMILY = "You are not part of any ENTERTAINER Family."
    MEMBER_NOT_PART_OF_YOUR_ENTERTAINER_FAMILY = "Member is not part of your ENTERTAINER Family."
    NOT_ALLOWED_TO_ADD_MEMBERS = "Not allowed to add member."
    NOT_ALLOWED_TO_RESEND_INVITATION = "Not allowed to resend invitation."
    NOT_ALLOWED_TO_REMOVE_MEMBERS = "Not allowed to remove member."
    NOT_ALLOWED_TO_EDIT_MEMBERS = "Not allowed to edit member."
    NOT_ALLOWED_TO_ACCEPT_INVITATION = "Not allowed to accept invitation."
    NOT_ALLOWED_TO_CANCEL_INVITATION = "Not allowed to cancel invitation."
    CANCELLED_BY_PRIMARY_USER = 'Cancelled by Primary user.'
    REJECTED_BY_USER = 'Rejected by user.'
    INVITATION_LIMIT_MESSAGE = "Your invitation limit exceeded."
    INVITATION_ALREADY_SENT = "You cannot invite the same person multiple times"
    INVITATION_PENDING_LIMIT_MESSAGE = "Sorry, this user cannot receive any more ENTERTAINER family invites."
    FAMILY_MEMBER_NOT_FOUND = "Family member not found."
    EDITED_SUCCESSFULLY = 'Edited Successfully'
    INVITATION_NOT_FOUND = "Invitation not found."
    NO_INVITATION_FOUND = 'You do not have any invites at the moment'
    INVITATION_ALREADY_EXISTS = "Invitation already sent"
    CONFIRM_ACTIVE_REMOVE_MEMBER = "Are you sure you want to remove {name} from your ENTERTAINER family?"

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    family_id = Column(INTEGER(11), nullable=False, index=True)
    user_id = Column(INTEGER(11), nullable=False, index=True)
    is_primary = Column(BIT(1), nullable=False)
    identifier = Column(String(50), nullable=False, index=True)
    email = Column(String(255), nullable=False, index=True)
    relationship = Column(String(30), nullable=False)
    is_cheers_to_include = Column(BIT(1))
    show_cheers_popup = Column(BIT(1))
    cheers_consent_date = Column(DateTime)
    is_active = Column(BIT(1), nullable=False)
    status = Column(TINYINT(1), nullable=False, default=1)
    reason = Column(String(100))
    member_since = Column(DateTime)
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_by_user_id(cls, user_id):
        """
        Returns family_member detail against user_id
        :param int user_id:
        :rtype: FamilyMember
        """
        return cls.query.filter(cls.user_id == user_id).first()

    @classmethod
    def get_all_active_and_accepted_by_user_id(cls, user_id):
        """
        Returns family_member detail against user_id
        :param int user_id:
        :rtype: list
        """
        return cls.query.filter(cls.user_id == user_id, cls.is_active == 1, cls.status == cls.ACCEPTED).all()

    @classmethod
    def get_first_active_and_accepted_by_user_id(cls, user_id):
        """
        Returns family_member detail against user_id
        :param int user_id:
        :rtype: FamilyMember
        """
        return cls.query.filter(cls.user_id == user_id, cls.is_active == 1, cls.status == cls.ACCEPTED).first()

    @classmethod
    def find_family_member(cls, filters=None, in_filters=None, not_equal_filters=None, single=True):
        """
        Finds the family members of family
        """
        query = cls.query
        if filters and isinstance(filters, dict):
            for field, value in filters.items():
                query = query.filter(getattr(FamilyMember, field) == value)

        if in_filters and isinstance(in_filters, list):
            for in_filter in in_filters:
                for field, values_list in in_filter.items():
                    if values_list:
                        query = query.filter(getattr(FamilyMember, field).in_(values_list))

        if not_equal_filters and isinstance(not_equal_filters, dict):
            for field, value in not_equal_filters.items():
                query = query.filter(getattr(FamilyMember, field) != value)

        if single:
            return query.first()
        else:
            return query.all()

    @classmethod
    @with_master
    def update_member(cls, filters=None, in_filters=None, data=None):
        """
        Update family member info
        """
        _query = cls.query
        if filters:
            for key, value in filters.items():
                _query = _query.filter(getattr(cls, key) == value)

        for in_filter in in_filters:
            for field, values_list in in_filter.items():
                if values_list:
                    _query = _query.filter(getattr(cls, field).in_(values_list))

        _query.update(data, synchronize_session=False)
        cls.update_record()
        return True

    @classmethod
    def find_family_members_by_id_or_status(cls, family_id=None, status=None):
        """
        Finds family member on the basis of status
        """
        if family_id:
            _query = cls.query.with_entities(
                cls.status, cls.relationship.label('name'),
                cls.user_id, cls.date_created, cls.is_cheers_to_include, cls.identifier
            )
            _query = _query.filter(cls.family_id == family_id, cls.is_active == 1)
            if status:
                _query = _query.filter(cls.status == status)
            return _query.all()

    @classmethod
    def find_pending_invites_of_user(cls, user_id=None):
        """
        Finds the pending family invites of user
        :param user_id: int|None: id of user
        """
        return cls.query.with_entities(
            EntCustomerProfile.profile_image,
            EntCustomerProfile.firstname,
            EntCustomerProfile.lastname,
            EntCustomerProfile.email,
            EntCustomerProfile.id.label('customer_id'),
            cls.status,
            cls.relationship.label('name'),
            cls.user_id,
            cls.date_created,
            cls.is_cheers_to_include,
            cls.identifier,
            cls.family_id,
            cls.show_cheers_popup
        ).select_from(
            FamilyMember
        ).join(
            EntCustomerProfile,
            cls.user_id == EntCustomerProfile.user_id
        ).filter(
            cls.user_id == user_id,
            cls.status == cls.PENDING,
            cls.is_active == 1
        ).all()

    @classmethod
    def find_family_invitations_pending_accepted(
            cls, family_id=None, is_active=1, include_active_status=True,
            include_primary=True, is_primary=0
    ):
        """
        Finds the pending family invitations
        """
        _query = cls.query.filter(cls.family_id == family_id)

        if include_primary:
            _query = _query.filter(cls.is_primary == is_primary)
        if include_active_status:
            _query = _query.filter(cls.is_active == is_active)
        _query = _query.filter(cls.status.in_([cls.PENDING, cls.ACCEPTED]))

        return _query.all()

    @classmethod
    def find_family_member_count(cls, filters=None, in_filters=None, not_equal_filters=None):
        """
        Finds family member count
        """
        query = cls.query
        if filters:
            for key, value in filters.items():
                query = query.filter(getattr(cls, key) == value)

        if not_equal_filters:
            for key, value in not_equal_filters.items():
                query = query.filter(getattr(cls, key) != value)

        for in_filter in in_filters:
            for field, values_list in in_filter.items():
                if values_list:
                    query = query.filter(getattr(cls, field).in_(values_list))
        else:
            return query.count()

    @classmethod
    @with_master
    def deactivate_pending_invites(cls, user_id=None, exclude_invitation_ids=None, data=None):
        """
        Deactivates all pending invites
        """
        _query = cls.query.filter(cls.user_id == user_id, cls.is_active == 1, cls.status == cls.PENDING)
        if exclude_invitation_ids:
            _query = _query.filter(~cls.id.in_(exclude_invitation_ids))
        _query.update(data, synchronize_session=False)
        cls.update_record()
        return data

    @classmethod
    def find_family_members_part_of_any_family(cls, user_ids=None, email_list=None, family_id=None):
        """
        Finds all the member of any family on the base of email or user id
        """
        if user_ids is None:
            user_ids = []
        if email_list is None:
            email_list = []
        _query = cls.query.filter(cls.family_id == family_id, cls.is_active == 1, cls.status == cls.ACCEPTED)

        if user_ids and email_list:
            _query = _query.filter(or_(
                cls.email.in_(list_to_str_tuple(email_list)),
                cls.user_id.in_(list_to_str_tuple(user_ids))
            ))
        elif user_ids:
            _query = _query.filter(cls.user_id.in_(user_ids))
        elif email_list:
            _query = _query.filter(cls.email.in_(email_list))

        return _query.all()
