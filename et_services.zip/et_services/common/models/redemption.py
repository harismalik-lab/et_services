"""
Redemption Model
"""
import datetime
from datetime import timedelta

from flask import current_app
from sqlalchemy import (Column, DateTime, Float, ForeignKey, String, and_,
                        case, func, or_)
from sqlalchemy.dialects.mysql import BIT, INTEGER, TIMESTAMP, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.mixin import Mixin
from ..models.offer import Offer
from ..models.outlet import Outlet


class Redemption(db.Model, Mixin):
    __tablename__ = 'redemption'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    # Constants
    TYPE_DEFAULT = 1
    TYPE_DELIVERY = 2

    ACTIVE = 1
    IN_PROGRESS = 2
    INACTIVE = 3

    NOT_REDEEMABLE = 0
    REDEEMED = 1
    REDEEMABLE = 2
    REUSABLE = 3

    PROD_THRESHOLD = 31820843
    REDEEMABILITY_ALL = "all"
    REDEEMABILITY_NOT_REDEEMABLE = "not_redeemable"
    REDEEMABILITY_REDEEMED = "redeemed"
    REDEEMABILITY_REDEEMABLE = "redeemable"
    REDEEMABILITY_REUSABLE = "reusable"
    REDEEMABILITY_REDEEMABLE_REUSABLE = "redeemable_reusable"

    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM = 4
    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO = -18
    REDEMPTION_TRIGGERED_BY_OFFLINE_API = 'offline_api'

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    date_created = Column(DateTime, index=True, default=datetime.datetime.now)
    status = Column(TINYINT(1), nullable=False, default=1)
    offer_id = Column(ForeignKey(Offer.id, ondelete='SET NULL', onupdate='CASCADE'), index=True)
    product_id = Column(INTEGER(11))
    customer_id = Column(INTEGER(10), nullable=False, index=True, comment='The Magento customer ID.')
    primary_user_id = Column(INTEGER(11), index=True)
    outlet_id = Column(ForeignKey(Outlet.id, ondelete='SET NULL', onupdate='CASCADE'), index=True)
    code = Column(String(100), index=True)
    quantity = Column(INTEGER(11), nullable=False, default=1)
    session_token = Column(String(100))
    root_code = Column(String(20))
    company = Column(String(20), index=True, default='entertainer')
    purchased_through_connect = Column(BIT(1), default=False)
    conflict = Column(BIT(1))
    savings_estimate = Column(INTEGER(11), default=0)
    is_shared = Column(BIT(1))
    is_birthday_offer = Column(BIT(1))
    transaction_id = Column(String(100))
    sync = Column(BIT(1), index=True)
    is_onboarding = Column(TINYINT(1), default=0)
    sync_redemption_summary = Column(TINYINT(1), default=0)
    is_rate_updated = Column(TINYINT(1), default=0)
    peak_rate = Column(Float, default=0)
    peak_rate_aed = Column(Float, default=0)
    off_peak_rate = Column(Float, default=0)
    off_peak_rate_aed = Column(Float, default=0)
    device_os = Column(String(20))
    device_model = Column(String(50))
    device_language = Column(String(5))
    az_sync = Column(BIT(1), index=True)
    updated_on = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def find_redemptions_count_by_customer(cls, company, customer_id):
        """
        Find count of redemption made by a customer.
        :param str company: company
        :param customer_id: customer_id
        :rtype: int
        """
        if company and customer_id:
            query = cls.query.with_entities(cls.id).filter_by(customer_id=customer_id)
            query = query.filter(cls.company.like("{}%".format(company)))
            return query.count()
        return 0

    @classmethod
    @with_master
    def get_by_transaction_id_and_customer_id(cls, transaction_id, customer_id):
        """
        Returns redemption against transaction_id and customer_id.
        :param str transaction_id: Redemption transaction id
        :param int customer_id: User Id
        :rtype: Redemption
        """
        return cls.query.filter(cls.transaction_id == transaction_id, cls.customer_id == customer_id).first()

    @classmethod
    @with_master
    def get_number_of_redemptions_within_last_x_hours(cls, customer_id, offer_id, company, number_of_hours=24):
        """
        Get the redemption by time.
        :param int customer_id: Customer Id
        :param int offer_id: Offer Id
        :param str company: Company
        :param int number_of_hours: Number of hours
        :rtype: int
        """
        delta_datetime = (datetime.datetime.now() - timedelta(hours=number_of_hours))
        return cls.query.filter(
            cls.customer_id == customer_id,
            cls.offer_id == offer_id,
            cls.company.like('%{}%'.format(company)),
            cls.date_created > delta_datetime
        ).count()

    @classmethod
    @with_master
    def get_by_customer_id_and_company(cls, customer_id, company='', offer_ids=None):
        """
        Gets the redeemed quantities for customer
        :param None|list offer_ids: Offer ids
        :param int customer_id: Id of customer
        :param str company: Company
        :rtype: dict
        """
        query = cls.query.filter(
            cls.customer_id == customer_id,
            cls.company == company,
            cls.quantity > 0
        )
        if offer_ids:
            query = query.filter(cls.offer_id.in_(offer_ids))
        return query.all()

    @classmethod
    @with_master
    def update_status_flag(cls, redemption_ids_list=None, is_accepted=False):
        """
        Updates the status flag of redemption

        :param list redemption_ids_list: list of redemption ids
        :param bool is_accepted: is accepted flag
        """
        if redemption_ids_list:
            query = cls.query.filter(cls.id.in_(redemption_ids_list))
            if is_accepted:
                query.update({'status': cls.ACTIVE}, synchronize_session=False)
            else:
                query.update({'status': cls.INACTIVE}, synchronize_session=False)
            cls.update_record()

    @classmethod
    @with_master
    def get_redeemed_quantities_for_customer_primary_v3(
            cls,
            customer_id,
            is_onboarding,
            offer_id,
            company
    ):
        """
        Get redeemed quantities of offers for a customer.
        """
        query = cls.query.with_entities(
            cls.offer_id,
            cls.product_id,
            func.SUM(cls.quantity).label('quantity')
        )

        query = query.filter(cls.is_shared != 1)
        query = query.filter(coalesce(cls.primary_user_id, cls.customer_id, 0) == customer_id)

        if not is_onboarding:
            query = query.filter(cls.is_onboarding == 0)

        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            elif isinstance(offer_id, int):
                query = query.filter(cls.offer_id == offer_id)

        if company:
            query = query.filter(cls.company.like("{}%".format(company)))

        query = query.filter(cls.status.in_([cls.ACTIVE, cls.IN_PROGRESS]))

        query = query.group_by(cls.offer_id)

        return query.all()

    @classmethod
    @with_master
    def get_redeemed_quantites_for_customer_primary(
            cls, customer_id, is_onboarding=False, offer_id=None, company='entertainer',
    ):
        """
        Get redeemed quantites
        :param customer_id: Customer Id
        :param is_onboarding: Boolean flag to manipulate results
        :param offer_id: Offer Id
        :param company: Company name
        :return:
        """
        if customer_id:
            query = cls.query.with_entities(cls.offer_id, func.SUM(cls.quantity).label('qty'))
            query = query.filter(cls.is_shared == 0)
            query = query.filter(
                case(
                    [
                        (
                            cls.primary_user_id.is_(None),
                            cls.customer_id
                        ),
                    ],
                    else_=cls.primary_user_id
                ) == customer_id
            )
            if not is_onboarding:
                query = query.filter(cls.is_onboarding == 0)
            if offer_id:
                if isinstance(offer_id, list):
                    query = query.filter(cls.offer_id.in_(offer_id))
                else:
                    query = query.filter(cls.offer_id == offer_id)
            if company:
                query = query.filter(cls.company.like('{}%'.format(company)))
            query = query.filter(cls.status.in_([cls.ACTIVE, cls.IN_PROGRESS]))
            query = query.group_by(cls.offer_id)
            redemption_quantities = {}
            redemption_results = query.all()
            for redemption in redemption_results:
                redemption_quantities[redemption.offer_id] = int(redemption.qty)
            return redemption_quantities
        return {}

    @classmethod
    def count_offer_redemptions_by_customer(
            cls, customer_id, company, offer_id=None, group_by=False, is_shared=None, primary_user_id=None
    ):
        """
        Counts offer redemption of customer
        :param int customer_id: customer id
        :param str company: company name
        :param list offer_id: offer id
        :param bool group_by: group by boolean flag
        :param bool is_shared: is_shared boolean flag
        :param int primary_user_id: primary user id
        :rtype: list or int
        """
        query = cls.query.with_entities(
            cls.offer_id,
            func.SUM(cls.quantity).label('quantity')
        )

        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        query = query.filter(cls.customer_id == customer_id, cls.primary_user_id == primary_user_id)
        if is_shared is not None:
            query = query.filter(cls.is_shared == is_shared)
        query = query.filter(cls.company.like(company))
        query = query.filter(cls.status.in_([Redemption.ACTIVE, Redemption.IN_PROGRESS]))

        if group_by:
            query = query.group_by(cls.offer_id)
        records = query.all()
        if not records:
            records = 0
            if group_by:
                records = []
        return records

    @classmethod
    def count_offer_redemptions_by_customer_shared_offers(
            cls,
            customer_id,
            offer_id,
            group_by,
            primary_user_id,
            is_active_family_member,
            company
    ):
        """
        Gets the count of redemptions made by customer for shared offers.

        :param int customer_id: id of customer to get redeemed quantities for.
        :param int offer_id: id/ids of offer if we want to get redeemed quantities for specific offers.
        :param bool group_by: True if we want to group results by offer.
        :param int primary_user_id: id of primary user.
        :param bool is_active_family_member: True if customer is a member.
        :param company company: name of company.
        """
        query = cls.query.with_entities(cls.offer_id, func.SUM(cls.quantity).label('quantity'))
        query = query.filter(cls.company.like('{}%'.format(company)), cls.is_shared == 1)
        if primary_user_id and is_active_family_member:
            query = query.filter(cls.primary_user_id == primary_user_id)
        else:
            query = query.filter(
                or_(
                    cls.primary_user_id == customer_id,
                    and_(
                        cls.customer_id == customer_id,
                        func.coalesce(cls.primary_user_id, 0) == 0
                    )
                )
            )
        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        query = query.filter(cls.status.in_([cls.ACTIVE, cls.IN_PROGRESS]))

        if group_by:
            query = query.group_by(cls.offer_id)

        return query.all()

    @classmethod
    @with_master
    def get_reattempt_redemption_info(cls, customer_id, transaction_id, offer_id, outlet_id):
        """
        Verify reattempt redemption
        :param int customer_id: Id of customer
        :param int transaction_id: transaction Id
        :param int offer_id: Offer Id
        :param int outlet_id: outlet Id
        """
        transaction_expiry_date = datetime.datetime.now() - datetime.timedelta(minutes=2)
        query = cls.query.filter(
            cls.customer_id == customer_id,
            cls.offer_id == offer_id,
            cls.outlet_id == outlet_id,
            cls.transaction_id == transaction_id
        )
        query = query.filter(cls.date_created > transaction_expiry_date.strftime('%Y-%m-%d %H:%M:%S'))
        return query.first()

    @classmethod
    @with_master
    def get_redeemed_quantities_for_customer(
            cls,
            customer_id,
            primary_user_id,
            family_id,
            is_onboarding,
            offer_id,
            company
    ):
        """
        Gets the redeemed quantities for customer.

        :param int customer_id: id of customer to get redeemed quantities for.
        :param bool is_onboarding: True if customer is on boarding, else False.
        :param offer_id: id/ids of offer if we want to get redeemed quantities for specific offers.
        :param company company: name of company.
        :param int primary_user_id: id of primary user.
        :param int family_id: id of family.
        """
        assert (family_id and primary_user_id) or customer_id, 'Insufficient params'
        query = cls.query.with_entities(
            cls.offer_id,
            func.SUM(cls.quantity).label('qty')
        )
        if current_app.config.get('IS_PRODUCTION'):
            query = cls.query.filter(cls.id >= cls.PROD_THRESHOLD)
        if primary_user_id == customer_id:
            query = query.filter(
                or_(
                    cls.primary_user_id == customer_id,
                    and_(
                        cls.customer_id == customer_id,
                        coalesce(cls.primary_user_id, 0) == 0
                    ),

                ),
                cls.is_shared == 0
            )
        elif primary_user_id:
            query = query.filter(
                cls.is_shared == 0,
                coalesce(cls.is_birthday_offer, 0) == 0,
                or_(
                    cls.primary_user_id == primary_user_id,
                    and_(
                        cls.customer_id == primary_user_id,
                        coalesce(cls.primary_user_id, 0) == 0
                    )
                )

            )
        else:
            query = query.filter(
                or_(
                    cls.primary_user_id == customer_id,
                    and_(cls.customer_id == customer_id, coalesce(cls.primary_user_id, 0) == 0)),
                cls.is_shared == 0
            )
        if not is_onboarding:
            query = query.filter(cls.is_onboarding == 0)
        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        if company:
            query = query.filter(cls.company.like("{}%".format(company)))
        query = query.filter(cls.status.in_([cls.ACTIVE, cls.IN_PROGRESS]))
        query = query.group_by(cls.offer_id)
        return query.all()

    @classmethod
    @with_master
    def get_birthday_redeemed_quantities_for_secondary_customer(
            cls,
            customer_id,
            is_onboarding,
            offer_id,
            company
    ):
        """
        Gets birthday redeemed quantities for a secondary customer.

        :param int customer_id: id of customer.
        :param bool is_onboarding: if customer is on-boarding.
        :param offer_id: id/ids of offer if we want to get redeemed quantities for specific offers.
        :param str company: company of customer.
        """
        query = cls.query.with_entities(cls.offer_id, func.SUM(cls.quantity).label('qty'))
        if customer_id:
            query = query.filter(
                cls.customer_id == customer_id,
                cls.is_shared == 0,
                cls.primary_user_id == customer_id,
                cls.is_birthday_offer == 1
            )
        if not is_onboarding:
            query = query.filter(cls.is_onboarding == 0)
        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        if company:
            query = query.filter(cls.company.like('{}%'.format(company)))

        query = query.filter(cls.status.in_([cls.ACTIVE, cls.IN_PROGRESS]))
        query = query.group_by(cls.offer_id)

        return query.all()
