"""
Merchant Attributes Body Model
"""
import datetime

from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesBody(db.Model):
    __tablename__ = 'merchant_attributes_body'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    by_appointment_only = Column(TINYINT(1))
    couples_friendly = Column(TINYINT(1))
    indoor_facilities = Column(TINYINT(1))
    outdoor_facilities = Column(TINYINT(1))
    refreshments = Column(TINYINT(1))
    certified = Column(TINYINT(1))
    female_only = Column(TINYINT(1))
    supervised_play_area = Column(TINYINT(1))
    parking = Column(TINYINT(1))
    valet_parking = Column(TINYINT(1))
    male_only = Column(TINYINT(1))
    jacuzzi = Column(TINYINT(1))
    kids_play_area = Column(TINYINT(1))
    moroccan_bath = Column(TINYINT(1))
    personal_trainer = Column(TINYINT(1))
    sauna = Column(TINYINT(1))
    steam_room = Column(TINYINT(1))
    pool = Column(TINYINT(1))
    wheelchair_accessible = Column(TINYINT(1))
    wi_fi = Column(TINYINT(1))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).first()
