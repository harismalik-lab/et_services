"""
Merchant Attribute Group Translation Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class MerchantAttributeGroupTranslation(db.Model):
    __tablename__ = 'merchant_attribute_group_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    attribute_group_id = Column(INTEGER(10), nullable=False)
    locale = Column(String(10))
    name = Column(String(100))
