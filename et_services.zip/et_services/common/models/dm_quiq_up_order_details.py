"""
Dm Quiq up order details
"""
from sqlalchemy import Column, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class DmQuiqUpOrderDetail(db.Model, Mixin):
    __tablename__ = 'dm_quiq_up_order_details'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    order_id = Column(INTEGER(11), nullable=False, index=True)
    quiq_job_id = Column(String(50), index=True)
    quiq_job_status = Column(String(20))
    is_current_status = Column(TINYINT(1), server_default=text("'0'"))
    quiq_up_delivery_time = Column(Float(8), server_default=text("'0.0000'"))
    dropoff_tracking_url = Column(String(200))
    driver_name = Column(String(30))
    driver_number = Column(String(20), nullable=False, server_default=text("''"))
    created_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    updated_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    pickup_tracking_url = Column(String(200))

    @classmethod
    def get_quiq_up_delivery_status(cls, order_id, customer_id):
        """
        Gets the order status from DB. Gets the details of delivery quiq up job.
        :param int order_id: id of order
        :param int customer_id: id of customer
        :rtype: orm obj:
        :return Returns Quiqup Order status provided by hookup.
        """
        from ..models.dm_merchant_order import DmMerchantOrder

        query = cls.query.join(DmMerchantOrder, cls.order_id == DmMerchantOrder.id)
        query = query.with_entities(
            cls.quiq_job_id,
            cls.created_date,
            cls.quiq_job_status,
            cls.dropoff_tracking_url,
            cls.driver_name,
            cls.driver_number,
            DmMerchantOrder.order_number
        )
        query = query.filter(
            DmMerchantOrder.customer_id == customer_id,
            cls.order_id == order_id,
            cls.is_current_status == 1
        )
        return query.first()
