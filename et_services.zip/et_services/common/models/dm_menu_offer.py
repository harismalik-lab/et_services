"""
Dm Menu Offer Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmMenuOffer(db.Model):
    __tablename__ = 'dm_menu_offer'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    offer_id = Column(INTEGER(11), index=True)
    dm_menu_item_id = Column(INTEGER(11), index=True)
    offer_sf_id = Column(String(25))
    company = Column(String(50), nullable=False, index=True, default='entertainer')
    company_id = Column(INTEGER(11), nullable=False, index=True, default=50)
