"""
Configuration Cheers Translation Model
"""
from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class ConfigurationCheersTranslation(db.Model):
    __tablename__ = 'configuration_cheers_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    config_id = Column(INTEGER(11))
    locale = Column(String(2))
    redemption_message = Column(Text)
    product_information = Column(Text)
    message_for_legal_terms = Column(Text)
    consent_confirmation_message = Column(Text)
    age_restriction_message = Column(Text)
    redemption_confirm_message = Column(Text)
    delivery_title = Column(String(255))
    delivery_description = Column(Text)
    delivery_button_title = Column(String(255))
    drinking_age_confirmation_message = Column(String(255))
    not_interested_in_cheers_offers_message = Column(String(255))
    error_message_to_select_an_option = Column(String(255))
