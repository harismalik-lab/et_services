"""
Cuisine model
"""
from sqlalchemy import Column, String, text
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT, VARCHAR

from ..constants import ENTERTAINER_WEB
from ..models.cuisine_translation import CuisineTranslation
from ..models.db import db
from ..models.mixin import Mixin


class Cuisine(db.Model, Mixin):
    __tablename__ = 'cuisine'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    name = Column(VARCHAR(500))
    value = Column(String(50))
    order_id = Column(SMALLINT(6), server_default=text("'1'"))
    is_top_cuisine = Column(TINYINT(1), server_default=text("'0'"))
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    image_url = Column(String(255))
    image_url_default = Column(String(255))
    image_url_selected = Column(String(255))

    @classmethod
    def get_cuisines_for_merchant_filters(cls, **kwargs):
        """
        Fetch cuisines for merchants
        :rtype: list
        """
        locale = kwargs.get('locale', 'en')
        query = cls.query.join(CuisineTranslation, cls.id, CuisineTranslation.cuisine_id)
        query = query.with_entities(
            cls.id,
            cls.name.label('value'),
            CuisineTranslation.name,
            cls.order_id,
            cls.is_top_cuisine,
            cls.is_active,
            cls.image_url,
            cls.image_url_default,
            cls.image_url_selected
        )
        query = query.filter(CuisineTranslation.locale == locale, cls.is_active == 1)
        query = query.order_by(cls.order_id.asc(), cls.is_top_cuisine.desc(), CuisineTranslation.name.asc())
        return query.all()
