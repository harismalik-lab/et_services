"""
CustomerOrderData model of EntertainerBusiness schema.
"""
from sqlalchemy import Column, String, TIMESTAMP, text, Date, Text, Float
from sqlalchemy.dialects.mysql import INTEGER, TINYINT, LONGTEXT

from ..constants import ENTERTAINER_BUSINESS
from ..models.mixin import Mixin
from ..models.db import db


class CustomerOrderData(db.Model, Mixin):
    __tablename__ = 'customer_order_data'
    __table_args__ = ({
        "schema": ENTERTAINER_BUSINESS
    })

    id = Column(INTEGER(11), primary_key=True)
    order_id = Column(INTEGER(10), nullable=False, index=True)
    request_data = Column(Text)
    data = Column(Text)

    @classmethod
    def add_entry(cls, **kwargs):
        """
        Add data into customer order to keep record.
        """
        order_data = cls(**kwargs)
        order_data.insert_record()
