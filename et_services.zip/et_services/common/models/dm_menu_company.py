"""
DM Menu Company Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmMenuCompany(db.Model):
    __tablename__ = 'dm_menu_company'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    outlet_setting_id = Column(INTEGER(11), index=True)
    company = Column(String(50), index=True, default='entertainer')
    company_id = Column(INTEGER(11), nullable=False, index=True, default=50)
    is_selected = Column(TINYINT(1), default=0)
    is_deleted = Column(TINYINT(1), nullable=False, index=True, default=0)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
