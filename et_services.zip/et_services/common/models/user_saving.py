"""
User Savings Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.exchange_rate import ExchangeRate
from ..models.mixin import Mixin


class UserSaving(db.Model, Mixin):
    __tablename__ = 'user_savings'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(20), nullable=False, index=True, default='entertainer')
    user_id = Column(INTEGER(11), nullable=False, index=True)
    total_redemptions = Column(INTEGER(11), default=0)
    total_savings = Column(INTEGER(11), default=0)
    current_year_redemptions = Column(INTEGER(11), default=0)
    current_year_savings = Column(INTEGER(11), default=0)
    total_points = Column(INTEGER(11), default=0)
    current_year_points = Column(INTEGER(11), default=0)
    gems_savings = Column(INTEGER(11), default=0)
    user_rank = Column(SMALLINT(6), default=0)
    is_notification_to_send = Column(TINYINT(1), default=0)
    is_user_rank_processed = Column(TINYINT(1), default=1)
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_by_user_id_and_company(cls, user_id, company):
        """
        Returns savings against user_id and company_id
        :param int user_id: User Id
        :param str company: Company
        :rtype: UserSaving
        """
        return cls.query.filter(cls.user_id == user_id, cls.company == company).first()

    @classmethod
    def get_user_savings_online(cls, customer_id, currency, company):
        """
        Gets the user savings
        :param int customer_id: User Id
        :param str currency: Currency
        :param str company: Company
        :rtype dict
        """
        user_savings_response = {
            'savings': 0,
            'yearly_savings': 0
        }

        user_savings = cls.query.filter_by(
            user_id=customer_id,
            company=company
        ).order_by(coalesce(cls.total_points, 0)).order_by(coalesce(cls.gems_savings, 0)).all()

        if len(user_savings) > 0:
            user_savings = user_savings[0]
            savings = ExchangeRate.get_conversion_rate(
                float(user_savings.total_savings),
                'AED',
                currency
            )
            yearly_savings = ExchangeRate.get_conversion_rate(
                float(user_savings.current_year_savings),
                'AED',
                currency
            )
            if 1 > savings > 0:
                savings = 1
            if 1 > yearly_savings > 0:
                yearly_savings = 1

            user_savings_response['savings'] = round(savings)
            user_savings_response['yearly_savings'] = round(yearly_savings)
            user_savings_response['points'] = user_savings.total_points
        return user_savings_response

    @classmethod
    @with_master
    def update_user_savings(cls, _id, user_id, savings, points=0):
        """
        Updates user savings in a way to avoid race condition
        :param int _id: Row Id
        :param int user_id: User Id
        :param int savings: savings
        :param int points: points
        """
        sql = 'UPDATE {db_name}.user_savings ' \
              'SET total_savings = COALESCE(total_savings, 0) + {savings},' \
              'current_year_savings = COALESCE(current_year_savings, 0) + {savings},' \
              'current_year_redemptions = COALESCE(current_year_redemptions,0) + 1,' \
              'total_redemptions = COALESCE(total_redemptions, 0) + 1,' \
              'total_points = COALESCE(total_points, 0) + {points},' \
              'current_year_points = COALESCE(current_year_points, 0) + {points},' \
              'is_user_rank_processed=0 ' \
              'WHERE id={id} AND user_id={user_id}'
        savings = int(savings or 0)

        sql = sql.format(
            savings=savings,
            points=points,
            db_name=ENTERTAINER_WEB,
            id=_id,
            user_id=user_id
        )
        db.session.execute(sql)

    @classmethod
    def get_user_yearly_savings(cls, user_id, company='entertainer'):
        """
        The method gets user's yearly savings
        :param int user_id: User Id
        :param str company: User's company name
        """
        query = cls.query.with_entities(
            coalesce(cls.current_year_redemptions, 0).label('offers_used'),
            coalesce(cls.current_year_savings, 0).label('savings_this_year')
        ).filter_by(
            user_id=user_id,
            company=company
        )
        return query.first()
