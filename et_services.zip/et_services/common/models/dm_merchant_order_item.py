"""
Dm merchant order items
"""
from sqlalchemy import Column, DateTime, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.dm_attribute_group_translation import DmAttributeGroupTranslation
from ..models.mixin import Mixin


class DmMerchantOrderItem(db.Model, Mixin):
    __tablename__ = 'dm_merchant_order_item'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    offer_sf_id = Column(String(100))
    offer_name = Column(String(200))
    order_id = Column(INTEGER(11), index=True)
    quantity = Column(TINYINT(11))
    promo = Column(String(200))
    total_price = Column(Float(8), server_default=text("'0.0000'"))
    base_total_price = Column(Float(8), server_default=text("'0.0000'"))
    sub_total = Column(Float(8), server_default=text("'0.0000'"))
    base_sub_total = Column(Float(8), server_default=text("'0.0000'"))
    total_discount = Column(Float(8), server_default=text("'0.0000'"))
    base_total_discount = Column(Float(8), server_default=text("'0.0000'"))
    item_json = Column(String(2))
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    created_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    dm_menu_item_id = Column(INTEGER(11))
    redemption_id = Column(INTEGER(11))
    dm_attribute_id = Column(INTEGER(11))
    dm_attribute_group_id = Column(INTEGER(11))
    offer_id = Column(INTEGER(11))
    base_tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    settlement_id = Column(INTEGER(11), index=True)
    parent_order_item_id = Column(INTEGER(11))

    @classmethod
    def get_order_redemption_ids(cls, order_id):
        """
        Get order redemption ids

        :param int order_id: id of order
        :return orm obj: query set result
        """
        query = cls.query.with_entities(
            cls.redemption_id
        )
        query = query.filter(cls.order_id == order_id)
        return query.all()

    @classmethod
    def get_order_items_detail(cls, order_id):
        """
        Get order items detail

        :param order_id: id of order
        :return orm obj: query set result
        """
        query = cls.query.with_entities(
            cls.id,
            cls.promo,
            cls.total_price,
            cls.dm_menu_item_id,
            cls.total_discount,
            cls.redemption_id,
            cls.parent_order_item_id,
            coalesce(cls.quantity).label('item_quantity'),
            coalesce(cls.offer_name).label('item_title'),
            coalesce(cls.dm_attribute_id).label('attribute_id'),
            coalesce(DmAttributeGroupTranslation.group_name).label('sub_title'),
            DmAttributeGroupTranslation.dm_attribute_group_id
        )
        query = query.outerjoin(
            DmAttributeGroupTranslation,
            DmAttributeGroupTranslation.dm_attribute_group_id == cls.dm_attribute_group_id
        )
        query = query.filter(cls.order_id == order_id, cls.is_active == 1)
        query = query.order_by(cls.id.asc())
        return query.all()
