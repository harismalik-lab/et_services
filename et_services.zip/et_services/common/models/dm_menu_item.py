"""
Dm Menu Item Model
"""
import datetime

from sqlalchemy import Column, Enum, Float, String, and_
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import AED, EN, ENTERTAINER_WEB
from ..models.db import db


class DmMenuItem(db.Model):
    __tablename__ = 'dm_menu_item'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    outlet_setting_id = Column(INTEGER(11), index=True)
    item_price = Column(Float(8), default=0.00)
    dm_category_id = Column(INTEGER(10), index=True)
    updated_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    sort_order = Column(TINYINT(1), default=0)
    is_deleted = Column(TINYINT(1), default=0)
    online_status = Column(Enum('online', 'offline'), default='online')
    status = Column(TINYINT(1), default=1)
    omnivore_item_id = Column(INTEGER(11))
    updated_by = Column(String(100))

    @classmethod
    def get_outlet_items_customisations(cls, menu_item_ids, locale=EN, currency=AED):
        """
        :param str currency: Currency
        :param list menu_item_ids: Menu Item Ids
        :param str locale: Locale
        """
        from ..models.dm_attribute_group import DmAttributeGroup
        from ..models.dm_attribute_group_translation import DmAttributeGroupTranslation
        from ..models.dm_attribute import DmAttribute
        from ..models.dm_attribute_translation import DmAttributeTranslation

        query = cls.query.join(
            DmAttributeGroup,
            and_(
                DmAttributeGroup.dm_menu_item_id == cls.id,
                DmAttributeGroup.is_delete == 0
            )
        )
        query = query.join(
            DmAttributeGroupTranslation,
            DmAttributeGroup.id == DmAttributeGroupTranslation.dm_attribute_group_id
        )
        query = query.outerjoin(
            DmAttribute,
            and_(
                DmAttributeGroup.id == DmAttribute.dm_attribute_group_id,
                DmAttribute.is_deleted == 0
            )
        )
        query = query.join(DmAttributeTranslation, DmAttribute.id == DmAttributeTranslation.dm_attribute_id)
        query = query.with_entities(
            cls.id.label('menu_item_id'),
            DmAttributeGroup.group_identifier,
            DmAttributeGroupTranslation.group_name,
            coalesce(DmAttribute.attribute_price_field, 0).label('attribute_price_field'),
            DmAttributeGroup.id.label('attribute_group_id'),
            DmAttributeGroupTranslation.group_name.label('title'),
            DmAttributeTranslation.name.label('option_title'),
            DmAttribute.id.label('item_id'),
            coalesce(DmAttributeGroup.min_choices, 0).label('min_choices'),
            DmAttributeGroup.group_identifier,
            coalesce(DmAttributeGroup.max_choices, 0).label('max_choices')
        )
        query = query.filter(cls.id.in_(menu_item_ids))
        query = query.order_by(cls.id.desc())
        return query.all()
