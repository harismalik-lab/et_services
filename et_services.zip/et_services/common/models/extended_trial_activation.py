"""
Extended trial activation Model
"""
import datetime

from sqlalchemy import Column, DateTime
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class ExtendedTrialActivation(db.Model):
    __tablename__ = 'extended_trial_activation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    extended_trial_group_id = Column(INTEGER(11))
    user_id = Column(INTEGER(11))
    created_date = Column(DateTime, default=datetime.datetime.now)
    updated_date = Column(DateTime, default=datetime.datetime.now)
    is_active = Column(BIT(1))

    @classmethod
    def get_group_id_by_user_id(cls, user_id):
        """
        Returns list of extended_trial_group_id against user_id
        :rtype: list
        """
        return cls.query.with_entities(cls.extended_trial_group_id).filter(cls.user_id == user_id).all()

    @classmethod
    def deactivate_extended_trial_of_user(cls, customer_id=0):
        """
        Deactivates the extended trail of user
        """
        if customer_id:
            changes = {'is_active': 0}
            cls.query.filter(
                cls.user_id == customer_id,
                cls.is_active == 1
            ).update(
                changes
            )
            cls.update_record()
            return True
        else:
            return False
