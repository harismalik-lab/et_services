"""
Company Messages Model
"""
import datetime

from sqlalchemy import VARCHAR, Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class CompanyMessages(db.Model, Mixin):
    __tablename__ = 'company_messages'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(50), nullable=False, index=True)
    message_key = Column(String(250), nullable=False, index=True)
    message_value = Column(VARCHAR(1000), nullable=False)
    locale = Column(String(20), index=True, default=EN)
    is_active = Column(BIT(1), index=True)
    created_at = Column(DateTime, default=datetime.datetime.now)

    @classmethod
    def get_message_key_related_records(cls, company_code, msg_keys):
        """
        get company and message_key specific records
        :param company_code:
        :param msg_keys:
        :return matching objects:
        """
        return cls.query.filter(cls.company == company_code, cls.message_key.in_(msg_keys)).all()

    @classmethod
    def get_company_translations(cls, company_code):
        """
        get company specific active records.
        :param company_code:
        :return matching objs:
        """
        return cls.query.with_entities(
            cls.message_key,
            cls.message_value,
            cls.locale
        ).filter(cls.company == company_code, cls.is_active == 1).all()
