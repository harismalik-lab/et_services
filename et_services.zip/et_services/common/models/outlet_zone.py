"""
Outlet Zone Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, Float, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class OutletZone(db.Model):
    __tablename__ = 'outlet_zone'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    title = Column(String(200))
    outlet_id = Column(INTEGER(11), nullable=False, index=True)
    min_order_amount = Column(Float(8))
    del_charge_total = Column(Float(8))
    del_charge_min = Column(Float(8))
    min_order_cap = Column(BIT(1), nullable=False)
    del_charge_on_total_order = Column(BIT(1), nullable=False)
    del_charge_on_less_than_min = Column(BIT(1), nullable=False)
    default_delivery_time = Column(SMALLINT(1))
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    update_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    is_deleted = Column(TINYINT(1), nullable=False, index=True, default=0)
    zone_type = Column(String(10))
