"""
Redemption Custom Codes Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class RedemptionCustomCode(db.Model, Mixin):
    __tablename__ = 'redemption_custom_codes'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    CUSTOM_CODE_STATUS_UNUSED = 0
    CUSTOM_CODE_STATUS_RESERVED = 1
    CUSTOM_CODE_STATUS_USED = 2

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(INTEGER(11), nullable=False, index=True)
    offer_id = Column(INTEGER(11), nullable=False, index=True)
    offer_sf_id = Column(String(20), nullable=False)
    code = Column(String(100), nullable=False)
    is_active = Column(BIT(1), nullable=False)
    status = Column(
        TINYINT(1),
        nullable=False,
        default=0,
        comment='to mark a custom code reserved while redemption workflow'
    )
    is_used = Column(BIT(1))
    redemption_id = Column(INTEGER(11), comment='primary id of redemption')
    batch_reference_code = Column(String(20))
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_custom_code_for_offer(cls, offer_id):
        """
        This function returns unused custom code for an offer if available.
        :param int offer_id: Offer Id
        """
        query = cls.query.filter(
            cls.offer_id == offer_id,
            cls.is_active.is_(True),
            cls.status == cls.CUSTOM_CODE_STATUS_UNUSED,
            cls.is_used.isnot(True)
        )
        return query.first()

    @classmethod
    def get_custom_code_by_id(cls, custom_code_id):
        """
        Custom code
        :param custom_code_id: custom code Id
        """
        return cls.query.filter(cls.id == custom_code_id).one()
