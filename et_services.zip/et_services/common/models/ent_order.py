"""
Ent Order Model
"""
from sqlalchemy import TIMESTAMP, Column, Enum, Float, String, text
from sqlalchemy.dialects.mysql import BIGINT, CHAR, INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import AR, CN, CONSOLIDATION, EL
from ..models.db import db
from ..models.ent_order_item import EntOrderItem
from ..models.mixin import Mixin
from ..models.product import Product
from ..models.product_translation import ProductTranslation
from ..utils.translation_manager import TranslationManager


class EntOrder(db.Model, Mixin):
    __tablename__ = 'ent_order'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(INTEGER(10), primary_key=True)
    company = Column(String(20), nullable=False, default=text("'entertainer'"))
    order_number = Column(BIGINT(20))
    tracking_number = Column(String(50), nullable=False)
    user_id = Column(INTEGER(10), nullable=False, index=True)
    create_date = Column(TIMESTAMP, nullable=False, default=text("CURRENT_TIMESTAMP"))
    update_date = Column(TIMESTAMP)
    cart_forming_time = Column(INTEGER(11), default=0)
    order_status_id = Column(INTEGER(10), nullable=False)
    shipping_option_id = Column(INTEGER(10), default=0)
    payment_type_id = Column(INTEGER(10), default=0)
    items_count = Column(Float)
    promo = Column(String(50), index=True)
    discount = Column(Float(asdecimal=True), nullable=False)
    subtotal = Column(Float(asdecimal=True), nullable=False)
    placed_from = Column(String(50))
    total_price = Column(Float, default=0)
    base_sub_total = Column(Float)
    base_discount_amount = Column(Float)
    hash = Column(CHAR(32), nullable=False)
    user_ip = Column(String(40))
    server_ip = Column(String(40))
    customer_group_id = Column(INTEGER(11), nullable=False, default=1)
    using_trial = Column(TINYINT(1), default=1)
    payment_gateway = Column(String(255), default=text("'checkout.com'"), comment='checkout.com etc')
    credit_card_type = Column(String(100))
    cc_number = Column(String(4), comment='Last four digits')
    order_currency = Column(String(5))
    local_currency = Column(String(5))
    cc_charge_id = Column(String(255))
    item_status = Column(Enum('Invoiced'), default=text("'Invoiced'"))
    order_instructions = Column(String(500), nullable=False)
    base_total_price = Column(Float, default=0)
    base_shipping_amount = Column(Float, default=0)
    shipping_amount = Column(Float, default=0)
    app_version = Column(String(100))
    is_pay_monthly = Column(TINYINT(1), default=0)
    is_refunded = Column(TINYINT(1), default=0)
    smiles_to_burn = Column(INTEGER(11), nullable=False, default=0)
    tax_amount = Column(Float(8))
    base_tax_amount = Column(Float(8))
    refund_amount = Column(Float(8), default=0.0000)
    base_refund_amount = Column(Float(8), default=0.0000)
    refund_tax_amount = Column(Float(8), default=0.0000)
    base_refund_tax_amount = Column(Float(8), default=0.0000)
    tax_percentage = Column(INTEGER(11))
    shukran_code = Column(String(50))
    affiliate_id = Column(INTEGER(11), nullable=False, default=1)
    updated_by = Column(INTEGER(11))

    @classmethod
    def get_customer_purchased_skus_profile(cls, user_id, company, locale):
        """
        Gets the customer purchased sku
        :param int user_id: id of the user
        :param str company: company of the user
        :param str locale: locale of customer
        :rtype: dict
        """
        query = cls.query.join(EntOrderItem, cls.id == EntOrderItem.id)
        query = query.join(Product, Product.sf_id == EntOrderItem.product_sku)
        query = query.join(ProductTranslation, Product.id == ProductTranslation.product_id)
        query = query.filter(
            cls.user_id == user_id,
            cls.company == company,
            ProductTranslation.locale == locale,
            coalesce(EntOrderItem.inactive, 0)
        ).distinct()

        result = query.first()
        if result:
            valid_until_text = TranslationManager.VALID_UNTIL_TEXT_EN
            if locale == AR:
                valid_until_text = TranslationManager.VALID_UNTIL_TEXT_AR
            elif locale == CN:
                valid_until_text = TranslationManager.VALID_UNTIL_TEXT_CN
            elif locale == EL:
                valid_until_text = TranslationManager.VALID_UNTIL_TEXT_EL
            for result in result:
                if result.expiry_date:
                    result['product_validity_message'] = "{} {}".format(
                        valid_until_text, result.expiry_date.strftime('%d %B %Y')
                    )
                    result['expiry_date'] = str(result.expiry_date)
        return result
