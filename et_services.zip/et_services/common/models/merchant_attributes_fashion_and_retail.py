"""
Merchant Attributes Fashion and Retail Model
"""
import datetime

from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesFashionAndRetail(db.Model):
    __tablename__ = 'merchant_attributes_fashion_and_retail'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    children_baby_only = Column(TINYINT(1))
    fashion_accessories = Column(TINYINT(1))
    footwear = Column(TINYINT(1))
    ladieswear = Column(TINYINT(1))
    menswear = Column(TINYINT(1))
    opticians = Column(TINYINT(1))
    sportswear = Column(TINYINT(1))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).first()
