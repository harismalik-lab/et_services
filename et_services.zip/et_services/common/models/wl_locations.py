"""
wl locations model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class Wllocation(db.Model, Mixin):
    __tablename__ = 'wllocations'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    location_id = Column(INTEGER(11), nullable=False)
    wl_company = Column(String(5), nullable=False, index=True)
    active = Column(BIT(1), nullable=False)
    is_careem_enabled = Column(BIT(1))
    order_id = Column(INTEGER(11), nullable=True, default=0)
