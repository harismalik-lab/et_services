"""
App Config Model
"""
from sqlalchemy import Column, or_
from sqlalchemy.dialects.mysql import INTEGER, TINYTEXT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class ApiConfiguration(db.Model, Mixin):
    __tablename__ = 'api_configuration'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    KEY_LESS_ACTIVATION = 'key_less_activation'
    SHOW_MERLIN_OFFERS = 'show_merlin_offers'
    EMAIL_SERVICE_ENABLED = 'email_service_enabled'
    MERCHANT_PIN_VALIDATION = 'merchant_pin_validation'
    ENABLE_USER_WELCOME_EMAIL = 'enable_user_welcome_email'

    GENERIC = 'generic'
    IS_LOOKUP_BASED = 'is_lookup_based'
    IS_PARENT_BASED = 'is_parent_based'
    BLUE_PRODUCTS = 'blue_products'  # Alfuttaim Blue Product SKUs

    ENABLE_BIRTHDAY_FEATURE = 'enable_birthday_feature'
    ENABLE_FAMILY_FEATURE = 'enable_family_feature'
    ENABLE_PING_FEATURE = 'enable_ping_feature'
    ENABLE_SMILE_FEATURE = 'enable_smile'

    ENABLE_USER_EMAIL_VERIFICATION = 'enable_user_email_verification'
    ENABLE_DELIVERY_CASHLESS = 'enable_delivery_cashless'
    ENABLE_LAST_MILE = 'enable_last_mile'
    ENABLE_TAKEAWAYS = 'enable_takeaways'
    ENABLE_CINEMA_INTEGRATION = 'enable_cinema_integration'

    ENCRYPTED_RESPONSE = 'enable_encryption'
    COMPANY_TYPE = 'company_type'

    ENABLE_CHEERS = 'enable_cheers'
    ENABLE_SHARED_OFFERS = 'enable_shared_offers'
    ENABLE_TOP_UP_OFFERS = 'enable_top_up_offers'
    ENABLE_NEW_OFFERS = 'enable_new_offers'
    ENABLE_MONTHLY_OFFERS = 'enable_monthly_offers'
    ENABLE_FOURTH_OFFERS = 'enable_fourth_offers'
    ENABLE_LIVE_OFFERS = 'enable_live_offers'

    ENABLE_EXTENDED_TRIAL = 'enable_extended_trial'
    ENABLE_TABLE_RESERVATION = 'enable_table_reservation'

    id = Column(INTEGER(11), primary_key=True)
    config_key = Column(TINYTEXT)
    config_value = Column(TINYTEXT)
    company = Column(TINYTEXT)
    environment = Column(TINYTEXT)
    config_group = Column(TINYTEXT)

    @classmethod
    def get_configuration_by_company(cls, company, environment='prod', group=''):
        """
        get company based configurations for specific environment
        :param str company:
        :param str environment:
        :param str group:
        """
        query = cls.query.filter(
            or_(
                cls.company == company,
                cls.company == cls.GENERIC
            ),
            cls.environment == environment
        )
        if group:
            query = query.filter(cls.config_group == group)
        return query.all()
