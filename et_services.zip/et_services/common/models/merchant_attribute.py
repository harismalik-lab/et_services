"""
Merchant Attribute Model
"""
from flask import g
from sqlalchemy import Column, String, Text, and_
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant_attribute_translation import MerchantAttributeTranslation

cache = g.cache


class MerchantAttribute(db.Model):
    __tablename__ = 'merchant_attribute'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    category_id = Column(INTEGER(11), nullable=False, index=True)
    merchant_attribute_group_id = Column(INTEGER(11), nullable=False)
    attribute_key = Column(String(100), nullable=False)
    attribute_name = Column(String(100), nullable=False)
    attribute_type = Column(TINYINT(1), default=0)
    attribute_values = Column(Text)
    order_id = Column(SMALLINT(6), default=1)
    image_url = Column(Text)
    is_active = Column(BIT(1), nullable=False)

    @classmethod
    @cache.memoize(3600)
    def get_by_locale(cls, locale=EN):
        """
        Returns Merchant Attributes against locale
        :param str locale: Locale
        """
        return cls.query.with_entities(
            cls.category_id, cls.merchant_attribute_group_id,
            cls.attribute_key, MerchantAttributeTranslation.attribute_title.label('attribute_name'),
            cls.attribute_type, cls.attribute_values, cls.image_url
        ).join(
            MerchantAttributeTranslation,
            and_(
                cls.id == MerchantAttributeTranslation.attribute_id,
                MerchantAttributeTranslation.locale == locale
            )
        ).filter(
            cls.is_active,
            cls.attribute_type == 1
        ).all()
