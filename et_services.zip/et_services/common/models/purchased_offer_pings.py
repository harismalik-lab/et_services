"""
Purchased Offer Ping model
"""
from sqlalchemy import TIMESTAMP, Column, DateTime, case, func, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class PurchasedOfferPing(db.Model):
    __tablename__ = 'purchased_offer_pings'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(11), nullable=False)
    primary_user_id = Column(INTEGER(11), index=True)
    transaction_type = Column(TINYINT(1), nullable=False)
    pings = Column(INTEGER(11), nullable=False)
    amount = Column(INTEGER(11), nullable=False)
    smiles_used = Column(INTEGER(11), nullable=False)
    transaction_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    expiry_date = Column(DateTime)
    is_active = Column(TINYINT(1), nullable=False)

    @classmethod
    def get_purchased_pings(cls, user_id, current_year):
        """
        :param user_id:
        :param current_year:
        :return:
        """
        start_date = "{}-01-01".format(current_year)
        end_date = "{}-12-31".format(current_year)
        query = cls.query.with_entities(func.sum(cls.pings.label('purchased_pings')))
        query = query.filter(
            cls.is_active == 1,
            case(
                [
                    (
                        cls.primary_user_id.isnot(None),
                        cls.primary_user_id
                    ),
                ],
                else_=cls.user_id
            ) == user_id)
        query = query.filter(cls.expiry_date.between(start_date, end_date))

        pings = query.first()
        pings = pings._asdict()
        if pings:
            pings = int(pings['purchased_pings']) if pings['purchased_pings'] else 0
            return pings
        return 0
