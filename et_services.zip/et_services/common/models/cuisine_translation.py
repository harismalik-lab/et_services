"""
Cuisine translation model
"""
from sqlalchemy import Column, ForeignKey, String, Text, text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class CuisineTranslation(db.Model, Mixin):
    __tablename__ = 'cuisine_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    cuisine_id = Column(ForeignKey('cuisine.id', ondelete='CASCADE', onupdate='CASCADE'), nullable=False, index=True)
    locale = Column(String(5), server_default=text("'en'"))
    name = Column(Text)
