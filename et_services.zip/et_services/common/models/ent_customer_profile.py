"""
Ent Customer Profile Model
"""
import datetime

from sqlalchemy import (TIMESTAMP, VARBINARY, Column, Date, DateTime, String,
                        Text)
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import CONSOLIDATION
from ..models.db import db, with_master
from ..models.mixin import Mixin
from ..models.user import User


class EntCustomerProfile(db.Model, Mixin):
    __tablename__ = 'ent_customer_profile'
    __table_args__ = {"schema": CONSOLIDATION}

    # Constants
    TRIAL = 1
    MEMBER = 2

    ONBOARDING_NOT_STARTED = 0
    ONBOARDING_INPROGRESS = 1
    ONBOARDING_FINISHED = 2

    INACTIVE_MEMBERSHIP_SUB_GROUP = 0
    ACTIVE_MEMBERSHIP_SUB_GROUP = 1

    MEMBERSTATUS_PROSPECT = 1  # New-user from app might be from web and does not own any digital products.
    MEMBERSTATUS_MEMBER = 2  # If user own products.
    MEMBERSTATUS_ONBOARDING = 3  # New-user start using mobile apps.
    MEMBERSTATUS_REPROSPECT = 4  # When user's membership ends and its ready to target again.

    Token_Expiry_In_Hours = 72

    USER_NOT_EXIST = "User does not exist with this customer id"
    CAN_NOT_APPLY_KEY = "Sorry! You can’t extend your trial any further."

    STATUS_FROZEN = 11
    STATUS_BLACKLISTED = 12
    STATUS_TEMPORARILY_WHITELISTED = 13

    TRAIL_REDEMPTIONS_LIMIT = 1
    ONBOARDING_LIMIT = 1

    TRIAL_GROUP_ID = 1
    MEMBER_GROUP_ID = 2
    TRIAL_DAYS = 14

    CURRENCY_ID = 45
    CURRENCY = 'USD'

    MEMBERSHIP_EXPIRAION_DATE_MAX = '02 JAN {year}'.format(year=datetime.datetime.now().year + 1)
    ALLOWED_NUMBER_OF_DEVICES = 20
    MAX_OUTLETS = 60

    DIGITAL_TRAVEL_COMPLEMENTARY_PRODUCT = ""

    CUSTOMER_ORDER_SUCCESS = 2

    VERIFICATION_STATE_NOT_STARTED = 0
    VERIFICATION_STATE_STARTED = 1
    VERIFICATION_STATE_PHONE_VERIFIED = 2
    VERIFICATION_STATE_PHONE_NOT_VERIFIED_BUT_DEMOGRAPHIC_UPDATED = 3
    VERIFICATION_STATE_VERIFICATION_COMPLETED = 4

    TABS_ALL_OFFERS_EN = "ALL OFFERS"
    TABS_ALL_OFFERS_AR = " كافة العروض"
    TABS_ALL_OFFERS_EL = "ΟΛΕΣ ΟΙ ΠΡΟΣΦΟΡΕΣ"

    TABS_MONTHLY_EN = "MONTHLY"
    TABS_MONTHLY_AR = " العروض الشهرية"
    TABS_MONTHLY_EL = "Μηνιαίες"

    TABS_NEW_EN = "NEW"
    TABS_NEW_AR = " العروض الجديدة"
    TABS_NEW_EL = "ΝΕΕΣ ΠΡΟΣΦΟΡΕΣ"

    TABS_ALL_OFFERS_REDEEMABILITY = "redeemable_reusable"
    TABS_MONTHLY_REDEEMABILITY = "reusable"
    TABS_NEW_REDEEMABILITY = "redeemable_reusable"

    TABS_ALL_OFFERS_FILTER_BY_TYPE = "NIL"
    TABS_MONTHLY_FILTER_BY_TYPE = "2"
    TABS_NEW_FILTER_BY_TYPE = "4"

    HAPPY_BIRTHDAY_START_RANGE_DAYS = -8
    HAPPY_BIRTHDAY_END_RANGE_DAYS = 21

    EGO_NOT_ELIGIBLE = '0'
    EGO_ELIGIBLE = '1'
    EGO_AVAILED = '2'
    EGO_NOT_AVAILED = '3'

    customer_group = 1

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(10), nullable=False, index=True, default=0)
    language = Column(String(5), default='en')
    firstname = Column(String(255))
    middlename = Column(String(255))
    lastname = Column(String(255))
    email = Column(String(150), index=True)
    new_member_group = Column(TINYINT(1), nullable=False, default=1)
    membership_sub_group = Column(TINYINT(1))
    gender = Column(String(100), comment='This should be saved as text not id Male,Female')
    age_bracket = Column(String(20))
    marital_status = Column(String(20), comment='This should be saved as TEXT with values Yes and No')
    income_bracket = Column(String(20))
    mobile_phone = Column(String(100))
    number_children = Column(INTEGER(5))
    nationality = Column(String(100))
    affiliate_code = Column(String(255))
    affiliate_code_date = Column(Date)
    city_of_residence = Column(String(100))
    country_of_residence = Column(String(100), index=True)
    birthdate = Column(Date, index=True)
    dob = Column(String(100))
    accepted_terms = Column(TINYINT(1), comment='This should be saved as TEXT with values not the id')
    receive_email = Column(TINYINT(1), default=1)
    education_level = Column(String(30))
    occupation_level = Column(String(30))
    lead_source = Column(String(255))
    language_preference = Column(String(20))
    default_currency = Column(INTEGER(4), default=45)
    currency = Column(String(10), nullable=False, default='USD', comment='Stores currency short name')
    search_code = Column(String(255))
    campaign_id = Column(String(18))
    third_email_opt_out = Column(TINYINT(1), default=0)
    processed = Column(SMALLINT(1), default=0)
    lifestyle_preference = Column(String(100))
    residential_neighborhood = Column(String(255))
    business_neighborhood = Column(String(255))
    book_serial_number = Column(VARBINARY(100))
    app_id = Column(INTEGER(11))
    app_name = Column(String(255))
    member_group = Column(INTEGER(4), nullable=False, default=1)
    membership_status = Column(TINYINT(1), default=1)
    membership_expiry = Column(DateTime)
    trial_start_date = Column(DateTime)
    membership_code = Column(String(30), nullable=False)
    is_using_trial = Column(INTEGER(1), nullable=False, default=0)
    is_used_trial = Column(INTEGER(1), nullable=False, default=0)
    create_time = Column(TIMESTAMP, default=datetime.datetime.now)
    update_time = Column(TIMESTAMP, default=datetime.datetime.now)
    onboarding_status = Column(TINYINT(1), default=0)
    onboarding_startdate = Column(DateTime, default=datetime.datetime.now)
    onboarding_enddate = Column(DateTime, default=datetime.datetime.now)
    onboarding_redemptions_count = Column(TINYINT(1), nullable=False, default=0)
    trial_finish_reason = Column(String(50), comment='Add reason why trial is expired')
    home_address = Column(String(500))
    work_address = Column(String(500))
    push_notifications = Column(TINYINT(1), default=1)
    verification_state = Column(TINYINT(1), default=0)
    is_phone_verified = Column(TINYINT(1), default=0)
    verified_phone_number = Column(String(50))
    profile_image = Column(String(255))
    about_me = Column(Text)
    savings = Column(INTEGER(11), default=0)
    yearly_savings = Column(INTEGER(11), default=0)
    affiliates_info = Column(String(500))
    ego_registration_date = Column(DateTime)
    ego_status = Column(TINYINT(1), default=0)
    ego_onboarding_status = Column(INTEGER, index=True, default=0)
    ego_onboarding_start_date = Column(DateTime)
    ego_onboarding_end_date = Column(DateTime)
    onboarding_redemptions_limit = Column(TINYINT(1))

    @classmethod
    def get_by_user_id(cls, user_id):
        """
        Get Customer Profile
        :param int user_id: User Id
        :rtype: EntCustomerProfile|None
        """
        if user_id:
            return cls.query.filter(cls.user_id == user_id).first()

    @classmethod
    def get_user_verification_state(cls, user_id):
        """
        Get Customer Profile only with verification_state field
        :param int user_id: User Id
        :rtype: EntCustomerProfile|None
        """
        if user_id:
            return cls.query.filter(
                cls.user_id == user_id
            ).with_entities(
                cls.verification_state
            ).first()
        return None

    @classmethod
    @with_master
    def update_customer_profile(cls, customer_id, changes={}):
        """
        Fetch user obj by user_id and updates user obj
        :param customer_id:
        :param changes:
        :return:
        """
        if customer_id and changes:
            if isinstance(customer_id, list):
                cls.query.filter(
                    cls.user_id.in_(customer_id)
                )
            else:
                cls.query.filter(
                    cls.user_id == customer_id
                )
            cls.query.update(changes, synchronize_session=False)
            cls.update_record()
            return True
        return False

    @classmethod
    def get_member_type(cls, group_id):
        """
        Gets the member type
        :param int group_id: group id
        :rtype: str
        """
        member_types = {
            cls.MEMBERSTATUS_MEMBER: 'member',
            cls.MEMBERSTATUS_ONBOARDING: 'onboarding',
            cls.MEMBERSTATUS_REPROSPECT: 'reprospect'
        }
        return member_types.get(group_id, 'prospect')

    @classmethod
    def get_demographics_info(cls, customer_id):
        """
        get 3 attr of ent_customer_profile model.
        :param int customer_id:
        :return orm obj:
        """
        query = cls.query.filter(cls.user_id == customer_id)
        query = query.with_entities(
            cls.gender,
            cls.nationality,
            cls.birthdate
        )
        return query.first()

    def to_dict(self):
        """
        convert EntCustomerProfile obj into dict.
        :return: dict
        """
        return {
            'nationality': self.nationality,
            'campaign_id': self.campaign_id,
            'create_time': str(self.create_time),
            'yearly_savings': self.yearly_savings,
            'new_member_group': self.new_member_group,
            'receive_email': self.receive_email,
            'app_name': self.app_name,
            'work_address': self.work_address,
            'id': self.id,
            'affiliate_code': self.affiliate_code,
            'third_email_opt_out': self.third_email_opt_out,
            'update_time': str(self.update_time),
            'membership_sub_group': self.membership_sub_group,
            'education_level': self.education_level,
            'member_group': self.member_group,
            'push_notifications': self.push_notifications,
            'affiliates_info': self.affiliates_info,
            'affiliate_code_date': self.affiliate_code_date,
            'user_id': self.user_id,
            'processed': self.processed,
            'onboarding_status': self.onboarding_status,
            'gender': self.gender,
            'occupation_level': self.occupation_level,
            'membership_status': self.membership_status,
            'verification_state': self.verification_state,
            'ego_registration_date': self.ego_registration_date,
            'language': self.language,
            'city_of_residence': self.city_of_residence,
            'lifestyle_preference': self.lifestyle_preference,
            'onboarding_startdate': str(self.onboarding_startdate),
            'age_bracket': self.age_bracket,
            'lead_source': self.lead_source,
            'membership_expiry': self.membership_expiry,
            'is_phone_verified': self.is_phone_verified,
            'ego_status': self.ego_status,
            'country_of_residence': self.country_of_residence,
            'firstname': self.firstname,
            'residential_neighborhood': self.residential_neighborhood,
            'onboarding_enddate': str(self.onboarding_enddate),
            'marital_status': self.marital_status,
            'language_preference': self.language_preference,
            'trial_start_date': self.trial_start_date,
            'verified_phone_number': self.verified_phone_number,
            'ego_onboarding_status': self.ego_onboarding_status,
            'birthdate': self.birthdate,
            'middlename': self.middlename,
            'business_neighborhood': self.business_neighborhood,
            'onboarding_redemptions_count': self.onboarding_redemptions_count,
            'income_bracket': self.income_bracket,
            'default_currency': self.default_currency,
            'membership_code': self.membership_code,
            'profile_image': self.profile_image,
            'ego_onboarding_start_date': self.ego_onboarding_start_date,
            'lastname': self.lastname,
            'dob': self.dob,
            'book_serial_number': self.book_serial_number,
            'trial_finish_reason': self.trial_finish_reason,
            'mobile_phone': self.mobile_phone,
            'currency': self.currency,
            'is_using_trial': self.is_using_trial,
            'about_me': self.about_me,
            'ego_onboarding_end_date': self.ego_onboarding_end_date,
            'email': self.email,
            'accepted_terms': self.accepted_terms,
            'app_id': self.app_id,
            'home_address': self.home_address,
            'number_children': self.number_children,
            'search_code': self.search_code,
            'is_used_trial': self.is_used_trial,
            'savings': self.savings,
            'onboarding_redemptions_limit': self.onboarding_redemptions_limit
        }

    @classmethod
    def get_customer_profile(cls, customer_id):
        """
        Returns selected customer profile fields
        """
        from ..models.country import Country
        from ..models.user import User

        query = cls.query.join(User, cls.user_id == User.id)
        # TODO: changed following country outer_join from simple join. revert if needed
        query = query.join(Country, cls.country_of_residence == Country.shortname, isouter=True)
        query = query.filter(cls.user_id == customer_id).with_entities(
            cls.user_id,
            cls.firstname,
            cls.lastname,
            cls.email,
            cls.member_group.label('group_id'),
            cls.accepted_terms,
            cls.receive_email.label('do_not_email'),
            coalesce(cls.third_email_opt_out, "0").label('third_do_not_email'),
            cls.onboarding_status.label('using_trial'),
            cls.is_used_trial.label('used_trial_membership'),
            User.is_active.label('is_active'),
            cls.membership_code,
            cls.age_bracket,
            cls.marital_status,
            cls.income_bracket,
            cls.mobile_phone,
            coalesce(cls.nationality, "").label('nationality'),
            cls.city_of_residence,
            cls.country_of_residence,
            cls.education_level,
            cls.occupation_level,
            cls.currency,
            cls.lifestyle_preference,
            cls.firstname,
            cls.lastname,
            coalesce(cls.gender, "").label('gender'),
            cls.membership_expiry.label('membership_expiration_date'),
            cls.onboarding_startdate,
            cls.create_time.label('created_at'),
            cls.update_time.label('updated_at'),
            cls.new_member_group.label('member_type'),
            cls.onboarding_status,
            cls.onboarding_redemptions_count,
            cls.create_time.label('user_creation_date'),
            coalesce(cls.birthdate, "").label('date_of_birth'),
            coalesce(cls.profile_image, "").label('profile_image'),
            coalesce(Country.name, "").label('country'),
            coalesce(cls.about_me, "").label('about_me'),
            coalesce(cls.home_address, "").label('home_address'),
            coalesce(cls.work_address, "").label('work_address'),
            coalesce(cls.push_notifications, "1").label('push_notifications'),
            cls.is_phone_verified,
            cls.verification_state,
            coalesce(cls.affiliate_code, "").label('affiliate_code'),
            cls.onboarding_redemptions_limit
        )
        return query.first()

    @classmethod
    def load_customer_profile_by_user_id(cls, user_id):
        """
        Load customer profile by id
        :rtype dict
        :param user_id: user id
        """
        customer_profile = {}
        if user_id:
            query = cls.query
            if isinstance(user_id, list):
                query = query.filter(cls.user_id.in_(user_id))
                customer_profile = query.all()
                customer_profile = {profile.user_id: profile for profile in customer_profile}
            else:
                customer_profile = query.filter(cls.user_id == user_id).one()
        return customer_profile

    @classmethod
    def load_customer_profile_by_id(cls, customer_id):
        """
        Load customer profile by id
        :param int customer_id: customers id
        :rtype dict or obj
        """
        customer_profile = {}
        if customer_id:
            query = cls.query
            if isinstance(customer_id, list):
                query = query.filter(cls.user_id.in_(customer_id))
                customer_profile = query.all()
                customer_profile = {profile.id: profile for profile in customer_profile}
            else:
                customer_profile = query.filter(cls.user_id == customer_id).one()
        return customer_profile

    @classmethod
    def load_customer_profile_by_email(cls, email):
        """
        Load customer profile by email
        :param int email: customers email
        :rtype dict or obj

        """
        customer_profile = {}
        if email:
            query = cls.query
            customer_profile = query.filter(cls.email == email).one()
        return customer_profile

    @classmethod
    def get_user_birth_date(cls, user_id):
        """
        get user birth_date by user id
        :param user_id:
        :return orm obj:
        """
        return cls.query.filter(cls.user_id == user_id).with_entities(cls.birthdate).one()

    @classmethod
    def get_customer_profile_info(cls, customer_id):
        """
        Returns customer profile info against customer id
        :param int customer_id:
        :rtype: dict
        """
        if customer_id:
            query = cls.query.with_entities(
                cls.new_member_group.label('member_group'), cls.birthdate.label('birth_date'), cls.firstname,
                cls.email, cls.user_id, cls.onboarding_redemptions_count, cls.onboarding_status,
                cls.onboarding_enddate.label('onboarding_end_date'), cls.onboarding_startdate,
                cls.onboarding_redemptions_limit
            )
            return query.filter(cls.user_id == customer_id).one()
        return {}

    @classmethod
    def get_full_customer_name(cls, customer):
        """
        Returns customers full name
        :param customer: Customer instance
        :return: string
        """
        return '{first_name} {last_name}'.format(
            first_name=customer.firstname,
            last_name=customer.lastname
        )

    @classmethod
    def load_customer_profile_and_user_info_by_id(
        cls, customer_ids=None, single_profile=False, check_black_list_user_status=True
    ):
        """
        Loads the customer profile by user id
        """
        customer_profile = {}
        if customer_ids is None:
            customer_ids = []
        if customer_ids:
            _query = cls.query.with_entities(
                User.status,
                User.is_active,
                cls.new_member_group,
                cls.membership_sub_group,
                cls.user_id,
            ).select_from(
                EntCustomerProfile
            ).join(
                User,
                cls.user_id == User.id
            ).filter(
                User.is_active == 1
            )
            if check_black_list_user_status:
                _query = _query.filter(User.status != cls.STATUS_BLACKLISTED)
            if isinstance(customer_ids, list):
                _query = _query.filter(cls.user_id.in_(customer_ids))
                customer_profile = _query.all()
            elif customer_ids and single_profile:
                _query = _query.filter(cls.user_id == customer_ids)
                customer_profile = _query.all()
        return customer_profile
