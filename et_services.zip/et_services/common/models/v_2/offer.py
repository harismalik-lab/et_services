"""
Offer Model V2
"""
from sqlalchemy import and_, literal_column, or_
from sqlalchemy.sql.functions import coalesce, func

from ...constants import CATEGORY_API_NAME_ALL, OFFER_ATTRIBUTES
from ...utils.api_utils import (
    get_delivery_enabled_location_ids_against_company, get_takeaways_enabled_location_ids_against_company
)
from ..location import Location
from ..offer import Offer


class OfferV2(Offer):
    """
    V2 version of offer model.

    Updates:
    1. Moved the get offers function from outlet to offers and updated it.

    """
    @classmethod
    def get_offers(cls, **kwargs):
        """
        Returns all the offers based on the criteria passed in the keyword args.
        The kwargs contain flags and parameters for offers.

        """

        from ..merchant import Merchant
        from ..offer_attribute import OfferAttribute
        from ..offer_translation import OfferTranslation
        from ..outlet import Outlet
        from ..outlet_offer import OutletOffer
        from ..package import Package
        from ..product import Product
        from ..product_offer import ProductOffer
        from ..redemption import Redemption

        is_customer_logged_in = kwargs['is_customer_logged_in']
        is_customer_using_trial = kwargs['is_using_trial']
        is_customer_using_ext_trial = kwargs['is_using_extended_trial']
        product_ids = kwargs['customer_product_ids']
        location_id = kwargs["location_id"]
        category = kwargs["category"]
        sub_categories_selected = kwargs["sub_categories_selected"]
        offer_redeemability = kwargs["offer_redeemability"]
        received_offer_ids = kwargs["received_offer_ids"]
        offer_types_selected = kwargs["offer_types_selected"]
        cashless_delivery_enabled = kwargs["cashless_delivery_enabled"]
        takeaways_enabled = kwargs["takeaways_enabled"]
        ping_enabled = kwargs["ping_enabled"]
        cheers_enabled = kwargs["cheers_enabled"]
        offer_attributes_selected = kwargs["offer_attributes_selected"]
        query_args = kwargs.get('query_string', [])
        is_cheers = kwargs.get("is_cheers")
        is_birthday = kwargs.get("is_birthday")
        is_delivery = kwargs.get("is_delivery")
        is_more_sa = kwargs.get("is_more_sa")
        is_travel = kwargs.get("is_travel")
        is_ent = kwargs['is_ent']
        company = kwargs["company"]

        is_cashless_location = (
            location_id in get_delivery_enabled_location_ids_against_company(company) and cashless_delivery_enabled
        )
        is_takeaways_location = (
            location_id in get_takeaways_enabled_location_ids_against_company(company) and takeaways_enabled
        )

        if offer_attributes_selected:
            offer_attributes_selected_set = set(offer_attributes_selected)
            invalid_offer_attributes = offer_attributes_selected_set - OFFER_ATTRIBUTES
            offer_attributes_selected = offer_attributes_selected_set - invalid_offer_attributes

        select_list = [
            cls.id,
            cls.merchant_category,
            coalesce(cls.sub_category, '').label('sub_category'),
            cls.valid_from.label('valid_from_date'),
            cls.valid_to.label('expiration_date'),
            cls.type,
            cls.quantity,
            cls.savings_estimate,
            cls.is_take_away_offer,
            cls.is_delivery_cashless_offer,
            func.concat(Redemption.NOT_REDEEMABLE, '').label('redeemability'),
            literal_column("0").label("times_redeemed"),
            OfferTranslation.name.label('offer_name'),
            Product.id.label('product_id'),
            Product.sf_id.label('product_sku'),
            func.max(Product.is_cheers).label('is_cheers'),
            func.max(Product.delivery_enabled).label('is_delivery'),
            func.max(Product.is_more_sa).label('is_more_sa'),
            func.max(Product.ismember).label('is_monthly'),
            Merchant.is_for_members_only,
            Product.is_ent.label('is_entertainer'),
            Product.cashless_delivery_enabled,
            Product.product_type,
            Product.istravel.label('is_travel'),
            Product.has_merlin_offers.label('is_merlin_offer'),
            Product.has_cinema_offers,
            Product.is_johor_bahru,
            Product.has_bonus_offers.label('is_bonus_offer'),
            Product.is_core_fine_dining_product,
            Product.is_core_family_product,
            Product.is_core_fitness_product,
            Product.ismember
        ]
        if is_travel and offer_attributes_selected:
            select_list.extend([
                Package.is_relax.label("hww_relax"),
                Package.is_dine.label("hww_dine"),
                Package.is_play.label("hww_play"),
                Package.is_brunch.label("hww_brunch")
            ])

        if ping_enabled and kwargs.get('isshared'):
            select_list.append(func.min(Outlet.id).label("outlet_ids"))
        else:
            select_list.append(func.group_concat(Outlet.id.distinct()).label('outlet_ids'))

        query = cls.query.join(OutletOffer, cls.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(
            OfferTranslation,
            and_(
                OfferTranslation.offer_id == cls.id,
                OfferTranslation.locale == kwargs["locale"]
            )
        )
        query = query.join(ProductOffer, cls.id == ProductOffer.offer_id)

        query = query.join(
            Product,
            and_(
                Product.id == ProductOffer.product_id,
                Product.isactive == 1,
            )
        )

        if is_ent:
            query = query.filter(Product.is_ent == 1)
        else:
            from ..wl_product import WlProduct
            query = query.join(WlProduct, Product.sf_id == WlProduct.product_sku)
            query = query.filter(WlProduct.wl_company == company, WlProduct.active == 1)
            if is_travel:
                query = query.filter(WlProduct.istravel == 1)

        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        if offer_attributes_selected:
            query = query.join(OfferAttribute, cls.id == OfferAttribute.offer_id)
            if is_travel:
                query = query.join(Package, Package.offer_id == cls.id)

        if cashless_delivery_enabled:
            if is_cashless_location and not takeaways_enabled:
                query = query.filter(
                    Product.cashless_delivery_enabled == 1,
                    cls.is_delivery_cashless_offer == 1
                )
            elif is_takeaways_location:
                query = query.filter(
                    Product.cashless_delivery_enabled == 1,
                    cls.is_take_away_offer == 1
                )
        common_product_filters = [
            Product.is_dummy_product != 1,
            Product.show_offers_if_purchased != 1,
            Product.is_freemium != 1
        ]
        if is_customer_logged_in:
            if received_offer_ids and not cashless_delivery_enabled:
                query = query.filter(
                    or_(
                        and_(*common_product_filters),
                        or_(
                            Product.id.in_(product_ids),
                            cls.id.in_(received_offer_ids)
                        )
                    )
                )
            else:
                query = query.filter(
                    or_(
                        and_(*common_product_filters),
                        Product.id.in_(product_ids)
                    )
                )
        else:
            query = query.filter(
                *common_product_filters,
                Product.is_cheers != 1
            )

        like_filter = None
        if query_args:
            like_filter = or_(*[OfferTranslation.name.like('%{}%'.format(arg)) for arg in query_args])

        if like_filter is not None:
            query = query.filter(like_filter)

        if ping_enabled and kwargs['isshared']:
            if kwargs.get('received_offer_ids'):
                query = query.filter(cls.id.in_(kwargs['received_offer_ids']))
        else:
            if offer_types_selected:
                query = query.filter(cls.voucher_type.in_(offer_types_selected))

            if offer_redeemability == Redemption.REDEEMABILITY_NOT_REDEEMABLE:
                query = query.filter(Product.purchase_product_id > 0)

            if cheers_enabled and is_cheers:
                if is_cashless_location:
                    query = query.filter(
                        or_(
                            Product.is_cheers == 1,
                            Product.cashless_delivery_enabled == 1
                        )
                    )
                else:
                    query = query.filter(Product.is_cheers == 1)

            if is_more_sa:
                query = query.filter(Product.is_more_sa == 1)

            if is_birthday:
                if is_cashless_location:
                    query = query.filter(
                        or_(
                            Product.type == Product.PRODUCT_TYPE_BIRTHDAY,
                            Product.cashless_delivery_enabled == 1
                        )
                    )
                else:
                    query = query.filter(Product.type == Product.PRODUCT_TYPE_BIRTHDAY)

            if is_cashless_location:
                if cashless_delivery_enabled:
                    query = query.filter(Product.cashless_delivery_enabled == 1)
            else:
                if is_delivery:
                    query = query.filter(Product.delivery_enabled == 1)

            if is_ent:
                if kwargs.get('outlet_id'):
                    query = query.filter(cls.id == kwargs['outlet_id'])
                elif kwargs.get('category', '').lower() == 'travel':
                    query = query.filter(Product.istravel == 1)
                else:
                    locations = Product.MORE_SA_LOCATION_IDS
                    query = query.filter(Product.location_id == location_id)
                    or_filter = None
                    if category == CATEGORY_API_NAME_ALL:
                        or_filter = or_(True, Product.istravel == 1)
                    if location_id == Location.LOCATION_ID_SINGAPORE:
                        or_filter = or_(or_filter, Product.is_johor_bahru == 1)
                    if location_id in locations:
                        or_filter = or_(or_filter, Product.is_more_sa == 1)
                    if or_filter is not None:
                        query = query.filter(or_filter)
                    if location_id == Location.LOCATION_ID_MALAYSIA:
                        query = query.filter(coalesce(Product.is_johor_bahru, 0) == 0)

            else:
                if kwargs.get('product_sku'):
                    query = query.filter(Product.sf_id == kwargs['product_sku'])
                elif kwargs.get('outlet_id'):
                    query = query.filter(cls.id == kwargs['outlet_id'])
                elif kwargs.get('category', '').lower() == 'travel':
                    query = query.filter(Product.istravel == 1)
                else:
                    query = query.filter(Product.location_id == location_id)
                    or_filter = None
                    if category == CATEGORY_API_NAME_ALL:
                        or_filter = or_(True, Product.istravel == 1)
                    if location_id in Product.MORE_SA_LOCATION_IDS:
                        or_filter = or_(or_filter, Product.is_more_sa == 1)
                    if or_filter is not None:
                        query = query.filter(or_filter)

        # Fuzzy search.
        fuzzy_search_outlet_ids = kwargs.get("fuzzy_search_outlet_ids")
        if kwargs.get("is_fuzzy_search_on") and fuzzy_search_outlet_ids:
            query = query.filter(Outlet.id.in_(fuzzy_search_outlet_ids))

        # Trial offers.
        if is_customer_using_trial:
            if not is_ent or is_customer_using_ext_trial:
                query = query.filter(
                    or_(
                        cls.type != cls.TYPE_MEMBER,
                        Product.has_merlin_offers == 1
                    )
                )

        # Apply filter on category.
        if kwargs.get('category') and kwargs['category'].strip().lower() != 'all':
            query = query.filter(cls.merchant_category == kwargs['category'])

        # Apply filter on sub_categories.
        if sub_categories_selected:
            query = query.filter(cls.sub_category.in_(sub_categories_selected))

        # Apply offer attributes.
        for offer_attribute in offer_attributes_selected:
            if is_travel:
                query = query.filter(getattr(Package, offer_attribute) == 1)
            else:
                query = query.filter(getattr(OfferAttribute, offer_attribute) == 1)

        query = query.with_entities(*select_list)

        query = query.group_by(cls.id)

        return query.all()
