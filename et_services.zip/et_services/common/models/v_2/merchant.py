"""
Merchant Model V2
"""
import datetime

from sqlalchemy import and_, literal_column
from sqlalchemy.sql.functions import coalesce, func

from ...constants import CATEGORY_NAME_TRAVEL
from ..merchant import Merchant


class MerchantV2(Merchant):

    @classmethod
    def get_featured_merchants(cls, **kwargs):
        """
        Returns featured merchants based on passed key word arguments.
        """

        is_cheers = kwargs.get('is_cheers', False)
        is_customer_owns_cheers_for_location = kwargs.get('is_customer_owns_cheers_for_location', False)

        if is_cheers and not is_customer_owns_cheers_for_location:
            return []

        from ..merchant_translation import MerchantTranslation
        from ..outlet import Outlet
        from ..outlet_offer import OutletOffer
        from ..offer import Offer
        from ..featured_merchant import FeaturedMerchant

        locale = kwargs['locale']
        featured_category = kwargs['featured_category']
        category = kwargs['category']
        billing_country = kwargs.get('billing_country')
        location_id = kwargs.get('location_id')

        add_future_check = kwargs.get('add_future_check')

        current_datetime = datetime.datetime.now()
        query = cls.query.with_entities(
            Merchant.id,
            MerchantTranslation.name,
            Merchant.position,
            MerchantTranslation.description,
            Merchant.category,
            Merchant.digital_section,
            MerchantTranslation.cuisine,
            coalesce(Merchant.ad_travel_country, "").label('ad_travel_country'),
            Merchant.is_featured,
            Merchant.ad_active_status,
            Merchant.logo_retina_url.label('logo_url'),
            Merchant.logo_non_retina_url.label('logo_small_url'),
            Merchant.photo_retina_url.label('photo_url'),
            Merchant.photo_non_retina_url.label('photo_small_url'),
            func.count(func.distinct(Outlet.id)).label('outlets_count'),
            literal_column("''").label("outlets_info"),
            func.group_concat(func.distinct(Outlet.id)).label('outlet_ids'),
        ).join(
            MerchantTranslation,
            and_(cls.id == MerchantTranslation.merchant_id, MerchantTranslation.locale == locale)
        ).join(
            Offer,
            cls.id == Offer.merchant_id
        ).join(
            OutletOffer,
            Offer.id == OutletOffer.offer_id
        ).join(
            Outlet,
            and_(OutletOffer.outlet_id == Outlet.id, Outlet.active == 1)
        ).join(
            FeaturedMerchant,
            and_(
                cls.id == FeaturedMerchant.merchant_id,
                FeaturedMerchant.is_active == 1
            )
        ).filter(
            FeaturedMerchant.featured_category == featured_category,
            FeaturedMerchant.is_featured_for_home_screen == 0,
            Offer.merchant_category == category,
            FeaturedMerchant.valid_from < current_datetime,
        )
        if add_future_check:
            query = query.filter(FeaturedMerchant.valid_to > current_datetime - datetime.timedelta(days=1))

        if category == CATEGORY_NAME_TRAVEL:
            if billing_country:
                query = query.filter(Outlet.billing_country == billing_country)
        else:
            if location_id:
                query = query.filter(Outlet.location_id == location_id)

        query = query.group_by(Merchant.id).order_by(Merchant.position.asc())
        return query.all()
