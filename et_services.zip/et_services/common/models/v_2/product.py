"""
Product Model V2
"""
from outlet_service.common.models.wl_product import WlProduct

from ..product import Product


class ProductV2(Product):
    """

    """
    @classmethod
    def get_products(cls, **kwargs):
        """
        Gets count of products based on passed keyword arguments.
        """
        product_ids = kwargs.get('product_ids')
        location_id = kwargs.get('location_id')
        is_ent = kwargs.get('is_ent')
        company = kwargs.get('company')
        is_cheers = kwargs.get('is_cheers')
        is_distinct = kwargs.get('is_distinct')
        get_count = kwargs.get('get_count')

        query = cls.query

        if is_ent:
            query = query.filter(cls.is_ent == 1)

        elif company:
            query = query.join(
                WlProduct,
                cls.sf_id == WlProduct.product_sku,
            )
            query = query.filter(WlProduct.wl_company == company, WlProduct.active == 1)

        if product_ids:
            query = query.filter(cls.id.in_(product_ids))

        if location_id:
            query = query.filter(cls.location_id == location_id)

        if is_cheers:
            query = query.filter(cls.is_cheers == 1)

        if is_distinct:
            query = query.distinct()

        if get_count:
            return query.with_entities(cls.id).count()

        return query.all()
