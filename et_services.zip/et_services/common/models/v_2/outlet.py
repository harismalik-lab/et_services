"""
Outlet Model V2
"""
from sqlalchemy import and_

from ..outlet import Outlet


class OutletV2(Outlet):
    """

    """
    pass

    @classmethod
    def cashless_delivery_outlets(cls, **kwargs):
        """
        Filters out cashless delivery outlets from given outlet IDs.
        """
        from ..outlet_offer import OutletOffer
        from ..product_offer import ProductOffer
        from ..product import Product

        outlet_ids = kwargs.get('outlet_ids')
        company = kwargs.get('company')
        is_ent = kwargs.get('is_ent')

        query = cls.query.join(OutletOffer, cls.id == OutletOffer.outlet_id)
        query = query.join(ProductOffer, OutletOffer.offer_id == ProductOffer.offer_id)

        query = query.join(
            Product,
            and_(
                Product.id == ProductOffer.product_id,
                Product.isactive == 1,
            )
        )
        if is_ent:
            query = query.filter(Product.is_ent == 1)
        else:
            from ..wl_product import WlProduct
            query = query.join(WlProduct, Product.sf_id == WlProduct.product_sku)
            query = query.filter(WlProduct.wl_company == company, WlProduct.active == 1)

        query = query.with_entities(
            cls.id.label('outlet_id'),
            Product.cashless_delivery_enabled,
        )
        query = query.filter(
            cls.id.in_(outlet_ids),
            Product.cashless_delivery_enabled == 1,
        )
        return query.all()
