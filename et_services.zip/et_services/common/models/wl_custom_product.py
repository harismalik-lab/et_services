"""
WL Custom Product Model
"""

from sqlalchemy import Column, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class WlCustomProduct(db.Model):
    __tablename__ = 'wl_custom_product'
    __table_args__ = {"schema": ENTERTAINER_WEB}
    id = Column(INTEGER(11), primary_key=True)
    product_code = Column(String(50))
    title = Column(String(100))
    description = Column(text)
    price_aed = Column(Float, default=0)
    currency = Column(String(5))
    is_active = Column(TINYINT(1), default=0)
    image_url = Column(String(500))
    company = Column(String(10))
    user_group_id = Column(TINYINT(1))
    wl_user_group = Column(TINYINT(1), default=0)
    du_asset_id = Column(String(50))
    du_content_type = Column(String(50))
    du_product_id = Column(String(100))
    du_service_id = Column(String(50))
    du_premium_resource_type = Column(String(100))
