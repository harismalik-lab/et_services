"""
Dm Attribute Group Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmAttributeGroup(db.Model):
    __tablename__ = 'dm_attribute_group'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    group_identifier = Column(String(200))
    dm_menu_item_id = Column(INTEGER(11), index=True)
    min_choices = Column(TINYINT(1))
    max_choices = Column(TINYINT(1))
    sort_order = Column(SMALLINT(11))
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    is_deleted = Column(TINYINT(1), default=0)
