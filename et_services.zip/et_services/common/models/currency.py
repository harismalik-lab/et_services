"""
Currency Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class Currency(db.Model, Mixin):
    __tablename__ = 'currency'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    currency = Column(String(45))
    name = Column(VARCHAR(500))

    @classmethod
    def get_currency_by_code(cls, locale=EN, code=None):
        """
        get currency info on the basis of currency code and locale
        :param str locale:
        :param str code:
        :return:
        """
        from ..models.currency_translation import CurrencyTranslation
        if code:
            query = cls.query.join(CurrencyTranslation, cls.id == CurrencyTranslation.currency_id)
            query = query.filter(
                CurrencyTranslation.locale == locale,
                cls.currency == code
            )
            query = query.with_entities(
                cls.id.label('currency_id'),
                cls.currency.label('id'),
                CurrencyTranslation.name,
                CurrencyTranslation.translated_currency
            )
            return query.first()
        return {}
