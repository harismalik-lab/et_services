"""
Product Translation Ent Active Model
"""
from sqlalchemy import Column, Index, String, Text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db


class ProductTranslationEntActive(db.Model):
    __tablename__ = 'product_translation_ent_active'
    __table_args__ = (
        Index('idx_translation', 'product_id', 'locale'),
        {"schema": ENTERTAINER_WEB}
    )

    id = Column(INTEGER(11), primary_key=True)
    product_id = Column(INTEGER(11), nullable=False, index=True)
    locale = Column(String(5), default=EN)
    name = Column(String(255))
    details = Column(Text)
    description = Column(Text)
    also_text = Column(String(512))
    categories = Column(String(512))
    product_summary = Column(String(500))
    offer_summary = Column(String(100))
    category_summary = Column(String(255))
    savings_summary = Column(String(100))
    travel_summary = Column(String(100))
