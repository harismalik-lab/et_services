"""
Dm Outlet Setting Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, Enum, Float, String, and_, or_
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import AED, EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class DmOutletSetting(db.Model, Mixin):
    __tablename__ = 'dm_outlet_setting'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    ONLINE = 'online'

    id = Column(INTEGER(11), primary_key=True)
    location_id = Column(INTEGER(11))
    merchant_id = Column(INTEGER(11), index=True)
    merchant_sf_id = Column(String(200), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    outlet_sf_id = Column(String(200), index=True)
    currency_id = Column(SMALLINT(1))
    menu_price = Column(Float(8))
    days_of_delivery = Column(String(20))
    default_delivery_time = Column(SMALLINT(1))
    minimum_order_amount = Column(Float(8))
    delivery_fee = Column(Float(8))
    average_prep_time = Column(SMALLINT(1))
    average_travel_time = Column(SMALLINT(1))
    collection_time = Column(SMALLINT(1))
    integration_type = Column(String(200), index=True)
    is_omnivore_menu = Column(TINYINT(1), default=0)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    update_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    disabled = Column(TINYINT(1), nullable=False, index=True, default=1)
    status = Column(TINYINT(1), index=True, default=1)
    online_status = Column(Enum('Online', 'Offline', 'Not Responding'), index=True)
    delivery_free_above_amount = Column(Float(8))
    updated_by = Column(String(100))
    is_vat_inclusive = Column(TINYINT(1), index=True, default=1)
    status_label = Column(String(50))
    status_value = Column(INTEGER(11))

    @classmethod
    def get_merchant_delivery_details(cls, merchant_id, outlet_id, location_id, locale=EN):
        """
        Get merchant delivery details.

        :param merchant_id:
        :param outlet_id:
        :param location_id:
        :param locale:
        :return orm obj:
        """
        from ..models.dm_outlet_setting_translation import DmOutletSettingTranslation
        from ..models.currency_translation import CurrencyTranslation
        from ..models.dm_delivery_timings import DmDeliveryTiming
        from ..utils.api_utils import get_current_time_of_location, filter_outlet_time_slots

        query = cls.query.outerjoin(
            DmOutletSettingTranslation,
            and_(
                cls.id == DmOutletSettingTranslation.dm_outlet_setting_id,
                DmOutletSettingTranslation.locale == locale
            )
        )
        query = query.join(CurrencyTranslation, cls.currency_id == CurrencyTranslation.currency_id)
        query = query.outerjoin(
            DmDeliveryTiming,
            and_(
                cls.id == DmDeliveryTiming.outlet_setting_id,
                DmDeliveryTiming.day_of_week == get_current_time_of_location(location_id).strftime("%A").lower()
            )
        )
        query = query.with_entities(
            coalesce(cls.delivery_fee, 0).label('deliveryCharges'),
            cls.status,
            coalesce(cls.minimum_order_amount, 0).label('minimum_order_amount'),
            coalesce(CurrencyTranslation.translated_currency, AED).label('currency'),
            coalesce(cls.delivery_free_above_amount, 0).label('noDeliveryFeeAboveAmount'),
            coalesce(cls.default_delivery_time, 60).label('default_delivery_time'),
            coalesce(DmOutletSettingTranslation.allergy_information, '').label('allergy_information'),
            DmDeliveryTiming.delivery_start_time,
            DmDeliveryTiming.delivery_end_time,
            DmDeliveryTiming.total_minutes
        )
        query = query.filter(
            cls.merchant_id == merchant_id,
            or_(
                cls.outlet_id.is_(None),
                cls.outlet_id == 0,
                cls.outlet_id == outlet_id
            )
        )
        query = query.filter(
            CurrencyTranslation.locale == locale,
            cls.status == 1,
            cls.disabled == 0,
            or_(
                cls.online_status == cls.ONLINE,
                cls.online_status == 'Online'
            )
        ).order_by(cls.outlet_id.desc())

        outlets = query.all()

        outlet = {}
        if len(outlets) > 1:
            current_time = get_current_time_of_location(location_id)
            outlet = filter_outlet_time_slots(outlets, current_time)
        elif outlets:
            outlet = outlets[0]
        return outlet

    @classmethod
    def get_outlet_delivery_categories_and_items(
        cls,
        merchant_id,
        outlet_id,
        company,
        is_take_aways_enabled
    ):
        """
        Returns the outlet delivery categories and items.
        """
        from ..models.dm_menu_company import DmMenuCompany
        from ..models.dm_menu_item import DmMenuItem
        from ..models.dm_menu_item_translation import DmMenuItemTranslation
        from ..models.dm_category import DmCategory
        from ..models.dm_category_translation import DmCategoryTranslation
        from ..models.dm_menu_offer import DmMenuOffer
        from ..models.merchant import Merchant

        from ..models.offer import Offer

        query = cls.query.join(
            DmMenuCompany,
            and_(
                cls.id == DmMenuCompany.outlet_setting_id,
                DmMenuCompany.company == company,
                DmMenuCompany.is_deleted == 0
            )
        )
        query = query.join(DmMenuItem, cls.id == DmMenuItem.outlet_setting_id)
        query = query.join(DmMenuItemTranslation, DmMenuItem.id == DmMenuItemTranslation.dm_menu_item_id)
        query = query.join(DmCategoryTranslation, DmMenuItem.dm_category_id == DmCategoryTranslation.dm_category_id)
        query = query.outerjoin(DmCategory, DmMenuItem.dm_category_id == DmCategory.id)
        query = query.outerjoin(
            DmMenuOffer,
            and_(
                DmMenuItem.id == DmMenuOffer.dm_menu_item_id,
                DmMenuOffer.company == company
            )
        )
        query = query.outerjoin(Offer, Offer.id == DmMenuOffer.offer_id)
        query = query.outerjoin(Merchant, Merchant.id == merchant_id)
        if is_take_aways_enabled:
            query.outerjoin(Offer, DmMenuOffer.offer_id == Offer.id and Offer.is_take_away_offer)
        else:
            query.outerjoin(Offer, DmMenuOffer.offer_id == Offer.id and Offer.is_delivery_cashless_offer)

        query = query.with_entities(
            DmCategoryTranslation.dm_category_id.label('menuId'),
            DmCategoryTranslation.name.label('menuName'),
            DmMenuItemTranslation.name.label('product_name'),
            DmMenuItemTranslation.description.label('product_description'),
            DmMenuItem.id.label('product_id'),
            DmMenuItem.item_price,
            Offer.id.label('voucherId'),
            Offer.merchant_category.label('m_category'),
            Offer.voucher_type,
            Offer.type.label('offer_type'),
            Merchant.category,
            DmCategory.sort_order.label('sort_order')
        )
        query = query.filter(
            cls.status == 1,
            DmMenuItem.status == 1,
            DmMenuItem.online_status == 1,
            DmMenuItem.is_deleted == 0
        )
        query = query.filter(cls.merchant_id == merchant_id)
        if outlet_id:
            query = query.filter(
                or_(
                    cls.outlet_id == outlet_id,
                    coalesce(cls.outlet_id, 0) == 0
                )
            )
        query = query.order_by(DmCategoryTranslation.dm_category_id.asc())
        query = query.order_by(DmMenuItem.id.asc())
        return query.all()

    @classmethod
    def get_outlet_avg_prep_time(cls, outlet_id):
        """
        Get outlets average food preparation time
        :param int outlet_id: Outlet id
        :rtype: int
        """
        average_prep_time = 0
        if outlet_id:
            query = cls.query.with_entities(cls.average_prep_time)
            query = query.filter(cls.outlet_id == outlet_id)
            average_prep_time = query.first()
            if average_prep_time:
                return average_prep_time.average_prep_time
            else:
                return 0
        return average_prep_time
