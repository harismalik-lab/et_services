"""
DM Area Coordinates
"""
from sqlalchemy import TIMESTAMP, Column, Enum, Float, String, Text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmAreaCoordinate(db.Model):
    __tablename__ = 'dm_area_coordinates'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    polygon_coordinates = Column(Text)
    lat = Column(Float(10))
    lng = Column(Float(10))
    status = Column(TINYINT(1))
    is_approved = Column(TINYINT(1))
    merchant_password = Column(String(300))
    created_date = Column(TIMESTAMP)
    updated_date = Column(TIMESTAMP)
    updated_by = Column(Enum('Merchant', 'Admin', 'SF'))
    outlet_zone_id = Column(INTEGER(11))
    map_type = Column(String(30))
    is_deleted = Column(TINYINT(1), nullable=False)
    band_id = Column(INTEGER(11))
