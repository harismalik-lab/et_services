"""
Merchant Attributes Restaurants And Bars Model
"""
import datetime

from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesRestaurantsAndBar(db.Model):
    __tablename__ = 'merchant_attributes_restaurants_and_bars'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    alcohol = Column(TINYINT(1))
    brunch = Column(TINYINT(1))
    buffet = Column(TINYINT(1))
    cuisine = Column(String(100))
    cuisines = Column(String(255))
    dress_code = Column(String(100))
    fine_dining = Column(String(100))
    groups_welcome = Column(TINYINT(1))
    halal = Column(TINYINT(1))
    kids_welcome = Column(TINYINT(1))
    live_entertainment = Column(TINYINT(1))
    outdoor_cooling = Column(TINYINT(1))
    outdoor_heating = Column(TINYINT(1))
    outdoor_seating = Column(TINYINT(1))
    parking = Column(TINYINT(1))
    pets_allowed = Column(TINYINT(1))
    pork_products = Column(TINYINT(1))
    smoking_indoor = Column(TINYINT(1))
    smoking_outdoor = Column(TINYINT(1))
    smoking_shisha = Column(TINYINT(1))
    sports_screens = Column(TINYINT(1))
    supervised_play_area = Column(TINYINT(1))
    takeaway = Column(TINYINT(1))
    valet_parking = Column(TINYINT(1))
    wheelchair_accessible = Column(TINYINT(1))
    wi_fi = Column(TINYINT(1))
    rooftop_bars = Column(TINYINT(1))
    wineries = Column(TINYINT(1))
    delivery = Column(TINYINT(1))
    hubbly_bubbly = Column(TINYINT(1))
    kids_play_area = Column(TINYINT(1))
    open_late = Column(TINYINT(1))
    with_a_view = Column(TINYINT(1))
    price_range = Column(String(50))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).first()
