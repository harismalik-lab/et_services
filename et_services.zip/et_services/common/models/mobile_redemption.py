"""
Mobile Redemption Model class
"""
from sqlalchemy import Column, Date, DateTime, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import INFORMATICA
from ..models.db import db
from ..models.mixin import Mixin


class MobileRedemption(db.Model, Mixin):
    __tablename__ = 'mobile_redemption'
    __table_args__ = {"schema": INFORMATICA}

    id = Column(INTEGER(11), primary_key=True, unique=True)
    date_created = Column(DateTime)
    offer_sf_id = Column(String(20))
    outlet_sf_id = Column(String(20))
    merchant_sf_id = Column(String(20))
    code = Column(String(100))
    customer_id = Column(INTEGER(10), nullable=False)
    quantity = Column(INTEGER(11), default=1)
    membership_code = Column(String(20), index=True)
    processed = Column(TINYINT(1), default=0)
    session_token = Column(String(100))
    root_code = Column(String(20))
    synch_time = Column(Date)
    sf_id = Column(String(30))
    fail_count = Column(INTEGER(11))
    reason = Column(String(255))
    company = Column(String(20))
