"""
location translation model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class LocationTranslation(db.Model, Mixin):
    __tablename__ = 'location_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    location_id = Column(INTEGER)
    locale = Column(String(5), default='en')
    name = Column(String(255))
