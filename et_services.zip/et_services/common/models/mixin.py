"""
This module contains Model Mixins
"""
from flask import request

from ..models.db import db


class Mixin(object):
    def insert_record(self, immediate_read=True):
        """
        Inserts a record
        :rtype: EntCustomerProfile
        """
        db.session.add(self)
        db.session.commit()
        if immediate_read:
            try:  # Reading from master
                request.with_master = True
                self.id
            finally:
                request.with_master = False
        return self

    @classmethod
    def bulk_insert(cls, objects):
        """
        Inserts list of objects
        :param objects: List of objects
        """
        db.session.add_all(objects)
        db.session.commit()

    def update_record(self):
        """
        Commit changes
        """
        db.session.commit()

    @classmethod
    def bulk_upsert(cls, objects):
        """
        for bulk update/insert and commit changes
        """
        db.session.bulk_save_objects(objects)
        db.session.commit()

    @classmethod
    def bulk_update(cls):
        """
        for bulk update commit changes
        """
        db.session.commit()

    @classmethod
    def call_sp(cls, sp_name, params):
        """
        Calls the passed stored procedure with params.
        """
        raw_conn = db.engine.raw_connection()
        try:
            cursor = raw_conn.cursor()
            cursor.callproc(sp_name, params)
            results = list(cursor.fetchall())
            cursor.close()
            raw_conn.commit()
        finally:
            raw_conn.close()
        return results
