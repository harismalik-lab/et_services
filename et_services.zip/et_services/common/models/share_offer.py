"""
Share Offer Model
"""
import datetime

from sqlalchemy import (TIMESTAMP, Column, DateTime, String, and_, case, func,
                        or_, text)
from sqlalchemy.dialects.mysql import BIT, INTEGER
from sqlalchemy.sql.functions import coalesce

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.ent_customer_profile import EntCustomerProfile
from ..models.merchant import Merchant
from ..models.merchant_translation import MerchantTranslation
from ..models.mixin import Mixin
from ..models.offer_translation import OfferTranslation
from ..models.product_offer import ProductOffer
from ..utils.api_utils import multi_key_sort


class ShareOffer(db.Model, Mixin):
    __tablename__ = 'share_offer'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    TYPE_NEW = 0
    TYPE_ACCEPTED = 1
    TYPE_REJECTED = 2
    TYPE_CANCELLED = 3
    MAX_ALLOWED_SHARES = 10

    PING_STATUS_SENT = 'Sent'
    PING_STATUS_ACCEPTED = 'Accepted'
    PING_STATUS_CANCELLED = 'Recalled'
    PING_STATUS_REJECTED = 'Rejected'

    OFFER_ACCEPT_BUTTON_TEXT = 'Accept'
    OFFER_REJECT_BUTTON_TEXT = 'Reject'
    OFFER_REJECT_MESSAGE = 'Do you want to reject this ping'
    OFFER_REJECT_TITLE = 'Are you sure?'

    OFFER_RECALL_BUTTON_TEXT = 'Recall'
    OFFER_RECALL_MESSAGE = 'Do you want to recall this ping'
    OFFER_RECALL_TITLE = 'Are you sure?'

    SET_OF_PINGS_PER_PRODUCT_PURCHASE = 1
    MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_NON_MEMBER = 3
    MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_MEMBER = 99999

    COLOR_CODE_WHEN_USER_HAS_PING_QUOTA_TO_RECEIVE_OR_SEND = "6098cd"
    COLOR_CODE_WHEN_USER_HAS_NO_PING_QUOTA_LEFT_TO_RECEIVE_OR_SEND = "c02828"

    FREE_PINGS_QUOTA = 1000
    FREE_PINGS_USED_FOR_DEC = 0

    id = Column(INTEGER(11), primary_key=True)
    entry_id = Column(String(100))
    user_id = Column(INTEGER(11), index=True)
    primary_sender_user_id = Column(INTEGER(11), index=True)
    recipient_email = Column(String(100), index=True)
    created_date = Column(DateTime, default=datetime.datetime.now)
    status = Column(INTEGER(11), server_default=text("'0'"))
    is_exempt_from_yearly_quota = Column(BIT(1))
    offer_id = Column(INTEGER(11), index=True)
    product_id = Column(INTEGER(11), index=True)
    accepted_date = Column(DateTime)
    recipient_id = Column(INTEGER(11), index=True)
    primary_recipient_user_id = Column(INTEGER(11), index=True)
    active = Column(BIT(1), default=True)
    amz_update_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    activation_type = Column(String(10))
    activation_type_id = Column(INTEGER(11))
    expiration_date = Column(DateTime)

    @classmethod
    def get_ping_limit_allowed(cls, group, is_active_family_member=False):
        """
        Returns max number of allowed pings according to member status
        :param is_active_family_member:
        :param int group: Member group
        :rtype: int
        """
        if group == EntCustomerProfile.MEMBERSTATUS_MEMBER or is_active_family_member:
            return cls.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_MEMBER
        return cls.MAX_ALLOWED_PINGS_TO_RECEIVE_FOR_NON_MEMBER

    @classmethod
    def get_pings_accepted_or_pending_by_user_id_or_email(
            cls, email_or_id, include_pending=False, return_count=False, primary_user_id=0
    ):
        """
        Returns pinged offer or their count weather they are in accepted or pending state
        :param int primary_user_id: Primary User Id
        :param int|str email_or_id: Email or customer id
        :param bool include_pending: Flag to include pending pinged offers
        :param bool return_count: Flag to return count instead of list
        :rtype: list|int
        """
        if email_or_id and isinstance(email_or_id, str) and email_or_id.isdigit():
            email_or_id = int(email_or_id)
        ping_statuses = [cls.TYPE_ACCEPTED]
        if include_pending:
            ping_statuses.append(cls.TYPE_NEW)
        query = cls.query.with_entities(cls.offer_id)
        query = query.filter(cls.active == 1).filter(cls.is_exempt_from_yearly_quota != 1)
        query = query.filter(cls.status.in_(ping_statuses))
        user_id = 0
        if isinstance(email_or_id, str):
            query = query.filter(cls.recipient_email == email_or_id)
        else:
            user_id = email_or_id
            if primary_user_id:
                user_id = primary_user_id
        if user_id:
            query = query.filter(
                or_(
                    cls.primary_recipient_user_id == user_id,
                    and_(
                        cls.recipient_id == user_id,
                        coalesce(cls.primary_recipient_user_id, 0) == 0
                    )
                )
            )

        # raise Exception('This version does not handle emails.')
        # The date when ping restriction was applied
        pings_cut_off_data = '2018-03-12 12:00:00'
        converted_date_obj = datetime.datetime.strptime(pings_cut_off_data, '%Y-%m-%d %H:%M:%S')
        query = query.filter(cls.created_date > converted_date_obj)
        if return_count:
            return query.count()
        return query.all()

    @classmethod
    def validate_ping_to_accept(cls, recipient_id, ping_id):
        """
        :param recipient_id: Contains recipient id
        :param ping_id: Contains ping id
        :param int recipient_id: id of recipient
        :param int ping_id: id of ping
        :return:
        """
        if recipient_id and ping_id:
            query = cls.query.with_entities(cls.status)
            query = query.filter(cls.id == ping_id, cls.recipient_id == recipient_id)
            return query.first()
        else:
            return {}

    @classmethod
    def validate_pings_to_accept_or_reject(cls, recipient_id, ping_ids):
        """
        Gets validated pings ids to be accepted or rejected

        :param int recipient_id: user id
        :param list ping_ids: ping ids
        :rtype list
        :return: validated pings ids
        """
        if recipient_id and ping_ids:
            query = cls.query.with_entities(cls.id)
            query = query.filter(cls.id.in_(ping_ids), cls.recipient_id == recipient_id, cls.status == cls.TYPE_NEW)
            pings = query.all()
            return [ping.id for ping in pings]
        else:
            return []

    @classmethod
    @with_master
    def post_accept_shared_offer(cls, entry_id, status, ping_id=None):
        """
        This method updates the ping status to accepted

        :param int entry_id: entry id
        :param bool|str status: status
        :param int ping_id: id of ping
        """
        query = cls.query
        changes = {"status": status, "accepted_date": str(datetime.datetime.now())}
        if entry_id:
            query = query.filter(cls.entry_id == entry_id)
        elif ping_id:
            query = query.filter(cls.id == ping_id)
        if ping_id or entry_id:
            query = query.filter(cls.status == cls.TYPE_NEW)
        query.update(changes)
        cls.update_record()
        return True

    @classmethod
    @with_master
    def post_accept_or_reject_shared_offers(cls, status, ping_ids=None):
        """
        Update status of pings

        :param int status: status
        :param list ping_ids: pings ids
        """
        query = cls.query.filter(cls.id.in_(ping_ids))
        changes = {"status": status, "accepted_date": str(datetime.datetime.now())}
        query.update(changes)
        cls.update_record()

    @classmethod
    def get_shared_offers_pending(cls, recipient_id, return_offer_ids=False):
        """
        Gets the customer pending shared offers

        :param int recipient_id: id of recipient
        :param bool return_offer_ids: return offer ids
        """
        from ..models.product import Product
        from ..models.offer import Offer

        query = cls.query.with_entities(
            cls.entry_id,
            func.max(cls.user_id).label('user_id'),
            func.group_concat(cls.offer_id).label('offer_id'),
            func.group_concat(Product.is_cheers).label('is_cheers'),
            func.max(Product.location_id).label('location_id')
        )
        query = query.join(Offer, cls.offer_id == Offer.id)
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.filter(cls.active == 1, cls.status == cls.TYPE_NEW, cls.recipient_id == recipient_id)
        query = query.group_by(cls.entry_id)
        return query.all()

    @classmethod
    def get_shared_received_offers(
            cls, recipient_id, locale, primary_recipent_id=0, pings_history=False, include_rejected=False
    ):
        """
        This method fetches the received offers.
        :param primary_recipent_id:
        :param recipient_id: id against which offers are to be fetched
        :param locale: locale for which offers are to be fetched
        :param pings_history: calculate extra params for pings history api
        :param include_rejected: whether to include rejected pings or not
        :return: list of received offers
        """
        from common.models.offer import Offer
        from common.models.product import Product
        from common.models.product_translation import ProductTranslation

        query = cls.query.with_entities(
            cls.id,
            cls.recipient_email.label('recipientEmail'),
            cls.created_date.label('createdDate'),
            cls.status,
            cls.accepted_date.label('acceptedDate'),
            cls.user_id.label('senderId'),
            OfferTranslation.name.label('offerName'),
            MerchantTranslation.name.label('merchantName'),
            Merchant.logo_retina_url.label('logoUrl'),
            Merchant.logo_non_retina_url.label('logoSmallUrl'),
            Offer.merchant_category.label('category'),
            cls.entry_id
        )

        if pings_history:
            query = query.with_entities(
                cls.id,
                cls.recipient_email.label('recipientEmail'),
                cls.created_date.label('createdDate'),
                cls.status,
                cls.accepted_date.label('acceptedDate'),
                cls.user_id.label('senderId'),
                OfferTranslation.name.label('offerName'),
                MerchantTranslation.name.label('merchantName'),
                Merchant.logo_retina_url.label('logoUrl'),
                Merchant.logo_non_retina_url.label('logoSmallUrl'),
                Offer.merchant_category.label('category'),
                cls.entry_id,
                Product.is_cheers,
                Product.location_id,
                Offer.merchant_id,
                Product.sf_id.label('sku_product'),
                ProductTranslation.name.label('product_name')
            )
        query = query.join(Offer, Offer.id == cls.offer_id)
        query = query.join(OfferTranslation, Offer.id == OfferTranslation.offer_id)

        if pings_history:
            query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
            query = query.join(Product, ProductOffer.product_id == Product.id)
            query = query.join(
                ProductTranslation, Product.id == ProductTranslation.product_id
            )
        if primary_recipent_id == recipient_id:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale,
                MerchantTranslation.locale == locale,
                or_(
                    cls.recipient_id == recipient_id,
                    cls.primary_recipient_user_id == recipient_id
                ),
                or_(
                    cls.primary_recipient_user_id == recipient_id,
                    cls.primary_recipient_user_id == 0,
                    cls.primary_recipient_user_id.is_(None)
                )
            )
            if pings_history:
                query = query.filter(ProductTranslation.locale == locale)
                if include_rejected:
                    query = query.filter(cls.status.in_([0, 1, 2]))
                else:
                    query = query.filter(cls.status.in_([0, 1]))
            else:
                query = query.filter(cls.status == 1)
        elif primary_recipent_id:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale, MerchantTranslation.locale == locale,
                cls.primary_recipient_user_id == primary_recipent_id
            )
            if pings_history:
                query = query.filter(ProductTranslation.locale == locale)
                if include_rejected:
                    query = query.filter(cls.status.in_([cls.TYPE_NEW, cls.TYPE_ACCEPTED, cls.TYPE_REJECTED]))
                else:
                    query = query.filter(cls.status.in_([cls.TYPE_NEW, cls.TYPE_ACCEPTED]))
            else:
                query = query.filter(cls.status == cls.TYPE_ACCEPTED)
        else:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale,
                MerchantTranslation.locale == locale,
                cls.recipient_id == recipient_id,
                or_(
                    cls.primary_recipient_user_id == recipient_id,
                    cls.primary_recipient_user_id == 0,
                    cls.primary_recipient_user_id.is_(None)
                )
            )
            if pings_history:
                query = query.filter(ProductTranslation.locale == locale)
                if include_rejected:
                    query = query.filter(cls.status.in_([cls.TYPE_NEW, cls.TYPE_ACCEPTED, cls.TYPE_REJECTED]))
                else:
                    query = query.filter(cls.status.in_([cls.TYPE_NEW, cls.TYPE_ACCEPTED]))
            else:
                query = query.filter(cls.status == cls.TYPE_ACCEPTED)
        query = query.join(Merchant, Merchant.id == Offer.merchant_id)
        query = query.join(MerchantTranslation, MerchantTranslation.merchant_id == Merchant.id)
        return query.order_by(cls.id.desc()).all()

    @classmethod
    def get_shared_sent_offers(
            cls, sender_id, locale, primary_user_id=0, pings_history=False,
            order_by_status=False, include_rejected=False
    ):
        """
        This method fetches the sent offers
        :param primary_user_id:
        :param sender_id: sender id against which offers are to be fetched
        :param locale: locale against which offers are to be fetched
        :param pings_history: calculate extra params for pings history api
        :param order_by_status: sort ping by status
        :param include_rejected: whether to include rejected status pings or not
        :return: list of sent offers
        """
        from ..models.offer import Offer
        from ..models.product import Product
        from ..models.product_translation import ProductTranslation

        query = cls.query.with_entities(
            cls.id,
            cls.recipient_email.label('recipientEmail'),
            cls.created_date.label('createdDate'),
            cls.status,
            cls.accepted_date.label('acceptedDate'),
            cls.recipient_id.label('recipientId'),
            OfferTranslation.name.label('offerName'),
            MerchantTranslation.name.label('merchantName'),
            Merchant.logo_retina_url.label('LogoUrl'),
            Merchant.logo_non_retina_url.label('logoSmallUrl'),
            Offer.merchant_category.label('category'),
            cls.entry_id
        )
        if pings_history:
            query = cls.query.with_entities(
                cls.id,
                cls.recipient_email.label('recipientEmail'),
                cls.created_date.label('createdDate'),
                cls.status,
                cls.accepted_date.label('acceptedDate'),
                cls.recipient_id.label('recipientId'),
                OfferTranslation.name.label('offerName'),
                MerchantTranslation.name.label('merchantName'),
                Merchant.logo_retina_url.label('LogoUrl'),
                Merchant.logo_non_retina_url.label('logoSmallUrl'),
                Offer.merchant_category.label('category'),
                cls.entry_id,
                Product.is_cheers,
                Product.location_id,
                Offer.merchant_id,
                Product.sf_id.label('sku_product'),
                ProductTranslation.name.label('product_name')
            )
        query = query.join(Offer, Offer.id == cls.offer_id)
        query = query.join(OfferTranslation, Offer.id == OfferTranslation.offer_id)
        if pings_history:
            query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
            query = query.join(Product, ProductOffer.product_id == Product.id)
            query = query.join(
                ProductTranslation, Product.id == ProductTranslation.product_id
            )

        if primary_user_id == sender_id:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale,
                MerchantTranslation.locale == locale, ProductTranslation.locale == locale,
                or_(
                    cls.user_id == sender_id,
                    cls.primary_sender_user_id == sender_id
                ),
                or_(
                    cls.primary_sender_user_id == sender_id,
                    cls.primary_sender_user_id == 0,
                    cls.primary_sender_user_id.is_(None)
                )
            )

        elif primary_user_id:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale, MerchantTranslation.locale == locale,
                ProductTranslation.locale == locale, cls.primary_sender_user_id == primary_user_id
            )

        else:
            query = query.filter(
                cls.active == 1, OfferTranslation.locale == locale, cls.user_id == sender_id,
                MerchantTranslation.locale == locale, ProductTranslation.locale == locale,
                or_(
                    cls.primary_sender_user_id == sender_id,
                    cls.primary_sender_user_id == 0,
                    cls.primary_sender_user_id.is_(None)
                )
            )
        if not include_rejected:
            query = query.filter(cls.status != 2)
        query = query.join(Merchant, Merchant.id == Offer.merchant_id)
        query = query.join(MerchantTranslation, MerchantTranslation.merchant_id == Merchant.id)
        query = query.order_by(cls.id.asc())
        shared_offers = query.all()
        resultant_list = []
        if order_by_status:
            for offer_obj in shared_offers:
                offer = offer_obj._asdict()
                offer['pings_order'] = 9999
                if offer['status'] == cls.TYPE_NEW:
                    offer['pings_order'] = 1
                resultant_list.append(offer)
            shared_offers = multi_key_sort(resultant_list, ['pings_order', 'id'])
        return shared_offers

    @classmethod
    def get_shared_offers_by_sender_primary(cls, sender_id, offer_id=None):
        query = cls.query.with_entities(cls.offer_id)
        query = query.filter(cls.active == 1, case(
            [
                (
                    or_(cls.primary_sender_user_id.is_(None), cls.primary_sender_user_id == 0),
                    cls.user_id
                )
            ],
            else_=cls.primary_sender_user_id
        ) == sender_id)
        query = query.filter(~cls.status.in_([ShareOffer.TYPE_REJECTED, ShareOffer.TYPE_CANCELLED]))
        if offer_id:
            if isinstance(offer_id, list):
                query = query.filter(cls.offer_id.in_(offer_id))
            else:
                query = query.filter(cls.offer_id == offer_id)
        return query.all()

    @classmethod
    def get_shared_offers_accepted_family(cls, primary_recipient_id):
        """
        Gets shared offers accepted by family

        :param primary_recipient_id: Primary recipient id of family
        :rtype: orm list
        """
        query = cls.query.with_entities(cls.offer_id).filter(
            cls.active == 1,
            cls.primary_recipient_user_id == primary_recipient_id,
            cls.status == cls.TYPE_ACCEPTED
        )
        return query.all()

    @classmethod
    def get_shared_offers_by_sender_merchant_controller(cls, sender_id, offer_id=None, primary_user_id=0):
        """
        Gets shared offers by sender merchant controller

        :param sender_id: Sender id
        :param offer_id: Offer id
        :param primary_user_id: Primary user id
        :rtype: list
        """
        user_id = sender_id
        if primary_user_id:
            user_id = primary_user_id
        query = cls.query.with_entities(cls.offer_id)
        query = query.filter(
            cls.active == 1,
            coalesce(cls.primary_sender_user_id, 0) == 0,
            or_(
                cls.primary_sender_user_id == user_id,
                cls.user_id == user_id
            ),
            cls.status.notin_([cls.TYPE_REJECTED, cls.TYPE_CANCELLED])
        )
        if offer_id:
            query = query.filter(cls.offer_id == offer_id)
        return query.all()

    @classmethod
    def get_shared_offers_accepted(cls, recipient_id, offer_id=None, primary_user_id=0, get_family_flag=False):
        """
        Gets shared offers accepted by user
        :param recipient_id: Recipient id
        :param offer_id: Offer id
        :param primary_user_id: Id of primary user
        :param get_family_flag: Family flag
        :rtype: list
        """
        assert primary_user_id or recipient_id, "Insufficient params"
        query = cls.query.with_entities(cls.offer_id)
        if get_family_flag:
            query = query.with_entities(coalesce(cls.primary_recipient_user_id, 0).label('is_family_offer'))

        if offer_id:
            query = query.filter(cls.offer_id == offer_id)

        query = query.filter(cls.active == 1, cls.status == cls.TYPE_ACCEPTED)

        if recipient_id == primary_user_id:
            query = query.filter(
                cls.recipient_id == recipient_id,
                or_(
                    cls.primary_recipient_user_id == 0,
                    cls.primary_recipient_user_id.is_(None)
                )
            )
        elif primary_user_id:
            query = query.filter(cls.primary_recipient_user_id == primary_user_id)
        else:
            query = query.filter(
                cls.recipient_id == recipient_id,
                or_(
                    cls.primary_recipient_user_id == recipient_id,
                    cls.primary_recipient_user_id == 0,
                    cls.primary_recipient_user_id.is_(None)
                )
            )
        return query.all()

    @classmethod
    def get_personal_shared_offers_accepted_for_secondary(cls, recipient_id, get_family_flag=False):
        """
        Gets personal shared offers accepted for secondary user

        :param recipient_id: Recipient id
        :param get_family_flag: Family flag
        :rtype: list
        """
        selected_cols = []
        query = cls.query
        selected_cols.append(cls.offer_id)
        if get_family_flag:
            selected_cols.append(coalesce(cls.primary_recipient_user_id, 0).label('is_family_offer'))
        query = query.filter(
            cls.active == 1,
            cls.status == cls.TYPE_ACCEPTED,
            and_(
                or_(
                    cls.primary_recipient_user_id == recipient_id,
                    cls.recipient_id == recipient_id,
                ),
                coalesce(cls.primary_recipient_user_id, 0) == 0,
            )
        )
        query = query.with_entities(*selected_cols)
        return query.all()

    @classmethod
    @with_master
    def get_shared_offers_by_sender(cls, sender_id, offer_id=None, primary_user_id=0):
        """
        Gets shared offers by sender
        :param sender_id: Sender id
        :param offer_id: Offer id
        :param primary_user_id: Primary user id
        :rtype: list
        """
        from ..models.offer import Offer
        query = cls.query.with_entities(cls.offer_id)
        if primary_user_id == sender_id:
            query = query.filter(
                cls.active == 1,
                or_(cls.user_id == sender_id, cls.primary_sender_user_id == sender_id),
                or_(cls.primary_sender_user_id == sender_id,
                    or_(cls.primary_sender_user_id == 0, cls.primary_sender_user_id.is_(None))
                    )
            )
        elif primary_user_id:
            query = query.filter(cls.active == 1, cls.primary_sender_user_id == primary_user_id)
        else:
            query = query.filter(
                cls.active == 1,
                cls.user_id == sender_id,
                or_(cls.primary_sender_user_id == sender_id,
                    or_(cls.primary_sender_user_id == 0, cls.primary_sender_user_id.is_(None))
                    )
            )
        query = query.filter(cls.status != Offer.TYPE_REJECTED)
        if offer_id:
            query = query.filter(cls.offer_id == offer_id)
        return query.all()

    @classmethod
    def get_shared_offers_by_sender_count_primary(cls, sender_id, offer_id=None):
        """
        Gets shared offers against sender count primary

        :param int sender_id: sender id
        :param int offer_id: offer id
        """
        query = cls.query.with_entities(cls.offer_id)
        query = query.filter(cls.active == 1)
        query = query.filter(
            case(
                [
                    (
                        or_(cls.primary_sender_user_id.is_(None), cls.primary_sender_user_id == 0),
                        cls.user_id
                    )
                ],
                else_=cls.primary_sender_user_id
            ) == sender_id
        )
        query = query.filter(cls.status != cls.TYPE_REJECTED)
        current_year = datetime.datetime.now().year
        # sql_dal.where_gt("s.created_date", '{current_year}-01-03 59:00:00'.format(current_year=current_year))
        query = query.filter(cls.created_date > '{current_year}-01-03 59:00:00'.format(current_year=current_year))
        if offer_id:
            query = query.filter(cls.offer_id == offer_id)
        return query.count()

    @classmethod
    @with_master
    def get_shared_offers_by_sender_count(cls, sender_id, offer_id=None, primary_sender_user_id=None):
        """
        returns customer shared offer pings count
        :param sender_id:
        :param offer_id:
        :param primary_sender_user_id:
        """
        user_id = sender_id
        if primary_sender_user_id:
            user_id = primary_sender_user_id

        query = cls.query.with_entities(cls.offer_id).filter(
            cls.active == 1,
            or_(
                cls.primary_sender_user_id == user_id,
                cls.user_id == user_id,
                coalesce(cls.primary_sender_user_id, 0) == 0
            )
        )
        query = query.filter(cls.status.notin_([cls.TYPE_REJECTED, cls.TYPE_CANCELLED]))
        if offer_id:
            query.filter(cls.offer_id == offer_id)

        return query.count()

    @classmethod
    def get_pings_count_accepted_or_pending_by_user_id(cls, user_id):
        """
        Returns pinged offer or their count weather they are in accepted or pending state
        :param int user_id: User Id
        :rtype: list|int
        """
        pings_cut_off_date = datetime.datetime.strptime('2018-03-12 12:00:00', '%Y-%m-%d %H:%M:%S')
        return cls.query.with_entities(cls.id).filter(
            cls.active == 1,
            cls.is_exempt_from_yearly_quota != 1,
            cls.status.in_([cls.TYPE_ACCEPTED, cls.TYPE_NEW]),
            or_(
                cls.primary_recipient_user_id == user_id,
                and_(
                    cls.recipient_id == user_id,
                    coalesce(cls.primary_recipient_user_id, 0) == 0
                )
            ),
            cls.created_date > pings_cut_off_date
        ).count()

    @classmethod
    def get_accepted_received_offers(cls, recipient_id, offer_ids=None, primary_user_id=0):
        """
        Returns Accepted ping offers
        :param int recipient_id: Recipient User Id
        :param list offer_ids: Offer ids list for quick lookup
        :param int primary_user_id: Primary User Id
        :rtype: list
        """
        query = cls.query.with_entities(cls.offer_id).filter(
            cls.active == 1,
            cls.status == cls.TYPE_ACCEPTED
        )
        if offer_ids:
            query = query.filter(cls.offer_id.in_(offer_ids))
        if primary_user_id:
            if primary_user_id == recipient_id:
                query = query.filter(
                    or_(
                        cls.primary_recipient_user_id == primary_user_id,
                        and_(
                            cls.recipient_id == recipient_id,
                            coalesce(cls.primary_recipient_user_id, 0) == 0,
                        )
                    )
                )
            else:
                query = query.filter(cls.primary_recipient_user_id == primary_user_id)
        else:
            query = query.filter(
                or_(
                    cls.primary_recipient_user_id == recipient_id,
                    and_(
                        coalesce(cls.recipient_id, 0) == 0,
                        cls.recipient_id == recipient_id
                    )
                )
            )
        return query.all()

    @classmethod
    def get_sent_offers(cls, user_id, offer_ids=None):
        """
        Returns Sent offer ids
        :param int user_id: Sender User Id
        :param list offer_ids: Offer Ids
        """
        query = cls.query.with_entities(cls.offer_id).filter(
            cls.status != cls.TYPE_REJECTED,
            cls.active == 1,
            or_(
                cls.primary_sender_user_id == user_id,
                and_(
                    cls.user_id == user_id,
                    coalesce(cls.primary_sender_user_id, 0) == 0
                )
            )
        )
        if offer_ids:
            query = query.filter(
                cls.offer_id.in_(offer_ids)
            )
        return query.all()
