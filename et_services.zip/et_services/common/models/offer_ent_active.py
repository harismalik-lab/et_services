"""
Offer Ent Active Model
"""
import datetime

from sqlalchemy import Column, DateTime, Float, Index, String, func, or_, text
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TIMESTAMP, TINYINT

from common.models.merchant import Merchant

from ..constants import ENTERTAINER_WEB
from ..models.country_translation import CountryTranslation
from ..models.db import db
from ..models.mixin import Mixin
from ..models.product import Product
from ..models.product_offer_ent_active import ProductOfferEntActive


class OfferEntActive(db.Model, Mixin):
    __tablename__ = 'offer_ent_active'
    __table_args__ = (
        Index('idx_validity', 'valid_from', 'valid_to', 'status'),
        Index('idx_relevant', 'valid_from', 'valid_to', 'status', 'type', 'promoted_from', 'promoted_to'),
        Index('idx_member_trial_promotion', 'type', 'promoted_from', 'promoted_to', 'status'),
        Index('idx_offer_status_type', 'status', 'type'),
        {"schema": ENTERTAINER_WEB}
    )
    # Constants
    TYPE_DEFAULT = 0
    TYPE_TRIAL = 1
    TYPE_MEMBER = 2
    TYPE_BOTH = 3
    TYPE_NEW_OFFER = 4
    TYPE_FEATURED_OFFER = 5  # Both New and Monthly
    OFFER_TYPE_VALUE_DEFAULT = 0
    OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
    OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
    OFFER_TYPE_VALUE_GIFT = 3
    OFFER_TYPE_VALUE_PACKAGE = 4
    OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

    id = Column(INTEGER(11), primary_key=True)
    sf_id = Column(String(20), unique=True, comment='Salesforce ID')
    merchant_id = Column(INTEGER(11), nullable=False, index=True)
    valid_from = Column(DateTime)
    valid_to = Column(DateTime)
    savings_estimate = Column(INTEGER(11), default=0, comment='Savings estimate is in AED.')
    offer_sequence = Column(TINYINT(1), default=1)
    type = Column(SMALLINT(6), index=True, default=0,
                  comment='Types:\\n\\n0 = default, normal offer (belongs to a product, purchasable in book or '
                          'bundles)\\n1 = trial offer (given to trial members for free, does not need to belong to a '
                          'product)\\n2 = member offer (give to full members for free, does not need '
                          'to belong to a  /* comment truncated */ /*product)*/')
    voucher_type = Column(SMALLINT(6))
    spend = Column(SMALLINT(6), server_default=text("'0'"))
    reward = Column(SMALLINT(6), server_default=text("'0'"))
    percentage_off = Column(TINYINT(1), server_default=text("'0'"))
    no_of_people = Column(TINYINT(1), server_default=text("'0'"))
    is_alcohol_offer = Column(TINYINT(1), default=0)
    voucher_restrictions = Column(String(255))
    voucher_restriction1 = Column(SMALLINT(6))
    voucher_restriction2 = Column(SMALLINT(6))
    promoted_from = Column(DateTime)
    promoted_to = Column(DateTime)
    status = Column(String(20), index=True, default='Active', comment='Draft, Approved, Active, Inactive')
    quota = Column(INTEGER(11), default=0)
    quantity = Column(INTEGER(11), default=1)
    has_red_custom_code = Column(BIT(1))
    redemptions_limit_in_x_hours = Column(SMALLINT(6), default=4, comment='This is to apply a cap on monthly offers')
    hours_to_consider_for_redemption_cap = Column(SMALLINT(6), default=24, comment='Number of hours to restrict limit on redemption')  # noqa
    merchant_email = Column(String(255))
    merchant_website = Column(String(255))
    merchant_telephone = Column(String(45))
    merchant_fax = Column(String(45))
    merchant_cuisine = Column(String(255))
    merchant_category = Column(String(255), index=True)
    sub_category = Column(String(255))
    digital_section = Column(String(255))
    group_sf_id = Column(String(20))
    group_telephone = Column(String(45))
    group_website = Column(String(255))
    merchant_instagram = Column(String(255))
    inactive_reason = Column(String(255))
    local_currency = Column(String(10))
    is_promo_code_offer = Column(TINYINT(1), server_default=text("'0'"))
    redemption_method = Column(TINYINT(1), server_default=text("'0'"))
    savings_estimate_local_currency = Column(INTEGER(11), default=0)
    amz_update_time = Column(TIMESTAMP, default=datetime.datetime.now)
    min_total_fee = Column(Float, default=0)
    off_peak_rate = Column(Float, default=0)
    off_peak_aed = Column(Float, default=0)
    opportunity_currency = Column(String(10))
    participation_offers_fee = Column(Float, default=0)
    peak_rate = Column(Float, default=0)
    peak_rate_aed = Column(Float, default=0)
    sales_person = Column(String(100))
    created_date = Column(DateTime)
    opportunity_stage = Column(String(50))
    item_code = Column(String(45))
    parent_offer_sf_id = Column(String(50))
    dcp_license = Column(String(100))
    ppr_not_applicable = Column(TINYINT(4))
    opportunity_sf_id = Column(String(20))
    inclusion_fee_cancelled = Column(TINYINT(1))
    is_point_based_offer = Column(TINYINT(1), default=0)
    gems_points = Column(INTEGER(11))

    @classmethod
    def find_by_id(cls, offer_id):
        """
        find offers by offer_id
        :param int offer_id: offer Id
        :return: offer
        """
        query = cls.query.with_entities(
            cls.id,
            cls.redemptions_limit_in_x_hours,
            cls.hours_to_consider_for_redemption_cap,
            cls.type,
            cls.merchant_id,
            cls.sf_id,
            cls.savings_estimate,
            cls.valid_from,
            cls.valid_to,
            cls.quantity,
            cls.has_red_custom_code,
        ).filter(
            cls.id == offer_id,
            cls.status == 'Active'
        )
        return query.first()

    @classmethod
    def get_by_offer_ids_and_product_ids(cls, offer_ids, product_ids):
        """
        Returns offer against offer and product ids
        :param list offer_ids: Offer Id
        :param list product_ids: Product Id
        :rtype: list
        """
        return cls.query.with_entities(
            cls.id,
            cls.valid_from,
            cls.valid_to,
            cls.type,
            cls.quantity,
            ProductOfferEntActive.product_id
        ).join(
            ProductOfferEntActive, cls.id == ProductOfferEntActive.offer_id
        ).join(
            Product, ProductOfferEntActive.product_id == Product.id
        ).filter(
            cls.id.in_(offer_ids), Product.id.in_(product_ids)
        ).all()

    def get_offer_quantities(cls, offer_ids):
        """
        Returns offer quantities
        :param list offer_ids: Offer Ids
        :rtype: dict
        """
        quantities = {}
        if offer_ids:
            query = cls.query.with_entities(cls.id, cls.quantity)
            offers = query.filter(cls.id.in_(offer_ids)).all()
            quantities = {}
            for offer in offers:
                quantities.update({
                    offer.id: quantities.get(offer.id, 0) + offer.quantity
                })
        return quantities

    @classmethod
    def any_offer_monthly_or_not_pingable(cls, offer_ids):
        """
        Returns True if any offer is monthly or it's merchant doesn't allow pings
        :param list offer_ids: Offer Ids
        :rtype: bool
        """
        if offer_ids:
            query = cls.query.with_entities(cls.id)
            query = query.join(Merchant, cls.merchant_id == Merchant.id)
            query = query.filter(cls.id.in_(offer_ids))
            query = query.filter(
                or_(
                    Merchant.is_pingable != 1,
                    cls.type == cls.TYPE_MEMBER
                )
            )
            return bool(query.count())
        return False

    def get_country_areas(cls, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that
        are assigned for the supplied Location.

        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        """
        from ..models.country import Country
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product_ent_active import ProductEntActive
        from ..models.product_offer_ent_active import ProductOfferEntActive

        query = cls.query.with_entities(
            func.concat(OutletTranslation.neighborhood, ', ', CountryTranslation.name).distinct().label('item'),
            OutletTranslation.neighborhood,
            CountryTranslation.name
        )
        query = query.join(ProductOfferEntActive, ProductOfferEntActive.offer_id == cls.id)
        query = query.join(ProductEntActive, ProductEntActive.id == ProductOfferEntActive.product_id)
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(
            cls.status == 'Active',
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
        )

        if category:
            query = query.filter(Merchant.category == category)

        # Determine bundled Product if we have supplied a Location.
        # Bundled Products are usually Travel books/bundle given for free with a regular Product.
        # Remember: Travel Products will have NULL for location_id.
        if location_id:
            query = query.filter(
                Outlet.location_id == location_id,
                ProductEntActive.location_id == location_id
            )
        if search_keyword:
            query = query.filter(OutletTranslation.neighborhood.like('%{}%'.format(search_keyword)))

        query = query.order_by(func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name))

        records = query.all()
        items = []

        for record in records:
            if record.neighborhood:
                if record.item.startswith(', ') or record.item.endswith(', '):
                    record.item = record.item.replace(', ', '')

                if record.neighborhood in record.name:
                    record.item = record.neighborhood
                items.append({'name': record.item, 'value': record.neighborhood})

        return items

    @classmethod
    def get_attribute_values_malls(cls, attribute, location_id=False, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.

        :param str attribute: column name of OutletTranslation in which we ned to look up keyword.
        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        """
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product_ent_active import ProductEntActive
        from ..models.product_offer_ent_active import ProductOfferEntActive

        query = cls.query.with_entities(
            getattr(OutletTranslation, attribute).label('item')
        )

        query = query.join(ProductOfferEntActive, ProductOfferEntActive.offer_id == cls.id)
        query = query.join(ProductEntActive, ProductEntActive == ProductOfferEntActive.product_id)
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(OutletTranslation.locale == locale)
        if category:
            query = query.filter(Merchant.category == category)

        if location_id:
            query = query.filter(Outlet.location_id == location_id)
            bundled_product_skus = ProductEntActive.find_bundled_product_skus_by_location(location_id)
            if bundled_product_skus and bundled_product_skus.bundled_product_sku:
                bundled_product_skus = bundled_product_skus.bundled_product_sku.split(',')
            bundled_product_skus = list(set(bundled_product_skus))
            if bundled_product_skus:
                query = query.filter(
                    or_(
                        ProductEntActive.location_id == location_id,
                        ProductEntActive.sf_id.in_(bundled_product_skus)
                    )
                )
            else:
                query = query.filter(ProductEntActive.location_id == location_id)

        if search_keyword:
            query = query.filter(getattr(OutletTranslation, attribute).like('%{}%'.format(search_keyword)))

        query = query.filter(cls.status == 'Active')
        query = query.order_by(getattr(OutletTranslation, attribute))
        records = query.distinct().all()
        items = [record.item for record in records]
        return items

    @classmethod
    def get_country_hotels(cls, location_id=0, locale='en', search_keyword="", category=""):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.

        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        """
        from ..models.country import Country
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product_ent_active import ProductEntActive
        from ..models.product_offer_ent_active import ProductOfferEntActive

        query = cls.query.with_entities(
            func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name).label('item'),
            OutletTranslation.hotel,
            CountryTranslation.name
        )
        query = query.join(ProductOfferEntActive, ProductOfferEntActive.offer_id == cls.id)
        query = query.join(ProductEntActive, ProductEntActive.id == ProductOfferEntActive.product_id)
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(
            cls.status == 'Active',
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
        )

        if category:
            query = query.filter(Merchant.category == category)

        if str(location_id).isdigit() and int(location_id):
            query.filter(
                Outlet.location_id == location_id
            )
            bundled_product_skus = ProductEntActive.find_bundled_product_skus_by_location(location_id)
            if bundled_product_skus and bundled_product_skus.bundled_product_sku:
                bundled_product_skus = bundled_product_skus.bundled_product_sku.split(',')
            bundled_product_skus = list(set(bundled_product_skus))
            if bundled_product_skus:
                query = query.filter(
                    or_(
                        ProductEntActive.location_id == location_id,
                        ProductEntActive.sf_id.in_(bundled_product_skus)
                    )
                )
            else:
                query = query.filter(ProductEntActive.location_id == location_id)

        if search_keyword:
            query = query.filter(OutletTranslation.hotel.like('%{}%'.format(search_keyword)))

        query = query.order_by(func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name))
        records = query.distinct().all()
        items = []

        for record in records:
            if record.hotel:
                if record.item.startswith(', ') or record.item.endswith(', '):
                    record.item = record.item.replace(', ', '')

                if record.name in record.hotel:
                    record.item = record.hotel
                items.append({'name': record.item, 'value': record.hotel})
        return items
