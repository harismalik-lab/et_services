"""
Ent Crg Lookup Model
"""
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db
from ..models.mixin import Mixin
from ..utils import get_dubai_datetime


class EntCrgLookup(db.Model, Mixin):
    __tablename__ = 'ent_crg_lookup'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(INTEGER(10), primary_key=True)
    email = Column(String(150), index=True)
    user_id = Column(INTEGER(11), default=0)
    first_name = Column(String(250))
    last_name = Column(String(250))
    user_group = Column(TINYINT(2), default=1)
    created_on = Column(DateTime, default=get_dubai_datetime)
    updated_on = Column(DateTime, default=get_dubai_datetime)
    is_active = Column(TINYINT(2), default=1)

    @classmethod
    def get_by_email(cls, email):
        """
        Find gem data according to email
        :param email: customer's email
        :rtype: EntCrgLookup
        """
        return cls.query.filter(cls.email == email, cls.is_active).first()
