"""
Delivery Menu Items Model
"""
import datetime

from sqlalchemy import Column, Float, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DeliveryMenuItem(db.Model):
    __tablename__ = 'delivery_menu_items'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    IMAGE_LINK = "https://s3.amazonaws.com/entertainer-app-assets/deliverable-active.png"

    id = Column(INTEGER(11), primary_key=True)
    title_en = Column(String(255))
    title_ar = Column(String(255))
    title_cn = Column(String(255))
    title_el = Column(String(255))
    description_en = Column(String(500))
    description_ar = Column(String(500))
    description_cn = Column(String(500))
    description_el = Column(String(500))
    category_en = Column(String(255))
    category_ar = Column(String(255))
    category_cn = Column(String(255))
    category_el = Column(String(255))
    price = Column(Float)
    is_entertainer = Column(TINYINT(1))
    currency = Column(String(5))
    merchant_id = Column(INTEGER(11))
    updated_at = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_items(cls, merchant_id):
        """
        returns delivery menu items
        :param merchant_id:
        :return:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).all()
