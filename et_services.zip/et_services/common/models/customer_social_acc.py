"""
Customer Social Account Model
"""

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from common.constants import CONSOLIDATION

from ..models.db import db


class CustomerSocialAcc(db.Model):
    __tablename__ = 'customer_social_acc'
    __table_args__ = {"schema": CONSOLIDATION}

    media_id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(11))
    facebook_login = Column(String(255), nullable=False)
    instagram_login = Column(String(255), nullable=False)
    twitter_login = Column(String(255), nullable=False)
    google_login = Column(String(255), nullable=False)

    @classmethod
    def get_facebook_login_by_customer_id(cls, customer_id):
        """
        Returns Facebook login against customer id
        :param int customer_id: Customer Id
        :rtype: CustomerSocialAcc
        """
        return cls.query.with_entities(cls.facebook_login).filter(cls.customer_id == customer_id).first()
