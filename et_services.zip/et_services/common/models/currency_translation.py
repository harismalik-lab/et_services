"""
Currency Translation Model
"""
from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.currency import Currency
from ..models.db import db
from ..models.mixin import Mixin


class CurrencyTranslation(db.Model, Mixin):
    __tablename__ = 'currency_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    currency_id = Column(ForeignKey(
        Currency.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        index=True
    )
    locale = Column(String(5), default='en')
    name = Column(String(100))
    translated_currency = Column(String(100))
