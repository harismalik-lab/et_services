"""
Outlet Offers Model
"""
from sqlalchemy import TIMESTAMP, Column, ForeignKey

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.offer import Offer
from ..models.outlet import Outlet


class OutletOffer(db.Model, Mixin):
    __tablename__ = 'outlet_offer'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    outlet_id = Column(ForeignKey(
        Outlet.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        primary_key=True,
        nullable=False,
        index=True
    )
    offer_id = Column(
        ForeignKey(Offer.id, ondelete='CASCADE', onupdate='CASCADE'),
        primary_key=True,
        nullable=False,
        index=True
    )
    amz_update_time = Column(TIMESTAMP)
