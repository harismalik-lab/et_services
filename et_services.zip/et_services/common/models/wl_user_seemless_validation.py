"""
User Seemless Validation Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.mixin import Mixin


class WlUserSeemlessValidation(db.Model, Mixin):
    __tablename__ = 'wl_user_seemless_validation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    UUID_LOGIN_TYPE = 'uuid'
    ACTIVE = 1
    STATIC_PASSWORD = '03d5#61c-f667-7yht+-'

    id = Column(INTEGER(11), primary_key=True, autoincrement=True)
    company = Column(String(255), index=True)
    user_id = Column(INTEGER(11))
    uuid = Column(String(50), index=True)
    email = Column(String(255), index=True)
    status = Column(TINYINT(3), index=True)
    user_group = Column(INTEGER(11))
    filename = Column(String(100))
    created_at = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_at = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)

    @classmethod
    @with_master
    def get_active_by_uuid_and_company(cls, uuid, company):
        """
        Returns active row against uuid and company
        :param str uuid: UUID
        :param str company: Company Code
        :rtype: WlUserSeemlessValidation
        """
        return cls.query.filter(cls.uuid == uuid, cls.company == company, cls.status == cls.ACTIVE).first()
