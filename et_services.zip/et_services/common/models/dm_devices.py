"""
Dm Devices Model
"""
from sqlalchemy import Column, DateTime, String, or_
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmDevice(db.Model):
    __tablename__ = 'dm_devices'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    device_id = Column(String(500), nullable=False, index=True)
    device_name = Column(String(150))
    is_device_online = Column(TINYINT(4), default=1)
    merchant_sf_id = Column(String(20), index=True)
    outlet_sf_id = Column(String(20), index=True)
    is_active = Column(TINYINT(4), index=True, default=1)
    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    last_ping = Column(DateTime)
    device_token = Column(String(500))
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    updated_by = Column(String(100))
    device_make = Column(String(200))
    device_model = Column(String(100))
    android_version = Column(String(50))
    group_name = Column(String(200))
    app_version = Column(String(20))
    status_label = Column(String(50))
    outlet_ids = Column(String(300))

    PING_TIME = 300
    APP_DOWNLOAD_PATH = 'https://drive.google.com/uc?export=download&id=1em2H-2AGj6Z8Scwv0wfauWrhOzJwHeRO'
    LATEST_VERSION = 6
    CIRCLE_SHAPE_CONSTANT = 'circle'
    POLYGON_SHAPE_CONSTANT = 'polygon'

    @classmethod
    def find_device_by_filter(cls, filters, in_filters, multiple_devices, order_desc, order_field):
        """
        Get device from DmDevices as suggested by filters.

        :param dict filters: a key-value hash-map of column and column value to match.
        :param list in_filters: a list of key-value hash-maps of column and list of values to match.
        :param bool multiple_devices: True if you want to get all devices, else returns one.
        :param bool order_desc: True if you want to get the latest device.
        :param str order_field: Name of column to order the devices by.
        """

        query = cls.query

        if filters:
            for field, value in filters.items():
                query = query.filter(getattr(cls, field) == value)

        if in_filters:
            for in_filter in in_filters:
                for field, values_list in in_filter.items():
                    if values_list:
                        query = query.filter(getattr(cls, field).in_(values_list))

        if order_desc:
            query = query.order_by(getattr(cls, order_field).desc())
        else:
            query = query.order_by(getattr(cls, order_field))

        if multiple_devices:
            return query.all()

    @classmethod
    def get_dm_devices_against_merchant_id(cls, merchant_id, outlet_id):
        """
        get dm devices for specific merchant
        :param merchant_id:
        :param outlet_id:
        :return:
        """
        query = cls.query.filter(
            cls.merchant_id == merchant_id,
            cls.is_active == 1,
            or_(
                cls.outlet_id == outlet_id,
                cls.outlet_id.is_(None),
                cls.outlet_id == 0
            )
        )
        query = query.order_by(cls.outlet_id.desc()).order_by(cls.last_ping).order_by(cls.is_device_online.desc())
        return query.first()
