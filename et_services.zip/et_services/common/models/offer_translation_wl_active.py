"""
Offer Translation Wl Active Model
"""
from sqlalchemy import Column, Index, String, Text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class OfferTranslationWlActive(db.Model):
    __tablename__ = 'offer_translation_wl_active'
    __table_args__ = (
        Index('idx_translation', 'offer_id', 'locale'),
        {'schema': ENTERTAINER_WEB}
    )

    id = Column(INTEGER(11), primary_key=True)
    offer_id = Column(INTEGER(11), nullable=False, index=True)
    locale = Column(String(5), default='en')
    title = Column(String(255))
    name = Column(String(255))
    description = Column(Text)
    terms_and_conditions = Column(Text)
    rules_of_use = Column(Text)
    card_line = Column(String(255))
    merchant_name = Column(String(255))
    merchant_description = Column(Text)
    merchant_rules_of_use = Column(Text)
    merchant_terms_and_conditions = Column(Text)
    merchant_address = Column(String(255))
    merchant_opening_hours = Column(String(255))
    merchant_accreditation = Column(Text)
    group_name = Column(String(255))
    group_description = Column(Text)
    group_address = Column(String(255))
    merchant_category = Column(String(255))
