"""
Dm Attribute Group Translation Model
"""
import datetime

from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmAttributeGroupTranslation(db.Model):
    __tablename__ = 'dm_attribute_group_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    dm_attribute_group_id = Column(INTEGER(11), index=True)
    locale = Column(String(2), index=True)
    group_name = Column(String(200))
