"""
CHB Company Lookup Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, Date, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WL_LOOKUP
from ..models.db import db
from ..models.mixin import Mixin


class ChbLookup(db.Model, Mixin):
    __tablename__ = 'chb_lookup'
    __table_args__ = {'schema': ENTERTAINER_WL_LOOKUP}

    id = Column(INTEGER(11), primary_key=True)
    email = Column(String(255, 'utf8mb4_general_ci'), index=True)
    first_name = Column(String(100, 'utf8mb4_general_ci'))
    last_name = Column(String(100, 'utf8mb4_general_ci'))
    user_id = Column(INTEGER(11), index=True, default=0)
    nationality = Column(String(5, 'utf8mb4_general_ci'))
    gender = Column(String(5, 'utf8mb4_general_ci'))
    dob = Column(Date)
    user_group = Column(INTEGER(11), default=1)
    is_active = Column(TINYINT(1), index=True, default=1)
    created_at = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    file_name = Column(String(50, 'utf8mb4_general_ci'))

    @classmethod
    def get_one_by_email(cls, email):
        return cls.query.filter(cls.is_active, cls.email == email).first()
