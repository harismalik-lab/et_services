"""
Product Wl Active Model
"""
from sqlalchemy import Column, Float, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.offer_wl_active import OfferWlActive
from ..models.product_offer_wl_active import ProductOfferWlActive


class ProductWlActive(db.Model, Mixin):
    __tablename__ = 'product_wl_active'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(20), nullable=False, default='entertainer')
    product_id = Column(INTEGER(11), nullable=False)
    product_sku = Column(String(20), nullable=False)
    price = Column(Float, default=0)
    image = Column(String(500))
    is_active = Column(BIT(1), nullable=False)
    location_id = Column(INTEGER(11))

    @classmethod
    def get_offer_types(cls, offer_ids):
        """
        Returns offer types against offers ids
        :param list offer_ids: Offer ids
        :rtype: dict
        """
        assert isinstance(offer_ids, list), "Invalid params; got {}".format(offer_ids)
        query = cls.query.with_entities(cls.is_cheers.label('type'), OfferWlActive.id)
        query = query.join(ProductOfferWlActive, cls.id == ProductOfferWlActive.product_id)
        query = query.join(OfferWlActive, ProductOfferWlActive.offer_id == OfferWlActive.id)
        query = query.filter(OfferWlActive.id.in_(offer_ids))
        rows = query.all()
        offers_types = {}
        for row in rows:
            offers_types.update({row.id: row.type})
        return offers_types

    @classmethod
    def get_product_id_by_offer_id(cls, offer_id, default=None):
        if not default:
            default = []
        query = cls.query.with_entities(cls.id, ProductOfferWlActive.offer_id)
        query = query.join(ProductOfferWlActive, cls.id == ProductOfferWlActive.product_id)
        if isinstance(offer_id, list):
            query = query.filter(ProductOfferWlActive.offer_id.in_(offer_id))
            record = query.all()
            record = {product.offer_id: product for product in record}
        else:
            query = query.filter(ProductOfferWlActive.offer_id == offer_id)
            record = query.first()
            if record:
                return record.id

        return record if record else default

    @classmethod
    def get_cheers_product_by_product_ids(cls, product_ids=None, convert_to_string=False):
        """
        This method returns location_ids against product_ids
        :param list product_ids: Product Id
        :param boolean convert_to_string:
        :rtype: list
        """
        filtered_product_ids = []
        if not product_ids:
            product_ids = []
        product_ids = list(filter(None, product_ids))
        if product_ids:
            product_ids = list(set(map(int, filter(None, product_ids))))
            query = cls.query.with_entities(cls.id)
            query = query.filter(cls.is_cheers == 1)
            query = query.filter(cls.id.in_(product_ids))

            records = query.all()
            return [str(record.id) if convert_to_string else record.id for record in records]
        return filtered_product_ids

    @classmethod
    def get_location_ids_by_product_ids(cls, product_ids=None):
        """
        Returns product location ids against provided product ids
        :param list product_ids: Product Ids
        """
        if product_ids is None:
            product_ids = []
        return cls.query.with_entities(cls.location_id).filter(cls.id.in_(product_ids)).distinct().all()

    @classmethod
    def get_cheers_products_count_against_product_ids_and_location_id(cls, product_ids, location_id=0):
        """
        Returns count of cheers products against product ids and location id
        :param list product_ids: Product Ids
        :param int location_id: Location Id
        """
        return cls.query.with_entities(cls.id).filter(
            cls.id.in_(product_ids),
            cls.is_cheers == 1,
            cls.location_id == location_id
        ).count()
