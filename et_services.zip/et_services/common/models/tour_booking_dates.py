"""
BookingDates table of Entertainer Tours schema.
"""
from sqlalchemy import Column, Date, DateTime, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_TOURS
from ..models.db import db
from ..models.mixin import Mixin


class TourBookingDates(db.Model, Mixin):
    __table_args__ = {'schema': ENTERTAINER_TOURS}
    __tablename__ = 'booking_dates'

    id = Column(INTEGER(11), primary_key=True)
    tour_id = Column(INTEGER(11), index=True)
    booking_date = Column(Date, index=True)
    is_active = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    created_date = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime)
    created_by = Column(String(50))
    updated_by = Column(String(50))
