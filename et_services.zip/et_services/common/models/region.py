"""
Region model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class Region(db.Model, Mixin):
    __tablename__ = 'region'
    __table_args__ = {'schema': ENTERTAINER_WEB}
    id = Column(INTEGER(11), primary_key=True)
    name = Column(String(100))
