"""
Home Screen Configuration Translation model
"""
from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.mysql import INTEGER

from common import constants

from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'tamoors@theentertainerasia.com'


class HomeScreenConfigurationsTranslation(db.Model, Mixin):
    __tablename__ = 'home_screen_configurations_translation'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    config_id = Column(INTEGER(11), nullable=False, index=True)
    locale = Column(String(5), index=True, default=constants.EN)
    title = Column(String(100))
    description = Column(Text)
