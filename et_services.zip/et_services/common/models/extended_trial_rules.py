"""
Extended trial rules model
"""
from flask import g
from sqlalchemy import Column, DateTime, String, text
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

cache = g.cache


class ExtendedTrialRule(db.Model, Mixin):
    __tablename__ = 'extended_trial_rules'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    extended_trial_group_id = Column(INTEGER(11), index=True)
    location_id = Column(INTEGER(11), index=True)
    category = Column(String(200), nullable=False, index=True, server_default=text("''"))
    max_savings_estimate_cap = Column(SMALLINT(6), server_default=text("'0'"))
    enabled_cheer_offers = Column(BIT(1))
    enabled_delivery_offers = Column(BIT(1))
    enabled_monthly_offers = Column(BIT(1))
    enabled_more_offers = Column(BIT(1))
    enabled_merlin_offers = Column(BIT(1))
    enabled_cinema_offers = Column(BIT(1))
    enabled_bonus_offers = Column(BIT(1))
    enabled_johor_baru_offers = Column(BIT(1))
    created_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    is_active = Column(BIT(1))
    enabled_core_product_family_offers = Column(BIT(1))
    enabled_core_product_fine_dining_offers = Column(BIT(1))
    enabled_core_product_fitness_offers = Column(BIT(1))

    @classmethod
    @cache.memoize(timeout=3600)
    def user_trial_extended_rules(cls, extended_trail_group_ids=None, location_id=None):
        """
        Gets trail extended rules object of specific location
        :param list extended_trail_group_ids:
        :param int location_id:
        :rtype: dict
        """
        if not extended_trail_group_ids:
            extended_trail_group_ids = []
        query = cls.query.filter(cls.is_active == 1)
        if location_id:
            query = query.filter(cls.location_id == location_id)
        if extended_trail_group_ids:
            query = query.filter(cls.extended_trial_group_id.in_(extended_trail_group_ids))
        return query.all()

    @classmethod
    def extended_trial_rules(cls, extended_trail_group_ids):
        """
        Gets extended trial rules or specific ones if provided list of group ids.
        :param list extended_trail_group_ids:
        """
        query = cls.query
        if extended_trail_group_ids:
            query = query.filter(cls.extended_trial_group_id.in_(extended_trail_group_ids))

        query = query.filter(cls.is_active == 1)
        return query.all()
