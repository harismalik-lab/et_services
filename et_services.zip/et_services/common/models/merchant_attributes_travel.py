"""
Merchant Attributes Travel Model
"""
import datetime

from sqlalchemy import Column, ForeignKey, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesTravel(db.Model):
    __tablename__ = 'merchant_attributes_travel'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    x24_hour_reception = Column(TINYINT(1))
    x24_hour_room_service = Column(TINYINT(1))
    adaptor = Column(TINYINT(1))
    air_conditioning = Column(TINYINT(1))
    airport_pick_up_drop_off = Column(TINYINT(1))
    alcohol = Column(TINYINT(1))
    balcony = Column(TINYINT(1))
    beach = Column(TINYINT(1))
    beach_club = Column(TINYINT(1))
    beauty_centre = Column(TINYINT(1))
    bed_breakfast = Column(TINYINT(1))
    boutique = Column(TINYINT(1))
    butler_service = Column(TINYINT(1))
    car_park = Column(TINYINT(1))
    chauffeur_service = Column(TINYINT(1))
    city = Column(TINYINT(1))
    closest_airport_name = Column(String(255))
    club_lounge = Column(TINYINT(1))
    concierge = Column(TINYINT(1))
    couples_only = Column(TINYINT(1))
    day_spa = Column(TINYINT(1))
    family = Column(TINYINT(1))
    golf = Column(TINYINT(1))
    gym_fitness = Column(TINYINT(1))
    hair_salon = Column(TINYINT(1))
    health_programmes = Column(TINYINT(1))
    health_spa_resort = Column(TINYINT(1))
    heating = Column(TINYINT(1))
    home_safety = Column(TINYINT(1))
    housekeeping = Column(TINYINT(1))
    hotel_apartment = Column(TINYINT(1))
    inhouse_movies = Column(TINYINT(1))
    in_room_spa_bath = Column(TINYINT(1))
    kids_club = Column(TINYINT(1))
    kids_friendly = Column(TINYINT(1))
    kitchen_facilities = Column(TINYINT(1))
    laundry_service = Column(TINYINT(1))
    lodge_safari = Column(TINYINT(1))
    lodge_ski = Column(TINYINT(1))
    luggage_storage = Column(TINYINT(1))
    mini_bar = Column(TINYINT(1))
    mountain_country = Column(TINYINT(1))
    night_club = Column(TINYINT(1))
    no_of_bars = Column(INTEGER(11))
    no_of_cafes = Column(INTEGER(11))
    no_of_restaurants = Column(INTEGER(11))
    plunge_pool = Column(TINYINT(1))
    prayer_room = Column(TINYINT(1))
    proximity_to_airport_kms = Column(INTEGER(11))
    proximity_to_city_centre_kms = Column(INTEGER(11))
    resort = Column(TINYINT(1))
    safe_deposit_box = Column(TINYINT(1))
    seaside = Column(TINYINT(1))
    shopping_mall = Column(TINYINT(1))
    sightseeing = Column(TINYINT(1))
    smoking_rooms = Column(TINYINT(1))
    sound_system = Column(TINYINT(1))
    sports_club = Column(TINYINT(1))
    swimming_pool = Column(TINYINT(1))
    toiletries = Column(TINYINT(1))
    total_no_of_rooms = Column(INTEGER(11))
    tv_in_room = Column(TINYINT(1))
    valet_parking = Column(TINYINT(1))
    villas = Column(TINYINT(1))
    water_sports = Column(TINYINT(1))
    wheelchair_accessible = Column(TINYINT(1))
    wi_fi = Column(TINYINT(1))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id == merchant_id).first()
