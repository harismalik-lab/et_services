"""
Location Feature Model
"""
import datetime

from flask import g
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.exc import SQLAlchemyError

from ..constants import ENTERTAINER_WEB
from ..models.db import db

cache = g.cache


class LocationFeature(db.Model):
    __tablename__ = 'location_features'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    location_id = Column(INTEGER(11))
    is_cashless_enabled = Column(TINYINT(1), default=0)
    is_take_away_enabled = Column(TINYINT(1), default=0)
    is_table_booking_enabled = Column(TINYINT(1))
    updated_date = Column(DateTime, default=datetime.datetime.now)
    created_date = Column(DateTime, default=datetime.datetime.now)
    is_dc_prospect_enabled = Column(TINYINT(1))
    company = Column(String(20))

    @classmethod
    def get_table_booking_location_ids(cls, company):
        """
        Gets the locations for table bookings.
        :rtype: list
        """
        return cls.query.with_entities(cls.location_id).filter(
            cls.is_table_booking_enabled == 1,
            cls.company == company
        ).all()

    @classmethod
    def get_take_away_location_ids(cls, company):
        """
        Gets Takeaways location ids.
        """
        query = cls.query.with_entities(cls.location_id)
        return query.filter(cls.is_take_away_enabled == 1, cls.company == company).all()

    @classmethod
    def get_delivery_cashless_location_ids(cls, company):
        """
        Gets delivery cashless location ids.
        :rtype: list
        """
        try:
            query = cls.query.with_entities(cls.location_id)
            return query.filter(cls.is_cashless_enabled == 1, cls.company == company).all()
        except SQLAlchemyError:  # Cannot connect until Invalid transaction is rolled back error
            cls.query.session.rollback()
            query = cls.query.with_entities(cls.location_id)
            return query.filter(cls.is_cashless_enabled == 1, cls.company == company).all()

    @classmethod
    def get_dc_enabled_prospect_location_ids(cls, company):
        """
        Gets DC prospect delivery locations from location features.
        """
        query = cls.query.with_entities(cls.location_id)
        return query.filter(
            cls.is_cashless_enabled == 1,
            cls.company == company,
            cls.is_dc_prospect_enabled == 1
        ).all()
