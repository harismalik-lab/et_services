"""
Dm Outlet Setting Translation Model
"""
from sqlalchemy import TEXT, Column
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db


class DmOutletSettingTranslation(db.Model):
    __tablename__ = 'dm_outlet_setting_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    dm_outlet_setting_id = Column(INTEGER(11), index=True)
    locale = Column(VARCHAR(3), index=True, default=EN)
    allergy_information = Column(TEXT)
