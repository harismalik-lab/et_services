"""
Home Screen Configuration Section Translation model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..models.db import db
from ..models.mixin import Mixin
from common import constants


class HomeScreenConfigurationsSectionTranslation(db.Model, Mixin):
    __tablename__ = 'home_screen_configurations_section_translation'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    section_id = Column(INTEGER(11), nullable=False, index=True)
    title = Column(String(200))
    locale = Column(String(20), index=True, default=constants.EN)
    create_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    update_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
