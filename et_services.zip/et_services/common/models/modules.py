"""
Modules model of EntertainerBusiness schema.
"""
from sqlalchemy import Column, String, TIMESTAMP, text, func
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_BUSINESS
from ..models.mixin import Mixin
from ..models.db import db


class Module(db.Model, Mixin):
    __tablename__ = 'modules'
    __table_args__ = (
        {"schema": ENTERTAINER_BUSINESS}
    )

    id = Column(INTEGER(11), primary_key=True)
    code = Column(String(50), nullable=False)
    name = Column(String(100), server_default=text("''"))
    identifier = Column(String(100), unique=True)
    affiliate_id = Column(INTEGER(11), index=True, server_default=text("'1'"))
    location_id = Column(INTEGER(11), server_default=text("'1'"))
    route = Column(String(255))
    order_prefix = Column(String(50))
    company = Column(String(50), index=True, server_default=text("'entertainer'"))
    company_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'50'"))
    is_ego = Column(TINYINT(1), index=True, server_default=text("'0'"))
    update_order = Column(TINYINT(1), index=True, server_default=text("'0'"))
    is_active = Column(TINYINT(1), nullable=False, index=True, server_default=text("'1'"))
    created_at = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @classmethod
    def get_module_info(cls, **kwargs):
        """
        Get module information based on name and other filters passed in kwargs.
        :rtype: Module
        """
        select_entities = [
            cls.id,
            cls.code,
            cls.order_prefix,
            cls.name,
            cls.identifier,
            cls.company_id
        ]
        query = cls.query.with_entities(*select_entities)
        if kwargs.get('name'):
            query = query.filter(func.lower(cls.name) == kwargs['name'].lower())
        if kwargs.get('location_id'):
            query = query.filter(cls.location_id == kwargs['location_id'])
        if kwargs.get('company'):
            query = query.filter(cls.company == kwargs['company'])

        return query.first()
