"""
Dm Merchant Order Model
"""
import datetime

from sqlalchemy import Column, DateTime, Float, String, and_, literal_column, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.orm import aliased
from sqlalchemy.sql.functions import coalesce

from common.utils.api_utils import get_current_date_time

from ..constants import EN, ENT_COMPANY, ENTERTAINER_WEB
from ..models.db import db
from ..models.dm_merchant_order_addresses import DmMerchantOrderAddress
from ..models.dm_merchant_order_history import DmMerchantOrderHistory
from ..models.dm_merchant_order_status import DmMerchantOrderStatus
from ..models.dm_outlet_setting import DmOutletSetting
from ..models.dm_quiq_up_order_details import DmQuiqUpOrderDetail
from ..models.ent_customer_profile import EntCustomerProfile
from ..models.merchant import Merchant
from ..models.merchant_translation import MerchantTranslation
from ..models.mixin import Mixin
from ..models.outlet import Outlet
from ..models.outlet_translation import OutletTranslation
from ..models.quiq_up_settings import QuiqUpSetting


class DmMerchantOrder(db.Model, Mixin):
    __tablename__ = 'dm_merchant_order'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    # constants
    UNDER_PREPARATION = 'Under Preparation'
    EN_ROUTE = 'En Route'
    PENDING = 'pending'
    ACCEPTED = 'accepted'
    EDITED = 'edit-pending'
    QUEUE = 'que-pending'

    id = Column(INTEGER(11), primary_key=True)
    order_number = Column(String(255), index=True)
    merchant_sf_id = Column(String(20), index=True)
    outlet_sf_id = Column(String(20), index=True)
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    customer_id = Column(INTEGER(11), index=True)
    customer_email = Column(String(255))
    customer_ip = Column(String(30))
    server_ip = Column(String(30))
    items_count = Column(TINYINT(11))
    order_currency = Column(String(10))
    base_currency = Column(String(10))
    payment_method = Column(String(50))
    order_status_id = Column(INTEGER(11), index=True, server_default=text("'0'"))
    total_paid = Column(Float(8), server_default=text("'0.0000'"))
    base_total_paid = Column(Float(8), server_default=text("'0.0000'"))
    sub_total = Column(Float(8), server_default=text("'0.0000'"))
    base_sub_total = Column(Float(8), server_default=text("'0.0000'"))
    total_discount = Column(Float(8), server_default=text("'0.0000'"))
    base_total_discount = Column(Float(8), server_default=text("'0.0000'"))
    delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    base_delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    delivery_instructions = Column(String(500))
    delivery_time = Column(INTEGER(11), server_default=text("'0'"))
    cc_charge_id = Column(String(255))
    cc_type = Column(String(50))
    cc_last_four_digits = Column(INTEGER(11))
    placed_from = Column(String(50))
    app_version = Column(String(50))
    tracking_number = Column(String(255))
    reject_reason = Column(String(255))
    is_cancelable = Column(TINYINT(1), index=True, server_default=text("'1'"))
    is_active = Column(TINYINT(1), index=True, server_default=text("'1'"))
    is_delivered = Column(TINYINT(1), index=True, server_default=text("'0'"))
    is_zero_order = Column(TINYINT(1), server_default=text("'0'"))
    created_at = Column(DateTime, nullable=False, index=True, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    is_refunded = Column(TINYINT(11), index=True, server_default=text("'0'"))
    refund_amount = Column(Float(8), server_default=text("'0.0000'"))
    delivery_address_id = Column(INTEGER(11), server_default=text("'0'"))
    sub_status_id = Column(INTEGER(11), index=True)
    base_tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    settlement_id = Column(INTEGER(11), index=True)
    checkout_status = Column(String(50))
    product_sku = Column(String(20))
    customer_name = Column(String(250))
    te_commission_from_merchant = Column(Float(8), server_default=text("'0.0000'"))
    te_checkout_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_auth_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue_after_vat = Column(Float(8), server_default=text("'0.0000'"))
    vat_payable_on_te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    refund_to_merchant = Column(Float(8), server_default=text("'0.0000'"))
    order_process_channel = Column(String(50))
    is_processed = Column(TINYINT(1), index=True, server_default=text("'0'"))
    processed_by = Column(INTEGER(11))
    order_edit_status = Column(TINYINT(1), index=True, server_default=text("'0'"))
    cron_processing = Column(TINYINT(1), index=True, server_default=text("'0'"))
    refund_reason = Column(String(500))
    refund_by = Column(String(100))
    refund_to = Column(String(100))
    refund_payment_mode = Column(String(200))
    company = Column(String(50), nullable=False, index=True, server_default=text("'entertainer'"))
    company_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'50'"))
    capture_retry = Column(TINYINT(1), server_default=text("'0'"))
    location_id = Column(INTEGER(11), nullable=False, server_default=text("'1'"))
    card_type = Column(String(20))
    commission_delivery_vat = Column(String(50))
    quiq_up_fee = Column(Float(8))
    refund_retry = Column(TINYINT(1), server_default=text("'0'"))
    delivery_type = Column(String(15))
    band_id = Column(INTEGER(11))
    delivery_charges_to_outlet = Column(Float)
    quiqup_settled = Column(TINYINT(1), server_default=text("'0'"))
    is_take_away_order = Column(TINYINT(1))
    is_prospect_order = Column(TINYINT(1))
    customer_status = Column(INTEGER(11))

    @classmethod
    def get_order_details(cls, order_id, customer_id, company=ENT_COMPANY):
        """
        Gets order details

        :param int order_id: id of order
        :param int customer_id: id of customer
        :param str company: company
        :rtype orm obj: query set result
        """
        dmos = aliased(DmMerchantOrderStatus)
        d_m_o_s = aliased(DmMerchantOrderStatus)

        query = cls.query.join(Outlet, cls.outlet_sf_id == Outlet.sf_id)
        query = query.join(
            OutletTranslation,
            and_(
                Outlet.id == OutletTranslation.outlet_id,
                OutletTranslation.locale == EN
            )
        )
        query = query.join(DmMerchantOrderAddress, cls.delivery_address_id == DmMerchantOrderAddress.id)
        query = query.join(EntCustomerProfile, EntCustomerProfile.user_id == DmMerchantOrderAddress.customer_id)
        # added outlet_setting join to get outlet collect order value
        query = query.join(DmOutletSetting, Outlet.id == DmOutletSetting.outlet_id)
        query = query.join(dmos, cls.order_status_id == dmos.id)
        query = query.outerjoin(d_m_o_s, cls.sub_status_id == d_m_o_s.id)

        query = query.with_entities(
            cls.customer_ip,
            cls.total_discount,
            cls.order_number,
            cls.sub_total,
            cls.delivery_charges,
            cls.order_currency,
            cls.delivery_instructions,
            cls.updated_at,
            cls.sub_status_id,
            cls.is_cancelable,
            cls.is_delivered,
            cls.is_refunded,
            cls.refund_amount,
            cls.merchant_id,
            cls.is_take_away_order,
            cls.is_prospect_order,
            coalesce(cls.id).label('order_id'),
            coalesce(cls.created_at).label('order_time'),
            coalesce(cls.base_total_paid).label('order_total'),
            coalesce(cls.total_paid).label('order_total_amount'),
            DmMerchantOrderAddress.home_office_address,
            DmMerchantOrderAddress.street,
            DmMerchantOrderAddress.area_city,
            DmMerchantOrderAddress.longitude,
            DmMerchantOrderAddress.latitude,
            coalesce(DmMerchantOrderAddress.delivery_to_phone).label('phone_number'),
            coalesce(DmMerchantOrderAddress.home_office_address).label('customer_address'),
            coalesce(DmMerchantOrderAddress.delivery_to_first_name).label('firstname'),
            coalesce(DmMerchantOrderAddress.delivery_to_last_name).label('lastname'),
            coalesce(dmos.title).label('status_title'),
            coalesce(dmos.label).label('status_label'),
            coalesce(dmos.id).label('status_id'),
            coalesce(dmos.short_title).label('status_identifier'),
            coalesce(d_m_o_s.short_title).label('sub_status_identifier'),
            coalesce(EntCustomerProfile.email).label('customer_email'),
            coalesce(Outlet.telephone).label('outlet_contact_number'),
            coalesce(OutletTranslation.name).label('outlet_name'),
            coalesce(Outlet.lat).label('outlet_lat'),
            coalesce(Outlet.lng).label('outlet_lng'),
            OutletTranslation.human_location,
            OutletTranslation.hotel,
            OutletTranslation.mall,
            OutletTranslation.neighborhood,
            DmOutletSetting.collect_order_value
        )

        query = query.filter(cls.id == order_id, cls.customer_id == customer_id, cls.company == company)
        return query.first()

    @classmethod
    def get_orders_history_by_customer(cls, customer_id, company=ENT_COMPANY, outlet_id=None, process_monthly=True):
        """
        Gets all the orders of the merchant on the monthly basis
        :param int customer_id: id of customer
        :param str company: company
        :param int outlet_id: id of outlet
        :param bool process_monthly: process monthly
        :rtype: orm obj: query set result
        """
        accepted_order_status = DmMerchantOrderStatus().get_filter_status(
            filters={'short_title': cls.ACCEPTED}, single=True
        )
        query = cls.query.outerjoin(
            DmMerchantOrderHistory,
            and_(
                DmMerchantOrderHistory.order_id == cls.id,
                DmMerchantOrderHistory.order_status_id == accepted_order_status.id
            )
        )
        query = query.join(DmMerchantOrderStatus, cls.order_status_id == DmMerchantOrderStatus.id)
        query = query.join(MerchantTranslation, cls.merchant_id == MerchantTranslation.merchant_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(Outlet, cls.outlet_id == Outlet.id)
        query = query.join(DmMerchantOrderAddress, cls.delivery_address_id == DmMerchantOrderAddress.id)
        query = query.outerjoin(
            DmOutletSetting,
            and_(
                DmOutletSetting.merchant_sf_id == cls.merchant_sf_id,
                DmOutletSetting.outlet_sf_id == cls.outlet_sf_id
            )
        )
        query = query.outerjoin(
            QuiqUpSetting,
            QuiqUpSetting.id == cls.band_id
        )
        query = query.outerjoin(
            DmQuiqUpOrderDetail,
            and_(
                DmQuiqUpOrderDetail.order_id == cls.id,
                DmQuiqUpOrderDetail.is_current_status == 1
            )
        )

        query = query.with_entities(
            cls.id,
            cls.merchant_id,
            cls.outlet_id,
            cls.created_at,
            cls.delivery_time,
            cls.band_id,
            cls.delivery_type,
            cls.is_take_away_order,
            cls.sub_status_id,
            coalesce(cls.order_currency).label('currency'),
            coalesce(cls.order_status_id).label('order_status'),
            coalesce(cls.total_paid).label('total'),
            coalesce(cls.total_discount).label('savings'),
            coalesce(cls.created_at).label('date'),
            coalesce(Outlet.lat).label('outlet_lat'),
            coalesce(Outlet.lng).label('outlet_lng'),
            coalesce(DmMerchantOrderStatus.title).label('status'),
            coalesce(DmMerchantOrderStatus.short_title).label('order_status_title'),
            DmMerchantOrderAddress.latitude,
            DmMerchantOrderAddress.longitude,
            coalesce(MerchantTranslation.name).label('merchant'),
            coalesce(Merchant.logo_retina_url).label('logo'),
            DmOutletSetting.average_prep_time,
            coalesce(DmMerchantOrderHistory.created_at).label('history_created_at'),
            QuiqUpSetting.average_drop_off_time,
            DmQuiqUpOrderDetail.quiq_job_status,
            literal_column("0").label("show_reorder_button")
        )
        query = query.filter(
            cls.is_active == 1,
            cls.customer_id == customer_id,
            cls.company == company
        )
        if outlet_id:
            query = query.filter(cls.outlet_id == outlet_id)
            query = query.filter(~DmMerchantOrderStatus.short_title.in_([
                cls.EDITED, cls.PENDING, cls.QUEUE, cls.ACCEPTED, cls.UNDER_PREPARATION, cls.EN_ROUTE
            ]))

        query = query.group_by(cls.created_at).order_by(cls.id.desc())
        return query.all()

    @classmethod
    def get_pending_order_status(cls, customer_id, language=EN, company=ENT_COMPANY):
        """
        Get pending order status
        :param int customer_id: id of customer
        :param str language: language
        :param str company: company
        :rtype dict
        """
        current_time = datetime.datetime.now()
        time_24_hours_before = current_time - datetime.timedelta(hours=24)
        accepted_order_status = DmMerchantOrderStatus().get_filter_status(
            filters={'short_title': cls.ACCEPTED}, single=True
        )

        query = cls.query.join(DmMerchantOrderStatus, cls.order_status_id == DmMerchantOrderStatus.id)
        query = query.outerjoin(
            DmMerchantOrderHistory,
            and_(
                DmMerchantOrderHistory.order_id == cls.id,
                DmMerchantOrderHistory.order_status_id == accepted_order_status.id
            )
        )
        query = query.join(OutletTranslation, cls.outlet_id == OutletTranslation.outlet_id)
        query = query.join(Merchant, cls.merchant_sf_id == Merchant.sf_id)
        query = query.outerjoin(
            DmOutletSetting,
            and_(
                DmOutletSetting.merchant_sf_id == cls.merchant_sf_id,
                DmOutletSetting.outlet_sf_id == cls.outlet_sf_id
            )
        )
        query = query.outerjoin(QuiqUpSetting, QuiqUpSetting.id == cls.band_id)
        query = query.outerjoin(
            DmQuiqUpOrderDetail,
            and_(
                DmQuiqUpOrderDetail.order_id == cls.id,
                DmQuiqUpOrderDetail.is_current_status == 1
            )
        )
        query = query.with_entities(
            cls.outlet_id,
            cls.merchant_id,
            cls.created_at,
            cls.delivery_time,
            cls.delivery_type,
            cls.band_id,
            cls.is_take_away_order,
            coalesce(cls.id).label('order_id'),
            Merchant.sf_id,
            DmOutletSetting.average_prep_time,
            QuiqUpSetting.average_drop_off_time,
            DmQuiqUpOrderDetail.quiq_job_status,
            coalesce(Merchant.logo_retina_url).label('logo'),
            coalesce(OutletTranslation.name).label('outlet_name'),
            coalesce(DmMerchantOrderStatus.short_title).label('order_status_title'),
            coalesce(DmMerchantOrderStatus.title).label('order_status'),
            coalesce(DmMerchantOrderHistory.created_at).label('history_created_at')
        )
        query = query.filter(
            cls.customer_id == customer_id,
            cls.company == company,
            OutletTranslation.locale == language
        )
        query = query.filter(DmMerchantOrderStatus.short_title != cls.EDITED)
        query = query.filter(cls.created_at >= time_24_hours_before)
        return query.all()

    @classmethod
    def get_merchant_order_and_status_by_id(cls, order_id, merchant_sf_id=None, outlet_sf_id=None, customer_id=0):
        """
        Gets the merchant order and status by id
        :param int order_id: order id
        :param str merchant_sf_id: merchant sale force id
        :param str outlet_sf_id: outlet sale force id
        :param int customer_id: customer id
        :return: orm obj: query set result
        """
        query = cls.query.join(DmMerchantOrderStatus, cls.order_status_id == DmMerchantOrderStatus.id)
        query = query.with_entities(
            cls.id,
            cls.is_active,
            cls.order_number,
            cls.tracking_number,
            cls.is_cancelable,
            cls.is_delivered,
            cls.reject_reason,
            coalesce(DmMerchantOrderStatus.short_title).label('status_identifier')
        )
        if customer_id:
            query = query.filter(
                cls.is_active == 1,
                cls.id == order_id,
                cls.customer_id == customer_id
            )
        elif outlet_sf_id:
            query = query.filter(
                cls.id == order_id,
                cls.is_active == 1,
                cls.outlet_sf_id == outlet_sf_id,
                cls.merchant_sf_id == merchant_sf_id
            )
        else:
            query = query.filter(
                cls.is_active == 1,
                cls.id == order_id,
                cls.merchant_sf_id == merchant_sf_id
            )
        return query.first()

    @classmethod
    def update_merchant_order(cls, order_id, data=None):
        """
        Update merchant order
        :param int order_id: id of order
        :param dict|list data: data which needs to update
        :return orm obj: query set result
        """
        try:
            if data:
                data['updated_at'] = get_current_date_time()
                query = cls.query.filter(cls.id == order_id).update(data, synchronize_session=False)
                cls.update_record()
                return query
        except Exception:
            raise

    @classmethod
    def get_status_of_order(cls, order_id, customer_id, location_id=1):
        """
        Gets the Order status and all the details
        :param str|int order_id: id of order
        :param str|int customer_id: id of customer
        :param str|int location_id: is of location
        :rtype: tuple
        :return returns the status of order and all of the order details
        """
        dmos = aliased(DmMerchantOrderStatus)
        od_sub_st = aliased(DmMerchantOrderStatus)

        query = cls.query.join(dmos, cls.order_status_id == dmos.id)
        query = query.outerjoin(od_sub_st, od_sub_st.id == cls.sub_status_id)
        query = query.join(
            DmOutletSetting,
            and_(
                DmOutletSetting.merchant_sf_id == cls.merchant_sf_id,
                DmOutletSetting.outlet_sf_id == cls.outlet_sf_id
            )
        )
        query = query.with_entities(
            cls.delivery_type,
            cls.band_id,
            cls.location_id,
            cls.delivery_time,
            cls.created_at,
            cls.is_take_away_order,
            cls.sub_status_id,
            coalesce(dmos.short_title).label('order_status'),
            coalesce(od_sub_st.short_title).label('sub_status_identifier'),
            DmOutletSetting.average_prep_time
        )
        query = query.filter(
            cls.id == order_id,
            cls.customer_id == customer_id
        )
        return query.first()

    @classmethod
    def get_merchant_order_by_id(cls, order_id, merchant_sf_id=None, outlet_sf_id=None, customer_id=0):
        """
        Get merchant order by id
        :param int order_id: id of order
        :param str merchant_sf_id: sales force id of merchant
        :param str outlet_sf_id: sales force id of outlet
        :param int customer_id: id of customer
        :return: orm obj: query set result
        """
        if customer_id:
            query = cls.query.filter(
                cls.id == order_id,
                cls.customer_id == customer_id,
                cls.is_active == 1
            )
        elif outlet_sf_id:
            query = cls.query.filter(
                cls.id == order_id,
                cls.outlet_sf_id == outlet_sf_id,
                cls.merchant_sf_id == merchant_sf_id,
                cls.is_active == 1
            )
        else:
            query = cls.query.filter(
                cls.id == order_id,
                cls.merchant_sf_id == merchant_sf_id,
                cls.is_active == 1
            )
        return query.first().__dict__
