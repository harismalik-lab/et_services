"""
Redemption model of Entertainer GO schema.
"""

from sqlalchemy import String, Column, DateTime, text
from sqlalchemy.dialects.mysql import INTEGER, BIT, TINYINT, TIMESTAMP, SMALLINT
from ..constants import ENTERTAINER_GO
from ..models.db import db
from ..models.mixin import Mixin


class EgoRedemption(db.Model, Mixin):
    __tablename__ = 'redemption'
    __table_args__ = {"schema": ENTERTAINER_GO}

    id = Column(INTEGER(11), primary_key=True)
    code = Column(String(100))
    redemption_date = Column(DateTime)
    time_zone = Column(String(50))
    year = Column(INTEGER(11))
    location_id = Column(INTEGER(11))
    company_id = Column(SMALLINT(1), nullable=False, server_default=text("'257'"))
    company = Column(String(20), index=True, server_default=text("'ego'"))
    session_id = Column(INTEGER(11), nullable=False)
    customer_id = Column(INTEGER(11), nullable=False, index=True, comment='Customer Id')
    merchant_id = Column(INTEGER(11))
    outlet_id = Column(INTEGER(11))
    offer_id = Column(INTEGER(11), index=True)
    product_id = Column(INTEGER(11), index=True)
    purchase_id = Column(INTEGER(11), index=True)
    quantity = Column(INTEGER(11), nullable=False, server_default=text("'1'"))
    savings_estimate = Column(INTEGER(11), server_default=text("'0'"))
    transaction_id = Column(String(100))
    device_os = Column(String(20))
    device_model = Column(String(50))
    device_language = Column(String(5))
    date_created = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    date_updated = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    is_synced = Column(BIT(1))
    is_renewed = Column(BIT(1))
    is_deleted = Column(BIT(1), nullable=False)
    email_status = Column(TINYINT(1))
    email_sf_id = Column(String(30))

    @classmethod
    def get_info(cls, **kwargs):
        """
        Return redemption object based on keyword args.
        """
        query = cls.query
        redemption_id = kwargs.get('redemption_id')

        if redemption_id:
            query = query.filter(cls.id == redemption_id)

        return query.first()

