"""
Offer Model
"""
from datetime import timedelta

from flask import g
from sqlalchemy import (TIMESTAMP, Column, DateTime, Float, ForeignKey, Index,
                        String, Time, and_, func, literal_column, or_)
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import EN, ENTERTAINER_WEB, VALID_CATEGORIES
from ..models.db import db
from ..models.location import Location
from ..models.merchant import Merchant
from ..models.merchant_translation import MerchantTranslation
from ..models.mixin import Mixin
from ..models.product import Product

cache = g.cache


class Offer(db.Model, Mixin):
    # constants
    NOT_REDEEMABLE = 0
    REDEEMED = 1
    REDEEMABLE = 2
    REUSABLE = 3

    TYPE_NEW = 0
    TYPE_ACCEPTED = 1
    TYPE_REJECTED = 2
    TYPE_CANCELLED = 3

    OFFER_TYPE_MONTHLY = 2
    TYPE_DEFAULT = 0
    TYPE_TRIAL = 1
    TYPE_MEMBER = 2
    TYPE_BOTH = 3
    TYPE_NEW_OFFER = 4
    TYPE_FEATURED_OFFER = 5  # Both New and Monthly
    MONTHLY_OFFER_TYPE = "monthly"

    __tablename__ = 'offer'
    __table_args__ = (
        Index('idx_validity', 'valid_from', 'valid_to', 'status'),
        Index('idx_offer_status_type', 'status', 'type'),
        Index('idx_member_trial_promotion', 'type', 'promoted_from', 'promoted_to', 'status'),
        Index('idx_relevant', 'valid_from', 'valid_to', 'status', 'type', 'promoted_from', 'promoted_to'),
        {"schema": ENTERTAINER_WEB}
    )

    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_FROM = 4
    HOURS_ADJUSTMENT_FOR_OFFER_EXPIRY_TO = -18

    SECTION_REDEEMABLE = 1
    SECTION_REDEEMED = 2
    SECTION_PINGED = 3
    SECTION_NOT_REDEEMABLE = 4
    SORT_REDEEMABLE = 1
    SORT_PURCHASED_AVAILABLE_IN_FUTURE = 2
    SORT_REDEEMED = 3
    SORT_PINGED = 4
    SORT_NOT_REDEEMABLE = 5
    SORT_EXPIRED = 6
    OFFER_TYPE_VALUE_DEFAULT = 0
    OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE = 1
    OFFER_TYPE_VALUE_PERCENTAGE_OFF = 2
    OFFER_TYPE_VALUE_GIFT = 3
    OFFER_TYPE_VALUE_PACKAGE = 4
    OFFER_TYPE_VALUE_FIX_PRICE_OFF = 5
    OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS = 6

    OFFER_TYPE_TEXT_BUY_ONE_GET_ONE_FREE = "Buy One Get One Free"
    OFFER_TYPE_TEXT_SPEND_THIS_GET_THIS = "Spend This Get That"
    OFFER_TYPE_TEXT_PERCENTAGE_OFF = "% Off"
    OFFER_TYPE_TEXT_GIFT = "Gift"
    OFFER_TYPE_TEXT_PACKAGE = "Package"
    OFFER_TYPE_TEXT_FIX_PRICE_OFF = "Fixed Price Off"

    id = Column(INTEGER(11), primary_key=True)
    sf_id = Column(String(20), unique=True, comment='Salesforce ID')
    merchant_id = Column(ForeignKey(Merchant.id, ondelete='CASCADE', onupdate='CASCADE'), nullable=False, index=True)
    valid_from = Column(DateTime)
    valid_to = Column(DateTime)
    savings_estimate = Column(INTEGER(11), default=0, comment='Savings estimate is in AED.')
    offer_sequence = Column(TINYINT(1), default=1)
    is_alcohol_offer = Column(TINYINT(1), default=0)
    type = Column(
        SMALLINT(6),
        index=True,
        default=0,
        comment='Types:\\n\\n0 = default, normal offer (belongs to a product, purchasable in book or bundles)\\'
                'n1 = trial offer (given to trial members for free, does not need to belong to a product)\\'
                'n2 = member offer (give to full members for free, does not need to belong to a  /* comment '
                'truncated */ /*product)*/'
    )
    voucher_type = Column(SMALLINT(6))
    spend = Column(SMALLINT(6), default=0)
    reward = Column(SMALLINT(6), default=0)
    percentage_off = Column(TINYINT(1), default=0)
    no_of_people = Column(TINYINT(1), default=0)
    voucher_restrictions = Column(String(255))
    voucher_restriction1 = Column(SMALLINT(6))
    voucher_restriction2 = Column(SMALLINT(6))
    promoted_from = Column(DateTime)
    promoted_to = Column(DateTime)
    status = Column(
        String(20),
        index=True,
        default='Active',
        comment='Draft, Approved, Active, Inactive'
    )
    quota = Column(INTEGER(11), default=0)
    quantity = Column(INTEGER(11), default=1)
    has_red_custom_code = Column(BIT(1))
    redemptions_limit_in_x_hours = Column(
        SMALLINT(6),
        default=4,
        comment='This is to apply a cap on monthly offers'
    )
    hours_to_consider_for_redemption_cap = Column(
        SMALLINT(6),
        default=24,
        comment='Number of hours to restrict limit on redemption'
    )
    merchant_email = Column(String(255))
    merchant_website = Column(String(255))
    merchant_telephone = Column(String(45))
    merchant_fax = Column(String(45))
    merchant_cuisine = Column(String(255))
    merchant_category = Column(String(255), index=True)
    sub_category = Column(String(255))
    digital_section = Column(String(255))
    group_sf_id = Column(String(20))
    group_telephone = Column(String(45))
    group_website = Column(String(255))
    merchant_instagram = Column(String(255))
    inactive_reason = Column(String(255))
    local_currency = Column(String(10))
    savings_estimate_local_currency = Column(INTEGER(11), default=0)
    amz_update_time = Column(TIMESTAMP)
    min_total_fee = Column(Float, default=0)
    off_peak_rate = Column(Float, default=0)
    off_peak_aed = Column(Float, default=0)
    opportunity_currency = Column(String(10))
    participation_offers_fee = Column(Float, default=0)
    peak_rate = Column(Float, default=0)
    peak_rate_aed = Column(Float, default=0)
    sales_person = Column(String(100))
    created_date = Column(DateTime)
    opportunity_stage = Column(String(50))
    item_code = Column(String(45))
    parent_offer_sf_id = Column(String(50))
    dcp_license = Column(String(100))
    ppr_not_applicable = Column(TINYINT(4))
    opportunity_sf_id = Column(String(20))
    inclusion_fee_cancelled = Column(TINYINT(1))
    is_point_based_offer = Column(TINYINT(1), default=0)
    is_delivery_cashless_offer = Column(TINYINT(1), default=0)
    is_promo_code_offer = Column(TINYINT(1), default=0)
    is_take_away_offer = Column(TINYINT(1), default=0)
    offer_replenishment_enabled = Column(TINYINT(1), default=0)
    delivery_applicable = Column(TINYINT(1), default=0)
    takeaways_applicable = Column(TINYINT(1), default=0)
    gems_points = Column(INTEGER(11))
    loyalty_card_free_offer = Column(BIT(1))
    valid_from_time = Column(Time)
    valid_to_time = Column(Time)
    deal_valid_on_sunday = Column(BIT(1))
    deal_valid_on_monday = Column(BIT(1))
    deal_valid_on_tuesday = Column(BIT(1))
    deal_valid_on_wednesday = Column(BIT(1))
    deal_valid_on_thursday = Column(BIT(1))
    deal_valid_on_friday = Column(BIT(1))
    deal_valid_on_saturday = Column(BIT(1))
    deal_validity_all_day = Column(BIT(1))
    deal_validity_all_week = Column(BIT(1))
    redemption_method = Column(TINYINT(1))
    is_payless_offer = Column(TINYINT(1), default=0)

    @classmethod
    def find_merchant_name(cls, offer_id, locale='en'):
        query = cls.query.with_entities(cls.id, MerchantTranslation.name)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(MerchantTranslation, MerchantTranslation.merchant_id == Merchant.id)
        query = query.filter(MerchantTranslation.locale == locale, cls.id == offer_id)
        merchant_name = query.first()
        return merchant_name.name

    @classmethod
    def any_offer_monthly_or_not_pingable(cls, offer_ids):
        """
        Returns True if any offer is monthly or it's merchant doesn't allow pings
        :param list offer_ids: Offer Ids
        :rtype: bool
        """
        if offer_ids:
            query = cls.query.with_entities(cls.id)
            query = query.join(Merchant, cls.merchant_id == Merchant.id)
            query = query.filter(cls.id.in_(offer_ids))
            query = query.filter(
                or_(
                    Merchant.is_pingable != 1,
                    cls.type == cls.TYPE_MEMBER
                )
            )
            return bool(query.count())
        return False

    @classmethod
    def get_offer_quantities(cls, offer_ids):
        """
        Returns offer quantities
        :param list offer_ids: Offer Ids
        :rtype: dict
        """
        quantities = {}
        if offer_ids:
            query = cls.query.with_entities(cls.id, cls.quantity)
            offers = query.filter(cls.id.in_(offer_ids)).all()
            quantities = {}
            for offer in offers:
                quantities.update({
                    offer.id: quantities.get(offer.id, 0) + offer.quantity
                })
        return quantities

    @classmethod
    def get_offer_merchant_details(cls, offer_id, locale=EN, group_by=False):
        """
        This method returns the offer's merchant details
        """
        from ..models.offer_translation import OfferTranslation
        if not offer_id:
            return []
        query = cls.query.with_entities(
            cls.id.label('offer_id'),
            func.max(OfferTranslation.name).label('offer_name'),
            cls.valid_to.label('offer_valid_to'),
            func.max(MerchantTranslation.name).label('merchant_name'),
            Merchant.logo_retina_url.label('logoUrl'),
            Merchant.logo_non_retina_url.label('logoSmallUrl'),
            cls.merchant_category.label('category')
        )
        query = query.join(OfferTranslation, cls.id == OfferTranslation.offer_id)
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(MerchantTranslation, Merchant.id == MerchantTranslation.merchant_id)
        query = query.filter(MerchantTranslation.locale == locale, OfferTranslation.locale == locale)
        if isinstance(offer_id, list):
            query = query.filter(cls.id.in_(offer_id))
            if group_by:
                query = query.group_by(cls.id)
        else:
            query = query.filter(cls.id == offer_id)
        offers = query.all()
        return offers

    @classmethod
    def find_by_outlets_v3(cls, *args, **kwargs):
        """
        finds offers based on outlets

         1. Override the function to implement new logic of monthly offers.
         2. Get ismember flag from offers in query then implement the monthly_offer on this flag.

        :param args:
        :param kwargs:
        :return: list of offers
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet import Outlet
        from ..models.merchant import Merchant
        from ..models.ent_customer_profile import EntCustomerProfile
        from ..models.product_offer import ProductOffer
        from ..models.product import Product
        from ..models.offer_translation import OfferTranslation
        from ..models.product_translation import ProductTranslation
        from ..utils.api_utils import (
            list_to_str_tuple,
            get_delivery_enabled_location_ids_against_company,
            get_takeaways_enabled_location_ids_against_company
        )

        merchant_id = kwargs.get('merchant_id')
        outlet_ids = kwargs.get('outlet_ids')

        if not merchant_id or not outlet_ids:
            return [], [], [], [], [], 0, True, 0

        locale = kwargs.get('locale', EN)
        company = kwargs.get('company')
        is_ent = kwargs.get('is_ent')
        outlet_id = kwargs.get('outlet_id')
        offer_id = kwargs.get('offer_id')
        customer = kwargs.get('customer', {})
        customer_logged_in = customer.get('is_user_logged_in')

        only_delivery = kwargs.get('only_delivery', False)
        outlet_exclude_from_offers = kwargs.get('all_offers_active', True)

        pings_received_offer_ids = kwargs.get('pings_received_offer_ids')
        show_cheer_offers = kwargs['show_cheer_offers']
        personal_cheer_offers = kwargs.get('personal_cheer_offers', [])
        location_id = kwargs.get('location_id', 0)
        is_take_away_enabled = kwargs.get('is_take_away_enabled', False)
        is_cashless_delivery_enabled = kwargs.get('enable_delivery_cashless', False)

        query = cls.query
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, Product.id == ProductOffer.product_id)

        if not is_ent:
            from ..models.wl_product import WlProduct
            query = query.join(
                WlProduct,
                and_(
                    WlProduct.product_sku == Product.sf_id,
                    WlProduct.active == 1,
                    WlProduct.wl_company == company
                )
            )
        query = query.join(ProductTranslation, Product.id == ProductTranslation.product_id)
        query = query.join(OutletOffer, OutletOffer.offer_id == Offer.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(Merchant, Merchant.id == Outlet.merchant_id)
        query = query.join(OfferTranslation, Offer.id == OfferTranslation.offer_id)

        query = query.with_entities(
            cls.id,
            cls.merchant_category.label('category'),
            cls.sub_category,
            cls.type,
            cls.quantity,
            cls.voucher_type,
            cls.spend,
            cls.reward,
            cls.percentage_off,
            cls.no_of_people,
            cls.voucher_restrictions.label('conditions'),
            cls.voucher_restriction1,
            cls.voucher_restriction2,
            cls.valid_from.label('valid_from_date'),
            cls.valid_to.label('expiration_date'),
            coalesce(cls.dcp_license, '').label('dcp_license'),
            coalesce(cls.local_currency, '').label('local_currency'),
            coalesce(cls.savings_estimate, 0).label('savings_estimate'),
            coalesce(cls.savings_estimate_local_currency, '').label('savings_estimate_local_currency'),
            coalesce(cls.offer_sequence, 1).label('offer_sequence'),
            coalesce(cls.percentage_off, 0).label('percentage_off'),
            cls.redemptions_limit_in_x_hours,
            cls.deal_valid_on_sunday,
            cls.deal_valid_on_monday,
            cls.deal_valid_on_tuesday,
            cls.deal_valid_on_wednesday,
            cls.deal_valid_on_thursday,
            cls.deal_valid_on_friday,
            cls.deal_valid_on_saturday,
            cls.deal_validity_all_day,
            cls.deal_validity_all_week,
            cls.valid_from_time,
            cls.valid_to_time,
            cls.is_take_away_offer,
            cls.is_delivery_cashless_offer,
            OfferTranslation.name,
            OfferTranslation.description.label('details'),
            OfferTranslation.merchant_rules_of_use.label('voucher_restrictions'),
            func.group_concat(Outlet.id.distinct()).label('outlet_ids'),
            Outlet.cinema_venue_id,
            Merchant.category.label('merchant_category'),
            Merchant.is_for_members_only,
            Merchant.dc_prospect_enabled,
            Product.id.label('product_id'),
            Product.sf_id.label('product_sku'),
            ProductTranslation.name.label('product_name'),
            Product.is_purchaseable.label('is_purchaseable'),
            Product.is_cheers,
            Product.delivery_enabled.label('is_delivery'),
            Product.is_ent,
            Product.purchase_product_id,
            Product.show_buy_mobile,
            Product.is_freemium,
            Product.product_type,
            coalesce(Product.product_type == 1, 0).label('is_birthday_offer'),
            Product.cashless_delivery_enabled,
            Product.has_bonus_offers.label('is_bonus_offers'),
            Product.is_core_product,
            Product.istravel.label('is_travel'),
            Product.is_more_sa,
            Product.is_johor_bahru,
            Product.is_core_fine_dining_product,
            Product.ismember,
            Product.is_core_family_product,
            Product.is_core_fitness_product,
            coalesce(Product.sequence, 0).label('product_sequence'),
            Product.is_deals_product,
            Product.has_merlin_offers.label('is_merlin_offer'),
            Product.has_cinema_offers,
            literal_column("''").label('merlin_title')
        )

        query = query.filter(
            Product.isactive == 1,
            OfferTranslation.locale == locale,
            ProductTranslation.locale == locale
        )

        if only_delivery:
            outlet_exclude_from_offers = False

        if customer.get('membership_sub_group') == EntCustomerProfile.INACTIVE_MEMBERSHIP_SUB_GROUP:
            query = query.filter(Product.is_taster_product != 1)

        if merchant_id:
            query = query.filter(Merchant.id == merchant_id)

        if outlet_ids and not outlet_exclude_from_offers and not only_delivery:
            query = query.filter(Outlet.id.in_(outlet_ids))

        if not kwargs.get('is_merlin_offers_to_show'):
            query = query.filter(Product.has_merlin_offers != 1)

        if offer_id:
            query = query.filter(Offer.id == offer_id)

        else:
            if not only_delivery:
                if customer_logged_in:
                    product_ids = customer.get('product_ids')
                    if (
                        is_cashless_delivery_enabled and
                        outlet_id and
                        location_id in get_delivery_enabled_location_ids_against_company(company)
                    ):
                        query = query.filter(
                            or_(
                                and_(
                                    Product.is_ent == 1,
                                    Product.is_dummy_product != 1,
                                    Product.show_offers_if_purchased != 1,
                                    Product.is_freemium != 1
                                ),
                                Product.id.in_(product_ids),
                                cls.id.in_(pings_received_offer_ids),
                                Product.cashless_delivery_enabled == 1
                            )
                        )
                    else:
                        query = query.filter(
                            or_(
                                and_(
                                    Product.is_ent == 1,
                                    Product.is_dummy_product != 1,
                                    Product.show_offers_if_purchased != 1,
                                    Product.is_freemium != 1
                                ),
                                Product.id.in_(product_ids),
                                cls.id.in_(pings_received_offer_ids)
                            )
                        )
                else:
                    query = query.filter(
                        Product.is_ent == 1,
                        Product.is_dummy_product != 1,
                        Product.show_offers_if_purchased != 1,
                        Product.is_cheers != 1,
                        Product.is_freemium != 1
                    )

        if kwargs.get('selected_category') in VALID_CATEGORIES:
            query = query.filter(Offer.merchant_category == kwargs.get('selected_category'))

        if not show_cheer_offers:
            if personal_cheer_offers:
                query = query.filter(
                    or_(
                        Product.is_cheers != 1,
                        and_(
                            Product.is_cheers == 1,
                            Offer.id.in_(list_to_str_tuple(personal_cheer_offers))
                        )
                    )
                )
            else:
                query = query.filter(Product.is_cheers != 1)

        if location_id in get_delivery_enabled_location_ids_against_company(kwargs.get('company')):
            if only_delivery and customer_logged_in and not is_take_away_enabled:
                query = query.filter(Product.cashless_delivery_enabled == 1)
                query = query.filter(cls.is_delivery_cashless_offer == 1)

        if location_id in get_takeaways_enabled_location_ids_against_company(kwargs.get('company')):
            if only_delivery and customer_logged_in and is_take_away_enabled:
                query = query.filter(Product.cashless_delivery_enabled == 1)
                query = query.filter(cls.is_take_away_offer == is_take_away_enabled)

        query = query.group_by(cls.id)
        return query.all()

    @classmethod
    @cache.memoize(3600)
    def get_cuisines_by_locale(cls, locale=EN):
        """
        Returns cuisines for merchant attributes
        :param str locale: locale
        """
        # mt = aliased(MerchantTranslation, name='mt')
        return db.session.bind.execute(
            "SELECT DISTINCT mt.cuisine FROM {entertainer_web}.offer_wl_active as o "
            "INNER JOIN {entertainer_web}.product_offer_wl_active AS po ON o.id=po.id "
            "INNER JOIN {entertainer_web}.product AS p ON po.product_id=p.id "
            "INNER JOIN {entertainer_web}.wlproducts AS wl ON  wl.product_sku=p.sf_id "
            "INNER JOIN {entertainer_web}.merchant AS m ON o.merchant_id=m.id "
            "INNER JOIN {entertainer_web}.merchant_translation AS mt ON m.id=mt.merchant_id AND mt.locale=%s "
            "WHERE mt.cuisine IS NOT NULL AND mt.cuisine != '' ORDER BY mt.cuisine ASC".format(
                entertainer_web=ENTERTAINER_WEB),
            (locale,)
        )

    @staticmethod
    @cache.memoize(timeout=900)
    def get_offer_array(location_id, company, category, locale='en', api_version='v613'):
        """
        Returns offers and outlets in a location for a category.
        :param int location_id: Location Id
        :param str company: company name
        :param str category: Merchant category
        :param str locale: Locale
        :return list: list of Offer objects.
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.product_offer import ProductOffer
        from ..models.offer_translation import OfferTranslation
        from ..models.outlet import Outlet

        query = Offer.query.join(OfferTranslation, Offer.id == OfferTranslation.offer_id)
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(OutletOffer, OutletOffer.offer_id == Offer.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(Merchant, Offer.merchant_id == Merchant.id)
        query = query.with_entities(
            Offer.id,
            Offer.merchant_category,
            coalesce(Offer.sub_category, '').label('sub_category'),
            Offer.valid_from.label('valid_from_date'),
            Offer.valid_to.label('expiration_date'),
            Offer.type,
            Offer.quantity,
            Product.id.label('product_id'),
            Product.sf_id.label('product_sku'),
            OfferTranslation.name.label('offer_name'),
            Offer.savings_estimate,
            Product.is_cheers,
            Product.delivery_enabled.label('is_delivery'),
            Product.is_ent.label('is_entertainer'),
            Product.is_dummy_product,
            Product.show_offers_if_purchased,
            Product.is_freemium,
            Product.is_more_sa,
            Product.product_type,
            func.group_concat(Outlet.id.distinct()).label('outlet_ids'),
            Product.purchase_product_id,
            Merchant.is_for_members_only,
            Product.is_core_product.label('is_core_product'),
            Product.istravel.label('is_travel'),
            Product.has_merlin_offers.label('is_merlin_offer'),
            Product.has_cinema_offers,
            Product.is_johor_bahru,
            Product.has_bonus_offers.label('is_bonus_offers'),
            Product.is_core_fine_dining_product,
            Product.is_core_family_product,
            Product.is_core_fitness_product,
            Product.ismember,
            Offer.is_delivery_cashless_offer,
            Offer.is_take_away_offer,
            Product.company.label('company'),
            literal_column("'0'").label("is_shared"),
            literal_column("'0'").label("top_up_offer"),
            literal_column("0").label("is_redeemable"),
            literal_column("'not_redeemable'").label("redeemability"),
            literal_column("'0'").label("times_redeemed"),
            literal_column("'0'").label("is_purchased"),
            Product.cashless_delivery_enabled
        )
        query = query.filter(
            Product.isactive == 1,
            OfferTranslation.locale == locale,
            Offer.merchant_category == category,
            Product.company.like("{}%".format(company))
        )

        if location_id in Location.MORE_SA_LOCATIONS:
            query = query.filter(or_(Product.location_id == location_id, Product.is_more_sa == 1))
        else:
            if location_id == Location.LOCATION_ID_SINGAPORE:
                query = query.filter(
                    or_(Product.location_id == location_id, Product.is_johor_bahru == 1))
            else:
                query = query.filter(Product.location_id == location_id)
                query = query.filter(coalesce(Product.is_johor_bahru, 0) == 0)
        query = query.group_by(Offer.id)
        query = query.order_by(Offer.type.desc())
        offers = query.all()
        return offers

    @staticmethod
    @cache.memoize(timeout=3600)
    def get_featured_merchants_cached(locale, category, location_id, api_version='v65'):
        from ..models.outlet_offer import OutletOffer
        from ..models.merchant_translation import MerchantTranslation
        from ..models.featured_merchant import FeaturedMerchant
        from ..models.outlet import Outlet

        category = Merchant.FEATURED_MERCHANT_CATEGORIES.get(category.lower(), category.lower())
        query = Offer.query.join(OutletOffer, Offer.id == OutletOffer.offer_id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(Merchant, Merchant.id == Offer.merchant_id)
        query = query.join(MerchantTranslation, MerchantTranslation.merchant_id == Merchant.id)
        query = query.join(FeaturedMerchant, FeaturedMerchant.merchant_id == Merchant.id)
        query = query.with_entities(
            Merchant.id.distinct(), MerchantTranslation.name, MerchantTranslation.description,
            MerchantTranslation.category, MerchantTranslation.digital_section,
            coalesce(MerchantTranslation.cuisine).label('cuisine'),
            coalesce(Merchant.ad_travel_country.label('ad_travel_country')),
            Merchant.is_featured, Merchant.ad_active_status, Merchant.logo_retina_url.label('logo_url'),
            Merchant.logo_non_retina_url.label('logo_small_url'),
            coalesce(FeaturedMerchant.featured_category).label('featuredCategory'),
            func.SUM(Outlet.id.distinct().label('outlets_count')),
            func.group_concat(Outlet.id).label('outlet_ids'),
            literal_column("''").label("featured_image"),
            literal_column("'FEATURED'").label("featured_title"),
            literal_column('""').label("outlets_info")
        )
        query = query.filter(FeaturedMerchant.valid_from < func.current_timestamp())
        query = query.filter((FeaturedMerchant.valid_to + timedelta(days=1)) > func.current_timestamp())
        query = query.filter(
            Outlet.active == 1,
            FeaturedMerchant.is_active == 1,
            FeaturedMerchant.is_featured_for_home_screen == 0,
            FeaturedMerchant.featured_category == category,
            Outlet.location_id == location_id,
            MerchantTranslation.locale == locale
        )
        query = query.group_by(
            Merchant.id, MerchantTranslation.name, MerchantTranslation.description,
            Merchant.digital_section, MerchantTranslation.cuisine,
            Merchant.ad_travel_country, Merchant.is_featured, Merchant.ad_active_status,
            Merchant.logo_retina_url, Merchant.logo_non_retina_url, Merchant.photo_retina_url,
            Merchant.photo_non_retina_url
        )
        query = query.order_by(FeaturedMerchant.position.asc())
        return query.all()

    @classmethod
    def find_saving_estimates_by_offer_id(cls, offer_id):
        query = cls.query.with_entities(
            cls.savings_estimate
        )
        return query.filter(cls.id == offer_id).first()

    @classmethod
    def find_by_id(cls, offer_id):
        """
        find offers by offer_id
        :param int offer_id: offer Id
        :return: offer
        """
        query = cls.query.with_entities(
            cls.id,
            cls.redemptions_limit_in_x_hours,
            cls.hours_to_consider_for_redemption_cap,
            cls.type,
            cls.merchant_id,
            cls.sf_id,
            cls.savings_estimate,
            cls.valid_from,
            cls.valid_to,
            cls.quantity,
            cls.has_red_custom_code,
            cls.is_promo_code_offer
        ).filter(
            cls.id == offer_id,
            cls.status == 'Active'
        )
        return query.first()

    @classmethod
    def get_by_offer_and_product_id(cls, offer_id, product_id, company, is_ent):
        """
        Returns offer against offer and product ids

        :param int offer_id: Offer Id
        :param int product_id: Product Id
        :param str company: company
        :param bool is_ent: check for entertainer
        :rtype: Offer
        """
        from ..models.product import Product
        from ..models.product_offer import ProductOffer
        from ..models.wl_product import WlProduct

        select_entities = [
            cls.id,
            cls.valid_from,
            cls.valid_to,
            cls.type,
            cls.quantity,
            ProductOffer.product_id,
            Product.cashless_delivery_enabled,
            Product.is_deals_product,
            cls.merchant_id,
            cls.hours_to_consider_for_redemption_cap,
            cls.redemptions_limit_in_x_hours,
            cls.savings_estimate_local_currency,
            cls.is_delivery_cashless_offer,
            cls.sf_id,
            cls.has_red_custom_code,
            cls.is_promo_code_offer,
            cls.deal_validity_all_week,
            cls.deal_validity_all_day,
            cls.deal_valid_on_saturday,
            cls.deal_valid_on_friday,
            cls.deal_valid_on_thursday,
            cls.deal_valid_on_wednesday,
            cls.deal_valid_on_tuesday,
            cls.deal_valid_on_monday,
            cls.deal_valid_on_sunday,
            cls.valid_to_time,
            cls.valid_from_time
        ]
        query = cls.query.join(
            ProductOffer, cls.id == ProductOffer.offer_id
        )
        query = query.join(
            Product, ProductOffer.product_id == Product.id
        )
        if not is_ent:
            query = query.join(
                WlProduct,
                and_(
                    WlProduct.product_sku == Product.sf_id,
                    WlProduct.active == 1,
                    WlProduct.wl_company == company
                )
            )
        query = query.filter(cls.id == offer_id, Product.id == product_id)
        query = query.with_entities(*select_entities)
        return query.first()

    @classmethod
    def get_by_offer_ids_and_product_ids(cls, offer_ids, product_ids, company, is_ent):
        """
        Returns offer against offer and product ids.
        :rtype: list
        """
        from ..models.product import Product
        from ..models.product_offer import ProductOffer
        from ..models.wl_product import WlProduct

        select_entities = [
            cls.id,
            cls.valid_from,
            cls.valid_to,
            cls.type,
            cls.quantity,
            ProductOffer.product_id.label('product_id')
        ]
        query = cls.query.join(
            ProductOffer, cls.id == ProductOffer.offer_id
        )
        query = query.join(
            Product, ProductOffer.product_id == Product.id
        )
        if not is_ent:
            query = query.join(
                WlProduct,
                and_(
                    WlProduct.product_sku == Product.sf_id,
                    WlProduct.active == 1,
                    WlProduct.wl_company == company
                )
            )
        query = query.filter(
            cls.id.in_(offer_ids), Product.id.in_(product_ids)
        )
        query = query.with_entities(*select_entities)
        return query.all()

    @classmethod
    def get_country_areas(cls, location_id, locale, search_keyword, category, company):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that
        are assigned for the supplied Location.

        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        :param str company: name of company.
        :rtype: dict
        """
        from ..models.country import Country
        from ..models.country_translation import CountryTranslation
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product import Product
        from ..models.product_offer import ProductOffer

        query = cls.query
        query = query.join(ProductOffer, ProductOffer.offer_id == cls.id)
        query = query.join(
            Product,
            and_(
                Product.id == ProductOffer.product_id,
                Product.company == company,
            )
        )
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(
            cls.status == 'Active',
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
        )

        if category:
            query = query.filter(Merchant.category == category)

        # Determine bundled Product if we have supplied a location.
        # Bundled Products are usually Travel books/bundle given for free with a regular Product.
        # Remember: Travel Products will have NULL for location_id.
        if location_id:
            query = query.filter(
                Outlet.location_id == location_id,
                Product.location_id == location_id
            )
        if search_keyword:
            query = query.filter(OutletTranslation.neighborhood.like('%{}%'.format(search_keyword)))

        query = query.order_by(func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name))

        query = query.with_entities(
            func.concat(OutletTranslation.neighborhood, ', ', CountryTranslation.name).distinct().label('item'),
            OutletTranslation.neighborhood,
            CountryTranslation.name
        )

        records = query.all()
        items = []

        for record in records:
            if record.neighborhood:
                if record.item.startswith(', ') or record.item.endswith(', '):
                    record.item = record.item.replace(', ', '')

                if record.neighborhood in record.name:
                    record.item = record.neighborhood
                items.append({'name': record.item, 'value': record.neighborhood})

        return items

    @classmethod
    def get_attribute_values_malls(cls, attribute, location_id, locale, search_keyword, category, company):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.

        :param str attribute: column name of OutletTranslation to look up keyword in.
        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        :param str company: name of company.
        :rtype: list
        """
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product import Product
        from ..models.product_offer import ProductOffer

        query = cls.query

        query = query.join(ProductOffer, ProductOffer.offer_id == cls.id)
        query = query.join(
            Product,
            and_(
                Product.id == ProductOffer.product_id,
                Product.company == company,
            )
        )
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(OutletTranslation.locale == locale)
        if category:
            query = query.filter(Merchant.category == category)

        if location_id:
            query = query.filter(Outlet.location_id == location_id)
            bundled_product_skus = Product.find_bundled_product_skus_by_location(company, location_id)
            if bundled_product_skus and bundled_product_skus.bundled_product_sku:
                bundled_product_skus = bundled_product_skus.bundled_product_sku.split(',')
            bundled_product_skus = list(filter(None, set(bundled_product_skus)))
            if bundled_product_skus:
                query = query.filter(
                    or_(
                        Product.location_id == location_id,
                        Product.sf_id.in_(bundled_product_skus)
                    )
                )
            else:
                query = query.filter(Product.location_id == location_id)

        if search_keyword:
            query = query.filter(getattr(OutletTranslation, attribute).like('%{}%'.format(search_keyword)))

        query = query.filter(cls.status == 'Active')
        query = query.order_by(getattr(OutletTranslation, attribute))
        query = query.with_entities(
            getattr(OutletTranslation, attribute).label('item')
        )
        records = query.distinct().all()
        items = [record.item for record in records if record.item]
        return items

    @classmethod
    def get_country_hotels(cls, location_id, locale, search_keyword, category, company):
        """
        Grab Outlet attribute values for Outlets associated with Active Offers for the Products that are assigned
        for the supplied Location.

        :param int location_id: id of location to get products for.
        :param str locale: locale set in db for outlet.
        :param str search_keyword: keyword used to search in db.
        :param str category: valid category to look up products for.
        :param str company: name of company.
        :rtype: dict
        """
        from ..models.country import Country
        from ..models.merchant import Merchant
        from ..models.outlet import Outlet
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product import Product
        from ..models.product_offer import ProductOffer
        from ..models.country_translation import CountryTranslation

        query = cls.query
        query = query.join(ProductOffer, ProductOffer.offer_id == cls.id)
        query = query.join(Product, and_(Product.id == ProductOffer.product_id, Product.company == company))
        query = query.join(OutletOffer, OutletOffer.offer_id == cls.id)
        query = query.join(Outlet, Outlet.id == OutletOffer.outlet_id)
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == OutletOffer.outlet_id)
        query = query.join(Country, Country.shortname == Outlet.billing_country)
        query = query.join(CountryTranslation, CountryTranslation.country_id == Country.id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.filter(
            cls.status == 'Active',
            OutletTranslation.locale == locale,
            CountryTranslation.locale == locale,
        )

        if category:
            query = query.filter(Merchant.category == category)

        if str(location_id).isdigit() and int(location_id):
            query.filter(
                Outlet.location_id == location_id
            )
            bundled_product_skus = Product.find_bundled_product_skus_by_location(company, location_id)
            if bundled_product_skus and bundled_product_skus.bundled_product_sku:
                bundled_product_skus = bundled_product_skus.bundled_product_sku.split(',')
            bundled_product_skus = list(filter(None, set(bundled_product_skus)))
            if bundled_product_skus:
                query = query.filter(
                    or_(
                        Product.location_id == location_id,
                        Product.sf_id.in_(bundled_product_skus)
                    )
                )
            else:
                query = query.filter(Product.location_id == location_id)

        if search_keyword:
            query = query.filter(OutletTranslation.hotel.like('%{}%'.format(search_keyword)))

        query = query.order_by(func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name))

        query = query.with_entities(
            func.concat(OutletTranslation.hotel, ', ', CountryTranslation.name).label('item'),
            OutletTranslation.hotel,
            CountryTranslation.name
        )

        records = query.distinct().all()
        items = []

        for record in records:
            if record.hotel:
                if record.item.startswith(', ') or record.item.endswith(', '):
                    record.item = record.item.replace(', ', '')

                if record.name in record.hotel:
                    record.item = record.hotel
                items.append({'name': record.item, 'value': record.hotel})
        return items

    @classmethod
    def get_max_saving_estimate(cls, offer_id):
        """
        This method returns the max saving estimate on offers.

        :param int offer_id: id of the offer.
        """

        query = cls.query.with_entities(cls.savings_estimate).filter(cls.id.in_(offer_id))
        query = query.order_by(cls.savings_estimate.desc())
        return query.all()[0].savings_estimate
