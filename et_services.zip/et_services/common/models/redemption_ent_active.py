"""
Redemption Ent Active Model
"""
from sqlalchemy import Column
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class RedemptionEntActive(db.Model, Mixin):
    __tablename__ = 'redemption_ent_active'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    redemption_id = Column(INTEGER(10), nullable=False)
    offer_id = Column(INTEGER(10), nullable=False)
    customer_id = Column(INTEGER(10), nullable=False, index=True)
    primary_user_id = Column(INTEGER(11))
    is_shared = Column(TINYINT(1), default=0)
    is_onboarding = Column(TINYINT(1), default=0)

