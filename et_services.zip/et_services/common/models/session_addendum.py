"""
Session Addendum Model Class
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, Float, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class SessionAddendum(db.Model, Mixin):
    __tablename__ = 'session_addendum'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    session_id = Column(INTEGER(11))
    user_id = Column(INTEGER(11))
    is_eula_agreed = Column(BIT(1), default=1)
    is_gdpr_agreed = Column(BIT(1), default=1)
    device_key = Column(String(30))
    device_os = Column(String(20))
    device_model = Column(String(20))
    device_language = Column(String(5))
    lat = Column(Float(10))
    lng = Column(Float(10))
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    consent_version = Column(String(15), default='v14.5.18')
    company = Column(String(50))
