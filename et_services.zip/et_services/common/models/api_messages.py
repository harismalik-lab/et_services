"""
API Messages Model
"""
import datetime

from flask import g
from sqlalchemy import VARCHAR, Column, DateTime, String, and_, case, or_
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import EN, ENTERTAINER_WEB, QUICKUP_SERVICE_DELAY_MESSAGE
from ..models.company_messages import CompanyMessages
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'
cache = g.cache


class APIMessages(db.Model, Mixin):
    __tablename__ = 'api_messages'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    message_key = Column(String(250), nullable=False, index=True)
    message_value = Column(VARCHAR(1000), nullable=False)
    locale = Column(String(20), index=True, default=EN)
    is_active = Column(BIT(1), index=True)
    created_at = Column(DateTime, default=datetime.datetime.now)

    @classmethod
    def get_messages(cls, locale=EN, company=''):
        query = cls.query.join(
            CompanyMessages,
            and_(
                and_(
                    CompanyMessages.message_key == cls.message_key,
                    CompanyMessages.locale == locale
                ),
                and_(
                    cls.locale == locale,
                    CompanyMessages.is_active
                )
            ),
            isouter=True
        ).with_entities(
            cls.message_key,
            case(
                [
                    (
                        CompanyMessages.message_value.isnot(None),
                        CompanyMessages.message_value
                    )
                ],
                else_=cls.message_value
            ).label('message_value')
            # CompanyMessages.message_value, cls.message_value
        ).filter(
            and_(
                and_(
                    cls.is_active,
                    cls.locale == locale
                ),
                or_(
                    CompanyMessages.company.is_(None),
                    CompanyMessages.company == company
                )
            )
        )
        result = query.all()
        return result

    @classmethod
    def get_api_message(cls, locale):
        """
        Gets message from api_message
        :param locale:
        :return:
        """
        query = cls.query.with_entities(cls.message_key, cls.message_value)
        query = query.filter(cls.locale == locale)
        query = query.filter(cls.message_key.like('%offer_tag%'))
        return query.all()

    @classmethod
    def get_offer_labels(cls, locale='en'):
        """
        Gets offer label
        :param locale: language
        :rtype: dict
        """
        offer_labels = cls.get_api_message(locale)
        offer_label_dict = dict()
        for offer_label in offer_labels:
            offer_label_obj = offer_label._asdict()
            offer_label_dict[offer_label_obj['message_key']] = offer_label_obj['message_value']
        return offer_label_dict

    @classmethod
    def get_api_message_for_quiqup_delay_service(cls, locale='en'):
        """
        Gets message from api_message
        :param locale: Contains language
        :return: single obj
        """
        query = cls.query.with_entities(cls.message_value)
        query = query.filter(cls.locale == locale, cls.message_key == QUICKUP_SERVICE_DELAY_MESSAGE)
        return query.one().message_value

