"""
Dm merchant order address model
"""
from sqlalchemy import Column, DateTime, Float, String, Text, text
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class DmMerchantOrderAddress(db.Model, Mixin):
    __tablename__ = 'dm_merchant_order_addresses'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(11))
    title = Column(String(100))
    customer_email = Column(String(255))
    delivery_to_first_name = Column(String(255))
    delivery_to_last_name = Column(String(255))
    delivery_to_phone = Column(String(20))
    delivery_to_street = Column(String(255))
    delivery_to_premises = Column(String(255))
    delivery_to_organisation = Column(String(100))
    delivery_to_city = Column(String(100))
    delivery_to_state = Column(String(100))
    delivery_to_country = Column(String(100))
    delivery_to_zip = Column(String(20))
    delivery_to_full_address = Column(String(50))
    delivery_instructions = Column(String(500))
    is_default = Column(TINYINT(1), server_default=text("'1'"))
    is_deleted = Column(TINYINT(1), server_default=text("'0'"))
    created_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    home_office_address = Column(Text, nullable=False)
    street = Column(String(100))
    area_city = Column(String(100))
    special_instructions = Column(String(500))
    latitude = Column(Float(10))
    longitude = Column(Float(10))
    date_created = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
