"""
Product Ent Active Model
"""
from sqlalchemy import TEXT, Column, DateTime, Float, String, func
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.offer_ent_active import OfferEntActive
from ..models.product import Product
from ..models.product_offer_ent_active import ProductOfferEntActive


class ProductEntActive(db.Model, Mixin):
    __tablename__ = 'product_ent_active'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    PRODUCT_TYPE_BIRTHDAY = 1

    id = Column(INTEGER(11), primary_key=True)
    sf_id = Column(String(20), unique=True)
    magento_product_id = Column(String(10))
    location_id = Column(INTEGER(11), index=True)
    type = Column(String(40))
    root_code = Column(String(40))
    edition = Column(String(40))
    valid_to = Column(DateTime, comment="Needed for CMS. Sync'd from Magento. Product expiration Date.")
    price = Column(Float)
    prices = Column(String(512), comment='Serialized PHP array of product prices in various currencies.')
    default_name = Column(String(255))
    default_description = Column(TEXT)
    also_text = Column(String(512))
    categories = Column(String(512), comment='Serialized array of products categories')
    featured = Column(String(40), index=True, default='Web')
    bundled_product_sku = Column(String(500))
    isactive = Column(TINYINT(1), default=0)
    istravel = Column(TINYINT(1), default=0)
    isnew = Column(TINYINT(1), default=0)
    ismember = Column(TINYINT(1), default=0)
    istest = Column(TINYINT(1), default=0)
    isconnect = Column(TINYINT(1), default=0)
    is_ent = Column(TINYINT(1), default=0)
    is_slice = Column(TINYINT(1), default=0)
    sequence = Column(INTEGER(11), default=0)
    gift_id = Column(INTEGER(11))
    image = Column(String(500))
    show_buy_mobile = Column(TINYINT(1), default=0)
    show_buy_web = Column(TINYINT(1), default=0)
    company = Column(String(45), default='entertainer')
    price_lsp = Column(Float)
    price_rrp = Column(Float)
    currency = Column(String(5))
    is_cheers = Column(TINYINT(1), default=0)
    is_purchaseable = Column(TINYINT(1), default=0)
    color_code = Column(String(100))
    title_color = Column(String(100))
    is_dummy_product = Column(TINYINT(1), default=0)
    tile_image = Column(String(500))
    delivery_enabled = Column(TINYINT(1), default=0)
    pmprice = Column(Float)
    pmstartdate = Column(DateTime)
    pmenddate = Column(DateTime)
    purchase_product_id = Column(INTEGER(11), nullable=False, default=0)
    product_type = Column(TINYINT(1), comment='1 = Birthday Sku')
    is_more_sa = Column(TINYINT(1), default=0)
    is_johor_bahru = Column(TINYINT(1))
    show_offers_if_purchased = Column(TINYINT(1), default=0)
    is_freemium = Column(TINYINT(1), default=0)
    has_merlin_offers = Column(BIT(1))
    cashless_delivery_enabled = Column(TINYINT(1))
    has_ego_free_offers = Column(TINYINT(1), default=0)
    has_cinema_offers = Column(BIT(1))
    has_bonus_offers = Column(BIT(1))
    is_core_product = Column(BIT(1))
    is_core_fine_dining_product = Column(BIT(1))
    is_core_family_product = Column(BIT(1))
    is_core_fitness_product = Column(BIT(1))
    is_taster_product = Column(BIT(1))

    @classmethod
    def get_offer_types(cls, offer_ids):
        """
        Returns offer types against offers ids
        :param str _type: Column name
        :param list offer_ids: Offer ids
        :rtype: dict
        """
        assert isinstance(offer_ids, list), "Invalid params; got {}".format(offer_ids)
        query = cls.query.with_entities(cls.is_cheers.label('type'), OfferEntActive.id)
        query = query.join(ProductOfferEntActive, cls.id == ProductOfferEntActive.product_id)
        query = query.join(OfferEntActive, ProductOfferEntActive.offer_id == OfferEntActive.id)
        query = query.filter(OfferEntActive.id.in_(offer_ids))
        rows = query.all()
        offers_types = {}
        for row in rows:
            offers_types.update({row.id: row.type})
        return offers_types

    @classmethod
    def get_product_id_by_offer_id(cls, offer_id, default=[]):
        query = cls.query.with_entities(cls.id, ProductOfferEntActive.offer_id)
        query = query.join(ProductOfferEntActive, cls.id == ProductOfferEntActive.product_id)
        if isinstance(offer_id, list):
            query = query.filter(ProductOfferEntActive.offer_id.in_(offer_id))
            record = query.all()
            record = {product.offer_id: product for product in record}
        else:
            query = query.filter(ProductOfferEntActive.offer_id == offer_id)
            record = query.first()
            if record:
                return record.id

        return record if record else default

    @classmethod
    def get_cheers_product_by_product_ids(cls, product_ids=None, convert_to_string=False):
        """
        This method returns location_ids against product_ids
        :param list product_ids: Product Id
        :rtype: list
        """
        filtered_product_ids = []
        if not product_ids:
            product_ids = []
        product_ids = list(filter(None, product_ids))
        if product_ids:
            product_ids = list(set(map(int, filter(None, product_ids))))
            query = cls.query.with_entities(cls.id)
            query = query.filter(cls.is_cheers == 1)
            query = query.filter(cls.id.in_(product_ids))

            records = query.all()
            return [str(record.id) if convert_to_string else record.id for record in records]
        return filtered_product_ids

    @classmethod
    def get_birthday_products_with_id(cls, location_id):
        """
        get birthday products ids with col `id`
        :param location_id:
        :return orm obj(product_ids):
        """
        query = cls.query.filter(cls.product_type == cls.PRODUCT_TYPE_BIRTHDAY)
        if location_id:
            query = query.filter(cls.location_id == location_id)
        return query.with_entities(cls.id).all()

    @classmethod
    def get_birthday_products_with_sf_id(cls, location_id):
        """
        get birthday products ids with col `sf_id`
        :param location_id:
        :return orm obj(product_ids):
        """
        query = cls.query.filter(cls.product_type == cls.PRODUCT_TYPE_BIRTHDAY)
        if location_id:
            query = query.filter(cls.location_id == location_id)
        return query.with_entities(cls.sf_id).all()

    @classmethod
    def get_bundled_products_against_skus(cls, skus):
        """
        Returns product details against provided SKUs.
        :param list skus: SKUs for which we need to find product details for.
        """
        return cls.query.with_entities(
            cls.bundled_product_sku,
            cls.sf_id
        ).filter(
            cls.sf_id.in_(skus)
        ).group_by(
            cls.sf_id,
            cls.bundled_product_sku
        ).all()

    @classmethod
    def find_bundled_product_skus_by_location(cls, location_id=None):
        """
        Gets a comma separated list of SKUs based on location id and company.

        :param int location_id: id of location.
        """
        query = cls.query.with_entities(
            func.group_concat(cls.bundled_product_sku).label('bundled_product_sku')
        )
        if location_id is not None:
            query = query.filter(cls.location_id == location_id)
        return query.one()

    @classmethod
    def get_location_ids_by_product_ids(cls, product_ids=None):
        """
        Returns location ids against provided Product ids.
        :param list product_ids: ids of products.
        """
        if product_ids is None:
            product_ids = []
        return cls.query.with_entities(cls.location_id).filter(cls.id.in_(product_ids)).distinct().all()

    @classmethod
    def get_cheers_products_count_against_product_ids_and_location_id(cls, product_ids, location_id=0):
        """
        Gets count of cheers products against product ids and location id.
        :param list product_ids: ids of products to look for cheer products in.
        :param int location_id: location id for which we need to find cheer products.
        """
        return cls.query.with_entities(cls.id).filter(
            cls.id.in_(product_ids),
            cls.is_cheers == 1,
            cls.location_id == location_id
        ).count()

    @classmethod
    def get_birthday_products(cls, location_id, column_to_get=None, convert_to_string=False):
        """
        Gets birthday products in a location.

        :param int location_id: location id for which we need to find birthday products.
        :param str column_to_get: column name of Product to return.
        :param bool convert_to_string: type casts column value to string if True, else keeps DB type.
        """

        if not column_to_get:
            column_to_get = 'sf_id'

        query = cls.query.with_entities(column_to_get).filter(
            cls.product_type == Product.PRODUCT_TYPE_BIRTHDAY
        )

        if location_id:
            query = query.filter(cls.location_id == location_id)

        records = query.all()
        return [str(record[column_to_get]) if convert_to_string else record[column_to_get] for record in records]

    @classmethod
    def is_customer_own_cheers_for_location_by_product_ids(cls, purchased_ids, location_id=0):
        """
        Returns True if cheer product found against provided product id and location id else False.
        :param list purchased_ids: Purchased product Ids
        :param int location_id: Location Id
        :rtype bool:
        """
        if purchased_ids:
            query = cls.query.with_entities(cls.id)
            query = query.filter(cls.is_cheers == 1, cls.location_id == location_id)
            query = query.filter(cls.id.in_(purchased_ids))
            result = query.first()
            return bool(result)
        return False

    @classmethod
    def get_birthday_product_ids(cls, location_id):
        """
        Gets the ids of currently available birthday products
        :param int location_id: id for the location where birthday products are to be searched
        :rtype: list
        """
        query = cls.query.with_entities(cls.id)
        query = query.filter(cls.product_type == Product.PRODUCT_TYPE_BIRTHDAY, cls.isactive == 1)
        if location_id:
            query = query.filter(cls.location_id == location_id)
        return [product.get('id') for product in query.all()]

    @classmethod
    def get_root_code_by_offer(cls, offer_id):
        query = cls.query.join(
            ProductOfferEntActive, cls.id == ProductOfferEntActive.product_id
        ).filter(
            ProductOfferEntActive.offer_id == offer_id
        ).with_entities(
            ProductOfferEntActive.root_code
        )
        return query.first()
