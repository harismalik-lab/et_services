"""
Family Model
"""
import datetime

from common.models.mixin import Mixin
from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db, with_master
from ..models.ent_customer_profile import EntCustomerProfile
from ..models.family_member import FamilyMember


class Family(db.Model, Mixin):
    __tablename__ = 'family'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    # Constants
    ACTIVE = 1
    INACTIVE = 0
    ON_GRACE_PERIOD = 2
    EXPIRED = 3
    BUTTON_TITLE = "REMOVE FROM FAMILY"
    BUTTON_COLOR = "ff0000"

    BUTTON_RESEND_TITLE = "RESEND INVITATION"
    BUTTON_RESEND_COLOR = "ff0000"
    LEAVED_SUCCESSFULLY = 'Family leaved Successfully.'
    GRACE_PERIOD_EXPIRED_DAYS_LIMIT = 20

    NO_FAMILY_PRIMARY_FOUND = 'It looks like you haven’t created a family yet.'
    FAMILY_REACTIVATED = 'Family Reactivated.'
    NOT_ALLOWED_FAMILY_REACTIVATED = 'Not allowed to reactivate family.'

    # Columns
    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(20), nullable=False)
    identifier = Column(String(50), nullable=False, unique=True)
    user_id = Column(INTEGER(11), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    is_active = Column(BIT(1), nullable=False)
    status = Column(TINYINT(1), nullable=False, default=1)
    reason = Column(String(100))
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now)

    def to_dict(self):
        """
        convert Family obj into dict.
        :return: dict
        """
        return {
            'id': self.id,
            'company': self.company,
            'identifier': self.identifier,
            'user_id': self.user_id,
            'name': self.name,
            'is_active': self.is_active,
            'status': self.status,
            'reason': self.reason,
            'date_created': self.date_created,
            'date_updated': self.date_updated
        }

    @classmethod
    def get_by_id(cls, family_id):
        return cls.query.filter(cls.id == family_id).first()

    @classmethod
    def get_active_by_id(cls, family_id):
        """
        Returns Active family by id
        :param int family_id: Family Id
        :rtype: Family
        """
        return cls.query.filter(cls.id == family_id, cls.is_active == 1).first()

    @classmethod
    def get_by_user_id(cls, user_id):
        return cls.query.filter(cls.user_id == user_id).first()

    @classmethod
    def get_active_by_user_id(cls, user_id):
        return cls.query.filter(cls.user_id == user_id, cls.is_active == 1).first()

    @classmethod
    @with_master
    def update_family(cls, filters=None, data=None):
        """
        Updates the family information
        """
        if filters and data:
            _query = cls.query
            if filters:
                for key, value in filters.items():
                    _query = _query.filter(getattr(cls, key) == value)

            _query.update(data, synchronize_session=False)
            cls.update_record()
            return True
        return False

    @classmethod
    def check_family_expired_and_grace_period(cls, session_data=None):
        """
        Checks Family expired or on grace period
        """
        session_data['family_expired'] = session_data['family_info'].status == cls.EXPIRED
        family_member_details = FamilyMember.find_family_member(
            filters={'user_id': session_data.get('customer_id'), 'status': FamilyMember.ACCEPTED, 'is_active': 1}
        )
        if (
            session_data['primary_member_membership_status'] == EntCustomerProfile.MEMBERSTATUS_MEMBER and
            (session_data['on_grace_period'] or session_data['family_expired']) and family_member_details and
            family_member_details.family_id
        ):
            cls.update_family(
                filters={
                    'id': family_member_details.family_id,
                    'status': Family.ON_GRACE_PERIOD,
                    'is_active': 1
                },
                data={'status': cls.ACTIVE}
            )
            cls.update_family(
                filters={
                    'id': family_member_details.family_id,
                    'status': cls.EXPIRED,
                    'is_active': 0
                },
                data={'is_active': 1, 'status': cls.ACTIVE}
            )
            if family_member_details.family_id:
                FamilyMember.update_member(
                    filters={
                        'family_id': family_member_details.family_id,
                        'is_primary': 1,
                        'user_id': session_data['primary_member_info'].get('user_id')
                    },
                    data={'is_active': 1}
                )
            if session_data['on_grace_period'] and family_member_details.family_id:
                family_members = FamilyMember.find_family_invitations_pending_accepted(
                    family_id=family_member_details.family_id,
                    include_active_status=False,
                    include_primary=False
                )
                if family_members:
                    family_members_email_not_registered = []
                    family_members_user_ids = []
                    filtered_users_id = []
                    filtered_families_emails_id = []
                    family_members_hash = dict()
                    for family_member in family_members:
                        if family_member.user_id:
                            family_members_hash[family_member.user_id] = family_member.id
                            family_members_user_ids.append(family_member.user_id)
                        else:
                            family_members_hash[family_member.email] = family_member.id
                            family_members_email_not_registered.append(family_member.email)
                    family_members_families = FamilyMember.find_family_members_part_of_any_family(
                        user_ids=family_members_user_ids,
                        email_list=family_members_email_not_registered,
                        family_id=family_member_details.family_id
                    )
                    for family_member in family_members_families:
                        if family_member.user_id:
                            filtered_users_id.append(family_member.user_id)
                        else:
                            filtered_families_emails_id.append(family_member.email)

                    family_members_user_ids = list(
                        set(family_members_user_ids) - set(filtered_users_id)
                    )
                    family_members_email_not_registered = list(
                        set(family_members_email_not_registered) - set(filtered_families_emails_id)
                    )
                    customer_profiles = EntCustomerProfile.load_customer_profile_and_user_info_by_id(
                        customer_ids=family_members_user_ids
                    )
                    family_members_user_ids = []
                    for customer_profile in customer_profiles:
                        if customer_profile.user_id == session_data.get('customer_id'):
                            family_members_user_ids.append(customer_profile.get('user_id'))
                        elif customer_profile.new_member_group != EntCustomerProfile.MEMBERSTATUS_MEMBER:
                            family_members_user_ids.append(customer_profile.user_id)
                    family_members_user_ids = list(set(family_members_user_ids))
                    family_members_ids = []
                    for family_members_user_id in family_members_user_ids:
                        family_members_ids.append(family_members_hash[family_members_user_id])
                    for family_member_email_not_registered in family_members_email_not_registered:
                        family_members_ids.append(family_members_hash[family_member_email_not_registered])

                    FamilyMember.update_member(
                        data={'is_active': 1},
                        filters={'is_active': 0, 'family_id': family_member_details.family_id},
                        in_filters=[{'id': family_members_ids}]
                    )

    @classmethod
    def find_family(cls, filters=None, in_filters=None, single=True):
        """
        This methods retrieves the ads for a specific company provided
        :return: list of ads
        """
        query = cls.query
        if filters:
            for key, value in filters.items():
                query = query.filter(getattr(cls, key) == value)

        for in_filter in in_filters:
            for field, values_list in in_filter.items():
                if values_list:
                    query = query.filter(getattr(cls, field).in_(values_list))
        if single:
            return query.first()
        else:
            return query.all()
