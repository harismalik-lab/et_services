"""
Featured merchants model
"""
from sqlalchemy import TIMESTAMP, Column, DateTime, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class FeaturedMerchant(db.Model, Mixin):
    __tablename__ = 'featured_merchant'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    product_name = Column(String(255))
    is_featured_for_home_screen = Column(TINYINT(1), index=True, server_default=text("'0'"))
    sf_id = Column(String(45))
    merchant_id = Column(INTEGER(11))
    featured_category = Column(String(45), index=True)
    position = Column(TINYINT(1))
    valid_from = Column(DateTime)
    valid_to = Column(DateTime)
    is_active = Column(TINYINT(1))
    create_time = Column(TIMESTAMP)
    amz_update_time = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
