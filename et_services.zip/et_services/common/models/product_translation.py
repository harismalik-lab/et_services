"""
Product translation Model
"""
from sqlalchemy import TIMESTAMP, Column, ForeignKey, String
from sqlalchemy.dialects.mysql import INTEGER, TEXT

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin
from ..models.product import Product


class ProductTranslation(db.Model, Mixin):
    __tablename__ = 'product_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    product_id = Column(ForeignKey(Product.id, ondelete='CASCADE', onupdate='CASCADE'), nullable=False, index=True)
    locale = Column(String(5), default=EN)
    name = Column(String(255))
    details = Column(TEXT)
    description = Column(TEXT)
    also_text = Column(String(512))
    categories = Column(String(512))
    amz_update_time = Column(TIMESTAMP)
    product_summary = Column(String(500))
    offer_summary = Column(String(100))
    category_summary = Column(String(255))
    savings_summary = Column(String(100))
    travel_summary = Column(String(100))

    # product = relationship('Product')
