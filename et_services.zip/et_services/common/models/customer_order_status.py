"""
CustomerOrderStatus model of EntertainerBusiness schema.
"""
from sqlalchemy import Column, String, TIMESTAMP, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_BUSINESS
from ..models.mixin import Mixin
from ..models.db import db


class CustomerOrderStatus(db.Model, Mixin):
    __tablename__ = 'customer_order_status'
    __table_args__ = (
        {"schema": ENTERTAINER_BUSINESS}
    )

    id = Column(INTEGER(11), primary_key=True)
    title = Column(String(255))
    label = Column(String(255))
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    is_sub_status = Column(TINYINT(1), server_default=text("'0'"))
    is_editable = Column(TINYINT(1), server_default=text("'0'"))
    parent_status_id = Column(INTEGER(11))
    module_id = Column(INTEGER(11))
    company = Column(String(100))

    PENDING = 'pending'
    COMPLETED = 'completed'

    @classmethod
    def get_status(cls, **kwargs):
        """
        Get customer order status based on filters present in keyword args.
        """
        query = cls.query

        if kwargs.get('module_id'):
            query = query.filter(cls.module_id == kwargs['module_id'])

        if kwargs.get('title'):
            query = query.filter(cls.title == kwargs['title'])

        if kwargs.get('get_one'):
            return query.first()

        return query.all()
