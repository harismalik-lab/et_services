"""
Dxb Ent Lookup Model
"""
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import BIGINT, INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db
from ..models.mixin import Mixin
from ..utils import get_dubai_datetime


class DxbEntLookup(db.Model, Mixin):
    __tablename__ = 'dxb_ent_lookup'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(BIGINT(20), primary_key=True)
    emp_code = Column(String(100), index=True)
    dob = Column(DateTime, index=True)
    user_id = Column(INTEGER(11), index=True)
    email = Column(String(150), index=True)
    first_name = Column(String(100))
    last_name = Column(String(100))
    action = Column(String(20), index=True)
    tier = Column(INTEGER(5), index=True, default=1)
    created_at = Column(DateTime, default=get_dubai_datetime)
    updated_at = Column(DateTime, default=get_dubai_datetime)
    is_active = Column(TINYINT(2), default=1)

    @classmethod
    def get_by_user_id(cls, user_id):
        """
        Returns record against user_id
        :param int user_id: User id
        :rtype: WlDxbEntRepository
        """
        return cls.query.filter(cls.user_id == user_id, cls.is_active).first()
