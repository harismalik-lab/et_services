"""
User Info Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class UserInfo(db.Model):
    __tablename__ = 'user_info'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    customer_id = Column(INTEGER(10), nullable=False, unique=True)
    is_exempt_from_yearly_quota = Column(BIT(1))
    ping_offer_limit = Column(INTEGER(10), default=10)
    amz_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_customer_ping_quota(cls, customer_id):
        """
        Returns customer's ping quota
        :param int customer_id: Customer Id
        :rtype: dict
        """
        user_info = {}
        if customer_id:
            query = cls.query
            user_info = query.filter(cls.customer_id == customer_id).first()
        return user_info

    @classmethod
    def get_ping_offer_limit(cls, customer_id):
        """
        :param customer_id:
        :return:
        """
        query = cls.query.with_entities(cls.ping_offer_limit)
        query = query.filter(cls.customer_id == customer_id)
        ping_offer_limit_for_customer = 0
        try:
            customer_ping_offer_limit = query.first()
            if customer_ping_offer_limit and int(customer_ping_offer_limit.ping_offer_limit) >= 0:
                ping_offer_limit_for_customer = int(customer_ping_offer_limit.ping_offer_limit)
        except:
            pass
        return ping_offer_limit_for_customer
