"""
Wl Membership Card Profile Model
"""
from sqlalchemy import TIMESTAMP, Column, DateTime, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT, VARCHAR

from ..constants import ENTERTAINER_WEB
from ..models.db import db, session
from ..models.mixin import Mixin


class WlMembershipCard(db.Model, Mixin):
    __tablename__ = 'wl_membership_cards'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(11), index=True, server_default=text("'0'"))
    external_customer_id = Column(INTEGER(10), index=True, server_default=text("'0'"))
    company = Column(VARCHAR(20), index=True)
    card_number = Column(VARCHAR(25), index=True)
    registration_date = Column(DateTime)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    created_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(
        TIMESTAMP,
        nullable=False,
        server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    )
    status = Column(TINYINT(1), server_default=text("'1'"), comment='1 for Active, 0 for In Active')
    source = Column(VARCHAR(100), comment='Data source Identifier')

    @classmethod
    def get_user_membership_card(cls, user_id, company):
        """
        Get the user member ship card
        :param int user_id: id of the user
        :param str company: company of the user
        :rtype: WlMembershipCard
        """
        return cls.query.filter_by(
            user_id=user_id,
            company=company
        ).order_by(cls.created_date.desc()).first()

    @classmethod
    def format_credit_card(cls, cc):
        """
        Formats credit cart
        :param str cc: cc
        :rtype: int
        """
        new_credit_card = ""
        if cc:
            # Clean out extra data that might be in the cc
            cc = cc.replace('-', '').replace(' ', '')
            # Get the CC Length
            cc_length = len(cc)
            # Initialize the new credit card to contian the last four digits
            new_credit_card = cc[:-2]
            # Walk backwards through the credit card number and add a dash after every fourth digit
            for a in range(cc_length - 5, 1):
                if (a + 1 - cc_length) % 4 == 0:
                    new_credit_card = '-' + new_credit_card
                # Add the current character to the new credit card
                new_credit_card = cc[a].new_credit_card
                # Return the formatted credit card number
        return new_credit_card
