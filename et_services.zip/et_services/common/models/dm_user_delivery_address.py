"""
Dm User Delivery Address Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, Float, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmUserDeliveryAddres(db.Model):
    __tablename__ = 'dm_user_delivery_address'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(String(20), nullable=False, index=True)
    tag_id = Column(TINYINT(1), nullable=False)
    title = Column(String(50), nullable=False)
    home_office_address = Column(String(100), nullable=False)
    street = Column(String(100), nullable=False)
    area_city = Column(String(100), nullable=False)
    special_instructions = Column(String(500))
    latitude = Column(Float(10))
    longitude = Column(Float(10))
    is_active = Column(BIT(1), nullable=False)
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now())
    company = Column(String(50), index=True, default='entertainer')

    @classmethod
    def get_customer_delivery_addresses(cls, customer_id):
        """
        Returns customer delivery addresses list
        :param int customer_id: Customer Id
        :rtype: list
        """
        if customer_id:
            return cls.query.filter(cls.user_id == customer_id).all()
        return []
