"""
Wl Tabs Model
"""
from sqlalchemy import Column, String, Text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class WlTab(db.Model, Mixin):
    __tablename__ = 'wl_tabs'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    wl_company = Column(String(20))
    type_id = Column(TINYINT(2))
    type = Column(String(20), default='all_offers')
    locale = Column(String(5))
    name = Column(String(50))
    order = Column(TINYINT(1), default=1)
    params = Column(String(100))
    is_sku_specific = Column(TINYINT(1), default=0)
    sku_list = Column(Text)
    locations = Column(Text)
    categories = Column(Text)
    icon_url = Column(Text)
    user_groups = Column(Text)

    @classmethod
    def get_tab_names(cls, company, locale):
        return cls.query.filter(cls.wl_company == company, cls.locale == locale).order_by(cls.order).all()

    @classmethod
    def get_by_id_and_company(cls, tab_id, company):
        if tab_id and company:
            return cls.query.filter(cls.id == tab_id, cls.wl_company == company).first()
