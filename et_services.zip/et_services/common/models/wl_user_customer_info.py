"""
WL User Custom Info Model
"""

from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db
from ..models.mixin import Mixin
from ..utils import get_dubai_datetime


class WlUserCustomInfo(db.Model, Mixin):
    __tablename__ = 'wl_user_custom_info'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(INTEGER(10), primary_key=True)
    company = Column(String(10), nullable=False)
    user_id = Column(INTEGER(10), nullable=False)
    password_hash = Column(String(255), nullable=False)
    status = Column(TINYINT(3), default=1)
    create_time = Column(TIMESTAMP, default=get_dubai_datetime)
    update_time = Column(TIMESTAMP, nullable=False, default=get_dubai_datetime)

    @classmethod
    def get_by_company_and_user_id(cls, company, user_id):
        """
        Returns WlUserCustomInfo object against company and user_id
        :param str company: Company
        :param int user_id: User Id
        :rtype: WlUserCustomInfo
        """
        return cls.query.filter(cls.company == company, cls.user_id == user_id).first()
