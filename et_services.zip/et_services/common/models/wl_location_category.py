"""
Wl Location Category Model
"""
from sqlalchemy import Column, String, func
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class WlLocationCategory(db.Model, Mixin):
    __tablename__ = 'wl_location_category'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    SINGAPORE = 11

    id = Column(INTEGER(11), primary_key=True)
    wl_company = Column(String(10), nullable=False)
    location_id = Column(INTEGER(11), nullable=False)
    category_id = Column(
        TINYINT(1),
        nullable=False,
        comment='0-body, 1-food, 2-leisure, 3-services, 4-travel, 5-sa, 7-kids'
    )
    title = Column(String(50), nullable=False)
    color_code = Column(String(20), nullable=False)
    order_id = Column(TINYINT(1), default=100)
    is_active = Column(BIT(1), nullable=False)
    user_group = Column(TINYINT(1), default=1)
    image = Column(String(500))
    api_name = Column(String(50))

    @classmethod
    def get_location_categories(cls, company, location_id, user_groups):
        """
        Gets location categories
        :param str company: company
        :param str locale: locale
        :param int location_id: id of location
        :param list user_group: user groups
        :rtype: list
        """
        query = cls.query.filter(
            cls.wl_company == company,
            cls.location_id == location_id,
            cls.is_active == 1
        )
        query = query.filter(cls.user_group.in_(user_groups))
        query = query.order_by(cls.order_id.asc())
        query = query.with_entities(
            func.upper(cls.title).label('display_name'),
            cls.image,
            cls.color_code,
            cls.api_name,
            cls.category_id
        )
        return query.distinct().all()
