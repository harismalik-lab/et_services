"""
Wl Gem Points Source Model
"""
from sqlalchemy import TIMESTAMP, Column, DateTime, String, func
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import CONSOLIDATION
from ..models.db import db, with_master
from ..models.mixin import Mixin


class WlGemsPointsSource(db.Model, Mixin):
    __tablename__ = 'wl_gems_points_source'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(11), nullable=False, index=True)
    gems_persistent_id = Column(String(255), index=True)
    email = Column(String(255))
    source_id = Column(INTEGER(11), index=True)
    source_transaction_id = Column(INTEGER(11))
    promo_code = Column(String(150))
    created_date = Column(TIMESTAMP, nullable=False)
    gems_points = Column(INTEGER(11))
    gems_points_burned = Column(INTEGER(11), default=0)
    number_of_times_points_burned = Column(SMALLINT(6))
    last_burn_transaction_id = Column(INTEGER(11))
    last_point_burn_date = Column(TIMESTAMP)
    savings = Column(INTEGER(11))
    transaction_id = Column(INTEGER(11))
    redemption_id = Column(INTEGER(11))
    points_added = Column(TINYINT(1), default=0)
    transaction_date = Column(DateTime)
    savings_added = Column(TINYINT(1), default=0)
    status = Column(TINYINT(1), default=1, comment='0 for inactive, 1 for active, 2 for expired etc')

    @classmethod
    @with_master
    def update_user_id(cls, email, user_id):
        """
        Updates user_id against email
        :param int user_id: User id to be updated with
        :param str email: Email
        """
        cls.query.filter(cls.email == email).update({'user_id': user_id})
        cls.update_record()
        return True

    @classmethod
    def get_user_points_stats(cls, user_id):
        """
        Calculates the stats for user points
        :param int user_id: user id
        :rtype: str database objects containing points_available, points burned and points earned by user
        """
        return cls.query.with_entities(
            func.SUM(coalesce(cls.gems_points, 0).label('points_earned')),
            func.SUM(coalesce(cls.gems_points_burned, 0).label('points_burned'))
        ).filter(cls.status, cls.user_id == user_id).group_by(cls.user_id).first()
