"""
Quiq Up Setting Model
"""
import datetime

from flask import g
from sqlalchemy import Column, Float, String
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYTEXT

from ..constants import ENTERTAINER_WEB
from ..models.db import db

cache = g.cache


class QuiqUpSetting(db.Model):
    __tablename__ = 'quiq_up_settings'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    band_name = Column(String(11))
    location_id = Column(INTEGER(11), index=True)
    default_currency = Column(TINYTEXT)
    local_currency = Column(TINYTEXT)
    start_range = Column(INTEGER(11))
    end_range = Column(INTEGER(11))
    average_drop_off_time = Column(INTEGER(11), default=0)
    delivery_charges = Column(Float, default=0)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)

    @classmethod
    @cache.memoize(timeout=1800)
    def get_avg_drop_off_time(cls, band_id=None, location_id=0):
        """
        Gets the average drop off time for the specific band based on location
        :param int band_id: id of band
        :param str location_id: id of location
        :rtype: dict
        :return orm obj
        """
        drop_off_details = {}
        if band_id:
            query = cls.query.with_entities(cls.id, cls.start_range, cls.end_range, cls.average_drop_off_time)
            query = query.filter(
                cls.id == band_id,
                cls.location_id == location_id
            )
            drop_off_details = query.first()
        return drop_off_details

    @classmethod
    def get_band_range_info(cls, location_id):
        """
        Returns list of band information based on location id
        :param int location_id: location id
        :return return the list of band information based on location id
        :rtype: list
        """
        return cls.query.with_entities(cls.id, cls.start_range, cls.end_range, cls.average_drop_off_time).filter(
            cls.location_id == location_id
        ).all()
