"""
Wl Template Model
"""
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class Wltemplate(db.Model):
    __tablename__ = 'wltemplates'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    # Constants
    ACTIVATION_OF_TRAIL = 1
    FORGOT_PASSWORD = 2
    REGISTER_INSTRUCTIONS = 3
    HOTEL_BOOKING = 4
    FRESH_START_FORGOT_PASSWORD = 545

    # Columns
    id = db.Column(INTEGER(11), primary_key=True)
    type_id = db.Column(INTEGER(11))
    wl_company = db.Column(VARCHAR(20))
    template_id = db.Column(INTEGER(11))
    user_group = db.Column(INTEGER(11), default=1)

    @classmethod
    def get_template_by_company_and_type(cls, wl_company, type_id, user_group=1):
        """
        Gets template by company and it's type
        :param str wl_company: whitelabel company
        :param int type_id: type id
        :param int user_group: user group
        :rtype: Wltemplate
        """
        query = cls.query.filter(cls.wl_company == wl_company, cls.type_id == type_id)
        if isinstance(user_group, list):
            query = query.filter(cls.user_group.in_(user_group))
        else:
            query = query.filter(cls.user_group == user_group)
        return query.first()

    @classmethod
    def get_template_by_id_and_company(cls, template_id, wl_company):
        """
        Returns template against company and template id
        :param int template_id: Template Id
        :param str wl_company: Company Code
        :rtype: Wltemplate
        """
        return cls.query.filter(cls.template_id == template_id, cls.wl_company == wl_company).first()
