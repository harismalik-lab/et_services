"""
Merchant Model
"""

import datetime

from sqlalchemy import (
    INT, TIMESTAMP, Column, DateTime, Float, ForeignKey, Index, String, Text, and_, case, func, literal_column
)
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from common.models.featured_merchant import FeaturedMerchant

from ..constants import EN, ENTERTAINER_WEB, TRAVEL
from ..models.db import db
from ..models.mixin import Mixin
from ..models.organization import Organization


class Merchant(db.Model, Mixin):
    __tablename__ = 'merchant'
    __table_args__ = (
        Index('idx_merchant_category_cuisine', 'category', 'cuisine'),
        {"schema": ENTERTAINER_WEB}
    )

    FEATURED_MERCHANT_CATEGORIES = {
        'leisure': 'Attractions & Leisure',
        'body': 'Beauty & Fitness',
        'restaurants and bars': 'Food & Drink',
        'retail': 'Retail',
        'services': 'Services'
    }

    id = Column(INTEGER(11), primary_key=True)
    group_id = Column(ForeignKey(Organization.id, ondelete='SET NULL', onupdate='CASCADE'), index=True)
    sf_id = Column(String(20), unique=True, comment=' Salesforce ID. XXXXXXX')
    settlement_level = Column(String(20), comment='super_group, group, merchant, outlet')
    delivery_commission_percantage = Column(Float(10))
    commission_delivery_vat = Column(String(50))
    pin = Column(String(4))
    logo_retina_url = Column(String(255))
    logo_non_retina_url = Column(String(255))
    logo_offer_retina_url = Column(String(255))
    logo_offer_non_retina_url = Column(String(255))
    photo_retina_url = Column(String(255))
    photo_non_retina_url = Column(String(255))
    is_opted_in_for_360_image = Column(TINYINT(1), default=1)
    p3_360_degree_image = Column(String(255))
    p3_hero_image_retina = Column(String(255))
    p3_hero_image_non_retina = Column(String(255))
    category = Column(String(255), index=True)
    categories = Column(String(255))
    book_section = Column(String(255))
    digital_section = Column(String(255))
    email = Column(String(255))
    password = Column(String(50))
    website = Column(String(255))
    facebook = Column(String(255))
    twitter = Column(String(255))
    bbm = Column(String(255))
    telephone = Column(String(45))
    fax = Column(String(45))
    major_cards = Column(TINYINT(1), default=0)
    kids_welcome = Column(TINYINT(1), default=0)
    dress_code = Column(String(45), default='')
    parking = Column(TINYINT(1), default=0)
    valet_parking = Column(TINYINT(1), default=0)
    takeaway = Column(TINYINT(1), default=0)
    pork_products = Column(TINYINT(1), default=0)
    buffet = Column(TINYINT(1), default=0)
    brunch = Column(TINYINT(1), default=0)
    pets_allowed = Column(TINYINT(1), default=0)
    wifi = Column(TINYINT(1), default=0)
    outdoor_heating = Column(TINYINT(1), default=0)
    outdoor_seating = Column(TINYINT(1), default=0)
    outdoor_cooling = Column(TINYINT(1), default=0)
    smoking_indoor = Column(TINYINT(1), default=0)
    smoking_outdoor = Column(TINYINT(1), default=0)
    smoking_shisha = Column(TINYINT(1), default=0)
    alcohol = Column(TINYINT(1), default=0)
    live_entertainment = Column(TINYINT(1), default=0)
    sports_screens = Column(TINYINT(1), default=0)
    wheelchair_accessible = Column(TINYINT(1), default=0)
    cuisine_group = Column(String(50))
    cuisine = Column(String(100), index=True)
    cuisines = Column(String(255))
    pdf_url = Column(String(255))
    hero_retina_urls = Column(Text)
    hero_non_retina_urls = Column(Text)
    merchant_instagram = Column(String(225))
    inactive_reason = Column(String(225))
    fine_dining = Column(String(225))
    closest_air_port_name = Column(String(225))
    booking_request = Column(BIT(1))
    booking_link = Column(String(255))
    is_tutorial = Column(TINYINT(1), default=0)
    merchant_profile_panorama_image_desktop = Column(String(255))
    merchant_profile_panorama_image_mobile = Column(String(255))
    billing_country = Column(String(10))
    is_featured = Column(TINYINT(1), default=0)
    ad_sf_id = Column(String(50))
    ad_from_date = Column(DateTime)
    ad_to_date = Column(DateTime)
    ad_travel_country = Column(String(100))
    ad_active_status = Column(TINYINT(1), default=0)
    amz_update_time = Column(TIMESTAMP)
    peak_days = Column(String(100))
    position = Column(TINYINT(1), default=1)
    is_pingable = Column(TINYINT(1), default=1)
    schedule_type = Column(String(25))
    is_for_members_only = Column(TINYINT(1), default=0)
    gross_bill_percentage = Column(TINYINT(1), default=0)
    gross_sales = Column(Float)
    cogs = Column(Float)
    total_saving = Column(Float)
    customers_per_redemption = Column(Float)
    invoice_entity = Column(String(50))
    invoice_entity_name = Column(String(100))
    sf_account_id = Column(String(50))
    is_family_241 = Column(TINYINT(1), default=0)
    is_couple_friendly_241 = Column(TINYINT(1), default=0)
    is_booking_required_241 = Column(TINYINT(1), default=0)
    merchant_profile_241_hero = Column(String(255))
    merchant_profile_241_hero_half = Column(String(255))
    delivery_contact_no = Column(String(100))
    is_featured_cheers = Column(TINYINT(1), default=0)
    cinema_chain_id = Column(INTEGER(11))
    price_range = Column(TINYINT(1))
    pass_timeout_fee_to_merchant = Column(TINYINT(1))
    invoice_level = Column(String(100))
    sales_person_name = Column(String(100))
    sales_person_email = Column(String(100))
    sales_person_mobile_phone = Column(String(100))
    pockiit_commencement_date = Column(String(40))
    vat_number = Column(String(100))
    loyalty_card_enabled = Column(BIT(1))
    live_offer_enabled = Column(BIT(1))
    loyalty_offer_after_x_redemptions = Column(TINYINT(1), default=0)
    has_promo_code_offers = Column(TINYINT(1), default=0)
    cinema_is_active = Column(TINYINT(1), default=0)
    cinema_is_refundable = Column(TINYINT(1), default=0)
    cinema_is_concessions = Column(TINYINT(1), default=0)
    dc_prospect_enabled = Column(TINYINT(1), default=0)
    cinema_code_type = Column(String(100))
    cinema_booking_time = Column(INT, default=0)
    hww_instant_booking = Column(TINYINT(1), default=0)

    # group = relationship('Organization')

    @classmethod
    def get_by_id(cls, merchant_id):
        """
        Returns merchant against merchant_id
        :param int merchant_id: Merchant Id
        :rtype: Merchant
        """
        return cls.query.filter(cls.id == merchant_id).first()

    @classmethod
    def find_by_id(cls, merchant_id, locale, selected_category=None):
        """
        Finds merchant by id.
        - if selected_category (as company type is `'ent'`):
            - then join with offer_ent_active model
        - else join with offer_wl_active model
        :rtype orm obj:
        """
        from ..models.merchant_translation import MerchantTranslation
        from ..models.offer import Offer

        query = cls.query.join(MerchantTranslation, cls.id == MerchantTranslation.merchant_id)
        # b2c logic for V3
        if selected_category:
            query = query.join(Offer, cls.id == Offer.merchant_id)
            query = query.filter(Offer.merchant_category == selected_category)

        query = query.with_entities(
            cls.id,
            cls.pin.label('merchant_pin'),
            cls.email,
            cls.website,
            cls.category,
            cls.categories.label('merchant_categories'),
            cls.hero_non_retina_urls.label('hero_small_urls'),
            cls.cuisines,
            cls.has_promo_code_offers,
            cls.is_pingable,
            cls.is_for_members_only,
            cls.sf_id.label('merchant_sf_id'),
            cls.dc_prospect_enabled,
            coalesce(cls.is_tutorial, 0).label('is_tutorial'),
            MerchantTranslation.name,
            MerchantTranslation.description,
            func.group_concat(Offer.merchant_category.distinct()).label('offer_categories'),
            func.group_concat(Offer.sub_category.distinct()).label('sub_categories'),
            coalesce(MerchantTranslation.cuisine).label('cuisine'),
            coalesce(MerchantTranslation.opening_hours, "").label('opening_hours'),
            case(
                [
                    (
                        cls.booking_link.is_(None),
                        literal_column("''")
                    )
                ],
                else_=cls.booking_link
            ).label('booking_link'),
            case(
                [
                    (
                        cls.booking_request == 0,
                        int(0)
                    )
                ],
                else_=cls.booking_request
            ).label('booking_request'),
            cls.logo_retina_url.label('logo_url'),
            cls.logo_non_retina_url.label('logo_small_url'),
            cls.logo_offer_retina_url.label('logo_offer_url'),
            cls.logo_offer_non_retina_url.label('logo_offer_small_url'),
            cls.photo_retina_url.label('photo_url'),
            cls.photo_non_retina_url.label('photo_small_url'),
            cls.hero_retina_urls.label('hero_urls'),
            cls.hero_non_retina_urls.label('hero_small_url'),
            cls.pdf_url,
            cls.is_opted_in_for_360_image,
            coalesce(cls.p3_360_degree_image, "").label('p3_360_degree_image'),
            coalesce(cls.p3_hero_image_retina, "").label('p3_hero_image_retina'),
            coalesce(cls.p3_hero_image_non_retina, "").label('p3_hero_image_non_retina'),
            coalesce(cls.delivery_contact_no, "").label('delivery_contact_no'),

        )
        query = query.filter(cls.id == merchant_id, MerchantTranslation.locale == locale)
        return query.first()

    @classmethod
    def get_merchant_cuisine(cls, merchant_id, locale=EN):
        """
        returns merchant cuisine
        :param int merchant_id:
        :param  str locale:
        :return orm obj:
        """
        from ..models.merchant_translation import MerchantTranslation

        if merchant_id:
            query = cls.query.outerjoin(MerchantTranslation, cls.id == MerchantTranslation.merchant_id)
            query = query.with_entities(
                cls.cuisine.label('m_cuisine'),
                MerchantTranslation.cuisine.label('t_cuisine')
            )
            query = query.filter(MerchantTranslation.locale == locale, cls.id == merchant_id)
            return query.first()
        return None

    @classmethod
    def get_delivery_contact_number(cls, merchant_id, locale=EN):
        """
        returns delivery_contact_number
        :param int merchant_id:
        :param str locale:
        :return orm obj:
        """
        query = cls.query.filter(cls.id == merchant_id)
        query = query.with_entities(
            coalesce(cls.delivery_contact_no, '').label('delivery_contact_no'),
        )
        return query.first()

    @classmethod
    def get_by_pin(cls, merchant_pin):
        """
        Returns first merchant by pin
        :param str merchant_pin: Merchant pin
        """
        if merchant_pin:
            return cls.query.with_entities(cls.id).filter(cls.pin == merchant_pin).first()

    @classmethod
    def get_featured_merchants(
            cls,
            location_id,
            category,
            featured_category,
            company,
            billing_country,
            locale,
            is_cheers,
            is_customer_own_cheers_for_location,
            add_future_check
    ):
        """
        Returns featured merchants.

        :param int location_id: location id of customer.
        :param str category: category of offers of merchant.
        :param str featured_category: featured category of FeaturedMerchant.
        :param str company: name of customer's company.
        :param str billing_country: name of customer's billing country.
        :param str locale: locale to get results in.
        :param bool is_cheers: if the offers are cheers.
        :param bool is_customer_own_cheers_for_location: if cheers offers are enabled for the location passed.
        :param bool add_future_check: if we want to check validity of FeaturedMerchant.
        """

        from common.models.merchant_translation import MerchantTranslation
        from common.models.outlet import Outlet
        from common.models.outlet_offer import OutletOffer
        from common.models.offer import Offer

        featured_merchants = []
        if is_cheers and not is_customer_own_cheers_for_location:
            return featured_merchants
        current_datetime = datetime.datetime.now()
        query = cls.query.with_entities(
            Merchant.id,
            MerchantTranslation.name,
            Merchant.position,
            MerchantTranslation.description,
            Merchant.category,
            Merchant.digital_section,
            MerchantTranslation.cuisine,
            coalesce(Merchant.ad_travel_country, "").label('ad_travel_country'),
            Merchant.is_featured,
            Merchant.ad_active_status,
            Merchant.logo_retina_url.label('logo_url'),
            Merchant.logo_non_retina_url.label('logo_small_url'),
            Merchant.photo_retina_url.label('photo_url'),
            Merchant.photo_non_retina_url.label('photo_small_url'),
            func.count(func.distinct(Outlet.id)).label('outlets_count'),
            literal_column("''").label("outlets_info"),
            func.group_concat(func.distinct(Outlet.id)).label('outlet_ids'),
        ).join(
            MerchantTranslation,
            and_(cls.id == MerchantTranslation.merchant_id, MerchantTranslation.locale == locale)
        ).join(
            Offer,
            cls.id == Offer.merchant_id
        ).join(
            OutletOffer,
            Offer.id == OutletOffer.offer_id
        ).join(
            Outlet,
            and_(OutletOffer.outlet_id == Outlet.id, Outlet.active == 1)
        ).join(
            FeaturedMerchant,
            and_(cls.id == FeaturedMerchant.merchant_id, FeaturedMerchant.is_active == 1)
        ).filter(
            FeaturedMerchant.featured_category == featured_category,
            FeaturedMerchant.is_featured_for_home_screen == 0,
            Offer.merchant_category == category,
            FeaturedMerchant.valid_from < current_datetime,
        )
        if add_future_check:
            query = query.filter(FeaturedMerchant.valid_to > current_datetime - datetime.timedelta(days=1))

        if location_id and category.lower() != TRAVEL:
            query = query.filter(Outlet.location_id == location_id)
        if category.lower() == TRAVEL and billing_country:
            query = query.filter(Outlet.billing_country == billing_country)

        # TODO: Why so many group bys
        query = query.group_by(
            Merchant.id,
            MerchantTranslation.name,
            MerchantTranslation.description,
            Merchant.category,
            Merchant.digital_section,
            MerchantTranslation.cuisine,
            Merchant.ad_travel_country,
            Merchant.is_featured,
            Merchant.ad_active_status,
            Merchant.logo_retina_url,
            Merchant.logo_non_retina_url,
            Merchant.photo_retina_url,
            Merchant.photo_non_retina_url
        ).order_by(Merchant.position.asc())
        return query.all()
