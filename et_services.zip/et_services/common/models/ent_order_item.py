"""
Ent Order Model
"""

from sqlalchemy import TIMESTAMP, Column, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db
from ..models.mixin import Mixin


class EntOrderItem(db.Model, Mixin):
    __tablename__ = 'ent_order_item'
    __table_args__ = {"schema": CONSOLIDATION}

    id = Column(INTEGER(10), primary_key=True)
    order_id = Column(INTEGER(10), index=True, server_default=text("'0'"))
    magento_product_id = Column(INTEGER(10), nullable=False)
    product_id = Column(INTEGER(11))
    quantity = Column(INTEGER(11))
    product_sku = Column(String(50))
    product_name = Column(String(150))
    total_price = Column(Float, comment='single product price')
    total_discount = Column(Float)
    base_row_total = Column(Float)
    base_discount_amount = Column(Float)
    promo = Column(String(50))
    additional_options = Column(String(255))
    inactive = Column(TINYINT(4))
    comment = Column(String(255))
    is_paired = Column(TINYINT(1), server_default=text("'0'"))
    is_free = Column(TINYINT(1), server_default=text("'0'"))
    is_cross_sell = Column(TINYINT(1), server_default=text("'0'"))
    is_pay_monthly = Column(TINYINT(1), server_default=text("'0'"))
    is_refunded = Column(TINYINT(11), server_default=text("'0'"))
    pay_monthly_price = Column(Float)
    is_bundle = Column(TINYINT(1), server_default=text("'0'"))
    is_addon = Column(TINYINT(1), server_default=text("'0'"))
    is_gift = Column(TINYINT(1), server_default=text("'0'"))
    parent_order_item_id = Column(INTEGER(11))
    status = Column(TINYINT(1), server_default=text("'0'"))
    smiles_to_burn = Column(INTEGER(11), nullable=False, server_default=text("'0'"))
    tax_amount = Column(Float(8))
    base_tax_amount = Column(Float(8))
    tax_percentage = Column(INTEGER(11))
    updated_by = Column(INTEGER(11))
    update_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    cc_charge_id = Column(String(255))
