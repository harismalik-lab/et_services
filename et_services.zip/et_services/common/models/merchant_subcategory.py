"""
Merchant Subcategory Model and Merchant Subcategory Translation Model class
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class MerchantSubCategory(db.Model, Mixin):
    __tablename__ = 'merchant_sub_category'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    category_id = Column(INTEGER(11), nullable=False)
    sub_category_key = Column(String(255))
    name = Column(String(100), nullable=False)
    order_id = Column(SMALLINT(6), default=100)
    is_active = Column(BIT(1), nullable=False)
    image_url = Column(String(255))
    image_url_default = Column(String(255))
    image_url_selected = Column(String(255))

    @classmethod
    def get_by_locale(cls, locale=EN):
        """
        Returns Merchant Subcategories against locale
        :param str locale: Locale
        """
        return cls.query.with_entities(
            cls.id.label('sub_category_id'),
            cls.category_id,
            MerchantSubCategoryTranslation.name,
            cls.name.label('category_key')
        ).join(
            MerchantSubCategoryTranslation,
            cls.id == MerchantSubCategoryTranslation.sub_category_id
        ).filter(
            cls.is_active, MerchantSubCategoryTranslation.locale == locale
        ).all()

    @classmethod
    def get_merchant_sub_categories(cls, locale='en', category_id=0):
        """
        Returns merchant sub categories
        :param int category_id: Merchant category Id
        :param str locale: Locale
        :rtype: list
        """
        query = cls.query.join(MerchantSubCategoryTranslation, cls.id == MerchantSubCategoryTranslation.sub_category_id)
        query = query.with_entities(
            cls.id.label('sub_category_id'), cls.category_id, MerchantSubCategoryTranslation.name,
            cls.name.label('key'), cls.image_url, cls.image_url_default, cls.image_url_selected
        )
        query = query.filter(cls.is_active == 1, MerchantSubCategoryTranslation.locale == locale)
        query = query.order_by(cls.order_id.asc(), cls.name.asc())
        if category_id:
            query = query.filter(cls.category_id == category_id)
        return query.all()


class MerchantSubCategoryTranslation(db.Model, Mixin):
    __tablename__ = 'merchant_sub_category_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    sub_category_id = Column(INTEGER(10), nullable=False)
    locale = Column(String(10))
    name = Column(String(100))
