"""
Home Screen Configuration Section model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, String, and_
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TINYINT
from sqlalchemy.sql.functions import coalesce

from common import constants

from ..models.db import db
from ..models.home_screen_configurations_section_translation import HomeScreenConfigurationsSectionTranslation
from ..models.mixin import Mixin

__author__ = 'tamoors@theentertainerasia.com'


class HomeScreenConfigurationsSection(db.Model, Mixin):
    __tablename__ = 'home_screen_configurations_section'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    section_name = Column(String(50), nullable=False)
    identifier = Column(String(100))
    section_identifier = Column(String(100))
    company = Column(String(50), nullable=False, default='entertainer')
    location_id = Column(SMALLINT(6), nullable=False)
    section_width = Column(SMALLINT(6), nullable=False)
    section_height = Column(SMALLINT(6), nullable=False)
    title_color = Column(String(100))
    background_color = Column(String(100))
    user_group = Column(SMALLINT(6), default=1)
    is_active = Column(BIT(1), nullable=False)
    order_id = Column(TINYINT(4))
    create_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    update_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)

    @classmethod
    def get_all(cls, location_id, user_group=0, company='', locale=constants.EN):
        """
        Gets all home screen configurations section
        :param  int location_id: user location id
        :param  int user_group:  user group
        :param  str company:     user company
        :param  str locale:      user language
        """

        query = cls.query.with_entities(
            cls.id,
            cls.section_name,
            cls.identifier,
            cls.section_identifier,
            cls.company,
            cls.section_width,
            cls.section_height,
            cls.title_color,
            cls.background_color,
            cls.user_group,
            cls.location_id,
            cls.is_active,
            cls.order_id,
            coalesce(HomeScreenConfigurationsSectionTranslation.title, '').label('title'),
        ).outerjoin(
            HomeScreenConfigurationsSectionTranslation,
            and_(
                cls.id == HomeScreenConfigurationsSectionTranslation.section_id,
                HomeScreenConfigurationsSectionTranslation.locale == locale
            )
        ).filter(
            cls.is_active,
            cls.company == company
        )

        query = query.filter(cls.user_group.in_([user_group, 0]))
        query = query.filter(cls.location_id.in_([location_id, 0]))
        query = query.order_by(cls.order_id.asc())
        return query.all()
