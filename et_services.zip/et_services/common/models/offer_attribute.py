"""
Offer Attribute Model Class
"""
from sqlalchemy import TIMESTAMP, Column, ForeignKey
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.offer import Offer


class OfferAttribute(db.Model):
    __tablename__ = 'offer_attributes'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    offer_id = Column(ForeignKey(Offer.id, ondelete='CASCADE', onupdate='CASCADE'), nullable=False, unique=True)
    alcohol = Column(TINYINT(1))
    brunch = Column(TINYINT(1))
    buffet = Column(TINYINT(1))
    delivery = Column(TINYINT(1))
    for_kids = Column(TINYINT(1))
    hubbly_bubbly = Column(TINYINT(1))
    body_treatments = Column(TINYINT(1))
    dance_classes = Column(TINYINT(1))
    dental = Column(TINYINT(1))
    dermatology = Column(TINYINT(1))
    diet_and_nutrition = Column(TINYINT(1))
    facials = Column(TINYINT(1))
    fitness_classes = Column(TINYINT(1))
    gym_membership = Column(TINYINT(1))
    hair = Column(TINYINT(1))
    make_overs = Column(TINYINT(1))
    mani_pedi = Column(TINYINT(1))
    martial_arts = Column(TINYINT(1))
    massage = Column(TINYINT(1))
    moroccan_bath = Column(TINYINT(1))
    personal_training = Column(TINYINT(1))
    pilates = Column(TINYINT(1))
    pool_swimming = Column(TINYINT(1))
    pre_natal = Column(TINYINT(1))
    slimming = Column(TINYINT(1))
    spin_cycle = Column(TINYINT(1))
    tanning = Column(TINYINT(1))
    waxing_threading_laser = Column(TINYINT(1))
    weight_loss = Column(TINYINT(1))
    yoga = Column(TINYINT(1))
    activity_camps = Column(TINYINT(1))
    boating = Column(TINYINT(1))
    desert = Column(TINYINT(1))
    fishing = Column(TINYINT(1))
    golf = Column(TINYINT(1))
    motor_sports = Column(TINYINT(1))
    team_sports = Column(TINYINT(1))
    theme_park = Column(TINYINT(1))
    water_park = Column(TINYINT(1))
    water_sports = Column(TINYINT(1))
    health_beauty = Column(TINYINT(1))
    beauty_products = Column(TINYINT(1))
    by_appointment_only = Column(TINYINT(1))
    pharmacy = Column(TINYINT(1))
    pick_up_drop_off = Column(TINYINT(1))
    no_of_rooms = Column(SMALLINT(6))
    last_update_time = Column(TIMESTAMP)
    express = Column(TINYINT(1))
    invoice_entity_id = Column(INTEGER(11))
