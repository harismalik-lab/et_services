"""
Home Screen Configuration model
"""
import datetime

from flask import g
from sqlalchemy import TIMESTAMP, VARCHAR, Column, String, and_, case
from sqlalchemy.dialects.mysql import INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from .. import constants
from ..models.db import db
from ..models.home_screen_configurations_translation import HomeScreenConfigurationsTranslation
from ..models.mixin import Mixin
from ..models.wl_company import WlCompany
from ..models.wl_location_category import WlLocationCategory
from ..models.wl_user_group import WlUserGroup
from ..models.wl_validation import Wlvalidation
from ..utils.translation_manager import TranslationManager

cache = g.cache

__author__ = 'osamaa@theentertainerasia.com'


class HomeScreenConfiguration(db.Model, Mixin):
    __tablename__ = 'home_screen_configurations'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(20), nullable=False, index=True, default='entertainer')
    entity_type = Column(String(100))
    entity_id = Column(INTEGER(11))
    location_id = Column(TINYINT(1), nullable=False, index=True, default=0)
    user_group = Column(INTEGER(11), default=0)
    order_id = Column(TINYINT(1), nullable=False, default=100)
    link_type = Column(String(20), index=True)
    section_identifier = Column(String(100))
    title = Column(String(100))
    description = Column(VARCHAR)
    is_external_link = Column(TINYINT(1), default=1)
    deep_link = Column(String(300))
    image_url = Column(VARCHAR)
    logo_url = Column(VARCHAR)
    image_url_fluid = Column(String(300))
    tile_bottom_banner_color = Column(String(20))
    is_active = Column(TINYINT(1), index=True, default=1)
    creation_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)

    @staticmethod
    def get_category_label(category='', locale='', company=''):
        """
        Gets the category label.
        :param company:
        :param locale:
        :param category:
        category, locale, company,
        :rtype: str
        """
        category = category.lower()

        if category == constants.RESTAURANTS_AND_BARS:
            return TranslationManager.get_translation(TranslationManager.FOOD_AND_DRINK, locale)
        # Todo: Need to update the translation in the controller. #ThisISOldWhiteLabelTODO
        elif category == constants.BODY:
            if locale == 'ar':
                return 'تجميل ولياقة بدنية'
            else:
                return TranslationManager.get_translation(TranslationManager.BODY, locale)
        elif category == constants.LEISURE:
            if locale == 'ar':
                return 'التسلية والترفيه'
            else:
                return TranslationManager.get_translation(TranslationManager.LEISURE, locale)
        elif category == constants.RETAIL:
            if locale == 'ar':
                return 'خدمات'
            else:
                return TranslationManager.get_translation(TranslationManager.FASHION_AND_RETAIL, locale)
        elif category == constants.SERVICES:
            if locale == 'en':
                if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                    return "RETAIL & SERVICES"
                else:
                    return "EVERYDAY SERVICES"
            elif locale == 'el':
                return 'Καθημερινές Υπηρεσίες'
            else:
                return TranslationManager.get_translation(TranslationManager.SERVICES, locale)
        elif category == 'travel':
            if company in (
                    WlCompany.COMPANY_CODE_ENTERTAINER_GEMS,
                    WlCompany.COMPANY_CODE_ENTERTAINER_HSBC,
                    WlCompany.COMPANY_CODE_DUBAI_ENTERTAINMENTS
            ):
                if locale == 'en':
                    return 'HOTELS'
                else:
                    return TranslationManager.get_translation(TranslationManager.TRAVEL, locale)
            else:
                return TranslationManager.get_translation(TranslationManager.TRAVEL, locale)
        return ''

    @staticmethod
    def get_categories(company, user_id, location_id, is_user_logged_in=False, purchasable_product_ids=[],
                       purchased_product_ids=[],
                       locale='en'):
        """
        Gets the categories.
        :param locale:
        :param purchased_product_ids:
        :param purchasable_product_ids:
        :param is_user_logged_in:
        :param location_id:
        :param user_id:
        :param company:
        :rtype: list
        """
        from ..utils.api_utils import category_title_to_lower

        show_all_categories = False
        show_freemium_slider_icons = False

        if all([
            is_user_logged_in,
            purchasable_product_ids,
            purchased_product_ids
        ]):
            for purchasable_product_id in purchasable_product_ids:
                if purchasable_product_id in purchased_product_ids:
                    show_all_categories = True
                    break

        if show_all_categories:
            categories = [
                {
                    "tile_id": 1,
                    "category_id": 1,
                    "is_free": False,
                    "image": constants.IMAGE_RESTAURANTS_AND_BARS,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.RESTAURANTS_AND_BARS, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_RestaurantsandBars,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS,
                    "category_color": constants.COLOR_RESTAURANTS_AND_BARS,
                    "map_pin_url": constants.MAP_PIN_RestaurantsandBars,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_RestaurantsandBars
                },
                {
                    "tile_id": 2,
                    "category_id": 2,
                    "is_free": False,
                    "image": constants.IMAGE_BODY,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_BODY,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.BODY, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Body,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_BODY,
                    "category_color": constants.COLOR_BODY,
                    "map_pin_url": constants.MAP_PIN_Body,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_Body
                },
                {
                    "tile_id": 3,
                    "category_id": 3,
                    "is_free": False,
                    "image": constants.IMAGE_LEISURE,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_LEISURE,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.LEISURE, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Leisure,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_LEISURE,
                    "category_color": constants.COLOR_LEISURE,
                    "map_pin_url": constants.MAP_PIN_Leisure,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_Leisure
                },
                {
                    "tile_id": 7,
                    "category_id": 7,
                    "is_free": show_freemium_slider_icons,
                    "image": constants.IMAGE_RETAIL,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_RETAIL,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.RETAIL, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Retail,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_RETAIL,
                    "category_color": constants.COLOR_RETAIL,
                    "map_pin_url": constants.MAP_PIN_Retail,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_Retail,
                    "map_pin_selected_url": constants.MAP_PIN_SELECTED_RETAIL,
                    "map_pin_selected_invalid_url": constants.MAP_PIN_SELECTED_INVALID_RETAIL
                },
                {
                    "tile_id": 4,
                    "category_id": 4,
                    "is_free": False,
                    "image": constants.IMAGE_SERVICES,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_SERVICES,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.SERVICES, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Services,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_SERVICES,
                    "category_color": constants.COLOR_SERVICES,
                    "map_pin_url": constants.MAP_PIN_Services,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_Services
                },
                {
                    "tile_id": 5,
                    "category_id": 5,
                    "is_free": False,
                    "image": constants.IMAGE_TRAVEL,
                    "banner_image": "",
                    "api_name": constants.CATEGORY_API_NAME_TRAVEL,
                    "display_name": HomeScreenConfiguration.get_category_label(
                        category=constants.TRAVEL, locale=locale
                    ),
                    "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Travel,
                    "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_TRAVEL,
                    "category_color": constants.COLOR_TRAVEL,
                    "map_pin_url": constants.MAP_PIN_Travel,
                    "map_pin_invalid_url": constants.MAP_PIN_INVALID_Travel
                }
            ]
        else:
            user_groups = []
            if is_user_logged_in:
                user_groups = Wlvalidation.get_user_groups(company, user_id)
            if not user_groups:
                user_groups.append(WlUserGroup.DEFAULT_USER_GROUP)

            categories = []
            results = WlLocationCategory.get_location_categories(
                company, location_id, user_groups
            )
            for row in results:
                category = row._asdict()
                category['tile_id'] = 1
                categories.append(category)

            for category in categories:
                api_name = category.get('api_name', '')
                category['banner_image'] = ''
                category["is_free"] = False
                category['title_color'] = constants.TITLE_COLOR
                constant_name = category.get('api_name', '').replace(' ', '')
                category['analytics_category_name'] = getattr(
                    constants, 'ANALYTICS_CATEGORY_CODE_{}'.format(constant_name)
                )
                category['featured_merchant_icon_url'] = getattr(
                    constants, 'FEATURED_MERCHANT_ICON_URL_{}'.format(constant_name)
                )
                category['category_color'] = category.get('color_code', '').replace("#", '')
                category_name = category_title_to_lower(api_name=api_name)
                if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                    category['map_pin_url'] = \
                        constants.MAP_PIN_GENERIC_PIN_GEMS.format(category=category_name)
                    category['map_pin_invalid_url'] = \
                        constants.Map_Pin_GENERIC_PIN_INVALID_GEMS.format(category=category_name)
                else:
                    category['map_pin_url'] = \
                        getattr(constants, 'MAP_PIN_{}'.format(constant_name))
                    category['map_pin_invalid_url'] = \
                        getattr(constants, 'MAP_PIN_INVALID_{}'.format(constant_name))
                try:
                    del category['color_code']
                except KeyError:
                    pass
                category['display_name'] = HomeScreenConfiguration.get_category_label(
                    category=api_name, locale=locale, company=company
                )
            if purchasable_product_ids:
                has_travel_category = False
                for category in categories:
                    if category['api_name'] == constants.CATEGORY_NAME_TRAVEL:
                        has_travel_category = True
                        break
                if not has_travel_category:
                    travel_cat_img = constants.IMAGE_TRAVEL
                    if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                        travel_cat_img = constants.TRAVEL_CAT_IMG_GEM
                    elif company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC:
                        travel_cat_img = constants.TRAVEL_CAT_IMG_HSBS

                    categories.append({
                        "tile_id": 5,
                        "category_id": 5,
                        "is_free": False,
                        "image": travel_cat_img,
                        "banner_image": "",
                        "api_name": constants.CATEGORY_API_NAME_TRAVEL,
                        "display_name": HomeScreenConfiguration.get_category_label(
                            category=constants.CATEGORY_API_NAME_TRAVEL,
                            locale=locale,
                            company=company
                        ),
                        "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Travel,
                        "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_TRAVEL,
                        "category_color": constants.COLOR_TRAVEL,
                        "map_pin_url": constants.MAP_PIN_Travel,
                        "map_pin_invalid_url": constants.MAP_PIN_INVALID_Travel
                    })
        return categories

    @classmethod
    @cache.memoize(timeout=1800)
    def get_configurations(cls, locale=constants.EN, location_id=0, company='entertainer'):
        """
        Returns home screen configuration
        :param  str  locale:      Language of the user
        :param  int  location_id: User location id
        :param  str  company:     User Company
        :rtype: list
        """
        query = cls.query.with_entities(
            cls.id,
            cls.location_id,
            cls.order_id,
            cls.link_type,
            cls.is_active,
            cls.is_external_link,
            coalesce(HomeScreenConfigurationsTranslation.title, '').label('title'),
            coalesce(HomeScreenConfigurationsTranslation.description, '').label('description'),
            coalesce(cls.deep_link, '').label('deep_link'),
            coalesce(cls.image_url, '').label('image_url'),
            coalesce(cls.logo_url, '').label('logo_url'),
            cls.tile_bottom_banner_color,
            cls.title.label('kaligo_location_identifier')
        ).join(
            HomeScreenConfigurationsTranslation, cls.id == HomeScreenConfigurationsTranslation.config_id
        ).filter(
            cls.location_id == location_id,
            cls.company == company,
            HomeScreenConfigurationsTranslation.locale == locale,
            cls.is_active == 1
        ).order_by(cls.order_id)

        return query.all()

    @classmethod
    def get_all_sections(
            cls, locale=constants.EN, location_id=0, company='entertainer', include_global_tiles=True, user_group=0
    ):
        """
        Returns home screen configuration sections

        :param  str  locale:      Language of the user
        :param  int  location_id: User location id
        :param  str  company:     User Company
        :rtype: list
        """
        query = cls.query.with_entities(
            cls.id,
            cls.location_id,
            cls.order_id,
            cls.link_type,
            cls.is_active,
            cls.section_identifier,
            cls.is_external_link,
            coalesce(case(
                [
                    (
                        HomeScreenConfigurationsTranslation.title != '',
                        HomeScreenConfigurationsTranslation.title
                    )
                ],
                else_=cls.title
            ), '').label('title'),
            coalesce(case(
                [
                    (
                        HomeScreenConfigurationsTranslation.description != '',
                        HomeScreenConfigurationsTranslation.description
                    )
                ],
                else_=cls.description
            ), '').label('description'),
            coalesce(cls.deep_link, '').label('deep_link'),
            coalesce(cls.image_url, '').label('image_url'),
            coalesce(cls.logo_url, '').label('logo_url'),
            coalesce(cls.tile_bottom_banner_color, '').label('tile_bottom_banner_color'),
        ).outerjoin(
            HomeScreenConfigurationsTranslation,
            and_(cls.id == HomeScreenConfigurationsTranslation.config_id,
                 HomeScreenConfigurationsTranslation.locale == locale)
        ).filter(
            cls.is_active,
            cls.company == company,
            cls.section_identifier.isnot(None)
        )

        query = query.filter(cls.user_group.in_([user_group, 0]))
        if include_global_tiles:
            query = query.filter(cls.location_id.in_([location_id, 0]))
        else:
            query = query.filter(cls.location_id == location_id)
        query = query.order_by(cls.order_id.asc())
        return query.all()
