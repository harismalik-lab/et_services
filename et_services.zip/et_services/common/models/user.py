"""
User Model
"""
import datetime

from sqlalchemy import TIMESTAMP, VARBINARY, Column, DateTime, String, or_
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db, with_master
from ..models.ent_order import EntOrder
from ..models.ent_order_item import EntOrderItem
from ..models.mixin import Mixin
from ..models.product import Product
from ..models.product_ent_active import ProductEntActive
from ..models.wl_user_custom_info import WlUserCustomInfo
from ..utils.security import security


class User(db.Model, Mixin):
    __tablename__ = 'user'
    __table_args__ = {"schema": CONSOLIDATION}

    TOKEN_EXPIRY_IN_HOURS = 72

    id = Column(INTEGER(10), primary_key=True)
    username = Column(String(255), nullable=False, unique=True)
    auth_key = Column(VARBINARY(32), nullable=False)
    maalga = Column(String(50))
    password_hash = Column(String(255), nullable=False)
    is_password_updated = Column(TINYINT(1))
    password_reset_token = Column(String(255))
    email_verification_token = Column(String(100), index=True)
    email = Column(String(255), nullable=False, index=True)
    is_email_verified = Column(TINYINT(1), index=True)
    status = Column(TINYINT(3), default=10)
    is_encrypted = Column(BIT(1))
    is_customer = Column(TINYINT(1), nullable=False, default=1)
    create_time = Column(TIMESTAMP, default=datetime.datetime.now)
    update_time = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    first_name = Column(String(255))
    last_name = Column(String(255))
    is_active = Column(TINYINT(1), default=1)
    token_exp_date = Column(DateTime)
    account_frozen_date = Column(TIMESTAMP, nullable=False, default='0000-00-00 00:00:00')

    @classmethod
    @with_master
    def find_active_user_by_email(cls, email):
        """
        Gets customer by Email Id
        :param str email: Email Address
        :rtype: EntCustomerProfile
        """
        return cls.query.filter(cls.email == email, cls.is_active).first()

    @classmethod
    @with_master
    def active_user_by_email_exists(cls, email):
        """
        return scalar value if user exists else None
        :param str email:
        :return id:
        """
        return cls.query.filter(cls.email == email, cls.is_active).scalar() is not None

    @classmethod
    def get_active_user_password_hash_by_email(cls, email):
        """
        Gets the password hash of the user
        :param email: email of the user.
        :rtype str
        """
        _hash = cls.query.with_entities(cls.password_hash).filter(cls.email == email, cls.is_active, cls.is_customer)\
            .first()
        if _hash:
            return _hash[0]

    @classmethod
    @with_master
    def login(cls, email, password, _hash='', company='entertainer', lookup_based_company=False):
        """
        Verify user's login credentials
        :param bool lookup_based_company: Whether it is a lookup based company or not
        :param str email: email
        :param str password: password
        :param str _hash: hash
        :param str company: company
        :rtype User
        """
        if security.validate_password(password, _hash) or security.validate_hash_magento(password, _hash):
            if lookup_based_company:
                return cls.query.join(WlUserCustomInfo, cls.id == WlUserCustomInfo.user_id)\
                    .filter(
                    cls.email == email, cls.is_active,
                    WlUserCustomInfo.company == company, WlUserCustomInfo.password_hash == _hash
                ).first()
            return cls.query.filter(cls.email == email, cls.is_active, cls.password_hash == _hash).first()

    @classmethod
    @with_master
    def update_password_reset_token(cls, customer_id, token):
        """
        Updates the password reset token
        :param int customer_id: id of the customer
        :param str token: token that is passed by the customer
        :rtype bool
        """
        try:
            token_expiry_date = datetime.datetime.now() + datetime.timedelta(hours=cls.TOKEN_EXPIRY_IN_HOURS)
            changes = {
                'password_reset_token': token,
                'token_exp_date': token_expiry_date
            }
            cls.query.filter(cls.id == customer_id).update(changes)
            db.session.commit()
            return True
        except Exception:
            return False

    @classmethod
    def get_by_password_reset_token(cls, token):
        """
        Returns user against password reset token
        :param str token: Password Reset Token
        :rtype: User
        """
        return cls.query.filter(cls.password_reset_token == token, cls.is_active).first()

    @classmethod
    @with_master
    def load_customer_by_id(cls, customer_id):
        """
        :param customer_id:
        :return:
        """
        if customer_id:
            query = cls.query
            query = query.filter(cls.is_active == 1)
            if isinstance(customer_id, list):
                query = query.filter(cls.id.in_(customer_id))
                result = query.all()
                result = {customer.id: customer for customer in result}
            else:
                query = query.filter(cls.id == customer_id)
                result = query.first()
            return result
        return {}

    @classmethod
    def get_active_by_id(cls, user_id):
        """
        Returns Active user by id
        :param int user_id: User Id
        :rtype: User
        """
        return cls.query.filter(cls.id == user_id, cls.is_active == 1).first()

    @classmethod
    def get_customer_orders_with_product_pairing(cls, user_id, company, include_printed_books=False):
        """
        Returns orders against user_id and company
        :param bool include_printed_books: Join from Product or product_ent_active
        :param int user_id: User Id
        :param str company: Company code
        :rtype: list
        """
        orders = cls.query.with_entities(
            EntOrderItem.product_sku,
            EntOrderItem.quantity,
            EntOrderItem.is_gift,
            EntOrder.create_date
        ).select_from(
            User
        ).join(
            EntOrder,
            cls.id == EntOrder.user_id
        ).join(
            EntOrderItem,
            EntOrder.id == EntOrderItem.order_id
        )
        product_table = ProductEntActive
        if include_printed_books:
            product_table = Product
        orders.join(
            product_table,
            EntOrderItem.product_sku == product_table.sf_id
        ).filter(
            cls.id == user_id,
            or_(
                EntOrderItem.inactive == 0,
                EntOrderItem.inactive.is_(None)  # noqa
            ),
            EntOrder.company == company,
            product_table.isactive == 1,
            EntOrderItem.is_gift == 0
        )
        return orders.all()
