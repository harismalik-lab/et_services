"""
Dm Delivery Timings Model
"""
import datetime

from sqlalchemy import Column, String, Time
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmDeliveryTiming(db.Model):
    __tablename__ = 'dm_delivery_timings'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    outlet_setting_id = Column(INTEGER(10), nullable=False, index=True)
    day_of_week = Column(String(20), index=True)
    delivery_start_time = Column(Time)
    delivery_end_time = Column(Time)
    is_delivery_available = Column(TINYINT(1), default=1)
    created_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_by = Column(String(100))
    total_minutes = Column(INTEGER(11), default=0)
