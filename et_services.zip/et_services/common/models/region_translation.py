"""
Region translation model
"""
from sqlalchemy import VARCHAR, Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class RegionTranslation(db.Model, Mixin):
    __tablename__ = 'region_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    region_id = Column(INTEGER)
    locale = Column(String(5), default='en')
    name = Column(VARCHAR)
