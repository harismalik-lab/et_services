"""
Business Model Class
"""
import datetime

from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.mysql import BIT, INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class Business(db.Model):
    __tablename__ = 'business'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    name = Column(String(255))
    api_key = Column(String(500), nullable=False, index=True)
    secret_key = Column(String(500), nullable=False)
    is_active = Column(BIT(1))
    date_updated = Column(DateTime, default=datetime.datetime.now)
    date_created = Column(DateTime, default=datetime.datetime.now)
    company_creation_limit = Column(INTEGER(11), default=100)

    @classmethod
    def get_active_by_api_key(cls, api_key):
        """
        Returns business object against api_key
        :param str api_key: Api Key
        :rtype: Business
        """
        return cls.query.filter(cls.api_key == api_key, cls.is_active == 1).first()
