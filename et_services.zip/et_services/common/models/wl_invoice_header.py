"""
WlInvoice Model
"""
import datetime

from sqlalchemy import TIMESTAMP, DateTime, Float, String
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class WlInvoiceHeader(db.Model):
    __tablename__ = 'wl_invoice_headers'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    # Constants
    NOT_EXIST_STATUS = 0
    VALID_STATUS = 1
    ALREADY_USED_STATUS = 2
    INVALID_STATUS = 3
    Invoice_Status_Valid_For_Sign_In_Sign_Up_Only = 4
    Invoice_Status_Valid_Linking_Through_Profile_Only = 5
    Invoice_Status_Outdated_Invoice = 6
    Invoice_Status_Invalid_Transaction_Type = 7
    Invoice_Status_Wrong_Amount = 8
    Invoice_Valid_For_Past_X_Days = 30
    SUMMARY_BY_MONTH = "by_month"
    SUMMARY_BY_YEAR = "by_year"

    # Columns
    id = db.Column(INTEGER(11), primary_key=True)
    user_id = db.Column(INTEGER(11), index=True, default=db.text("'0'"))
    external_customer_id = db.Column(INTEGER(11), index=True)
    card_number = db.Column(String(25), index=True)
    wl_membership_card_id = db.Column(INTEGER(11), index=True)
    transaction_type = db.Column(String(10))
    invoice_number = db.Column(String(20), index=True)
    quantity = db.Column(INTEGER(11), default=db.text("'0'"))
    transaction_total_price = db.Column(Float, comment='transaction_total_price = Savings')
    user_group = db.Column(String(25), index=True)
    invoice_date = db.Column(DateTime, nullable=False)
    location_code = db.Column(String(25))
    location_name = db.Column(String(50))
    company = db.Column(String(50))
    created_by = db.Column(String(50), default=db.text("'0'"))
    created_date = db.Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    updated_by = db.Column(String(50), default=db.text("'0'"))
    updated_date = db.Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    transaction_status = db.Column(VARCHAR(50), comment='pending, success etc')
    source = db.Column(VARCHAR(100), comment='Data source ip or name')

    @property
    def transaction_invoice(self):
        return self.transaction_type + self.invoice_number

    @classmethod
    def get_by_company_and_invoice_number(cls, company, invoice_number):
        """
        Gets invoice
        :param str company: company
        :param int invoice_number: invoice number
        :rtype: WlInvoiceHeader
        """
        return cls.query.filter(
            cls.company == company,
            cls.transaction_invoice == invoice_number
        ).first()

    @classmethod
    def get_by_user_id(cls, user_id):
        """
        Gets invoice
        :param int user_id: User Id
        :rtype: WlInvoiceHeader
        """
        return cls.query.filter(
            cls.user_id == user_id,
        ).first()

    @classmethod
    def get_highest_emax_user_group(cls, user_id, company):
        """
        Gets highest Emax user group
        :param int user_id: id of user
        :param str company: company
        :rtype: int
        """
        user_group = cls.query.with_entities(cls.user_group).filter(cls.user_id == user_id, cls.company == company)\
            .order_by(cls.user_group.desc()).first()
        if not user_group:
            return 1
        return user_group[0]
