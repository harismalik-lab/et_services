"""
BookingTimeSlots table of Entertainer Tours schema.
"""
from sqlalchemy import Column, DateTime, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import ENTERTAINER_TOURS
from ..models.db import db
from ..models.mixin import Mixin


class TourBookingTimeSlots(db.Model, Mixin):
    __table_args__ = {'schema': ENTERTAINER_TOURS}
    __tablename__ = 'booking_time_slots'

    id = Column(INTEGER(11), primary_key=True)
    booking_date_id = Column(INTEGER(11))
    booking_start_time = Column(DateTime)
    booking_end_time = Column(DateTime)
    booking_frequency = Column(INTEGER(11))
    max_guests = Column(INTEGER(11))
    total_spots = Column(INTEGER(11))
    available_spots = Column(INTEGER(11))
    is_active = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    created_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
