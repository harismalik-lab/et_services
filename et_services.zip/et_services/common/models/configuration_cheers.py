"""
Configuration Cheers Model
"""
from sqlalchemy import Column, Enum, String, Text, and_
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import EN, ENTERTAINER_WEB
from ..models.category import Category
from ..models.configuration_cheers_translation import ConfigurationCheersTranslation
from ..models.db import db


class ConfigurationCheer(db.Model):
    __tablename__ = 'configuration_cheers'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    CHEERS = 'cheers'
    DELIVERY = 'delivery'

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(100), server_default='entertainer')
    location_id = Column(TINYINT(1))
    product_id = Column(INTEGER(11))
    product_sku = Column(String(10))
    category_id = Column(TINYINT(1))
    category = Column(String(50))
    age_limit = Column(TINYINT(1))
    cheers_logo_url = Column(Text)
    type = Column(Enum(CHEERS, DELIVERY), server_default=CHEERS)

    @classmethod
    def get_by_company_locale_and_type(cls, company, location_id, locale=EN, _type=CHEERS):
        """
        Returns Cheers configs
        :param str company: Company
        :param str locale: Language
        :param str _type: Configs type
        """
        query = cls.query.with_entities(
            cls.id,
            cls.location_id,
            cls.product_id,
            cls.product_sku,
            cls.category,
            cls.category_id,
            cls.cheers_logo_url,
            Category.name.label('api_name'),
            ConfigurationCheersTranslation.consent_confirmation_message,
            ConfigurationCheersTranslation.age_restriction_message,
            ConfigurationCheersTranslation.redemption_confirm_message,
            ConfigurationCheersTranslation.drinking_age_confirmation_message,
            ConfigurationCheersTranslation.not_interested_in_cheers_offers_message,
            ConfigurationCheersTranslation.error_message_to_select_an_option,
            ConfigurationCheersTranslation.product_information
        ).join(
            ConfigurationCheersTranslation,
            and_(
                ConfigurationCheersTranslation.config_id == cls.id,
                ConfigurationCheersTranslation.locale == locale
            )
        ).join(
            Category,
            cls.category_id == Category.id
        ).filter(
            cls.company == company,
            cls.type == _type
        )

        if location_id:
            query = query.filter(cls.location_id == location_id)

        return query.all()
