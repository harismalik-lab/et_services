"""
Country Translation Model
"""
from sqlalchemy import VARCHAR, Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin

__author__ = 'osamaa@theentertainerasia.com'


class CountryTranslation(db.Model, Mixin):
    __tablename__ = 'country_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    country_id = Column(INTEGER)
    locale = Column(String(5), default='en')
    name = Column(VARCHAR)
