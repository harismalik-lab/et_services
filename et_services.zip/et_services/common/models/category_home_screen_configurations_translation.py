"""
Category home screen configuration translation
"""
from sqlalchemy import Column, String, text
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class CategoryHomeScreenConfigurationsTranslation(db.Model, Mixin):
    __tablename__ = 'category_home_screen_configurations_translation'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    config_id = Column(INTEGER(11), nullable=False, index=True)
    locale = Column(String(5), index=True, server_default=text("'en'"))
    title = Column(String(100))
    title_locked = Column(String(100))
