"""
Tour table of Entertainer Tours schema.
"""
import datetime

from sqlalchemy import VARCHAR, Column, DateTime, String, text
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_TOURS
from ..models.db import db
from ..models.mixin import Mixin

from ..models.tour_booking_dates import TourBookingDates
from ..models.tour_booking_time_slots import TourBookingTimeSlots


class Tour(db.Model, Mixin):
    __tablename__ = 'tour'
    __table_args__ = {'schema': ENTERTAINER_TOURS}

    id = Column(INTEGER(11), primary_key=True)
    offer_id = Column(INTEGER(11))
    outlet_id = Column(INTEGER(11), index=True)
    merchant_id = Column(INTEGER(11), index=True)
    group_size = Column(SMALLINT(10), server_default=text("'15'"))
    is_published = Column(TINYINT(1), nullable=False, index=True, server_default=text("'0'"))
    is_refundable = Column(TINYINT(1), server_default=text("'0'"))
    refund_percent = Column(INTEGER(11))
    terms_conditions = Column(String(1000))
    cancellation_policy = Column(String(1000))
    booking_lead_time = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    cancel_lead_time = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    inclusion_one = Column(VARCHAR(500))
    inclusion_two = Column(VARCHAR(500))
    inclusion_three = Column(VARCHAR(500))
    all_booking_days = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    disabled = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    timezone = Column(VARCHAR(500))
    updated_by = Column(VARCHAR(500))
    validity_date = Column(DateTime)
    is_active = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    created_date = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @classmethod
    def get_availabilities(cls, **kwargs):
        """
        Get tour availabilities for TE tour.
        """
        query = cls.query
        select_entities = [
            cls.id.label('tour_id'),
            cls.booking_lead_time,
            TourBookingDates.booking_date,
            TourBookingTimeSlots.id.label('slot_id'),
            TourBookingTimeSlots.booking_start_time.label('start_time'),
            TourBookingTimeSlots.booking_end_time.label('end_time'),
            TourBookingTimeSlots.total_spots,
            TourBookingTimeSlots.available_spots
        ]
        query = query.join(TourBookingDates, cls.id == TourBookingDates.tour_id)
        query = query.join(TourBookingTimeSlots, TourBookingDates.id == TourBookingTimeSlots.booking_date_id)
        query = query.with_entities(*select_entities)

        query = query.filter(
            cls.is_active == 1,
            cls.is_published == 1,
            cls.validity_date >= datetime.datetime.now(),
            TourBookingDates.is_active == 1,
            TourBookingTimeSlots.is_active == 1,
            TourBookingTimeSlots.available_spots > 0
        )

        if kwargs.get('tour_id'):
            query = query.filter(cls.id == kwargs['tour_id'])

        if kwargs.get('for_date'):
            query = query.filter(TourBookingDates.booking_date == kwargs['for_date'])
        elif kwargs.get('start_date') and kwargs.get('end_date'):
            query = query.filter(TourBookingDates.booking_date.between(kwargs['start_date'], kwargs['end_date']))

        if kwargs.get('start_time'):
            query = query.filter(TourBookingTimeSlots.booking_start_time > kwargs['start_time'])

        query = query.order_by(TourBookingTimeSlots.booking_start_time)

        return query.all()


