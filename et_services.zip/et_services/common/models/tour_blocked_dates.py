"""
BlockedDates table of Entertainer Tours schema.
"""
from sqlalchemy import Column, Date, String, text
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP

from ..constants import ENTERTAINER_TOURS
from ..models.db import db
from ..models.mixin import Mixin


class TourBlockedDates(db.Model, Mixin):
    __tablename__ = 'blocked_dates'
    __table_args__ = {'schema': ENTERTAINER_TOURS}

    id = Column(INTEGER(11), primary_key=True)
    tour_id = Column(INTEGER(11), nullable=False)
    block_from = Column(Date, nullable=False, index=True)
    block_to = Column(Date, nullable=False, index=True)
    block_reason = Column(String(255))
    block_type = Column(String(10), server_default=text("''"))
    created_at = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(TIMESTAMP)
    created_from = Column(String(40))
    updated_from = Column(String(40))
    created_by = Column(String(50))
    updated_by = Column(String(50))
