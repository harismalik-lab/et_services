"""
CustomerOrder model of EntertainerBusiness schema.
"""
from sqlalchemy import Column, String, TIMESTAMP, text, Date, Text, Float
from sqlalchemy.dialects.mysql import INTEGER, TINYINT, LONGTEXT

from ..constants import ENTERTAINER_BUSINESS
from ..models.mixin import Mixin
from ..models.db import db


class CustomerOrderHistory(db.Model, Mixin):
    __tablename__ = 'customer_order_history'
    __table_args__ = ({
        "schema": ENTERTAINER_BUSINESS,
        "comment": 'Customer Order History'
    })

    id = Column(INTEGER(11), primary_key=True)
    order_id = Column(INTEGER(11), index=True)
    order_number = Column(String(255), index=True)
    merchant_sf_id = Column(String(20), index=True)
    outlet_sf_id = Column(String(20), index=True)
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    customer_id = Column(INTEGER(11), index=True)
    customer_email = Column(String(255))
    customer_ip = Column(String(30))
    server_ip = Column(String(30))
    items_count = Column(TINYINT(11))
    order_currency = Column(String(10))
    base_currency = Column(String(10))
    payment_method = Column(String(50))
    order_status_id = Column(INTEGER(11), index=True, server_default=text("'0'"))
    total_paid = Column(Float(8), server_default=text("'0.0000'"))
    base_total_paid = Column(Float(8), server_default=text("'0.0000'"))
    sub_total = Column(Float(8), server_default=text("'0.0000'"))
    base_sub_total = Column(Float(8), server_default=text("'0.0000'"))
    total_discount = Column(Float(8), server_default=text("'0.0000'"))
    base_total_discount = Column(Float(8), server_default=text("'0.0000'"))
    delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    base_delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    delivery_instructions = Column(String(500))
    delivery_time = Column(INTEGER(11), server_default=text("'0'"))
    cc_charge_id = Column(String(255))
    cc_type = Column(String(50))
    cc_last_four_digits = Column(INTEGER(11))
    placed_from = Column(String(50))
    app_version = Column(String(50))
    tracking_number = Column(String(255))
    reject_reason = Column(String(255))
    refund_amount = Column(Float(8), server_default=text("'0.0000'"))
    customer_address_id = Column(INTEGER(11), server_default=text("'0'"))
    sub_status_id = Column(INTEGER(11), index=True)
    base_tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    settlement_id = Column(INTEGER(11), index=True)
    product_sku = Column(String(20))
    customer_name = Column(String(250))
    te_commission_from_merchant = Column(Float(8), server_default=text("'0.0000'"))
    te_checkout_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_auth_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue_after_vat = Column(Float(8), server_default=text("'0.0000'"))
    vat_payable_on_te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    refund_to_merchant = Column(Float(8), server_default=text("'0.0000'"))
    order_process_channel = Column(String(50))
    order_edit_status = Column(TINYINT(1), index=True, server_default=text("'0'"))
    refund_reason = Column(String(500))
    refund_by = Column(String(100))
    refund_to = Column(String(100))
    company = Column(String(50), nullable=False, index=True, server_default=text("'entertainer'"))
    company_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'50'"))
    capture_retry = Column(TINYINT(1), server_default=text("'0'"))
    location_id = Column(INTEGER(11), nullable=False, server_default=text("'1'"))
    order_json = Column(Text)
    card_type = Column(String(20))
    commission_delivery_vat = Column(String(50))
    refund_retry = Column(TINYINT(1), server_default=text("'0'"))
    third_party_delivery_fee = Column(Float(8))
    delivery_type = Column(String(15))
    delivery_area_id = Column(INTEGER(11))
    delivery_charges_to_outlet = Column(Float)
    third_party_delivey_settled = Column(TINYINT(1), server_default=text("'0'"))
    module_id = Column(String(45), nullable=False)
    external_transaction_id = Column(String(200))
    qr_code = Column(Text)
    is_cancelable = Column(TINYINT(1), index=True, server_default=text("'1'"))
    is_active = Column(TINYINT(1), index=True, server_default=text("'1'"))
    is_zero_order = Column(TINYINT(1), server_default=text("'0'"))
    updated_date = Column(TIMESTAMP, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    created_date = Column(TIMESTAMP, nullable=False, index=True, server_default=text("CURRENT_TIMESTAMP"))
    order_expire_after = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    checkin_date = Column(Date)
    checkout_date = Column(Date)
    number_of_rooms = Column(TINYINT(1))
    room_type = Column(Text)
    special_instruction = Column(String(256))
    payment_mode = Column(TINYINT(1), server_default=text("'1'"), comment='0 for offline,  1 for online')
    no_of_adults = Column(INTEGER(11), server_default=text("'0'"))
    no_of_childrens = Column(INTEGER(11), server_default=text("'0'"))

    @classmethod
    def add_item(cls, **kwargs):
        """
        Adds order item in the customer's order history.
        """
