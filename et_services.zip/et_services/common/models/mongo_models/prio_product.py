import datetime

from flask import g

from pymongo import UpdateOne

db = g.mongo_db


class PrioProduct(db.Document):

    product_id = db.IntField()
    title = db.StringField()
    ent_location_id = db.IntField()

    location_id = db.IntField()
    supplier_id = db.IntField()
    prio_json = db.StringField()

    is_active = db.BooleanField(default=True)
    date_created = db.DateTimeField(default=datetime.datetime.now)
    date_updated = db.DateTimeField(default=datetime.datetime.now)

    meta = {
        'collection': 'products',
        'indexes':
            [
                {'fields': ['+product_id']},
                {'fields': ['+ent_location_id']},
            ]
    }

    @classmethod
    def bulk_upsert(cls, docs):
        """
        Bulk inserts using PyMongo update to improve performance since MongoEngine is slow.

        :param list docs: List of dicts of mongo documents that need to be inserted/updated.
        """
        write_operation = False
        upsertions = []

        for doc in docs:
            upsertions.append(
                UpdateOne(
                    filter={'product_id': doc['product_id']},
                    update={'$set': doc},
                    upsert=True
                ))

        if upsertions:
            write_operation = cls._get_collection().bulk_write(upsertions, ordered=False)

        return write_operation

    @classmethod
    def get_products(cls, **kwargs):
        """
        Gets products from database against passed keyword arguments.
        """

        supplier_id = kwargs.get('supplier_id')
        product_id = kwargs.get('product_id')
        get_count = kwargs.get('get_count')
        get_one = kwargs.get('get_one')

        products = cls.objects.all()

        if supplier_id:
            products = products.filter(supplier_id=supplier_id)

        if product_id:
            products = products.filter(product_id=product_id)

        products = products.filter(is_active=True)

        if get_count:
            return len(products)

        if get_one:
            return products.first()

        return products
