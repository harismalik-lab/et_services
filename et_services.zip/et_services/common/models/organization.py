"""
Organization model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.mixin import Mixin


class Organization(db.Model, Mixin):
    __tablename__ = 'organization'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    parent_id = Column(INTEGER(11))
    sf_id = Column(String(20), unique=True)
    phone = Column(String(50))
    website = Column(String(50))
    email = Column(String(100))
    password = Column(String(100))
