"""
Outlet Model
"""
import datetime

from flask import g
from sqlalchemy import (TIMESTAMP, Column, Float, ForeignKey, Index, String,
                        and_, case, func, literal_column, or_)
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT
from sqlalchemy.sql.functions import coalesce

from ..constants import (BODY, CATEGORY_API_NAME_ALL, CATEGORY_API_NAME_BODY,
                         CATEGORY_API_NAME_LEISURE,
                         CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
                         CATEGORY_API_NAME_SERVICES, CATEGORY_API_NAME_TRAVEL,
                         EN, ENT_COMPANY_TYPE, ENTERTAINER_WEB, LEISURE,
                         MERCHANT_ATTRIBUTES_BODY, MERCHANT_ATTRIBUTES_LEISURE,
                         MERCHANT_ATTRIBUTES_RESTAURANTS_AND_BARS,
                         MERCHANT_ATTRIBUTES_RETAIL,
                         MERCHANT_ATTRIBUTES_SERVICES,
                         MERCHANT_ATTRIBUTES_TRAVEL, OFFER_ATTRIBUTES,
                         PACKAGE_ATTR_MAPPING, PACKAGE_ATTRIBUTES,
                         REDEEMBILITY_NOT_REDEEMABLE, RESTAURANTS_AND_BARS,
                         RETAIL, SERVICES, TRAVEL, VALID_CATEGORIES)
from ..models.db import db
from ..models.dm_menu_company import DmMenuCompany
from ..models.location import Location
from ..models.merchant import Merchant
from ..models.merchant_attributes_body import MerchantAttributesBody
from ..models.merchant_attributes_fashion_and_retail import \
    MerchantAttributesFashionAndRetail
from ..models.merchant_attributes_leisure import MerchantAttributesLeisure
from ..models.merchant_attributes_restaurants_and_bars import \
    MerchantAttributesRestaurantsAndBar
from ..models.merchant_attributes_services import MerchantAttributesService
from ..models.merchant_attributes_travel import MerchantAttributesTravel
from ..models.merchant_translation import MerchantTranslation
from ..models.offer_attribute import OfferAttribute
from ..models.product import Product
from ..models.product_offer import ProductOffer
from ..models.wl_company import WlCompany
from .wl_product import WlProduct

cache = g.cache


class Outlet(db.Model):
    __tablename__ = 'outlet'
    __table_args__ = (
        Index('idx_outlet_merchant_active', 'merchant_id', 'active'),
        Index('idx_outlet_active_location', 'active', 'location_id'),
        Index('idx_oulet_merchant_active_location', 'merchant_id', 'active', 'location_id'),
        {"schema": ENTERTAINER_WEB}
    )

    AVERAGE_PREP_TIME_TEXT = "Average preparation time: "
    AVERAGE_PREP_TIME_KEY = "order_prep_time"

    id = Column(INTEGER(11), primary_key=True)

    sf_id = Column(String(20), unique=True, comment='Salesforce ID. OXXXXXX')
    merchant_id = Column(ForeignKey(Merchant.id, ondelete='SET NULL', onupdate='SET NULL'), nullable=False, index=True)
    location_id = Column(ForeignKey('location.id', ondelete='SET NULL', onupdate='SET NULL'), index=True)
    product_location = Column(String(100))
    lat = Column(Float(10))
    lng = Column(Float(10))
    email = Column(String(255))
    telephone = Column(String(45))
    fax = Column(String(45))
    delivery_telephone = Column(String(45))
    active = Column(TINYINT(1), nullable=False, index=True, default=0)
    billing_country = Column(String(45), index=True)
    area_group = Column(String(255))
    ta_location_id = Column(INTEGER(10))
    ta_rating = Column(Float(6))
    ta_reviews_count = Column(INTEGER(11))
    ta_rating_img_url = Column(String(255))
    redemption_emails = Column(String(500))
    amz_update_time = Column(TIMESTAMP, default=datetime.datetime.now)
    billing_city = Column(String(250))
    sf_account_id = Column(String(50))
    merlin_url = Column(String(500))
    integration_type = Column(String(100))
    integration_type_other = Column(String(255))
    min_order_amount = Column(Float(10))
    del_charge_total = Column(Float(10))
    del_charge_min = Column(Float(10))
    min_order_cap = Column(BIT(1))
    del_charge_on_total_order = Column(BIT(1))
    del_charge_on_less_than_min = Column(BIT(1))
    cinema_venue_id = Column(INTEGER(11))
    table_reservation_enabled = Column(BIT(1))
    table_reservation_email = Column(String(550))
    nfc_tag_key = Column(String(50))
    nfc_tag_status = Column(String(10))
    own_delivery = Column(BIT(1))
    last_mile_delivery = Column(TINYINT(1), default=0)
    take_away_enabled = Column(TINYINT(1), default=0)
    exclusion_calendar_access = Column(BIT(1))
    invoice_entity_id = Column(String(100))
    invoice_entity_name = Column(String(100), default='test')
    cinema_site_id = Column(String(200))
    cinema_online_booking_enabled = Column(TINYINT(1), nullable=False, default=0)
    cinema_offset_from_utc = Column(String(5))
    cinema_timezone = Column(String(50))
    external_id = Column('af_external_id', String(50), index=True)

    @classmethod
    def get_by_id(cls, outlet_id):
        """
        Get outlet info
        :param int outlet_id: Outlet Id
        :rtype: Outlet
        """
        return cls.query.filter(cls.id == outlet_id).first()

    @classmethod
    def get_by_id_and_offer_id(cls, outlet_id, offer_id):
        """
        Get outlet info
        :param offer_id:
        :param int outlet_id: Outlet Id
        :rtype: Outlet
        """
        from ..models.outlet_offer import OutletOffer
        return cls.query.with_entities(
            cls.sf_id
        ).join(
            OutletOffer,
            cls.id == OutletOffer.outlet_id
        ).filter(
            cls.id == outlet_id,
            OutletOffer.offer_id == offer_id
        ).first()

    @classmethod
    def find_by_merchant(cls, merchant_id, location_id=0, latlong='0,0', locale=EN):
        """
        Find active outlets by merchant and other optional criteria.
        :param int merchant_id: id of merchant
        :param int location_id: id of location
        :param str latlong: String of latitude and longitude appended by coma
        :param str locale: locale language
        :rtypeorm obj:
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.offer import Offer

        query = cls.query.outerjoin(OutletTranslation, cls.id == OutletTranslation.outlet_id)
        query = query.join(OutletOffer, cls.id == OutletOffer.outlet_id)
        query = query.join(Offer, OutletOffer.offer_id == Offer.id)
        query = query.with_entities(
            cls.id,
            cls.email,
            cls.telephone,
            cls.lat,
            cls.lng,
            coalesce(cls.delivery_telephone, '').label('delivery_telephone'),
            coalesce(cls.merlin_url, '').label('merlin_url'),
            OutletTranslation.name,
            OutletTranslation.description,
            OutletTranslation.human_location,
            OutletTranslation.neighborhood,
            OutletTranslation.mall,
            OutletTranslation.hotel,

        )
        query = query.filter(
            cls.merchant_id == merchant_id,
            cls.active == 1,
            OutletTranslation.locale == locale,
        )
        if location_id:
            query = query.filter(cls.location_id == location_id)

        query = query.order_by(OutletTranslation.name.asc()).group_by(cls.id)

        return query.all()

    @classmethod
    def find_by_merchant_v3(cls, **kwargs):
        """
        V3: Find active outlets by merchant and other optional criteria.
        """
        from ..models.outlet_translation import OutletTranslation
        from ..models.outlet_offer import OutletOffer
        from ..models.offer import Offer
        from ..utils.api_utils import get_table_booking_enabled_location_ids_against_company

        merchant_id = kwargs.get('merchant_id')
        location_id = kwargs.get('location_id')
        locale = kwargs.get('locale')
        outlet_id = kwargs.get('outlet_id')
        cashless_delivery = kwargs.get('cashless_delivery')
        table_booking_location_id = kwargs.get('table_booking_location_id')
        table_reservation_enabled = kwargs.get('table_reservation_enabled')
        company = kwargs.get('company')

        selected_cols = []
        query = cls.query
        selected_cols.extend([
            cls.id,
            cls.billing_country.label('billingcountry'),
            coalesce(OutletTranslation.name, '').label('name'),
            coalesce(OutletTranslation.description, '').label('description'),
            cls.email,
            cls.telephone,
            coalesce(cls.delivery_telephone, '').label('delivery_telephone'),
            cls.lat,
            cls.lng,
            func.max(OutletTranslation.human_location).label('human_location'),
            func.max(OutletTranslation.neighborhood).label('neighborhood'),
            coalesce(OutletTranslation.mall, '').label('mall'),
            coalesce(OutletTranslation.hotel, '').label('hotel'),
            literal_column('0').label('distance'),
            coalesce(cls.ta_location_id, 0).label('tripadvisor_id'),
            coalesce(cls.merlin_url, '').label('merlin_url'),
            coalesce(cls.min_order_amount, 0).label('min_order_amount'),
            cls.sf_id.label('sfId'),
            func.ifnull(cls.ta_rating, 0).label('tripadvisor_rating'),
            cls.take_away_enabled,
            func.ifnull(cls.ta_reviews_count, 0).label('trip_adv_rating_reviews_count'),
            coalesce(cls.ta_rating_img_url, '').label('trip_adv_rating_image'),
            literal_column("''").label('trip_adv_webview_link'),
            cls.table_reservation_enabled,
            func.ifnull(cls.last_mile_delivery, 0).label('last_mile_delivery'),
            cls.own_delivery,
            cls.location_id
        ])
        if outlet_id and cashless_delivery:
            selected_cols.extend([
                coalesce(cls.del_charge_total, 0).label('del_charge_total'),
                coalesce(cls.del_charge_min, 0).label('del_charge_min'),
                coalesce(cls.min_order_cap, 0).label('min_order_cap'),
                coalesce(cls.del_charge_on_less_than_min, 0).label('del_charge_on_less_than_min'),
                coalesce(cls.del_charge_on_total_order, 0).label('del_charge_on_total_order')
            ])

        if table_reservation_enabled:
            if table_booking_location_id in get_table_booking_enabled_location_ids_against_company(company):
                from ..models.tb_booking_settings import TbBookingSetting
                query = query.outerjoin(TbBookingSetting, cls.id == TbBookingSetting.outlet_id)
                selected_cols.extend([
                    coalesce(TbBookingSetting.disabled, 0).label('tb_reservation_disabled'),
                    TbBookingSetting.is_published,
                ])
            else:
                selected_cols.append(literal_column('1').label('tb_reservation_disabled'))

        query = query.join(OutletTranslation, cls.id == OutletTranslation.outlet_id)
        query = query.filter(OutletTranslation.locale == locale, cls.merchant_id == merchant_id)

        if outlet_id and cashless_delivery:
            query = query.filter(cls.id == outlet_id)

        query = query.join(OutletOffer, cls.id == OutletOffer.outlet_id)

        query = query.join(Offer, Offer.id == OutletOffer.offer_id)
        query = query.group_by(OutletTranslation.id)
        query = query.order_by(func.max(OutletTranslation.name).asc())

        if location_id:
            query = query.filter(cls.id == location_id)

        query = query.with_entities(*selected_cols)
        return query.all()

    @classmethod
    @cache.memoize(timeout=1800)
    def get_outlet_lat_lng_band_info(cls, outlet_id, location_id):
        """
        Returns object of outlet's info

        :param  int outlet_id: outlet id
        :param  int location_id: location id
        :return return the outlet info based on location id
        """
        from ..models.quiq_up_settings import QuiqUpSetting
        from ..models.dm_area_coordinate import DmAreaCoordinate

        query = cls.query.join(DmAreaCoordinate, cls.id == DmAreaCoordinate.outlet_id)
        query = query.outerjoin(QuiqUpSetting, QuiqUpSetting.id == DmAreaCoordinate.band_id)
        query = query.with_entities(
            cls.id,
            cls.lat,
            cls.lng,
            cls.last_mile_delivery,
            func.group_concat(QuiqUpSetting.id.distinct()).label('bands')
        )
        query = query.filter(
            cls.id == outlet_id,
            cls.location_id == location_id,
            DmAreaCoordinate.status == 1,
            DmAreaCoordinate.is_approved == 1
        )
        return query.group_by(cls.id).first()

    @classmethod
    def find_by_outlets(
            cls,
            outlet_ids,
            is_cuckoo,
            category,
            locale,
            product_ids=None,
            user_include_cheers=False
    ):
        """
        return offers against given outlet ids
        :param list outlet_ids:
        :param bool is_cuckoo:
        :param str category:
        :param str locale:
        :param int product_ids:
        :param bool user_include_cheers:
        :return:
        """
        from ..models.outlet_offer import OutletOffer
        if product_ids is None:
            product_ids = []
        from ..models.product import Product
        from ..models.product_offer import ProductOffer
        from ..models.product_translation import ProductTranslation
        from ..models.offer_translation import OfferTranslation
        from ..models.offer import Offer

        query = cls.query.join(OutletOffer, cls.id == OutletOffer.outlet_id)
        query = query.join(Offer, Offer.id == OutletOffer.offer_id)
        query = query.join(OfferTranslation, Offer.id == OfferTranslation.offer_id)
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.join(ProductTranslation, Product.id == ProductTranslation.product_id)
        query = query.with_entities(
            Offer.id.distinct().label('id'),
            func.group_concat(cls.id.distinct()).label('outlet_ids'),
            func.max(OfferTranslation.name).label('name'),
            func.max(OfferTranslation.description).label('description'),
            Offer.merchant_category,
            Offer.sub_category,
            Offer.voucher_type,
            Offer.spend,
            Offer.reward,
            Offer.percentage_off,
            coalesce(OfferTranslation.merchant_rules_of_use, "").label('conditions'),
            coalesce(OfferTranslation.merchant_rules_of_use, "").label('voucher_restrictions'),
            Offer.type,
            Offer.quantity,
            coalesce(OfferTranslation.card_line, "").label('card_line'),
            Offer.voucher_restriction1,
            Offer.voucher_restriction2,
            Offer.savings_estimate,
            coalesce(Offer.local_currency, "").label('local_currency'),
            Offer.savings_estimate_local_currency,
            Offer.valid_from.label('valid_from_date'),
            Offer.valid_to.label('expiration_date'),
            func.group_concat(Product.id.distinct()).label('product_id'),
            func.group_concat(Product.sf_id.distinct()).label('product_sku'),
            func.group_concat(ProductTranslation.name.distinct()).label('product_name'),
            func.max(Product.is_cheers).label('is_cheers'),
            func.max(Product.delivery_enabled).label('is_delivery'),
            coalesce(Offer.item_code, "").label('item_code'),
            Offer.is_point_based_offer,
            Product.purchase_product_id,
            Product.show_buy_mobile,
            Product.product_type,
            func.group_concat(
                func.concat(
                    Product.id,
                    "_",
                    Product.sf_id,
                    "_",
                    ProductTranslation.name
                ).distinct()
            ).label('product_id_sku_name')
        )
        if product_ids:
            query = query.filter(Product.id.in_(product_ids))
        query = query.filter(cls.id.in_(outlet_ids))
        query = query.filter(
            Product.isactive == 1,
            Offer.status == "Active",
            OfferTranslation.locale == locale,
            ProductTranslation.locale == locale
        )

        if is_cuckoo:
            query = query.filter(Product.delivery_enabled == 0, Product.is_cheers == 0)

        if not user_include_cheers:
            query = query.filter(Product.is_cheers == 0)

        if category in VALID_CATEGORIES:
            query = query.filter(Offer.merchant_category == category)

        query = query.filter(Offer.is_point_based_offer == 0)
        query = query.group_by(Offer.id)
        offers = query.all()
        return offers

    @classmethod
    def find_offers(cls, locale, company, product_ids, product_sku, offer_redeemability, show_only_core_product_offers,
                    is_cuckoo, is_cheers, is_delivery, show_monthly_offers, show_new_offers, is_more_sa,
                    user_include_cheers, category, _is_fuzzy_search_on, _fuzzy_search_outlet_ids,
                    sub_category_filter, outlet_id, location_id, is_company_specific,
                    offer_valid_from_start_date, offer_valid_from_cut_off_date,
                    show_merlin_offers=False, merchant_categories=[]):

        from ..models.outlet_offer import OutletOffer
        from ..models.product import Product
        from ..models.category import Category
        from ..utils.api_utils import get_configured_sku_by_company
        from ..models.offer import Offer
        from ..models.offer_translation import OfferTranslation
        from ..models.redemption import Redemption

        query = cls.query.with_entities(
            Offer.id,
            Offer.merchant_category,
            coalesce(Offer.sub_category, '').label('sub_category'),
            func.group_concat(Outlet.id.distinct()).label('outlet_ids'),
            Offer.valid_from.label('valid_from_date'),
            Offer.valid_to.label('expiration_date'),
            Offer.type,
            func.concat(Offer.NOT_REDEEMABLE, '').label('redeemability'),
            Offer.quantity,
            # 0 as times_redeemed
            OfferTranslation.name.label('offer_name'),
            Offer.savings_estimate,
            # func.group_concat(Product.id.distinct()).label('product_id'),
            # func.group_concat(Product.sf_id.distinct()).label('product_sku'),
            Product.id.label('product_id'),
            Product.sf_id.label('product_sku'),
            func.max(Product.is_cheers).label('is_cheers'),
            func.max(Product.delivery_enabled).label('is_delivery'),
            func.max(Product.is_more_sa).label('is_more_sa'),
            func.max(Product.ismember).label('is_monthly'),
            Offer.is_point_based_offer
        )
        query = query.join(OutletOffer, OutletOffer.outlet_id == cls.id)
        query = query.join(Offer, Offer.id == OutletOffer.offer_id)
        query = query.join(
            OfferTranslation,
            and_(
                Offer.id == OfferTranslation.offer_id,
                OfferTranslation.locale == locale
            )
        )
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, and_(ProductOffer.product_id == Product.id, Product.isactive))
        query = query.filter(coalesce(Product.cashless_delivery_enabled, 0) == 0, Offer.status == 'Active')

        if product_sku:
            if ',' not in product_sku:
                query = query.filter(Product.sf_id == product_sku)
            else:
                query = query.filter(Product.sf_id.in_(product_sku.split(',')))
            # If multiple skus are passed, it means it's not all offers tab and we don't show merlin offers in
            # custom tabs
            if not show_merlin_offers:
                query = query.filter(Product.has_merlin_offers != 1)
            if offer_redeemability in (
                    Redemption.REDEEMABILITY_REDEEMABLE,
                    Redemption.REDEEMABILITY_REDEEMABLE_REUSABLE,
                    Redemption.REDEEMABILITY_REUSABLE
            ):
                query = query.filter(Product.id.in_(product_ids))

        else:
            # for locked / buy tab
            if offer_redeemability == REDEEMBILITY_NOT_REDEEMABLE:
                query = query.join(
                    Product,
                    and_(
                        Product.product_id == Product.id,
                        Product.is_active,
                        Product.company == company
                    )
                )
            else:
                query = query.filter(Product.id.in_(product_ids))
                if is_company_specific:
                    if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
                        company_skus = get_configured_sku_by_company(company)
                        query = query.filter(Product.sf_id.in_(company_skus))

        if show_only_core_product_offers:
            query = query.filter(
                Product.delivery_enabled == 0,
                Product.is_cheers == 0,
                Product.is_more_sa == 0,
                Product.ismember == 0
            )
        if is_cuckoo:
            query = query.filter(Product.delivery_enabled == 0, Product.is_cheers == 0)
        if not is_cuckoo and is_delivery:
            query = query.filter(Product.delivery_enabled)
        if not is_cuckoo and is_cheers:
            query = query.filter(Product.is_cheers)
        # for monthly offers
        if show_monthly_offers:
            query = query.filter(Offer.type == Offer.TYPE_MEMBER)
        # for new offers
        if show_new_offers:
            query = query.filter(
                Offer.valid_from > offer_valid_from_start_date,
                Offer.valid_from > offer_valid_from_cut_off_date
            )
        if is_more_sa:
            query = query.filter(Product.is_more_sa)
        if not user_include_cheers:
            query = query.filter(Product.is_cheers == 0)
        if category.lower() == Category.ALL:  # For quick search
            query = query.filter(or_(Product.location_id == location_id, Product.istravel, Product.is_more_sa))
        elif category == CATEGORY_API_NAME_TRAVEL:  # Only for Travel
            query = query.filter(Product.istravel)
        else:  # For categories other than Travel
            query = query.filter(or_(Product.location_id == location_id, Product.is_more_sa))
        if _is_fuzzy_search_on and _fuzzy_search_outlet_ids:
            query = query.filter(Outlet.id.in_(_fuzzy_search_outlet_ids))
        # Apply Filter on Category
        if merchant_categories:
            query = query.filter(Offer.merchant_category.in_(merchant_categories))
        elif category and category.lower() != "all":
            # is_service_cat_merged_company = is_service_category_merged_company(company)
            # if is_service_cat_merged_company and category == CATEGORY_API_NAME_SERVICES:
            #     query = query.filter(
            #         OfferWlActive.merchant_category.in_([CATEGORY_API_NAME_RETAIL, CATEGORY_API_NAME_SERVICES])
            #     )
            # else:
            query = query.filter(Offer.merchant_category == category)
        # Apply Filter on sub_category
        if (
                sub_category_filter and
                len(sub_category_filter.strip()) > 0 and
                sub_category_filter.strip().lower() != Category.ALL
        ):
            query = query.filter(Offer.sub_category == sub_category_filter)
        if outlet_id:
            query = query.filter(Outlet.id == outlet_id)

        # exclude points based offers
        query = query.filter(Offer.is_point_based_offer == 0)

        query = query.group_by(Offer.id)
        return query.all()

    @classmethod
    def find_by_criteria_merchant_attributes(cls, criteria=None, locale=EN, **kwargs):
        """
        Gets merchant against a given criteria.
        :param criteria: criteria to find merchant
        :param str locale: locale language
        :param kwargs: key word arguments
        :rtype: list
        """
        from ..models.outlet_translation import OutletTranslation
        if criteria is None:
            criteria = {}
        category = criteria['category']
        filters_selected_for_yes = criteria['filters_selected_for_yes']
        filters_selected_for_no = criteria['filters_selected_for_no']
        merchant_attributes = []
        lat_lng_exists = False
        if all([criteria['lat'], criteria['lat'] != '0,0', criteria['lng'], criteria['lng'] != ',']):
            lat_lng_exists = True

        query = cls.query
        if lat_lng_exists:
            select_lat_lng = func.acos(
                func.cos(
                    func.radians(
                        90.0 - criteria['lat']
                    )
                ) * func.cos(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) + func.sin(
                    func.radians(
                        90.0 - (criteria['lat'])
                    )
                ) * func.sin(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) * func.cos(
                    func.radians(
                        (criteria['lng']) - Outlet.lng
                    )
                )
            ) * 6371000.0
        else:
            select_lat_lng = literal_column('0')

        query = query.with_entities(
            Outlet.id,
            Outlet.sf_id.label('sfId'),
            OutletTranslation.name,
            Outlet.email,
            Outlet.lat,
            Outlet.lng,
            OutletTranslation.human_location,
            OutletTranslation.neighborhood,
            OutletTranslation.mall,
            OutletTranslation.hotel,
            case(
                [
                    (
                        Outlet.ta_location_id.is_(None),
                        int(0)
                    )
                ],
                else_=Outlet.ta_location_id
            ).label('tripadvisor_id'),
            select_lat_lng.label('distance'),
            Merchant.id.label('merchant_id'), MerchantTranslation.name.label('merchant_name'),
            MerchantTranslation.name.label('merchant_name_for_outlet'),  # Check duplicate
            Merchant.category.label('merchant_category'), Merchant.categories.label('merchant_categories'),
            coalesce(MerchantTranslation.cuisine, '').label('merchant_cuisine'),
            Merchant.cuisines.label('merchant_cuisines'),
            Merchant.logo_retina_url.label('merchant_logo_url'),
            Merchant.logo_non_retina_url.label('merchant_logo_small_url'),
            Merchant.photo_retina_url.label('merchant_photo_url'),
            Merchant.photo_non_retina_url.label('merchant_photo_small_url')
        )
        query = query.join(
            OutletTranslation,
            and_(
                Outlet.id == OutletTranslation.outlet_id,
                OutletTranslation.locale == locale
            )
        )
        query = query.join(Merchant, Outlet.merchant_id == Merchant.id)
        query = query.join(
            MerchantTranslation,
            and_(Merchant.id == MerchantTranslation.merchant_id,
                 MerchantTranslation.locale == locale
                 )
        )
        query = query.filter(Outlet.active == 1)
        include_merchant_attributes = False
        if any([(filters_selected_for_yes and filters_selected_for_yes[0] != ''), (
                filters_selected_for_no and filters_selected_for_no[0] != '')]):
            include_merchant_attributes = True

        is_category_matched = False
        if include_merchant_attributes and category:
            inner_join_table = ''
            if category == CATEGORY_API_NAME_BODY:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_BODY
                inner_join_table = MerchantAttributesBody
            elif category == CATEGORY_API_NAME_LEISURE:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_LEISURE
                inner_join_table = MerchantAttributesLeisure
            elif category == CATEGORY_API_NAME_RESTAURANTS_AND_BARS:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_RESTAURANTS_AND_BARS
                inner_join_table = MerchantAttributesRestaurantsAndBar
            elif category == CATEGORY_API_NAME_SERVICES:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_SERVICES
                inner_join_table = MerchantAttributesService
            elif category == CATEGORY_API_NAME_TRAVEL:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_TRAVEL
                inner_join_table = MerchantAttributesTravel

            if inner_join_table:
                query = query.join(inner_join_table, inner_join_table.merchant_id == Merchant.id)

            if is_category_matched:
                for include_filter in filters_selected_for_yes:
                    if include_filter in merchant_attributes:
                        query = query.filter(getattr(inner_join_table, include_filter).in_([1, 2]))

                for exclude_filter in filters_selected_for_no:
                    if exclude_filter in merchant_attributes:
                        query = query.filter(getattr(inner_join_table, exclude_filter).in_([0, 2]))

        if criteria['outlet_ids']:
            query = query.filter(Outlet.id.in_(criteria['outlet_ids']))
        if criteria['billing_country']:
            query = query.filter(Outlet.billing_country == criteria['billing_country'])
        if criteria['neighborhood']:
            query = query.filter(OutletTranslation.neighborhood, criteria['neighborhood'])
        if criteria['mall']:
            query = query.filter(OutletTranslation.mall == criteria['mall'])
        if criteria['hotel']:
            query = query.filter(OutletTranslation.hotel == criteria['hotel'])

        #  Filter down by radius around lat long
        if lat_lng_exists and criteria['radius']:
            query = query.having(select_lat_lng.label('distance') <= criteria['radius'])
        return query.all()

    @classmethod
    def cashless_delivery_outlets(cls, outlet_ids, company):
        """
        Calculate cashless_delivery_enabled based on outlets_ids

        :return: orm list
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.product_offer import ProductOffer
        from ..models.product import Product

        if outlet_ids:
            query = cls.query.join(OutletOffer, cls.id == OutletOffer.outlet_id)
            query = query.join(ProductOffer, OutletOffer.offer_id == ProductOffer.offer_id)
            query = query.join(Product, ProductOffer.product_id == Product.id)
            query = query.with_entities(
                Product.cashless_delivery_enabled,
                cls.id.label('outlet_id')
            )
            query = query.filter(
                cls.id.in_(outlet_ids),
                Product.cashless_delivery_enabled == 1,
                Product.company == company
            )
            return query.all()
        return []

    @classmethod
    def get_outlets_having_cinema_venue_ids(cls, outlet_ids=[]):
        """
        Gets outlet ids and cinema venue ids
        :param list outlet_ids: Outlet ids
        :rtype: dict
        """
        if outlet_ids:
            query = cls.query.filter(
                cls.id.in_(outlet_ids),
                cls.cinema_venue_id.isnot(None)
            ).with_entities(cls.id.label('outlet_id'), cls.cinema_venue_id)
            return query.all()
        return []

    @staticmethod
    def get_outlet_location_id(merchant_id, outlet_id=None):
        """
        get location id against provided outlet id.

        if outlet id not provided then return merchant first outlet location id.

        :param int merchant_id: merchant id
        :param int outlet_id: outlet id
        :return int: location id
        """
        query = Outlet.query.with_entities(Outlet.location_id)
        if outlet_id:
            query = query.filter(Outlet.id == outlet_id)
        else:
            query = query.filter(Outlet.merchant_id == merchant_id)
        data = query.first()
        if data:
            return data.location_id

    @staticmethod
    @cache.memoize(timeout=900)
    def get_outlet_array(location_id, category, company, locale='en', api_version='v67'):
        """
        Returns list of outlets
        :param str category: Merchant category
        :param str company: company
        :param locale: Locale
        :rtype: list
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.outlet_translation import OutletTranslation
        from ..models.product_offer import ProductOffer
        from ..models.offer import Offer
        from ..models.dm_outlet_setting import DmOutletSetting
        from common.utils.api_utils import outlets_array_processing

        query = Outlet.query.join(OutletTranslation, Outlet.id == OutletTranslation.outlet_id)
        query = query.join(Merchant, Outlet.merchant_id == Merchant.id)
        query = query.join(MerchantTranslation, Merchant.id == MerchantTranslation.merchant_id)
        query = query.join(OutletOffer, OutletOffer.outlet_id == Outlet.id)
        query = query.join(Offer, Offer.id == OutletOffer.offer_id)
        query = query.join(ProductOffer, Offer.id == ProductOffer.offer_id)
        query = query.join(Product, ProductOffer.product_id == Product.id)
        query = query.outerjoin(DmOutletSetting, and_(DmOutletSetting.outlet_id == Outlet.id,
                                                      and_(DmOutletSetting.disabled == 0,
                                                           DmOutletSetting.status == 1)))
        query = query.with_entities(
            Outlet.id, Outlet.sf_id.label('sfId'), OutletTranslation.name, Outlet.email, Outlet.telephone,
            Outlet.lat, Outlet.lng, OutletTranslation.human_location, OutletTranslation.neighborhood,
            OutletTranslation.mall, OutletTranslation.hotel,
            coalesce(Outlet.ta_location_id, 0).label('tripadvisor_id'),
            Merchant.id.label('merchant_id'),
            MerchantTranslation.name.label('merchant_name'),
            MerchantTranslation.name.label('merchant_name_for_outlet'),
            coalesce(MerchantTranslation.cuisine, "").label('merchant_cuisine'),
            Merchant.cuisines.label('merchant_cuisines'),
            coalesce(Merchant.ad_active_status, "").label('merchant_ad_travel_country'),
            Merchant.ad_active_status.label('merchant_ad_active_status'),
            Merchant.logo_retina_url.label('merchant_logo_url'),
            Merchant.logo_non_retina_url.label('merchant_logo_small_url'),
            Merchant.photo_non_retina_url.label('merchant_photo_small_url'),
            Merchant.photo_retina_url.label('merchant_photo_url'),
            Merchant.digital_section.label('merchant_digital_section'),
            DmOutletSetting.disabled.label('cashless_outlet_settings_enabled')
        )
        query = query.filter(
            Outlet.active == 1, OutletTranslation.locale == locale,
            MerchantTranslation.locale == locale,
            Offer.merchant_category == category,
            Product.company.like("{}%".format(company))
        )
        if location_id in Location.MORE_SA_LOCATIONS:
            query = query.filter(
                or_(
                    Product.location_id == location_id,
                    Product.is_more_sa == 1
                )
            )
        else:
            if location_id == Location.LOCATION_ID_SINGAPORE:
                query = query.filter(
                    or_(Product.location_id == location_id, Product.is_johor_bahru == 1))
            else:
                query = query.filter(Product.location_id == location_id)
                # TODO need to verify
                # sql_dal.set_parenthesised_where_clause(' AND IFNULL(p.is_johor_bahru,0)=0 ')
                query = query.filter(coalesce(Product.is_johor_bahru, 0) == 0)
        query = query.group_by(Outlet.id)
        outlets = query.all()

        return outlets_array_processing(outlets, category)

    def get_by_outlet_id_and_merchant_id(cls, outlet_id, merchant_id):
        """
        Returns pin against merchant_id and outlet_id
        :param int outlet_id: Outlet Id
        :param int merchant_id: Merchant Id
        """
        return cls.query.join(
            Merchant,
            and_(
                cls.merchant_id == Merchant.id,
                cls.merchant_id == merchant_id
            )
        ).with_entities(Merchant.pin).filter(
            cls.id == outlet_id
        ).first()

    @classmethod
    def get_by_merchant_pin_and_product_skus(cls, merchant_pin, product_skus):
        """
        Returns merchant against pin and product skus
        """
        from ..models.outlet_offer import OutletOffer
        from ..models.product_offer_wl_active import ProductOfferWlActive
        from ..models.product_wl_active import ProductWlActive
        from ..models.product import Product
        return cls.query.join(
            Merchant,
            and_(
                cls.merchant_id == Merchant.id,
            )
        ).join(
            OutletOffer,
            Outlet.id == OutletOffer.outlet_id
        ).join(
            ProductOfferWlActive,
            OutletOffer.offer_id == ProductOfferWlActive.offer_id
        ).join(
            ProductWlActive,
            ProductOfferWlActive.product_id == ProductWlActive.product_id
        ).join(
            MerchantTranslation,
            and_(cls.merchant_id == MerchantTranslation.merchant_id, MerchantTranslation.locale == EN)
        ).with_entities(
            Merchant.pin,
            Product.sf_id,
            Merchant.id,
            MerchantTranslation.name
        ).filter(
            Merchant.pin == merchant_pin,
            Product.sf_id.in_(product_skus)
        ).first()

    @classmethod
    def get_by_merchant_pin_af(cls, merchant_pin):
        """
        Returns merchant based on pin.

        # TODO: Should be in merchant model.
        """

        return cls.query.join(
            Merchant,
            and_(
                cls.merchant_id == Merchant.id,
                Merchant.pin == merchant_pin
            )
        ).join(
            MerchantTranslation,
            and_(cls.merchant_id == MerchantTranslation.merchant_id, MerchantTranslation.locale == EN)
        ).with_entities(
            Merchant.pin,
            Merchant.id,
            MerchantTranslation.name
        ).filter(coalesce(cls.external_id, '0') != '0', cls.external_id != "").first()

    @classmethod
    def get_by_ids(cls, outlet_ids, locale=EN, criteria=None, merchant_ids=None):
        """
        Gets merchant against a given criteria.
        :param merchant_ids:
        :param list|None outlet_ids: Outlet Ids
        :param str locale: locale language
        :param dict criteria: contains only lat lng info for now
        :rtype: list
        """
        from ..models.outlet_translation import OutletTranslation
        if criteria is None:
            criteria = {}
        if outlet_ids is None:
            outlet_ids = []
        if merchant_ids is None:
            merchant_ids = []

        lat_lng_exists = False
        if all([criteria['lat'], criteria['lat'] != '0,0', criteria['lng'], criteria['lng'] != ',']):
            lat_lng_exists = True

        query = cls.query
        if lat_lng_exists:
            select_lat_lng = func.acos(
                func.cos(
                    func.radians(
                        90.0 - criteria['lat']
                    )
                ) * func.cos(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) + func.sin(
                    func.radians(
                        90.0 - (criteria['lat'])
                    )
                ) * func.sin(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) * func.cos(
                    func.radians(
                        (criteria['lng']) - Outlet.lng
                    )
                )
            ) * 6371000.0
        else:
            select_lat_lng = literal_column('0')

        query = query.with_entities(
            Outlet.id, Outlet.sf_id.label('sfId'), OutletTranslation.name, Outlet.lat, Outlet.lng,
            OutletTranslation.human_location, OutletTranslation.neighborhood, OutletTranslation.mall,
            OutletTranslation.hotel,
            cls.merchant_id,
            select_lat_lng.label('distance')
        )
        query = query.join(
            OutletTranslation,
            and_(
                Outlet.id == OutletTranslation.outlet_id,
                OutletTranslation.locale == locale
            )
        )
        query = query.filter(Outlet.active == 1)
        query = query.filter(Outlet.id.in_(outlet_ids))
        query = query.filter(Outlet.merchant_id.in_(merchant_ids))
        if lat_lng_exists:
            query = query.order_by(select_lat_lng.asc())
        return query.all()

    @classmethod
    def get_outlets_by_external_id(cls, external_ids):
        """
        get outlets having `external_ids`
        :param external_ids:
        :return:
        """
        query = cls.query.with_entities(
            cls.external_id,
            cls.id.label('outlet_id'),
            cls.merchant_id,
            MerchantTranslation.name
        ).join(
            MerchantTranslation,
            and_(cls.merchant_id == MerchantTranslation.merchant_id, MerchantTranslation.locale == EN)
        )
        if isinstance(external_ids, list):
            query = query.filter(cls.external_id.in_(external_ids))
        else:
            query = query.filter(cls.external_id == external_ids)
        return query.all()

    @classmethod
    def find_offers_v3(cls, **kwargs):
        """
        Returns all the offers based on the criteria passed in the keyword args.
        The kwargs contain flags and parameters for offers.

        """

        from ..models.merchant import Merchant
        from ..models.offer import Offer
        from ..models.offer_translation import OfferTranslation
        from ..models.package import Package
        from ..models.product_offer import ProductOffer
        from ..models.outlet_offer import OutletOffer
        from ..models.redemption import Redemption
        from ..utils.api_utils import (
            get_delivery_enabled_location_ids_against_company, get_offer_monthly_status,
            get_takeaways_enabled_location_ids_against_company
        )

        company_type = kwargs['company_type']
        company = kwargs["company"]
        customer = kwargs.get('customer', {})
        product_ids = customer.get("product_ids", [])
        location_id = kwargs["location_id"]
        category = kwargs["category"]
        sub_categories_selected = kwargs["sub_categories_selected"]
        offer_redeemability = kwargs["offer_redeemability"]
        received_offer_ids = kwargs["received_offer_ids"]
        offer_types_selected = kwargs["offer_types_selected"]
        cashless_delivery_enabled = kwargs["cashless_delivery_enabled"]
        takeaways_enabled = kwargs["takeaways_enabled"]
        offer_attributes_selected = kwargs["offer_attributes_selected"]
        query_args = kwargs.get('query_string', [])
        is_cheers = kwargs.get("is_cheers")
        is_birthday = kwargs.get("is_birthday")
        is_delivery = kwargs.get("is_delivery")
        is_more_sa = kwargs.get("is_more_sa")
        is_travel = kwargs.get("is_travel")

        is_cashless_location = (
            location_id in get_delivery_enabled_location_ids_against_company(company) and cashless_delivery_enabled
        )
        is_takeaways_location = (
            location_id in get_takeaways_enabled_location_ids_against_company(company) and takeaways_enabled
        )

        if offer_attributes_selected:
            offer_attributes_selected_set = set(offer_attributes_selected)
            invalid_offer_attributes = offer_attributes_selected_set - OFFER_ATTRIBUTES
            offer_attributes_selected = offer_attributes_selected_set - invalid_offer_attributes

        select_list = [
            Offer.id,
            Offer.merchant_category,
            coalesce(Offer.sub_category, '').label('sub_category'),
            Offer.valid_from.label('valid_from_date'),
            Offer.valid_to.label('expiration_date'),
            Offer.type,
            func.concat(Redemption.NOT_REDEEMABLE, '').label('redeemability'),
            Offer.quantity,
            Offer.savings_estimate,
            Offer.is_take_away_offer,
            Offer.is_delivery_cashless_offer,
            literal_column("0").label("times_redeemed"),
            OfferTranslation.name.label('offer_name'),
            Product.id.label('product_id'),
            Product.sf_id.label('product_sku'),
            func.max(Product.is_cheers).label('is_cheers'),
            func.max(Product.delivery_enabled).label('is_delivery'),
            func.max(Product.is_more_sa).label('is_more_sa'),
            func.max(Product.ismember).label('is_monthly'),
            # B2C
            Merchant.is_for_members_only,
            Product.is_ent.label('is_entertainer'),
            Product.cashless_delivery_enabled,
            Product.product_type,
            Product.istravel.label('is_travel'),
            Product.has_merlin_offers.label('is_merlin_offer'),
            Product.has_cinema_offers,
            Product.is_johor_bahru,
            Product.has_bonus_offers.label('is_bonus_offer'),
            Product.is_core_fine_dining_product,
            Product.is_core_family_product,
            Product.is_core_fitness_product,
            Product.ismember
        ]
        if is_travel and offer_attributes_selected:
            select_list.extend([
                Package.is_relax.label("hww_relax"),
                Package.is_dine.label("hww_dine"),
                Package.is_play.label("hww_play"),
                Package.is_brunch.label("hww_brunch")
            ])

        if kwargs.get('isshared'):
            select_list.append(func.min(Outlet.id).label("outlet_ids"))
        else:
            select_list.append(func.group_concat(Outlet.id.distinct()).label('outlet_ids'))

        query = cls.query.join(OutletOffer, OutletOffer.outlet_id == cls.id)
        query = query.join(Offer, Offer.id == OutletOffer.offer_id)
        query = query.join(
            OfferTranslation,
            and_(
                OfferTranslation.offer_id == Offer.id,
                OfferTranslation.locale == kwargs["locale"]
            )
        )
        query = query.join(ProductOffer, ProductOffer.offer_id == Offer.id)

        query = query.join(
            Product,
            and_(
                Product.id == ProductOffer.product_id,
                Product.isactive == 1,
            )
        )

        if company_type != ENT_COMPANY_TYPE:
            query = query.join(
                WlProduct,
                and_(
                    WlProduct.product_sku == Product.sf_id,
                    WlProduct.isactive == 1,
                    WlProduct.wl_company == company
                )
            )
            if is_travel:
                query = query.filter(WlProduct.istravel == 1)
        else:
            query = query.filter(Product.is_ent == 1)

        query = query.join(Merchant, Merchant.id == Offer.merchant_id)

        if offer_attributes_selected:
            query = query.join(OfferAttribute, OfferAttribute.offer_id == Offer.id)
            if is_travel:
                query = query.join(Package, Package.offer_id == Offer.id)

        cashless_delivery_enabled_include = False
        if cashless_delivery_enabled:
            cashless_delivery_enabled_include = True
            if is_cashless_location and not takeaways_enabled:
                query = query.filter(
                    Product.cashless_delivery_enabled == 1,
                    Offer.is_delivery_cashless_offer == 1
                )
            elif is_takeaways_location:
                query = query.filter(
                    Product.cashless_delivery_enabled == 1,
                    Offer.is_take_away_offer == 1
                )

        if customer:
            if received_offer_ids and not cashless_delivery_enabled_include:
                query = query.filter(
                    or_(
                        and_(
                            Product.is_dummy_product != 1,
                            Product.show_offers_if_purchased != 1,
                            Product.is_freemium != 1
                        ),
                        or_(
                            Product.id.in_(product_ids),
                            Offer.id.in_(received_offer_ids)
                        )
                    )
                )
            else:
                common_filters = [
                    Product.is_dummy_product != 1,
                    Product.show_offers_if_purchased != 1,
                    Product.is_freemium != 1
                ]
                customer_product_ids = customer.get('product_ids', [])
                query = query.filter(
                    or_(
                        and_(*common_filters),
                        Product.id.in_(customer_product_ids)
                    )
                )
        else:
            query = query.filter(
                Product.is_dummy_product != 1,
                Product.show_offers_if_purchased != 1,
                Product.is_freemium != 1,
                Product.is_cheers != 1
            )

        like_filter = None
        if query_args:
            like_filter = or_(*[OfferTranslation.name.like('%{}%'.format(arg)) for arg in query_args])

        if like_filter is not None:
            query = query.filter(like_filter)

        if kwargs['isshared']:
            if kwargs.get('received_offer_ids'):
                query = query.filter(Offer.id.in_(kwargs['received_offer_ids']))
        else:
            if offer_types_selected:
                query = query.filter(Offer.voucher_type.in_(offer_types_selected))

            if offer_redeemability == REDEEMBILITY_NOT_REDEEMABLE:
                query = query.filter(Product.purchase_product_id > 0)

            if is_cheers:
                if is_cashless_location:
                    query = query.filter(
                        or_(
                            Product.is_cheers == 1,
                            Product.cashless_delivery_enabled == 1
                        )
                    )
                else:
                    query = query.filter(Product.is_cheers == 1)

            if is_more_sa:
                query = query.filter(Product.is_more_sa == 1)

            if is_birthday:
                if is_cashless_location:
                    query = query.filter(
                        or_(
                            Product.type == Product.PRODUCT_TYPE_BIRTHDAY,
                            Product.cashless_delivery_enabled == 1
                        )
                    )
                else:
                    query = query.filter(Product.type == Product.PRODUCT_TYPE_BIRTHDAY)

            # skip mode
            if location_id in get_delivery_enabled_location_ids_against_company(company):
                if cashless_delivery_enabled and cashless_delivery_enabled_include:
                    query = query.filter(Product.cashless_delivery_enabled == 1)
            else:
                if is_delivery:
                    query = query.filter(Product.delivery_enabled == 1)

            if company_type == ENT_COMPANY_TYPE:
                if kwargs.get('outlet_id'):
                    query = query.filter(cls.id == kwargs['outlet_id'])
                elif kwargs.get('category', '').lower() == 'travel':
                    query = query.filter(Product.istravel == 1)
                else:
                    locations = Product.MORE_SA_LOCATION_IDS
                    query = query.filter(Product.location_id == location_id)
                    or_filter = None
                    if category == CATEGORY_API_NAME_ALL:
                        or_filter = or_(True, Product.istravel == 1)
                    if location_id == Location.LOCATION_ID_SINGAPORE:
                        or_filter = or_(or_filter, Product.is_johor_bahru == 1)
                    if location_id in locations:
                        or_filter = or_(or_filter, Product.is_more_sa == 1)
                    if or_filter is not None:
                        query = query.filter(or_filter)
                    if location_id == Location.LOCATION_ID_MALAYSIA:
                        query = query.filter(coalesce(Product.is_johor_bahru, 0) == 0)

            else:
                if kwargs.get('product_sku'):
                    query = query.filter(Product.sf_id == kwargs['product_sku'])
                elif kwargs.get('outlet_id'):
                    query = query.filter(cls.id == kwargs['outlet_id'])
                elif kwargs.get('category', '').lower() == 'travel':
                    query = query.filter(Product.istravel == 1)
                else:
                    query = query.filter(Product.location_id == location_id)
                    or_filter = None
                    if category == CATEGORY_API_NAME_ALL:
                        or_filter = or_(True, Product.istravel == 1)
                    if location_id in Product.MORE_SA_LOCATION_IDS:
                        or_filter = or_(or_filter, Product.is_more_sa == 1)
                    if or_filter is not None:
                        query = query.filter(or_filter)

        # Fuzzy search.
        fuzzy_search_outlet_ids = kwargs.get("_fuzzy_search_outlet_ids")
        if kwargs.get("_is_fuzzy_search_on") and fuzzy_search_outlet_ids:
            query = query.filter(Outlet.id.in_(fuzzy_search_outlet_ids))

        # Trial offers.
        if customer.get('is_using_trial', False):
            if company_type != ENT_COMPANY_TYPE or customer.get('is_using_extended_trial', False):
                query = query.filter(
                    or_(
                        Offer.type != Offer.TYPE_MEMBER,
                        Product.has_merlin_offers == 1
                    )
                )

        # Apply Filter on Category
        if kwargs.get('category') and kwargs['category'].strip().lower() != 'all':
            query = query.filter(Offer.merchant_category == kwargs['category'])

        # Apply Filter on Subcategory
        if sub_categories_selected:
            query = query.filter(Offer.sub_category.in_(sub_categories_selected))

        # Apply offer attributes
        for offer_attribute in offer_attributes_selected:
            if is_travel and offer_attribute in PACKAGE_ATTRIBUTES:
                query = query.filter(getattr(Package, PACKAGE_ATTR_MAPPING[offer_attribute]) == 1)
            else:
                query = query.filter(getattr(OfferAttribute, offer_attribute) == 1)

        query = query.with_entities(*select_list)
        query = query.group_by(Offer.id)

        records = query.all()
        offers = []

        if records:
            is_show_monthly = kwargs.get('show_monthly_offers_product_wise', False)
            for record in records:
                offer = record._asdict()
                if company_type == ENT_COMPANY_TYPE:
                    offer['is_monthly'] = get_offer_monthly_status(
                        offer,
                        show_monthly_offers_product_wise=is_show_monthly
                    )
                offers.append(offer)
        return offers

    @classmethod
    def find_by_criteria_merchant_attributes_v3(cls, **criteria):
        """
        Finds outlets based on criteria of the request.

        :param **dict criteria:
        """

        from ..models.outlet_translation import OutletTranslation
        from ..models.dm_outlet_setting import DmOutletSetting
        from ..models.dm_delivery_timing import DmDeliveryTiming
        from ..models.dm_area_coordinates import DmAreaCoordinate
        from ..models.outlet_zone import OutletZone
        from ..models.quiq_up_settings import QuiqUpSetting
        from ..models.merchant import Merchant
        from ..models.merchant_translation import MerchantTranslation
        from ..models.country_translation import CountryTranslation
        from ..models.country import Country

        from ..utils.api_utils import get_current_time_of_location

        merchant_attributes = []
        merchant_attributes_selected = criteria['merchant_attributes']
        category = criteria['category'].lower()
        lat = criteria['lat']
        lng = criteria['lng']
        location_id = criteria['location_id']
        outlet_ids = criteria['outlet_ids']
        billing_country = criteria['billing_country']
        search_by_dest_type = criteria['search_by_dest_type']
        billing_city = criteria['billing_city']
        neighborhood = criteria['neighborhood']
        mall = criteria['mall']
        hotel = criteria['hotel']
        radius = criteria['radius']
        table_reservation_enabled = criteria['table_reservation_enabled']
        cashless_delivery = criteria['cashless_delivery']
        takeaways_enabled = criteria['takeaways_enabled']
        locale = criteria['locale']
        company = criteria['company']
        merchant_ids = criteria['merchant_ids']
        price_ranges = criteria['price_ranges']
        show_instant_booking_hotels = criteria['show_instant_booking_hotels']
        is_travel = criteria['is_travel']

        now = get_current_time_of_location(location_id)

        lat_lng_exists = False

        if lat and lng and lat != '0,0' and lng != ',':
            lat_lng_exists = True

        # In case of Dubai, cashless and no lat and lng send we will use Dubai center location.
        if cashless_delivery and not lat_lng_exists and location_id == 1:
            lat = 25.300579
            lng = 55.307709
            radius = 0
            lat_lng_exists = True

        select_entities = [
            cls.id,
            cls.sf_id.label('sfId'),
            OutletTranslation.name,
            cls.email,
            cls.telephone,
            cls.lat,
            cls.lng,
            cls.billing_city,
            cls.integration_type,
            cls.last_mile_delivery,
            cls.take_away_enabled,
            OutletTranslation.human_location,
            OutletTranslation.neighborhood,
            OutletTranslation.mall,
            OutletTranslation.hotel,
            coalesce(cls.ta_location_id, 0).label('tripadvisor_id'),
            DmOutletSetting.disabled.label('cashless_outlet_settings_enabled'),
            Merchant.id.label('merchant_id'),
            Merchant.category.label('merchant_category'),
            Merchant.categories.label('merchant_categories'),
            coalesce(Merchant.ad_travel_country, "").label('merchant_ad_travel_country'),
            Merchant.ad_active_status.label('merchant_ad_active_status'),
            Merchant.logo_retina_url.label('merchant_logo_url'),
            Merchant.logo_non_retina_url.label('merchant_logo_small_url'),
            Merchant.photo_retina_url.label('merchant_photo_url'),
            Merchant.photo_non_retina_url.label('merchant_photo_small_url'),
            Merchant.cuisines.label('merchant_cuisines'),
            Merchant.digital_section.label('merchant_digital_section'),
            MerchantTranslation.name.label('merchant_name'),
            MerchantTranslation.name.label('merchant_name_for_outlet'),
            MerchantTranslation.cuisine.label('merchant_cuisine'),
        ]
        if is_travel:
            select_entities.append(Merchant.hww_instant_booking.label('is_hww_instant_booking'))
            select_entities.append(Merchant.hero_non_retina_urls.label('hero_non_retina_urls'))
            select_entities.append(cls.ta_reviews_count)
            select_entities.append(cls.ta_rating)
            select_entities.append(cls.ta_rating_img_url)
            select_entities.append(CountryTranslation.name.label('billing_country'))

        if cashless_delivery:
            select_entities.extend([
                DmDeliveryTiming.delivery_start_time,
                DmDeliveryTiming.delivery_end_time,
                DmDeliveryTiming.total_minutes,
                DmOutletSetting.default_delivery_time,
                DmOutletSetting.online_status,
                DmAreaCoordinate.polygon_coordinates,
                DmAreaCoordinate.map_type,
                OutletZone.default_delivery_time.label('oz_default_delivery_time'),
                QuiqUpSetting.id.label('bands')
            ])

        if lat_lng_exists:
            select_lat_lng = func.acos(
                func.cos(
                    func.radians(
                        90.0 - lat
                    )
                ) * func.cos(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) + func.sin(
                    func.radians(
                        90.0 - lat
                    )
                ) * func.sin(
                    func.radians(
                        90.0 - Outlet.lat
                    )
                ) * func.cos(
                    func.radians(
                        lng - Outlet.lng
                    )
                )
            ) * 6371000.0
        else:
            select_lat_lng = literal_column('0')

        select_entities.append(
            select_lat_lng.label('distance')
        )
        query = cls.query.with_entities(*select_entities)
        query = query.join(
            OutletTranslation,
            and_(
                cls.id == OutletTranslation.outlet_id,
                OutletTranslation.locale == locale,
                cls.active == 1
            )
        )
        query = query.join(Merchant, cls.merchant_id == Merchant.id)
        query = query.join(
            MerchantTranslation,
            and_(
                Merchant.id == MerchantTranslation.merchant_id,
                MerchantTranslation.locale == locale
            )
        )
        if cashless_delivery:
            query = query.join(
                DmOutletSetting,
                and_(
                    DmOutletSetting.merchant_sf_id == Merchant.sf_id,
                    DmOutletSetting.outlet_sf_id == Outlet.sf_id,
                    DmOutletSetting.disabled == 0,
                    DmOutletSetting.status == 1
                )
            )
            query = query.join(
                DmMenuCompany,
                and_(
                    DmOutletSetting.id == DmMenuCompany.outlet_setting_id,
                    DmMenuCompany.company == company,
                    DmMenuCompany.is_deleted == 0
                )
            )
            query = query.outerjoin(
                DmDeliveryTiming,
                and_(
                    DmDeliveryTiming.outlet_setting_id == DmOutletSetting.id,
                    DmDeliveryTiming.day_of_week == now.strftime("%A").lower(),
                    DmDeliveryTiming.delivery_start_time.isnot(None)
                )
            )
            query = query.outerjoin(
                DmAreaCoordinate,
                and_(
                    DmAreaCoordinate.merchant_id == Merchant.id,
                    DmAreaCoordinate.outlet_id == Outlet.id,
                    DmAreaCoordinate.status == 1,
                    DmAreaCoordinate.is_approved == 1
                )
            )
            query = query.outerjoin(
                OutletZone,
                DmAreaCoordinate.outlet_zone_id == OutletZone.id,
                OutletZone.is_deleted == 0
            )
            query = query.outerjoin(
                QuiqUpSetting,
                QuiqUpSetting.id == DmAreaCoordinate.band_id
            )
        else:
            query = query.outerjoin(
                DmOutletSetting,
                and_(
                    DmOutletSetting.merchant_sf_id == Merchant.sf_id,
                    DmOutletSetting.outlet_sf_id == Outlet.sf_id,
                    DmOutletSetting.disabled == 0,
                    DmOutletSetting.status == 1
                )
            )

        if is_travel:
            query = query.join(
                Country, cls.billing_country == Country.shortname
            ).join(
                CountryTranslation,
                and_(
                    Country.id == CountryTranslation.country_id,
                    CountryTranslation.locale == locale
                )
            )

        include_merchant_attributes = False
        if merchant_attributes_selected and merchant_attributes_selected[0] != '':
            include_merchant_attributes = True

        is_category_matched = False
        if include_merchant_attributes and category:
            inner_join_table = ''
            if category == BODY:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_BODY
                inner_join_table = MerchantAttributesBody
            elif category == LEISURE:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_LEISURE
                inner_join_table = MerchantAttributesLeisure
            elif category == RESTAURANTS_AND_BARS:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_RESTAURANTS_AND_BARS
                inner_join_table = MerchantAttributesRestaurantsAndBar
            elif category == SERVICES:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_SERVICES
                inner_join_table = MerchantAttributesService
            elif category == TRAVEL:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_TRAVEL
                inner_join_table = MerchantAttributesTravel
            elif category == RETAIL:
                is_category_matched = True
                merchant_attributes = MERCHANT_ATTRIBUTES_RETAIL
                inner_join_table = MerchantAttributesFashionAndRetail

            if inner_join_table:
                query = query.join(inner_join_table, inner_join_table.merchant_id == Merchant.id)

            if is_category_matched:
                for include_filter in merchant_attributes_selected:
                    if include_filter in merchant_attributes:
                        query = query.filter(getattr(inner_join_table, include_filter).in_([1, 2]))

        if table_reservation_enabled:
            query = query.filter(cls.table_reservation_enabled == 1)

        if show_instant_booking_hotels:
            query = query.filter(Merchant.hww_instant_booking == 1)

        if takeaways_enabled:
            query = query.filter(cls.take_away_enabled == 1)

        if merchant_ids:
            query = query.filter(cls.merchant_id.in_(merchant_ids))

        if price_ranges:
            query = query.filter(Merchant.price_range.in_(price_ranges))

        if outlet_ids:
            query = query.filter(cls.id.in_(outlet_ids))

        if is_travel:
            if search_by_dest_type == 'country' and billing_country:
                query = query.filter(cls.billing_country == billing_country)
            elif search_by_dest_type == 'city' and billing_city:
                query = query.filter(cls.billing_city == billing_city)
            elif location_id:
                query = query.filter(cls.location_id == location_id)
        else:
            if billing_country:
                query = query.filter(cls.billing_country == billing_country)

        if neighborhood:
            query = query.filter(OutletTranslation.neighborhood.like('%{}%'.format(neighborhood)))

        if mall:
            query = query.filter(OutletTranslation.mall.like('%{}%'.format(mall)))

        if hotel:
            query = query.filter(OutletTranslation.hotel.like('%{}%'.format(hotel)))

        if lat_lng_exists and radius:
            query = query.having(select_lat_lng.label('distance') <= radius)

        return query.all()
