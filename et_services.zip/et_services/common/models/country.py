"""
Country Model
"""
from sqlalchemy import Column, String, case, literal_column
from sqlalchemy.dialects.mysql import FLOAT, INTEGER

from ..constants import CATEGORY_API_NAME_TRAVEL, ENTERTAINER_WEB
from ..models.country_translation import CountryTranslation
from ..models.db import db
from ..models.merchant import Merchant
from ..models.mixin import Mixin
from ..models.offer import Offer
from ..models.outlet import Outlet
from ..models.product import Product
from ..models.product_offer import ProductOffer
from ..models.region_translation import RegionTranslation

__author__ = 'osamaa@theentertainerasia.com'


class Country(db.Model, Mixin):
    __tablename__ = 'country'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    name = Column(String(100))
    shortname = Column(String(45), index=True)
    region_id = Column(INTEGER(11))
    position = Column(INTEGER(11), default=1)
    lat = Column(FLOAT(10))
    lng = Column(FLOAT(10))

    @classmethod
    def get_country(cls, locale):
        """
        return countries
        :param str locale: locale
        :rtype: list
        """
        try:
            results = []
            query = cls.query.with_entities(
                cls.id.distinct().label("id"), cls.shortname,
                CountryTranslation.name, cls.position
            ).join(
                CountryTranslation, cls.id == CountryTranslation.country_id).filter(
                CountryTranslation.locale == locale).order_by(
                cls.position.asc(), CountryTranslation.name.asc()
            )

            results = query.all()
        except Exception as e:
            print("Error occurred while getting countries : {}".format(e))
        finally:
            return results

    @classmethod
    def get_country_by_region(cls, product_ids=[], locale='en'):
        """
        return country by region
        :param product_ids: id's of products
        :param str locale: locale
        :rtype: list
        """
        results = []
        try:
            query = cls.query.with_entities(
                cls.id.distinct().label("id"),
                cls.shortname,
                CountryTranslation.name,
                case(
                    [
                        (
                            RegionTranslation.name.is_(None),
                            literal_column("''")
                        )
                    ],
                    else_=RegionTranslation.name
                ).label('region')
            ).join(
                CountryTranslation, cls.id == CountryTranslation.country_id
            ).join(
                RegionTranslation, cls.region_id == RegionTranslation.region_id
            ).join(
                Outlet, cls.shortname == Outlet.billing_country
            ).join(
                Merchant, Outlet.merchant_id == Merchant.id
            ).join(
                Offer, Merchant.id == Offer.merchant_id
            ).join(
                ProductOffer, Offer.id == ProductOffer.offer_id
            ).join(
                Product, ProductOffer.product_id == Product.id
            ).filter(
                Offer.merchant_category == CATEGORY_API_NAME_TRAVEL,
                RegionTranslation.locale == locale,
                CountryTranslation.locale == locale,
                Product.id.in_(product_ids)
            ).order_by(
                RegionTranslation.region_id.asc()
            )
            results = query.all()
        except Exception as e:
            print("Error occurred while getting countries by region : {}".format(e))
        finally:
            return results
