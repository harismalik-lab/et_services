"""
Dm Menu Item Translation Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import EN, ENTERTAINER_WEB
from ..models.db import db


class DmMenuItemTranslation(db.Model):
    __tablename__ = 'dm_menu_item_translation'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    dm_menu_item_id = Column(INTEGER(11), index=True)
    locale = Column(String(2), index=True, default=EN)
    name = Column(String(200))
    description = Column(String(500))
