"""
WL User Custom Info Model
"""
import datetime

from sqlalchemy import TIMESTAMP, String, text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db


class WlUserCustomInfo(db.Model):
    __tablename__ = 'wl_user_custom_info'
    __table_args__ = {"schema": CONSOLIDATION}

    id = db.Column(INTEGER(10), primary_key=True)
    company = db.Column(String(10), nullable=False)
    user_id = db.Column(INTEGER(10), nullable=False)
    password_hash = db.Column(String(255), nullable=False)
    status = db.Column(TINYINT(3), default=1)
    create_time = db.Column(TIMESTAMP, default=datetime.datetime.now)
    update_time = db.Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
