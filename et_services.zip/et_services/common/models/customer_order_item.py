"""
CustomerOrderItem model of EntertainerBusiness schema.
"""
from sqlalchemy import Column, String, TIMESTAMP, text, Date, Text, Float, DateTime
from sqlalchemy.dialects.mysql import INTEGER, TINYINT, LONGTEXT

from ..constants import ENTERTAINER_BUSINESS
from ..models.mixin import Mixin
from ..models.db import db


class CustomerOrderItem(db.Model, Mixin):
    __tablename__ = 'customer_order_item'
    __table_args__ = ({
        "schema": ENTERTAINER_BUSINESS,
        "comment": 'Order Items Table'
    })

    id = Column(INTEGER(11), primary_key=True)
    item_name = Column(String(100))
    offer_sf_id = Column(String(100))
    offer_name = Column(String(200))
    order_id = Column(INTEGER(11), index=True)
    quantity = Column(TINYINT(11))
    promo = Column(String(200))
    total_price = Column(Float(12), server_default=text("'0.0000'"))
    base_total_price = Column(Float(12), server_default=text("'0.0000'"))
    sub_total = Column(Float(12), server_default=text("'0.0000'"))
    base_sub_total = Column(Float(12), server_default=text("'0.0000'"))
    total_discount = Column(Float(8), server_default=text("'0.0000'"))
    base_total_discount = Column(Float(8), server_default=text("'0.0000'"))
    item_json = Column(Text)
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    created_date = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime, nullable=False,
                          server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    external_item_id = Column(String(20), server_default=text("''"))
    redemption_id = Column(INTEGER(11))
    attribute_id = Column(INTEGER(11))
    attribute_group_id = Column(INTEGER(11))
    offer_id = Column(INTEGER(11))
    base_tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    settlement_id = Column(INTEGER(11), index=True)
    parent_order_item_id = Column(INTEGER(11))
    external_seat_number = Column(String(45))
    is_refundable = Column(TINYINT(1), nullable=False, server_default=text("'0'"))
    booking_start_time = Column(DateTime)
    booking_end_time = Column(DateTime)
    item_description = Column(String(200))
    item_type = Column(String(20), server_default=text("'item'"))
    product_sku = Column(String(20))
    ent_delivery_charges = Column(Float(8))
    quiup_delivery_charges = Column(Float(8))
    merchant_tips = Column(Float(8))
    quiup_tips = Column(Float(8))

    @classmethod
    def add_item(cls, **kwargs):
        """
        Adds entry in customer_order_item table.
        """
        return cls(**kwargs).insert_record()