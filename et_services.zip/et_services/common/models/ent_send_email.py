"""
Ent Send Email Model
"""
import datetime

from sqlalchemy import TIMESTAMP, String, Text
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from common.models.mixin import Mixin

from ..constants import CONSOLIDATION
from ..models.db import db


class EntSendEmail(db.Model, Mixin):
    __tablename__ = 'ent_send_emails'
    __table_args__ = {"schema": CONSOLIDATION}

    PRIORITY_HIGH = 1
    PRIORITY_MEDIUM = 2
    PRIORITY_LOW = 3

    id = db.Column(INTEGER(11), primary_key=True)
    email_to = db.Column(String(255))
    email_template_type_id = db.Column(INTEGER(11))
    email_template_data = db.Column(String(500))
    optional_data = db.Column(Text, nullable=False)
    language = db.Column(String(5))
    priority = db.Column(INTEGER(5))
    created_date = db.Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    is_sent = db.Column(TINYINT(1), default=0)
