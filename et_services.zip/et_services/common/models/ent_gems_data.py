"""
Ent Gems Data Model
"""
import datetime

from sqlalchemy import Column, DateTime, Enum, Index, String
from sqlalchemy.dialects.mysql import BIGINT, INTEGER, TINYINT

from ..constants import CONSOLIDATION
from ..models.db import db
from ..models.mixin import Mixin


class EntGemsData(db.Model, Mixin):
    __tablename__ = 'ent_gems_data'
    __table_args__ = (
        Index('email_parent_idx', 'email', 'gems_user_id'),
        {"schema": CONSOLIDATION}
    )

    id = Column(INTEGER(10), primary_key=True)
    email = Column(String(150))
    user_id = Column(INTEGER(11), default=0)
    gems_user_id = Column(String(100))
    school = Column(String(100))
    user_group = Column(TINYINT(4))
    is_staff = Column(Enum('YES', 'NO'))
    created_on = Column(DateTime, default=datetime.datetime.now)
    updated_on = Column(DateTime, default=datetime.datetime.now)
    is_active = Column(TINYINT(2), default=1)
    is_email_sent = Column(TINYINT(2), default=0)
    email_sent_date = Column(DateTime)
    priority = Column(TINYINT(4))
    gems_persistent_id = Column(BIGINT(20), index=True)
    old_email = Column(String(150))
    old_gems_user_id = Column(String(50))

    @classmethod
    def get_by_email(cls, email):
        """
        Find gem data according to email
        :param email: customer's email
        :rtype: EntGemsData
        """
        return cls.query.filter(cls.email == email, cls.is_active).first()

    @classmethod
    def find_gem_data_by_id(cls, user_id):
        """
        Find gems data for user id
        :param int user_id: user id
        """
        return cls.query.filter(cls.user_id == user_id, cls.is_active).first()
