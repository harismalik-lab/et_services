"""
WlBinCode Model
"""
from sqlalchemy import Column, String
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import ENTERTAINER_WEB
from ..models.db import db, session
from ..models.wl_company import WlCompany

__author__ = 'osamaa@theentertainerasia.com'


class WlBinCode(db.Model):
    __tablename__ = 'wl_bin_codes'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    ica_country = Column(String(45))
    company_status_description = Column(String(45))
    bin = Column(String(45))
    bin_product_name = Column(String(45))
    bin_status_description = Column(String(45))
    user_group = Column(INTEGER(11), default=1)
    wl_company = Column(String(50))

    @classmethod
    def get_mce_by_bin(cls, _bin):
        """
        Gets mce user group.
        :param str _bin: Bin
        :rtype: int
        """
        result = None
        try:
            query = cls.query.with_entities(
                cls.user_group
            ).filter(
                cls.wl_company == WlCompany.COMPANY_CODE_MASTER_CARDS,
                cls.bin == _bin
            )
            result = query.first()
        except Exception as e:
            print("Error occurred while getting user group mce : {}".format(e))
        finally:
            return result
