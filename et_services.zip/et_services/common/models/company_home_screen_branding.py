"""
Company Home Screen Branding model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column, String
from sqlalchemy.dialects.mysql import INTEGER, TINYINT

from .. import constants
from ..models.db import db
from ..models.mixin import Mixin


class CompanyHomeScreenBranding(db.Model, Mixin):
    __tablename__ = 'company_home_screen_branding'
    __table_args__ = {'schema': constants.ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    company = Column(String(20), index=True)
    location_id = Column(INTEGER(11), index=True, default=0)
    category_id = Column(INTEGER(11), index=True, default=0)
    platform = Column(String(20), index=True, default='both')
    user_group = Column(INTEGER(11), default=0)
    main_top_color = Column(String(50))
    main_top_text_color = Column(String(50))
    main_top_image = Column(String(500))
    is_active = Column(TINYINT(1), index=True, default=1)
    created_at = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)

    @classmethod
    def get_branding(cls, company, location_id=0, category_id=0, user_group=0, platform='both'):
        query = cls.query.with_entities(
            cls.main_top_image,
            cls.main_top_color,
            cls.main_top_text_color
        ).filter(
            cls.is_active == 1,
            cls.company == company
        )
        query = query.filter(cls.location_id.in_([location_id, 0]))
        query = query.filter(cls.category_id.in_([category_id, 0]))
        query = query.filter(cls.user_group.in_([user_group, 0]))
        query = query.filter(cls.platform.in_([platform, 'both']))
        query = query.order_by(cls.user_group.desc())
        query = query.order_by(cls.user_group.desc())
        return query.first()
