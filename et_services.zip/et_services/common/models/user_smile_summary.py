"""
User Smile Summary Model
"""
import datetime

from sqlalchemy import TIMESTAMP, Column
from sqlalchemy.dialects.mysql import INTEGER

from ..constants import GAMIFICATION
from ..models.db import db


class UserSmileSummary(db.Model):
    __tablename__ = 'user_smile_summary'
    __table_args__ = {"schema": GAMIFICATION}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(11), index=True)
    leaderboard_id = Column(INTEGER(11), default=1)
    smiles = Column(INTEGER(11))
    updated_date = Column(TIMESTAMP, nullable=False, default=datetime.datetime.now)
    admin_id = Column(INTEGER(11), index=True)

    @classmethod
    def get_user_smiles_from_gamification_db(cls, user_id):
        """
        returns user smiles
        :param user_id:
        """
        return cls.query.filter(cls.user_id == user_id).with_entities(cls.smiles).first()
