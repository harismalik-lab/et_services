"""
dm merchant order history
"""
from sqlalchemy import Column, DateTime, Float, String, text
from sqlalchemy.dialects.mysql import INTEGER, SMALLINT, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.dm_merchant_order_status import DmMerchantOrderStatus
from ..models.mixin import Mixin


class DmMerchantOrderHistory(db.Model, Mixin):
    __tablename__ = 'dm_merchant_order_history'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    order_number = Column(String(255), index=True)
    merchant_sf_id = Column(String(20))
    outlet_sf_id = Column(String(20))
    merchant_id = Column(INTEGER(11))
    outlet_id = Column(INTEGER(11))
    customer_id = Column(INTEGER(11), index=True)
    customer_email = Column(String(200))
    customer_ip = Column(String(20))
    server_ip = Column(String(20))
    items_count = Column(TINYINT(11))
    order_currency = Column(String(5))
    base_currency = Column(String(5))
    payment_method = Column(String(25))
    order_status_id = Column(INTEGER(11), index=True, server_default=text("'0'"))
    total_paid = Column(Float(8), server_default=text("'0.0000'"))
    base_total_paid = Column(Float(8), server_default=text("'0.0000'"))
    sub_total = Column(Float(8), server_default=text("'0.0000'"))
    base_sub_total = Column(Float(8), server_default=text("'0.0000'"))
    total_discount = Column(Float(8), server_default=text("'0.0000'"))
    base_total_discount = Column(Float(8), server_default=text("'0.0000'"))
    delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    base_delivery_charges = Column(Float(8), server_default=text("'0.0000'"))
    delivery_instructions = Column(String(500))
    delivery_time = Column(INTEGER(11), server_default=text("'0'"))
    cc_charge_id = Column(String(255))
    cc_type = Column(String(50))
    cc_last_four_digits = Column(SMALLINT(4))
    placed_from = Column(String(20))
    app_version = Column(String(10))
    tracking_number = Column(String(255))
    reject_reason = Column(String(255))
    is_cancelable = Column(TINYINT(1), server_default=text("'1'"))
    is_active = Column(TINYINT(1), server_default=text("'1'"))
    is_delivered = Column(TINYINT(1), server_default=text("'0'"))
    is_zero_order = Column(TINYINT(1), server_default=text("'0'"))
    created_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_at = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    delivery_address_id = Column(INTEGER(11), server_default=text("'0'"))
    is_refunded = Column(TINYINT(1), server_default=text("'0'"))
    refund_amount = Column(Float(8), server_default=text("'0.0000'"))
    sub_status_id = Column(INTEGER(11))
    order_id = Column(INTEGER(11), index=True)
    settlement_id = Column(INTEGER(11), index=True)
    base_tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    tax_amount = Column(Float(8), server_default=text("'0.0000'"))
    checkout_status = Column(String(50))
    product_sku = Column(String(20))
    customer_name = Column(String(250))
    te_commission_from_merchant = Column(Float(8), server_default=text("'0.0000'"))
    te_checkout_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_auth_fee = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    te_revenue_after_vat = Column(Float(8), server_default=text("'0.0000'"))
    vat_payable_on_te_revenue = Column(Float(8), server_default=text("'0.0000'"))
    refund_to_merchant = Column(Float(8), server_default=text("'0.0000'"))
    order_process_channel = Column(String(50))
    is_processed = Column(TINYINT(1), server_default=text("'0'"))
    order_edit_status = Column(TINYINT(1), server_default=text("'0'"))
    cron_processing = Column(TINYINT(1), server_default=text("'0'"))
    refund_reason = Column(String(500))
    refund_by = Column(String(100))
    refund_to = Column(String(100))
    refund_payment_mode = Column(String(200))
    processed_by = Column(INTEGER(11))
    company = Column(String(50), nullable=False, index=True, server_default=text("'entertainer'"))
    company_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'50'"))
    capture_retry = Column(TINYINT(1), server_default=text("'0'"))
    location_id = Column(INTEGER(11), nullable=False, server_default=text("'1'"))
    card_type = Column(String(20))
    commission_delivery_vat = Column(String(50))
    quiqup_settled = Column(TINYINT(1), server_default=text("'0'"))
    quiq_up_fee = Column(Float(8))
    refund_retry = Column(TINYINT(1), server_default=text("'0'"))
    delivery_type = Column(String(11))
    band_id = Column(INTEGER(11))
    delivery_charges_to_outlet = Column(Float(8))
    is_take_away_order = Column(TINYINT(1))
    customer_status = Column(INTEGER(11))

    @classmethod
    def get_accepted_order(cls, order_id, order_status_id):
        """
        :param int order_status_id: id of order status
        :param int order_id: id of order
        :return orm obj: query set result
        """
        query = cls.query.join(DmMerchantOrderStatus, cls.order_status_id == DmMerchantOrderStatus.id)
        query = query.with_entities(cls.created_at)
        query = query.filter(
            cls.order_id == order_id,
            cls.order_status_id == order_status_id
        )
        return query.order_by(cls.id.desc()).first()

    @classmethod
    def insert_into_order_history(cls, order_history_data):
        """
        Insert into order history
        :param dict order_history_data: data of order history
        """
        try:
            if order_history_data:
                if '_sa_instance_state' in order_history_data.keys():
                    del order_history_data['_sa_instance_state']
                insert_order_info = DmMerchantOrderHistory(**order_history_data)
                insert_order_info.insert_record()
        except Exception:
            raise
