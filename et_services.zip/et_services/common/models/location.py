"""
Location Model
"""
from flask import g
from shapely import wkt
from shapely.errors import WKTReadingError
from shapely.geometry import Point
from sqlalchemy import Column, Float, String, case, literal_column
from sqlalchemy import Float, String, Column, case, literal_column, or_
from sqlalchemy.dialects.mysql import BIT, INTEGER, TINYINT

from ..constants import DUBAI_LOCATION_ID, EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.location_translation import LocationTranslation
from ..models.wl_locations import Wllocation
from ..models.wllocation_translation import WllocationTranslation

__author__ = 'osamaa@theentertainerasia.com'

cache = g.cache


class Location(db.Model):
    __tablename__ = 'location'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    MORE_SA_LOCATIONS = [4, 14, 20]
    LOCATION_ID_SINGAPORE = 11
    LOCATION_ID_ABU_DHABI = 2
    LOCATION_ID_MALAYSIA = 15
    LOCATION_ID_UNITED_KINGDOM = 17

    id = Column(INTEGER(11), primary_key=True)
    currency = Column(String(3))
    default_name = Column(String(250), index=True)
    active = Column(TINYINT(1), nullable=False, default=1)
    lat = Column(Float(10))
    lng = Column(Float(10))
    language = Column(String(45))
    flag = Column(String(500))
    country_id = Column(INTEGER(11))
    background = Column(String(500))
    reload_background = Column(TINYINT(4), default=1)
    is_show_category = Column(TINYINT(4), default=0)
    is_careem_enabled = Column(TINYINT(1), default=1)
    is_gcc = Column(BIT(1))

    GCC_LOCATION_IDS = {1, 2, 3, 7, 8, 9, 10, 18, 49}

    @classmethod
    @cache.memoize(timeout=1800)
    def get_locations(cls, company, locale='en'):
        """
        Gets the locations
        :param str company: company name
        :param str locale: locale
        :rtype: list
        """
        results = []
        try:
            query = cls.query.with_entities(
                cls.id,
                cls.currency,
                LocationTranslation.name,
                case(
                    [
                        (
                            Wllocation.active != 0,
                            literal_column("'true'")
                        )
                    ],
                    else_='false'
                ).label('active'),
                cls.lat,
                cls.lng,
                cls.language,
                cls.flag,
                cls.background,
                cls.reload_background,
                cls.is_show_category,
                Wllocation.is_careem_enabled
            ).join(
                LocationTranslation, cls.id == LocationTranslation.location_id
            ).join(
                Wllocation, cls.id == Wllocation.location_id
            ).filter(
                Wllocation.wl_company == company,
                Wllocation.active == 1,
                LocationTranslation.locale == locale,
            )
            results = query.all()

        except Exception as e:
            print("Error occurred while getting locations : {}".format(e))
        finally:
            return results

    @classmethod
    @cache.memoize(timeout=1800)
    def get_locations_v2(cls, company, locale='en'):
        """
        Gets the locations
        :param str company: company name
        :param str locale: locale
        :rtype: list
        """
        results = []
        try:
            query = cls.query.with_entities(
                cls.id,
                cls.currency,
                case(
                    [
                        (
                            WllocationTranslation.name != '',
                            WllocationTranslation.name
                        )
                    ],
                    else_=LocationTranslation.name
                ).label('name'),
                case(
                    [
                        (
                            Wllocation.active != 0,
                            literal_column("'true'")
                        )
                    ],
                    else_='false'
                ).label('active'),
                cls.lat,
                cls.lng,
                cls.language,
                cls.flag,
                cls.background,
                cls.reload_background,
                cls.is_show_category,
                Wllocation.is_careem_enabled
            ).join(
                LocationTranslation, cls.id == LocationTranslation.location_id
            ).join(
                Wllocation, cls.id == Wllocation.location_id
            ).join(
                WllocationTranslation, Wllocation.id == WllocationTranslation.wllocation_id, isouter=True
            ).filter(
                Wllocation.wl_company == company,
                Wllocation.active == 1,
                LocationTranslation.locale == locale,
                or_(WllocationTranslation.locale == locale, WllocationTranslation.locale.is_(None)),
            ).order_by(Wllocation.order_id)
            results = query.all()

        except Exception as e:
            print("Error occurred while getting locations : {}".format(e))
        finally:
            return results

    @classmethod
    def get_all_location_ids_and_iso_codes(cls):
        """
        Returns Location Ids along with iso codes
        """
        return cls.query.with_entities(cls.id, cls.flag).distinct().all()

    @classmethod
    @cache.memoize(timeout=1800)
    def get_all_location_ids_default_names_and_iso_codes(cls):
        """
        Returns Location Ids along with iso codes and default names
        """
        return cls.query.with_entities(
            cls.id, cls.default_name.label('name'), cls.flag.label('iso_code')
        ).filter(cls.active == 1).all()

    @classmethod
    @cache.memoize(timeout=3600)
    def get_location_translation_by_location_id(cls, location_id, locale=EN):
        """
        Gets location on the base of location id
        """
        if location_id and locale:
            _query = cls.query.with_entities(LocationTranslation.name)
            _query = _query.filter(
                LocationTranslation.location_id == location_id,
                LocationTranslation.locale == locale.lower()
            )
            location = _query.scalar()
            return location

    @staticmethod
    @cache.memoize(timeout=1800)
    def get_polygons_data(company, is_ent):
        """
        Gets polygons of locations.

        :rtype list
        """
        from sql_dal.sql_dal import SqlDal

        sql_dal = SqlDal()
        select_entities = [
            'location.id as location_id',
            'location.boundary_object as polygon',
            'IFNULL(location_features.is_cashless_enabled, 0) as is_cashless_enabled',
        ]
        if not is_ent:
            select_entities.append('wllocations.wl_company as company')
        sql_dal.select(select_entities)

        sql_dal.from_(['location'])

        if is_ent:
            sql_dal.left_join('location_features', 'location_features.location_id', 'location.id')
        else:
            sql_dal.inner_join('wllocations', 'location.id', "wllocations.location_id")
            sql_dal.left_join(
                'location_features', 'location_features.location_id',
                'location.id and wllocations.wl_company=location_features.company'
            )
        if is_ent:
            sql_dal.where({"location.active": 1})
        else:
            sql_dal.where('wllocations.wl_company', company)

        polygons_data = sql_dal.get(default=[])

        for polygon_data in polygons_data:
            try:
                polygon_data['polygon'] = wkt.loads(polygon_data['polygon']).buffer(0) if polygon_data['polygon'] else None
            except WKTReadingError:
                polygon_data['polygon'] = None
        return polygons_data

    @classmethod
    def get_location_id(cls, company, is_ent, latitude, longitude, quiq_up_order_flow=False):
        """
        Gets Entertainer location id from latitude, longitude.
        """
        polygons_data = cls.get_polygons_data(company=company, is_ent=is_ent)
        point = Point(longitude, latitude)
        for shapely_polygon in polygons_data:
            polygon = shapely_polygon.get('polygon')
            if polygon and polygon.contains(point):
                return shapely_polygon.get('location_id')
        if quiq_up_order_flow:
            return 0
        return DUBAI_LOCATION_ID
