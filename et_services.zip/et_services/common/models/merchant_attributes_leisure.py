"""
Merchant Attributes Leisure Model
"""
import datetime

from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesLeisure(db.Model):
    __tablename__ = 'merchant_attributes_leisure'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    age_restrictions = Column(TINYINT(1))
    aviation = Column(TINYINT(1))
    desert_safari = Column(TINYINT(1))
    fishing = Column(TINYINT(1))
    height_restrictions = Column(TINYINT(1))
    indoor_activities = Column(TINYINT(1))
    kids_welcome = Column(TINYINT(1))
    motor_sports = Column(TINYINT(1))
    outdoor_activities = Column(TINYINT(1))
    parking = Column(TINYINT(1))
    team_sports = Column(TINYINT(1))
    valet_parking = Column(TINYINT(1))
    alcohol = Column(TINYINT(1))
    boating = Column(TINYINT(1))
    extreme_sports = Column(TINYINT(1))
    golf = Column(TINYINT(1))
    holiday_programmes = Column(TINYINT(1))
    indoor_play_area = Column(TINYINT(1))
    live_entertainment = Column(TINYINT(1))
    outdoor_cooling = Column(TINYINT(1))
    outdoor_play_area = Column(TINYINT(1))
    racquet_sports = Column(TINYINT(1))
    theme_park = Column(TINYINT(1))
    water_park = Column(TINYINT(1))
    water_sports = Column(TINYINT(1))
    rooftop_bars = Column(TINYINT(1))
    wineries = Column(TINYINT(1))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).first()
