"""
Dm Area Coordinate Model
"""
import datetime

from sqlalchemy import Column, Enum, Float, String, Text
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db


class DmAreaCoordinate(db.Model):
    __tablename__ = 'dm_area_coordinates'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    POLYGON = 'polygon'

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(INTEGER(11), index=True)
    outlet_id = Column(INTEGER(11), index=True)
    polygon_coordinates = Column(Text)
    lat = Column(Float(10))
    lng = Column(Float(10))
    status = Column(TINYINT(1), default=0)
    is_approved = Column(TINYINT(1), default=0)
    merchant_password = Column(String(300))
    created_date = Column(TIMESTAMP)
    updated_date = Column(TIMESTAMP, default=datetime.datetime.now)
    updated_by = Column(Enum('Merchant', 'Admin', 'SF'))
    outlet_zone_id = Column(INTEGER(11))
    map_type = Column(String(30))
    is_deleted = Column(TINYINT(1), nullable=False, default=0)
    band_id = Column(INTEGER(11))

    @classmethod
    def get_area_coordinates(cls, merchant_id, outlet_id):
        """
        Returns outlet's geo info
        :param int merchant_id: merchant id
        :param int outlet_id: outlet id
        :return return the dm area coordinates based on merchant, outlet id
        :rtype: orm obj
        """
        from ..models.outlet_zone import OutletZone

        query = cls.query.outerjoin(
            OutletZone,
            cls.outlet_zone_id == OutletZone.id,
            OutletZone.is_deleted == 0
        )
        query = query.with_entities(
            cls.polygon_coordinates,
            cls.map_type,
            cls.outlet_zone_id,
            OutletZone.id,
            OutletZone.title,
            OutletZone.outlet_id,
            OutletZone.min_order_amount,
            OutletZone.del_charge_total,
            OutletZone.del_charge_min,
            OutletZone.min_order_cap,
            OutletZone.del_charge_on_total_order,
            OutletZone.del_charge_on_less_than_min,
            OutletZone.default_delivery_time
        )
        query = query.filter(
            cls.merchant_id == merchant_id,
            cls.outlet_id == outlet_id,
            cls.status == 1,
            cls.is_approved == 1
        )
        return query.first()

    @classmethod
    def get_area_coordinates_v3(cls, merchant_id, outlet_id, customer_last_mile_band_id=None):
        """
        Returns dict of outlet's info
        :param int merchant_id: merchant id
        :param int outlet_id: outlet id
        :param int customer_last_mile_band_id: customers in last mile band id i.e 1,2
        :return return the dm area coordinates based on merchant, outlet id and customer_last_mile_band_id (optional)
        :rtype: dict
        """
        query = cls.query
        if customer_last_mile_band_id:
            from ..models.quiq_up_settings import QuiqUpSetting

            query = query.outerjoin(QuiqUpSetting, cls.band_id == QuiqUpSetting.id)
            query = query.with_entities(
                cls.polygon_coordinates,
                cls.map_type,
                cls.outlet_zone_id,
                cls.lat,
                cls.lng,
                QuiqUpSetting.id,
                QuiqUpSetting.band_name,
                QuiqUpSetting.location_id,
                QuiqUpSetting.default_currency,
                QuiqUpSetting.local_currency,
                QuiqUpSetting.start_range,
                QuiqUpSetting.end_range,
                QuiqUpSetting.average_drop_off_time,
                QuiqUpSetting.delivery_charges
            )
            query = query.filter(cls.band_id == customer_last_mile_band_id)

        else:
            from ..models.outlet_zone import OutletZone

            query = query.outerjoin(OutletZone, cls.outlet_zone_id == OutletZone.id and OutletZone.is_deleted == 0)
            query = query.with_entities(
                cls.polygon_coordinates,
                cls.map_type,
                cls.outlet_zone_id,
                cls.lat,
                cls.lng,
                OutletZone.id,
                OutletZone.title,
                OutletZone.outlet_id,
                OutletZone.min_order_amount,
                OutletZone.del_charge_total,
                OutletZone.del_charge_min,
                OutletZone.min_order_cap,
                OutletZone.del_charge_on_total_order,
                OutletZone.del_charge_on_less_than_min,
                OutletZone.default_delivery_time
            )

        query = query.filter(
            cls.merchant_id == merchant_id,
            cls.outlet_id == outlet_id,
            cls.status == 1,
            cls.is_approved == 1
        )
        return query.all()
