"""
Tb booking order
"""

from sqlalchemy import Column, DateTime, and_, text
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT, TIMESTAMP, TINYINT, VARCHAR
from sqlalchemy.sql.functions import coalesce

from ..constants import CANCEL_RESERVATION_STATUS, EN, ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant
from ..models.mixin import Mixin
from ..models.outlet_translation import OutletTranslation
from ..models.tb_booking_settings import TbBookingSetting


class TbBookingOrder(db.Model, Mixin):
    __tablename__ = 'tb_booking_order'
    __table_args__ = {'schema': ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    booking_number = Column(VARCHAR(50))
    merchant_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'0'"))
    outlet_id = Column(INTEGER(11), nullable=False, index=True, server_default=text("'0'"))
    user_id = Column(INTEGER(11), index=True, server_default=text("'0'"))
    booking_status = Column(TINYINT(1))
    number_of_persons = Column(SMALLINT(5), index=True)
    booking_start_date = Column(DateTime, index=True)
    booking_end_date = Column(DateTime)
    diner_first_name = Column(VARCHAR(200))
    diner_last_name = Column(VARCHAR(200))
    diner_email = Column(VARCHAR(250))
    diner_mobile = Column(VARCHAR(40))
    special_request = Column(VARCHAR(400))
    table_detail = Column(VARCHAR(300))
    created_date = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    updated_date = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    is_sent = Column(BIT(1), nullable=False)
    lead_time = Column(TINYINT(1), server_default=text("'1'"))

    @classmethod
    def get_table_booking_order_status(cls, customer_id, locale=EN):
        """
        Gets table booking order status
        :param customer_id: Customer Id
        :param locale: Language
        :rtype: list
        """
        query = cls.query.join(
            TbBookingSetting,
            and_(
                TbBookingSetting.merchant_id == cls.merchant_id,
                TbBookingSetting.outlet_id == cls.outlet_id
            )
        )
        query = query.join(OutletTranslation, OutletTranslation.outlet_id == cls.outlet_id)
        query = query.join(Merchant, Merchant.id == cls.merchant_id)

        query = query.with_entities(
            cls.merchant_id,
            cls.outlet_id,
            cls.number_of_persons,
            cls.booking_status,
            coalesce(cls.booking_start_date).label('booking_date'),
            coalesce(cls.booking_number).label('order_id'),
            coalesce(OutletTranslation.name).label('outlet_name'),
            coalesce(Merchant.logo_retina_url).label('image_url'),
            TbBookingSetting.party_size_1,
            TbBookingSetting.party_size_2,
            TbBookingSetting.party_size_3,
            TbBookingSetting.party_size_4
        )

        query = query.filter(cls.user_id == customer_id, OutletTranslation.locale == locale)
        query = query.filter(cls.booking_status != CANCEL_RESERVATION_STATUS).order_by(cls.id.desc())
        table_bookings = query.all()
        return table_bookings
