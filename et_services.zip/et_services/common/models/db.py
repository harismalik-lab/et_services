"""
Contains SqlAlchemy db instance
"""

import logging
from functools import partial

import sqlalchemy.orm as orm
from flask import request
from flask_sqlalchemy import SQLAlchemy, get_state
from sqlalchemy.pool import NullPool

log = logging.getLogger(__name__)


class CustomizedSqlAlchemy(SQLAlchemy):
    def apply_driver_hacks(self, app, info, options):
        options.update({
            'poolclass': NullPool
        })
        super(CustomizedSqlAlchemy, self).apply_driver_hacks(app, info, options)
        # SqlAlchemy sets pool_size key, which causes error as NullPool doesnt support pool_size arg
        del options['pool_size']

    def apply_pool_defaults(self, app, options):
        super(CustomizedSqlAlchemy, self).apply_pool_defaults(app, options)
        options["pool_pre_ping"] = True

    # def create_session(self, options):
    #     return orm.sessionmaker(class_=RoutingSession, db=self, **options)

    def create_scoped_session(self, options=None):
        """
                 Used for factory class to create session
        Args:
            options:

        Returns:

        """
        if options is None:
            options = {}
        scopefunc = options.pop('scopefunc', None)
        return orm.scoped_session(
            partial(AutoRouteSession, self, **options), scopefunc=scopefunc)


class AutoRouteSession(orm.Session):

    def __init__(self, db, autocommit=False, autoflush=False, **options):
        self.app = db.get_app()
        self._model_changes = {}
        orm.Session.__init__(self, autocommit=autocommit, autoflush=autoflush,
                             bind=db.engine,
                             binds=db.get_binds(self.app), **options)

    def get_bind(self, mapper=None, clause=None):
        """
        According to the configuration and read and write operations, automatically change the database engine
        Args:
            mapper:
            clause:

        Returns:

        """
        try:
            state = get_state(self.app)
        except (AssertionError, AttributeError, TypeError) as err:
            log.info("Failed to get configuration, use default database: {}".format(err))
            return orm.Session.get_bind(self, mapper, clause)

        # If SQLALCHEMY_BINDS is not set, SQLALCHEMY_DATABASE_URI is used by default
        if state is None or not self.app.config['SQLALCHEMY_BINDS']:
            if not self.app.debug:
                log.debug("The database binding information (SQLALCHEMY_BINDS) is not obtained,"
                          " the default database is used")
            return orm.Session.get_bind(self, mapper, clause)

        # insert, update, delete operations use master
        elif self._flushing or (request and hasattr(request, 'with_master') and getattr(request, 'with_master')):
            log.debug("Current master")
            return state.db.get_engine(self.app, bind='master')

        # Other operations use slave
        else:
            log.debug("Currently using slave")
            return state.db.get_engine(self.app, bind='slave')


def with_master(fn):
    def wrapper(*arg, **kw):
        try:
            request.with_master = True
            return fn(*arg, **kw)
        finally:
            request.with_master = False
    return wrapper


db = CustomizedSqlAlchemy()
