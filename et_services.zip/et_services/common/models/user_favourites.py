"""
User Favourites Model
"""
import datetime

from common.constants import ENTERTAINER_WEB
from common.models.db import db
from common.models.mixin import Mixin
from sqlalchemy import TEXT, TIMESTAMP, VARCHAR, Column
from sqlalchemy.dialects.mysql import INTEGER, TINYINT


class UserFavourites(db.Model, Mixin):
    __tablename__ = 'user_favourites'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    user_id = Column(INTEGER(11), nullable=False)
    merchant_id = Column(INTEGER(11), nullable=False)
    outlet_id = Column(INTEGER(11))
    company = Column(VARCHAR(11), nullable=False)
    extra_information = Column(TEXT, nullable=False)
    is_active = Column(TINYINT(1), nullable=False)
    date_created = Column(TIMESTAMP, default=datetime.datetime.now)
    date_updated = Column(TIMESTAMP, default=datetime.datetime.now)

    @classmethod
    def get_favourite_merchants_by_id(cls, merchant_id, user_id, company):
        """
        Gets favourite merchant by id.
        """
        return cls.query.filter(
            cls.user_id == user_id,
            cls.merchant_id == merchant_id,
            cls.is_active == 1,
            cls.company == company
        ).first()
