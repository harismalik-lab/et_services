"""
Session model for Entertainer GO schema.
"""
from sqlalchemy import String, TIMESTAMP, Column, Text, text, literal_column
from sqlalchemy.dialects.mysql import BIT, INTEGER, SMALLINT

from ..constants import ENTERTAINER_GO
from ..models.db import db
from ..models.mixin import Mixin


class EgoSession(db.Model, Mixin):
    __tablename__ = 'session'
    __table_args__ = {'schema': ENTERTAINER_GO}

    id = Column(INTEGER(11), primary_key=True)
    session_token = Column(String(100), nullable=False, unique=True)
    customer_id = Column(INTEGER(10), nullable=False, index=True)
    data = Column(Text, comment='Comma separated SKUs')
    company_id = Column(SMALLINT(1), nullable=False, server_default=text("'257'"))
    company = Column(String(20), index=True, server_default=text("'ego'"))
    device_os = Column(String(20))
    device_model = Column(String(25))
    device_id = Column(String(50))
    app_version = Column(String(20))
    api_version = Column(String(10))
    date_created = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    date_updated = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    date_cached = Column(INTEGER(10))
    is_active = Column(BIT(1), nullable=False)
    refresh_session = Column(BIT(1))
    last_activity = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))

    @classmethod
    def get_by_company_and_session_token(cls, company, session_token):
        """
        Returns active session against company and session_token for Ego.
        :param str company: Company
        :param str session_token: Session Token
        :rtype: EgoSession
        """
        query = cls.query.with_entities(
            cls.id,
            cls.app_version,
            cls.company,
            cls.session_token,
            cls.customer_id,
            cls.data.label('product_data'),
            cls.refresh_session.label('refresh_required'),
            cls.is_active.label('isactive')
        )
        return query.filter(
            cls.company == company,
            cls.session_token == session_token,
            cls.is_active == 1
        ).first()
