"""
Merchant Attributes Services Model
"""
import datetime

from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import INTEGER, TIMESTAMP, TINYINT

from ..constants import ENTERTAINER_WEB
from ..models.db import db
from ..models.merchant import Merchant


class MerchantAttributesService(db.Model):
    __tablename__ = 'merchant_attributes_services'
    __table_args__ = {"schema": ENTERTAINER_WEB}

    id = Column(INTEGER(11), primary_key=True)
    merchant_id = Column(ForeignKey(
        Merchant.id,
        ondelete='CASCADE',
        onupdate='CASCADE'),
        nullable=False,
        unique=True
    )
    by_appointment_only = Column(TINYINT(1))
    delivery = Column(TINYINT(1))
    pick_up_drop_off = Column(TINYINT(1))
    pharmacy = Column(TINYINT(1))
    last_update_time = Column(TIMESTAMP, default=datetime.datetime.now)
    beauty_products = Column(TINYINT(1))

    # merchant = relationship('Merchant')

    @classmethod
    def get_attributes(cls, merchant_id):
        """
        get attributes against given merchant id
        :param int merchant_id:
        :return orm obj:
        """
        return cls.query.filter(cls.merchant_id==merchant_id).first()
