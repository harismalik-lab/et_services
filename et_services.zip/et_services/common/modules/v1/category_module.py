from common.constants import CATEGORY_NAME_BODY, CATEGORY_NAME_LEISURE, COLOR_BODY, \
    CATEGORY_NAME_RESTAURANTS_AND_BARS, CATEGORY_NAME_RETAIL, CATEGORY_NAME_SERVICES, CATEGORY_NAME_TRAVEL, \
    COLOR_LEISURE, COLOR_RESTAURANTS_AND_BARS, COLOR_RETAIL, COLOR_SERVICES, COLOR_TRAVEL, ANALYTICS_CATEGORY_CODES_DICT


class CategoryModule(object):

    CATEGORY_COLOR_MAPPING = {
        CATEGORY_NAME_BODY: COLOR_BODY,
        CATEGORY_NAME_LEISURE: COLOR_LEISURE,
        CATEGORY_NAME_RESTAURANTS_AND_BARS: COLOR_RESTAURANTS_AND_BARS,
        CATEGORY_NAME_RETAIL: COLOR_RETAIL,
        CATEGORY_NAME_SERVICES: COLOR_SERVICES,
        CATEGORY_NAME_TRAVEL: COLOR_TRAVEL
    }

    @classmethod
    def get_category_color_code(cls, category):
        """
        Returns color code for category.
        """
        return cls.CATEGORY_COLOR_MAPPING.get(category, '')

    @classmethod
    def get_analytics_codes_against_categories(cls, categories):
        """
        Gets analytics codes against given categories
        """
        codes = []
        for category in categories:
            value_against_category = ANALYTICS_CATEGORY_CODES_DICT.get(category.lower())
            if value_against_category:
                codes.append(value_against_category)
        return ','.join(codes)
