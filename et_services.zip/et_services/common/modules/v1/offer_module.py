import datetime
import json

from flask import current_app

from common.constants import V7_ADDITIONAL_DETAIL_COLOR, OFFER_TYPE_VALUE_DEFAULT, \
    OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE, OFFER_TYPE_VALUE_PERCENTAGE_OFF, OFFER_TYPE_VALUE_GIFT, \
    OFFER_TYPE_VALUE_PACKAGE, OFFER_TYPE_VALUE_FIX_PRICE_OFF, OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS, \
    GREY_BACKGROUND_COLOR, OFFER_TEXT_COLOR, TAG_TITLE_COLOR, IMAGE_TYPE_PARTY_SIZE, SECTION_REDEEMABLE, \
    SECTION_REDEEMED, SECTION_PINGED, SECTION_NOT_REDEEMABLE, SMILES_ICON_URL, SMILES_COLOR_CODE, \
    COLOR_CODE_ALREADY_REDEEMED, SORT_EXPIRED, SORT_PURCHASED_AVAILABLE_IN_FUTURE, SORT_REDEEMABLE, SORT_REDEEMED, \
    SORT_PINGED, SORT_NOT_REDEEMABLE, LIVE_OFFERS_IMAGE
from common.models.api_messages import APIMessages
from common.models.category import Category
from common.models.ent_customer_profile import EntCustomerProfile
from common.models.offer import Offer
from common.models.redemption import Redemption
from common.modules.v1.category_module import CategoryModule
from common.modules.v1.voucher_module import VoucherModule
from common.utils.api_utils import set_hours, get_api_configurations, multi_key_sort, get_current_time_of_location, \
    get_formatted_date
from common.utils.cummunicator import communicator
from common.utils.translation_manager import TranslationManager
from common.utils.v_1.shared_util import SharedUtil


class OfferModule(object):
    """

    """
    @staticmethod
    def get_offers_from_db(**kwargs):

        return Offer.find_by_outlets_v3(
            company=kwargs['company'],
            is_ent=kwargs['is_ent'],
            pings_received_offer_ids=kwargs['pings_received_offer_ids'],
            customer=kwargs['customer'],
            merchant_id=kwargs['merchant_id'],
            outlet_id=kwargs.get('outlet_id'),
            outlet_ids=kwargs['outlet_ids'],
            offer_id=kwargs['offer_id'],
            only_delivery=kwargs['only_delivery'],
            outlet_exclude_from_offers=kwargs['all_offers_active'],
            show_cheer_offers=kwargs['show_cheer_offers'],
            personal_cheer_offers=kwargs['personal_cheer_offers'],
            location_id=kwargs.get('location_id', 0),
            is_merlin_offers_to_show=kwargs['is_merlin_offers_to_show'],
            selected_category=kwargs['selected_category'],
            is_take_away_enabled=kwargs['is_take_away'],
            enable_delivery_cashless=kwargs['cashless_delivery_enabled']
        )

    @staticmethod
    def get_offers_from_es(**kwargs):

        # TODO: Test with ES.
        offers_es = kwargs['offers_es']
        offer_id = 0
        if kwargs.get('offer_id', 0):
            offer_id = kwargs.get('offer_id', 0)
        category = None

        from common.constants import VALID_CATEGORIES

        if kwargs.get('selected_category') in VALID_CATEGORIES:
            category = kwargs['selected_category']

        if kwargs.get('customer'):
            product_ids = kwargs['customer'].get('product_ids', [])
            filtered = []
            for offer in offers_es:
                if category and offer['category'] != category:
                    continue
                if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                    continue
                if offer_id and offer['id'] != kwargs['offer_id']:
                    continue
                if not (
                    (
                        offer['is_ent'] == 1 and
                        offer['is_dummy_product'] != 1 and
                        offer['show_offers_if_purchased'] != 1 and
                        offer['is_freemium'] != 1
                    ) or
                    (
                        offer['product_id'] in product_ids or offer['id'] in kwargs['pings_received_offer_ids']
                    )
                ):
                    continue
                filtered.append(offer)
            offers_es = filtered
        else:
            filtered = []
            for offer in offers_es:
                if category and offer['category'] != category:
                    continue
                if not kwargs.get('is_merlin_offers_to_show') and offer['is_merlin_offer'] == 1:
                    continue
                if offer_id and offer['id'] != kwargs['offer_id']:
                    continue
                if not (offer['is_ent'] == 1 and
                        offer['is_dummy_product'] != 1 and
                        offer['show_offers_if_purchased'] != 1 and
                        offer['is_cheers'] != 1 and
                        offer['is_freemium'] != 1):
                    continue
                filtered.append(offer)
            offers_es = filtered
        return offers_es

    @staticmethod
    def is_offer_allowed_to_ping(
            ping_offers_enabled,
            offer_type,
            category,
            is_freemium,
            membership_sub_group,
            is_merlin_offer
    ):
        """
        Checks whether or not the offer is allowed to be pinged.
        :return: bool
        """
        if not ping_offers_enabled:
            return False
        elif membership_sub_group == EntCustomerProfile.ACTIVE_MEMBERSHIP_SUB_GROUP:
            return False
        return (
                offer_type != Offer.TYPE_MEMBER and
                category.lower() != Category.TRAVEL.lower() and
                is_freemium == 0 and
                not is_merlin_offer
        )

    @staticmethod
    def get_offer_redeemability(offer, location_id):

        from common.rest_urls import RedemptionServiceAPIUrlsV3

        redeemability_params = {
            'offer_ids': offer.get('id'),
            'is_birthday_offer': offer.get('is_birthday_offer'),
            'location_id': location_id,
        }
        return communicator.communicate(
            RedemptionServiceAPIUrlsV3.CALCULATE_REDEEMABILITY,
            'GET',
            payload=redeemability_params
        ).json().get('data', {})

    @staticmethod
    def get_redemption_quantities_for_offers(customer, company, offer_ids):

        redemption_quantities = {}

        if customer.get('is_active_family_member', False):
            redemption_results = Redemption.get_redeemed_quantities_for_customer(
                customer_id=customer.get('customer_id', 0),
                family_id=customer.get('family_info', {}).get('id'),
                primary_user_id=customer['primary_user_id'],
                offer_id=offer_ids,
                company=company,
                is_onboarding=customer.get('is_using_trial', 0)
            )
            for redemption in redemption_results:
                redemption_quantities[redemption['offer_id']] = int(redemption.qty)

            if customer['primary_user_id'] != customer['customer_id']:
                secondary_birthday_redemptions = Redemption.get_birthday_redeemed_quantities_for_secondary_customer(
                    customer_id=customer.get('customer_id', 0),
                    is_onboarding=customer.get('is_using_trial', 0),
                    offer_id=offer_ids,
                    company=company
                )
                redemption_quantities.update(secondary_birthday_redemptions)
        else:
            redemption_results = Redemption.get_redeemed_quantities_for_customer(
                customer_id=customer.get('customer_id', 0),
                family_id=customer.get('family_info', {}).get('id'),
                primary_user_id=customer['primary_user_id'],
                offer_id=offer_ids,
                company=company,
                is_onboarding=customer.get('is_using_trial', 0),
            )
            for redemption in redemption_results:
                redemption_quantities[redemption.offer_id] = int(redemption.qty)

        return redemption_quantities

    def __process_offers(self, **kwargs):

        offers = []
        offer_ids = []
        offers_to_delete = []
        outlet_exclude_from_offers = kwargs.get('all_offers_active', True)
        customer = kwargs['customer']
        location_id = kwargs.get('location_id')
        offer_categories = kwargs['offer_categories']
        offer_sub_categories = kwargs['offer_sub_categories']
        only_delivery = kwargs.get('only_delivery', False)

        if only_delivery:
            outlet_exclude_from_offers = False

        ids = []
        has_dinner_offers = True

        delivery_offers_count = 0
        take_away_offers_count = 0

        for offer_index, offer in enumerate(kwargs['offers']):
            offer = offer._asdict()
            offers.append(offer)

            offer_ids.append(offer['id'])
            if offer.get('cashless_delivery_enabled', False) and outlet_exclude_from_offers:
                outlet_exclude_from_offers = False

            if isinstance(offer.get('outlet_ids'), list):
                outlet_ids = offer['outlet_ids']

            elif isinstance(offer.get('outlet_ids'), str):
                outlet_ids = list(set(map(int, filter(None, offer.get('outlet_ids').split(',')))))

            else:
                outlet_ids = []

            if (
                not only_delivery and
                location_id in SharedUtil.get_delivery_enabled_location_ids_against_company(kwargs['company'])
            ):
                if offer.get('is_take_away_offer', False):
                    take_away_offers_count += 1

            if (
                not only_delivery and
                location_id in SharedUtil.get_delivery_enabled_location_ids_against_company(kwargs['company']) and
                not outlet_exclude_from_offers
            ):
                if kwargs.get('outlet_id'):
                    # for cashless location we will exclude the offers for merchant details screen to show view
                    # delivery offers button this will be instantiated from delivery cashless merchant details screen
                    # https://entertainerproducts.atlassian.net/browse/DC-34
                    if kwargs['cashless_delivery_enabled']:
                        if offer.get('cashless_delivery_enabled', False) and offer('is_delivery_cashless_offer'):
                            if kwargs.get('outlet_id', 0) in outlet_ids:
                                delivery_offers_count += 1
                            offers_to_delete.append(offer_index)
                            ids.extend(outlet_ids)
                            continue
                        elif offer.get('is_delivery', False):
                            offers_to_delete.append(offer_index)
                            ids.extend(outlet_ids)
                            continue

                    if kwargs.get('outlet_id', 0) and kwargs.get('outlet_id', 0) not in outlet_ids:
                        offers_to_delete.append(offer_index)
                        ids.extend(outlet_ids)
                        continue
                else:
                    # for global search and cashless location if outlet is not part of delivery_cashless then exclude
                    # cashless_delivery_enabled and is_delivery offers
                    if (
                            offer.get('cashless_delivery_enabled', False) or
                            offer.get('is_delivery', False)
                    ):
                        offers_to_delete.append(offer_index)
                        ids.extend(outlet_ids)
                        continue

            if kwargs.get('is_merlin_offers_to_show'):
                offer['merlin_title'] = kwargs.get('merchant_name')

            if offer.get('category', '') not in offer_categories:
                offer_categories.append(offer.get('category'))

            if offer.get('sub_category', '') and offer.get('sub_category', '') not in offer_sub_categories:
                offer_sub_categories.append(offer.get('sub_category'))

            offer.update({
                'conditions': json.loads(offer.get('conditions', '{}')),
                'redeemability': 0,
                'is_purchased': False,
                'allowed_onboarding': False,
                'is_offer_valid_in_future': False,
                'is_offer_expired': False,
                'quantity_redeemable': 0,
                'quantity_redeemed': 0,
                'quantity_not_redeemable': offer.get('quantity', 0),
                'shared_sent_count': 0,
                'shared_received_count': 0,
                'shared_redemptions_count': 0,
                'is_show_purchase_button': False,
                'is_new': offer['type'] == Offer.TYPE_NEW_OFFER,
                "is_pingable": self.is_offer_allowed_to_ping(
                    ping_offers_enabled=kwargs['ping_enabled'],
                    offer_type=offer['type'],
                    category=offer['category'],
                    is_freemium=offer['is_freemium'],
                    is_merlin_offer=offer['is_merlin_offer'],
                    membership_sub_group=customer.get('membership_sub_group',
                                                      EntCustomerProfile.INACTIVE_MEMBERSHIP_SUB_GROUP)
                ),
                'outlet_ids': outlet_ids,
                'merlin_title': offer['merlin_title'],
                'is_merlin_offer': bool(offer['is_merlin_offer']),
                'valid_from_date': set_hours(offer['valid_from_date'], 4),
                'expiration_date': set_hours(offer['expiration_date'], 14),
                'has_cinema_offers': offer.get('has_cinema_offers', 0),
                'cinema_venue_id': offer.get('cinema_venue_id', 0),
                'is_bonus_offers': offer.get('is_bonus_offers', 0),
                'is_core_product': offer.get('is_core_product', 0),
                'is_core_fine_dining_product': offer.get('is_core_fine_dining_product', 0),
                "is_core_family_product": offer.get('is_core_family_product', 0),
                "is_core_fitness_product": offer.get('is_core_fitness_product', 0),
                'is_monthly_cheers': 0,
                'is_redeemable': 0
            })

            # Monthly offer check on base of ismember flag and offer_type if show_monthly_offers_on_product is True.
            if kwargs.get('show_monthly_offers_on_product', True):
                if offer['type'] == Offer.TYPE_MEMBER:
                    offer['is_monthly'] = offer['type'] == Offer.TYPE_MEMBER
                else:
                    offer['is_monthly'] = bool(offer.get('ismember'))
            else:
                offer['is_monthly'] = offer['type'] == Offer.TYPE_MEMBER

            if offer.get('is_merlin_offer'):
                offer['outlet_merlin_urls'] = kwargs['outlet_merlin_urls']
            else:
                offer['outlet_merlin_urls'] = []

            if offer.get('is_monthly_offer') and offer.get('is_cheers'):
                offer['is_monthly_cheers'] = 1

            if customer['is_user_logged_in']:
                is_top_up_offer = False
                top_up_offer_count = 0

                for top_up_offer in kwargs.get('top_up_offers', []):
                    if top_up_offer.offer_id == offer.get('id'):
                        is_top_up_offer = True
                        top_up_offer_count = top_up_offer_count + 1

                offer_redeemability = self.get_offer_redeemability(offer=offer, location_id=location_id)
                offer_product_id = "{}_{}".format(offer.get('id'), offer.get('product_id'))
                redeemability = offer_redeemability.get(offer_product_id, {})

                offer.update({
                    'redeemability': redeemability.get('redeemability', 2),
                    'is_purchased': redeemability.get('is_purchased'),
                    'allowed_onboarding': redeemability.get('allowed_onboarding'),
                    'is_offer_valid_in_future': redeemability.get('is_offer_valid_in_future'),
                    'is_offer_expired': redeemability.get('is_offer_expired'),
                    'quantity_redeemable': redeemability.get('quantity_redeemable', 1),
                    'quantity_redeemed': redeemability.get('quantity_redeemed', 0),
                    'quantity_not_redeemable': redeemability.get('quantity_not_redeemable', 0),
                    'shared_sent_count': redeemability.get('shared_sent_count', 0),
                    'shared_received_count': redeemability.get('shared_received_count', 0),
                    'shared_redemptions_count': redeemability.get('shared_redemptions_count', 0),
                    'is_show_purchase_button': redeemability.get('is_show_purchase_button'),
                    'personal_shared_received_count': redeemability.get('personal_shared_received_count', 0),
                    'personal_shared_redemptions_count': redeemability.get('personal_shared_redemptions_count', 0),
                    'is_top_up_offer': is_top_up_offer
                })

            if offer.get('redeemability') in (Redemption.REDEEMABLE, Redemption.REUSABLE):
                offer['is_redeemable'] = 1

            if kwargs.get('return_outlet_ids'):
                ids.extend(offer['outlet_ids'])

        if ids:
            ids = list(set(ids))

        for offer_index in sorted(offers_to_delete, reverse=True):
            try:
                del offers[offer_index]
            except IndexError:
                pass

        if kwargs.get('return_outlet_ids'):
            return (
                offers,
                ids,
                offer_categories,
                offer_sub_categories,
                offer_ids,
                delivery_offers_count,
                has_dinner_offers,
                take_away_offers_count
            )

        return (
            offers,
            [],
            offer_categories,
            offer_sub_categories,
            offer_ids,
            delivery_offers_count,
            has_dinner_offers,
            take_away_offers_count
        )

    def get_all_active_offers(self, **kwargs):

        pings_received_offer_ids = []

        for offer_received in kwargs['shared_offers_received']:
            if offer_received.offer_id not in pings_received_offer_ids:
                pings_received_offer_ids.append(offer_received.offer_id)

        kwargs['pings_received_offer_ids'] = pings_received_offer_ids

        if kwargs.get('offers_es'):
            kwargs['offers'] = self.get_offers_from_es(**kwargs)
        else:
            kwargs['offers'] = self.get_offers_from_db(**kwargs)

        return self.__process_offers(**kwargs)

    @staticmethod
    def allowed_offer_buy_back(
            top_up_offer_against_product,
            offer_type,
            offer_quantity_redeemed,
            is_member,
            is_active_family_member,
            membership_sub_group
    ):
        """
        Logic to allow/disallow offer pay back.
        :rtype: bool
        """
        return (
                not top_up_offer_against_product and
                offer_type != Offer.TYPE_MEMBER and
                offer_quantity_redeemed and
                (is_member or is_active_family_member) and
                membership_sub_group != EntCustomerProfile.ACTIVE_MEMBERSHIP_SUB_GROUP
        )

    @staticmethod
    def get_message_for_offer_type(locale, offer_type, spend, reward, discount_off_or_percentage_off):
        """
        Gets the offer message for the offer type.
        :param str locale: locality of the user.
        :param str offer_type: type of the offer.
        :param str spend: spends of the user.
        :param str reward: rewards of the user till now.
        :param str discount_off_or_percentage_off: discount of the user availed.
        :rtype: str
        """
        if not offer_type or int(offer_type) < 1:
            offer_type = OFFER_TYPE_VALUE_DEFAULT

        offer_type = int(offer_type)
        message = ""
        if offer_type == OFFER_TYPE_VALUE_DEFAULT:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_1, locale)
        elif offer_type == OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_1, locale)
        elif offer_type == OFFER_TYPE_VALUE_PERCENTAGE_OFF:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_2, locale)
            message = message.replace('_percentage_value_', str(discount_off_or_percentage_off))
        elif offer_type == OFFER_TYPE_VALUE_GIFT:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_3, locale)
        elif offer_type == OFFER_TYPE_VALUE_PACKAGE:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_4, locale)
        elif offer_type == OFFER_TYPE_VALUE_FIX_PRICE_OFF:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_5, locale)
            message = message.replace('_discount_value_', str(discount_off_or_percentage_off))
        elif offer_type == OFFER_TYPE_VALUE_SPEND_THIS_GET_THIS:
            message = TranslationManager.get_translation(TranslationManager.voucher_type_6, locale)
            message = message.replace('_spend_value_', str(spend))
            message = message.replace('_reward_value_', str(reward))
        return message

    @staticmethod
    def get_offer_deal_details(offer, category_color):
        """
        Get data dict containing deal_details & hours_validation_text keys of offer.
        deals details dict containing day wise data list will be in same order as displaying on redemption screen
        :param dict offer: offer data
        :return dict: data dict containing deal_details & hours_validation_text keys
        """
        data = []
        if offer.get('is_deals_product', False):
            deal_details = []
            if offer['deal_validity_all_week']:
                deals_validity = {
                    'Sun': {'id': 1, 'title': 'S', 'status': True},
                    'Mon': {'id': 2, 'title': 'M', 'status': True},
                    'Tue': {'id': 3, 'title': 'T', 'status': True},
                    'Wed': {'id': 4, 'title': 'W', 'status': True},
                    'Thu': {'id': 5, 'title': 'T', 'status': True},
                    'Fri': {'id': 6, 'title': 'F', 'status': True},
                    'Sat': {'id': 7, 'title': 'S', 'status': True}
                }
            else:
                deals_validity = {
                    'Sun': {'id': 1, 'title': 'S', 'status': offer['deal_valid_on_sunday']},
                    'Mon': {'id': 2, 'title': 'M', 'status': offer['deal_valid_on_monday']},
                    'Tue': {'id': 3, 'title': 'T', 'status': offer['deal_valid_on_tuesday']},
                    'Wed': {'id': 4, 'title': 'W', 'status': offer['deal_valid_on_wednesday']},
                    'Thu': {'id': 5, 'title': 'T', 'status': offer['deal_valid_on_thursday']},
                    'Fri': {'id': 6, 'title': 'F', 'status': offer['deal_valid_on_friday']},
                    'Sat': {'id': 7, 'title': 'S', 'status': offer['deal_valid_on_saturday']}
                }
            if (
                deals_validity['Sun'].get('status') or
                deals_validity['Mon'].get('status') or
                deals_validity['Tue'].get('status') or
                deals_validity['Wed'].get('status') or
                deals_validity['Thu'].get('status') or
                deals_validity['Fri'].get('status') or
                deals_validity['Sat'].get('status')
            ):
                for deal in deals_validity.values():
                    if deal.get('status'):
                        day_background_color = category_color
                    else:
                        day_background_color = GREY_BACKGROUND_COLOR
                    deal_details.append({
                        'title': deal['title'],
                        'is_offer_valid': bool(deal['status']),
                        'id': deal['id'],
                        'day_text_color': OFFER_TEXT_COLOR,
                        'day_background_color': day_background_color
                    })
                data = multi_key_sort(deal_details, ['id'])
            return data

    @staticmethod
    def get_deal_validity_data(offer, locale, location_id):
        """
        Verifies offer time and days

        1. verify is offer valid for whole week or not
        2. verify on which day offer is valid
        3. verify offer valid for whole day or for some time span

        :param dict offer: offer
        :param str locale: language to get error message in selected language
        :param int location_id: location id to calculate time in current location
        :returns dict of offer redeemability flag, offer redeemability value, error message title and error_message
        :rtype dict
        """
        try:
            # extract data from offer
            offer_valid_to_time = offer.get('valid_to_time', 0)
            offer_valid_from_time = offer.get('valid_from_time', 0)

            # get utc_time and convert into user timezone. and then convert it into timedelta object for comparison
            current_location_time = get_current_time_of_location(location_id)
            current_day = current_location_time.strftime('%A')
            utc_time = datetime.timedelta(
                hours=current_location_time.hour,
                minutes=current_location_time.minute,
                seconds=current_location_time.second
            )
            is_deal_valid_on_day = False

            # check offer settings updated or not w.r.t deals columns
            # check deal valid on that day
            if (
                offer.get('deal_validity_all_week', 0) or
                offer.get('deal_valid_on_{current_day}'.format(current_day=current_day.lower()))
            ):
                is_deal_valid_on_day = True

            # check deal validity on that hours
            if is_deal_valid_on_day and (
                    offer.get('deal_validity_all_day', 0) or
                    (offer_valid_from_time < utc_time < offer_valid_to_time)
            ):
                return {
                    'is_redeemable': True,
                    'redeemability': Redemption.REDEEMABLE,
                    'restriction_title': '',
                    'restriction_message': ''
                }

            error_message = TranslationManager.get_translation(TranslationManager.OFFER_RESTRICTION_MESSAGE, locale)
            offer_restriction_title = TranslationManager.get_translation(TranslationManager.OOPS_TEXT, locale)
            return {
                'is_redeemable': False,
                'redeemability': Redemption.NOT_REDEEMABLE,
                'restriction_title': offer_restriction_title,
                'restriction_message': error_message
            }

        except Exception:
            return {
                'is_redeemable': False,
                'redeemability': Redemption.NOT_REDEEMABLE,
                'restriction_title': '',
                'restriction_message': ''
            }

    @staticmethod
    def set_offer_label(offer_section, offer, offer_to_display, messages_locale, is_skip_mode=False):

        offer_to_display['product_sku'] = offer['product_sku']
        if offer['is_offer_expired']:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.expired_offer, messages_locale
            )
            return offer_to_display

        if offer_section == SECTION_REDEEMABLE:
            if offer['is_offer_valid_in_future']:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.purchased_available_from, messages_locale
                )
                offer_to_display['validity_date'] = get_formatted_date(offer['valid_from_date'])
            else:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.valid_to, messages_locale
                )
        elif offer_section == SECTION_REDEEMED:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.already_redeemed, messages_locale
            )
        elif offer_section == SECTION_PINGED:
            offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                TranslationManager.pinged, messages_locale
            )
        elif offer_section == SECTION_NOT_REDEEMABLE:
            if offer['is_show_purchase_button'] or is_skip_mode:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.included_in_mobile_product_not_yet_purchased, messages_locale
                )
            elif offer.get('is_purchaseable'):
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.this_product_is_no_more_purchasable, messages_locale
                )
            elif offer.get('category') == 'Travel':
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.THIS_IS_A_BUNDLED_PRODUCT,
                    locale=messages_locale
                )
            else:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.NOT_YET_PURCHASED, locale=messages_locale
                )
        if offer.get('has_cinema_offers', False):
            offer_to_display['sub_detail_label'] = ''

    def add_smiles_details(self, offer, offer_to_display, redeem_section, redeemability):

        if offer.get('smiles_earn_value'):
            offer_to_display['additional_details'].append(
                self.get_offer_sub_detail_object(
                    offer['smiles_earn_value'],
                    SMILES_ICON_URL,
                    "+{smiles} SMILES".format(smiles=offer['smiles_earn_value']),
                    SMILES_COLOR_CODE
                )
            )

        if (
            redeem_section != SECTION_REDEEMABLE or
            redeemability == Redemption.NOT_REDEEMABLE
        ):
            offer_to_display['additional_details'] = []
            offer_to_display['additional_details'].append(
                self.get_offer_sub_detail_object(
                    offer.get("smiles_earn_value", ""),
                    "",
                    offer_to_display.get('sub_detail_label', '').upper(),
                    COLOR_CODE_ALREADY_REDEEMED
                )
            )

    def initialize_offers_to_display_v592(self, **kwargs):

        offer = kwargs['offer']
        locale = kwargs['message_locale']
        url_update_v7 = kwargs['url_update_v7']
        category_color = CategoryModule.get_category_color_code(offer['category'])
        categories_list = []
        if offer['category']:
            categories_list = [offer['category']]
        offer_to_display = {
            'offer_id': offer['id'],
            'name': offer['name'],
            'category': offer['category'],
            'details': offer['details'],
            'offer_detail': offer.get('description', ''),
            'redeemability': kwargs['redeemability'],
            'is_cheers': bool(offer['is_cheers']),
            'is_pingable': False,
            'is_pinged': False,
            'is_topup_offer_allowed': False,
            'is_birthday_offer': offer['is_birthday_offer'],
            'is_family_offer': kwargs['is_family_offer'],
            'family_identifier': kwargs['family_identifier'],

            'hhs': kwargs['merchant_pin'],
            'offer_sequence': offer['offer_sequence'],
            'categories_analytics': CategoryModule.get_analytics_codes_against_categories(categories_list),
            'category_color': category_color,
            'voucher_type': offer['voucher_type'],
            'voucher_type_image': "",
            'conditions': offer['conditions'],
            'voucher_restriction1': offer['voucher_restriction1'],
            'voucher_restriction2': offer['voucher_restriction2'],
            'voucher_restrictions': offer['voucher_restrictions'],
            'savings_estimate': offer['savings_estimate'],
            'savings_estimate_aed': offer['savings_estimate_aed'],
            'savings_estimate_local_currency': offer['savings_estimate_local_currency'],
            'is_show_smiles': offer.get('show_smiles_earn_value', 0),
            'smiles_earn_value': offer.get('smiles_earn_value', 0),
            'smiles_burn_value': offer.get('smiles_burn_value', 0),
            'offer_pay_back_app_action_id': offer.get('offer_pay_back_app_action_id'),
            'dcp_license': offer.get('dcp_license'),
            'valid_from_date': offer['valid_from_date'],
            'expiration_date': offer['expiration_date'],
            'validity_date': offer['expiration_date'],
            'outlet_ids': offer['outlet_ids'],
            'merlin_title': offer['merlin_title'],
            'is_merlin_offer': offer['is_merlin_offer'],
            'outlet_merlin_urls': offer['outlet_merlin_urls'],
            'message': self.get_message_for_offer_type(
                locale,
                offer['voucher_type'],
                offer['spend'],
                offer['reward'],
                offer['percentage_off']
            ),
            'additional_details': [],
            'voucher_details': [],
            'voucher_rules_of_use': [],
            'sub_detail_label': ""
        }
        if kwargs['percentage_off']:
            offer_to_display['percentage_off'] = offer.get('percentage_off', 0)

        self.set_offer_label(
            kwargs['redeem_section'],
            offer,
            offer_to_display,
            locale,
            kwargs['is_skip_mode']
        )

        self.add_voucher_restrictions(offer_to_display=offer_to_display, **kwargs)

        self.add_people_detail(
            offer=offer,
            offer_to_display=offer_to_display,
            category_color=category_color,
            url_update_v7=url_update_v7,
            locale=locale
        )

        self.add_smiles_details(
            offer=offer,
            offer_to_display=offer_to_display,
            redeem_section=kwargs['redeem_section'],
            redeemability=kwargs['redeemability']
        )

        sort_order = self.get_otd_sort_order(offer=offer, redeem_section=kwargs['redeem_section'])
        if sort_order:
            offer_to_display['sort_order'] = sort_order

        if kwargs['url_update_v7'] and offer_to_display.get('additional_details', []):
            for additional_detail in offer_to_display.get('additional_details', []):
                additional_detail['color'] = V7_ADDITIONAL_DETAIL_COLOR

        if kwargs['live_offers_enabled']:
            offer_day_validity = self.get_offer_deal_details(offer, category_color)
            redeemability_data = self.get_deal_validity_data(offer, locale, kwargs['location_id'])

            is_live_offer = False
            if offer_day_validity:
                is_live_offer = True
                try:
                    # In case of Live Offer then remove person message and image from additional_details
                    del offer_to_display['additional_details'][0]
                except (KeyError, IndexError):
                    pass
            offer_to_display.update({
                'show_smiles': offer.get('show_smiles', True),
                'show_savings': offer.get('show_savings', True),
                'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
                'is_promo_code_offer': offer.get('is_promo_code_offer', False),
                'offer_day_validity': offer_day_validity,
                'is_live_offer': is_live_offer,
                'restriction_message': redeemability_data.get('restriction_message'),
                'restriction_title': redeemability_data.get('restriction_title')
            })

        else:
            offer_to_display.update({
                'show_smiles': offer.get('show_smiles', True),
                'show_savings': offer.get('show_savings', True),
                'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
                'is_promo_code_offer': offer.get('is_promo_code_offer', False)
            })
        offer_to_display.update(self.get_offer_to_display_tags(offer, kwargs['company'], locale))
        return offer_to_display

    def add_voucher_restrictions(self, offer_to_display, **kwargs):

        offer = kwargs['offer']
        offer['voucher_type'] = offer['voucher_type'] if offer['voucher_type'] else 1
        if offer['voucher_type']:
            voucher_type_details = VoucherModule.get_voucher_type_details(
                offer['voucher_type'],
                offer['category'],
                kwargs['message_locale'],
                kwargs['replace_241_type_with_141'],
                offer['is_monthly'],
                kwargs['company'],
                kwargs['url_update_v7']
            )
            if voucher_type_details:
                voucher_type_details['title'] = offer_to_display['message']
                offer_to_display['voucher_details'].append(voucher_type_details)
                offer_to_display['voucher_type_image'] = voucher_type_details['image']

        if offer.get('voucher_restriction1'):
            voucher_restriction1_details = VoucherModule.get_voucher_restriction_details(
                offer['voucher_restriction1'],
                offer['category'],
                kwargs['message_locale'],
                kwargs['url_update_v7']
            )
            if voucher_restriction1_details:
                offer_to_display['voucher_details'].append(voucher_restriction1_details)
                voucher_restriction1_details['title'] = voucher_restriction1_details['title']
                offer_to_display['additional_details'].append(voucher_restriction1_details)

        if offer.get('voucher_restriction2'):
            voucher_restriction2_details = VoucherModule.get_voucher_restriction_details(
                offer['voucher_restriction2'],
                offer['category'],
                kwargs['message_locale'],
                kwargs['message_locale'],
            )
            if voucher_restriction2_details:
                offer_to_display['voucher_details'].append(voucher_restriction2_details)

        if offer.get('voucher_restrictions'):
            offer_to_display['voucher_rules_of_use'].append(offer["voucher_restrictions"])

    @staticmethod
    def get_offer_sub_detail_object(id_='', image='', title='', color=''):
        """
        Gets offer sub detail object.
        :return:
        """
        return {'id': id_, 'image': image, 'title': title, 'color': color}

    def add_people_detail(self, offer, offer_to_display, category_color, url_update_v7, locale):

        if offer.get('no_of_people'):
            if offer['no_of_people'] == 1:
                _no_of_people_message = "1 {msg}".format(
                    msg=TranslationManager.get_translation(TranslationManager.Person, locale)
                )
            else:
                _no_of_people_message = "{number_of_people} {msg}".format(
                    number_of_people=offer['no_of_people'],
                    msg=TranslationManager.get_translation(TranslationManager.People, locale)
                )
            offer_to_display['additional_details'].append(
                self.get_offer_sub_detail_object(
                    '0',
                    VoucherModule.get_image_url(
                        image_type=IMAGE_TYPE_PARTY_SIZE,
                        category=offer['category'],
                        replace_241_type_with_141=False,
                        voucher_type_id=0,
                        voucher_restriction_id=0,
                        is_monthly=offer['is_monthly'],
                        company='',
                        url_update_v7=url_update_v7
                    ),
                    _no_of_people_message,
                    category_color
                )
            )

    @staticmethod
    def get_otd_sort_order(offer, redeem_section):

        if offer.get('is_offer_expired'):
            return SORT_EXPIRED

        if redeem_section == SECTION_REDEEMABLE:
            if offer['is_offer_valid_in_future']:
                return SORT_PURCHASED_AVAILABLE_IN_FUTURE
            else:
                return SORT_REDEEMABLE
        elif redeem_section == SECTION_REDEEMED:
            return SORT_REDEEMED
        elif redeem_section == SECTION_PINGED:
            return SORT_PINGED
        elif redeem_section == SECTION_NOT_REDEEMABLE:
            return SORT_NOT_REDEEMABLE

    @staticmethod
    def get_offer_to_display_tags(offer, company, locale):

        tag_info = {}
        if offer:
            environment = current_app.config.get('ENV', 'prod')
            offer_tags_labels = APIMessages.get_offer_labels(locale)
            offer_tags_colors = get_api_configurations(company, environment, config_group='offer_tag_color')

            if offer.get('is_promo_code_offer'):
                tag_info = {
                    'tag_title': offer_tags_labels.get('offer_tag_promo_code'),
                    'tag_bg_color': offer_tags_colors.get('promo'),
                    'tag_title_color': TAG_TITLE_COLOR
                }

            elif offer.get('is_deals_product'):
                tag_info = {
                    'tag_title': offer_tags_labels.get('offer_tag_live'),
                    'tag_bg_color': offer_tags_colors.get('live'),
                    'tag_title_color': TAG_TITLE_COLOR
                }
            elif offer.get('is_monthly'):
                tag_info = {
                    'tag_title': offer_tags_labels.get('offer_tag_resuable'),
                    'tag_bg_color': offer_tags_colors.get('re_usable'),
                    'tag_title_color': TAG_TITLE_COLOR
                }
            elif offer.get('offer_replenishment_enabled'):
                tag_info = {
                    'tag_title': offer_tags_labels.get('offer_tag_express'),
                    'tag_bg_color': offer_tags_colors.get('express'),
                    'tag_title_color': TAG_TITLE_COLOR
                }
        return tag_info

    def initialize_offer_to_display_array(self, **kwargs):

        offer = kwargs['offer']
        categories_list = []
        if offer['category']:
            categories_list = list(offer['category'])
        offer_to_display = {
            'categories_analytics': CategoryModule.get_analytics_codes_against_categories(categories_list),
            'hhs': kwargs['merchant_pin'],
            'offer_sequence': offer['offer_sequence'],
            'offer_id': offer['id'],
            'name': offer['name'],
            'category': "Services" if offer['category'] == "Retail" else offer['category'],
            'details': offer['details'],
            'is_cheers': bool(offer['is_cheers']),
            'voucher_restrictions': offer['voucher_restrictions'],
            'savings_estimate': round(offer['savings_estimate']),
            'savings_estimate_aed': offer['savings_estimate_aed'],
            'savings_estimate_local_currency': offer['savings_estimate_local_currency'],
            'redeemability': kwargs['redeemability'],
            'is_topup_offer_allowed': False,
            'is_pingable': False,
            'is_pinged': False,
            'is_show_smiles': offer['show_smiles_earn_value'],
            'smiles_earn_value': offer['smiles_earn_value'],
            'smiles_burn_value': offer['smiles_burn_value'],
            'offer_pay_back_app_action_id': offer['offer_pay_back_app_action_id'],
            'dcp_license': offer['dcp_license'], 'valid_from_date': offer['valid_from_date'],
            'expiration_date': offer['expiration_date'], 'validity_date': offer['expiration_date'],
            'outlet_ids': offer['outlet_ids'],
            'family_identifier': kwargs['family_identifier'],
            'is_birthday_offer': offer['is_birthday_offer'],
            'is_family_offer': kwargs['is_family_offer']
        }

        if kwargs['percentage_off']:
            offer_to_display['percentage_off'] = offer.get('percentage_off', 0)
        if kwargs['live_offers_enabled']:
            category_color = CategoryModule.get_category_color_code(offer['category'])
            offer_day_validity = self.get_offer_deal_details(offer, category_color)
            redeemability_data = self.get_deal_validity_data(offer, kwargs['message_locale'], kwargs['location_id'])

            is_live_offer = False
            if offer_day_validity:
                is_live_offer = True

            offer_to_display.update({
                'show_smiles': offer.get('show_smiles', True),
                'show_savings': offer.get('show_savings', True),
                'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
                'is_promo_code_offer': offer.get('is_promo_code_offer', False),
                'offer_day_validity': offer_day_validity,
                'is_live_offer': is_live_offer,
                'restriction_message': redeemability_data.get('restriction_message'),
                'restriction_title': redeemability_data.get('restriction_title')
            })
        else:
            offer_to_display.update({
                'show_smiles': offer.get('show_smiles', True),
                'show_savings': offer.get('show_savings', True),
                'is_swipe_based_offer_redemption': offer.get('is_swipe_based_offer_redemption', False),
                'is_promo_code_offer': offer.get('is_promo_code_offer', False),
            })
        return offer_to_display

    def get_offer_to_display(self, **kwargs):

        offer = kwargs['offer']

        if kwargs['is_offer_type_attributes_to_add']:
            offer_to_display = self.initialize_offers_to_display_v592(**kwargs)
        else:
            offer_to_display = self.initialize_offer_to_display_array(**kwargs)

            if offer.get('is_deals_product') and not offer_to_display.get('is_live_offer'):
                return False
            if offer.get('is_deals_product') and offer_to_display.get('is_live_offer'):
                offer_to_display['voucher_details'][0].update({'image': LIVE_OFFERS_IMAGE})
                offer_to_display['voucher_type_image'] = LIVE_OFFERS_IMAGE

            self.set_offer_label(
                kwargs['redeem_section'],
                kwargs['offer'],
                offer_to_display,
                kwargs['message_locale']
            )
            sort_order = self.get_otd_sort_order(offer=kwargs['offer'], redeem_section=kwargs['redeem_section'])
            if sort_order:
                offer_to_display['sort_order'] = sort_order

        return offer_to_display

    def formulate_ping_delivery_offers(self, **kwargs):

        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        if kwargs['ping_feature_enabled'] and kwargs['cashless_delivery_enabled']:
            if not offer_array.get('offers_to_display'):
                self.initialize_offers_array(offer_array, offer)
            if (
                offer['shared_received_count'] and
                offer_array['show_pinged_offers_delivery_section'] and
                offer['is_delivery']
            ):
                offer_array['is_show_purchase_button'] = False

                pinged_offers_redeemable = offer['shared_received_count'] - offer['shared_redemptions_count']

                for _ in range(pinged_offers_redeemable):
                    if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                        offer_to_display = self.get_offer_to_display(
                            redeemability=Redemption.REDEEMABLE,
                            redeem_section=SECTION_REDEEMABLE,
                            is_family_offer=True,
                            **kwargs
                        )
                        if offer_to_display:
                            if offer_array.get('offers_to_display'):
                                offer_array['offers_to_display'].append(offer_to_display)
                            else:
                                offer_array['offers_to_display'] = [offer_to_display]

                for _ in range(offer['shared_redemptions_count']):
                    offer_to_display = self.get_offer_to_display(
                        redeemability=Redemption.REDEEMED,
                        redeem_section=SECTION_REDEEMED,
                        is_family_offer=None,
                        **kwargs
                    )
                    if offer_to_display:
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

    def formulate_ping_non_delivery_offers(self, **kwargs):

        offer = kwargs['offer']
        offer_array = kwargs['offer_array']
        if (
            offer['shared_received_count'] and
            offer_array['show_pinged_offers_non_delivery_section'] and
            not offer['is_delivery']
        ):
            if not offer_array.get('offers_to_display'):
                self.initialize_offers_array(offer_array, offer)
            pinged_offers_redeemable = offer['shared_received_count'] - offer['shared_redemptions_count']
            for _ in range(pinged_offers_redeemable):
                if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                    offer_to_display = self.get_offer_to_display(
                        redeemability=Redemption.REDEEMABLE,
                        redeem_section=SECTION_REDEEMABLE,
                        is_family_offer=True,
                        **kwargs
                    )
                    if offer_to_display:
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

            # Show the Offers which are already redeemed
            for _ in range(offer['shared_redemptions_count']):
                offer_to_display = self.get_offer_to_display(
                    redeemability=Redemption.REDEEMED,
                    redeem_section=SECTION_REDEEMED,
                    is_family_offer=None,
                    **kwargs
                )
                if offer_to_display:
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

    def formulate_personal_ping_delivery_offers(self, **kwargs):

        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        if (
            offer.get('personal_shared_received_count') and
            offer_array.get('show_personal_pinged_offers_delivery_section') and
            offer['is_delivery']
        ):
            if not offer_array.get('offers_to_display'):
                self.initialize_offers_array(offer_array, offer)
            pinged_offers_redeemable = (
                offer['personal_shared_received_count'] - offer['personal_shared_redemptions_count']
            )

            for _ in range(pinged_offers_redeemable):
                if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                    family_flag = False
                    if offer['id'] in kwargs['personal_family_pinged_received']:
                        family_flag = True
                        kwargs['personal_family_pinged_received'].remove(offer['id'])
                    kwargs['is_family_offer'] = family_flag
                    offer_to_display = self.get_offer_to_display(
                        redeemability=Redemption.REDEEMABLE,
                        redeem_section=SECTION_REDEEMABLE,
                        is_family_offer=family_flag,
                        **kwargs
                    )
                    if offer_to_display:
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

            for _ in range(offer['personal_shared_redemptions_count']):
                offer_to_display = self.get_offer_to_display(
                    redeemability=Redemption.REDEEMED,
                    redeem_section=SECTION_REDEEMED,
                    is_family_offer=None,
                    **kwargs
                )
                if offer_to_display:
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

    def formulate_personal_ping_non_delivery_offers(self, **kwargs):

        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        if (
            offer.get('personal_shared_received_count') and
            offer_array.get('show_personal_pinged_offers_non_delivery_section') and
            not offer['is_delivery']
        ):
            if not offer_array.get('offers_to_display'):
                self.initialize_offers_array(offer_array, offer)
            pinged_offers_redeemable = (
                    offer['personal_shared_received_count'] - offer['personal_shared_redemptions_count']
            )

            for _ in range(pinged_offers_redeemable):
                if not offer['is_offer_expired'] and not offer['is_offer_valid_in_future']:
                    family_flag = False

                    if offer['id'] in kwargs['personal_family_pinged_received']:
                        family_flag = True
                        kwargs['personal_family_pinged_received'].remove(offer['id'])

                    offer_to_display = self.get_offer_to_display(
                        redeemability=Redemption.REDEEMABLE,
                        redeem_section=SECTION_REDEEMABLE,
                        is_family_offer=family_flag,
                        **kwargs
                    )
                    if offer_to_display:
                        if offer_array.get('offers_to_display'):
                            offer_array['offers_to_display'].append(offer_to_display)
                        else:
                            offer_array['offers_to_display'] = [offer_to_display]

            for _ in range(offer['personal_shared_redemptions_count']):
                offer_to_display = self.get_offer_to_display(
                    redeemability=Redemption.REDEEMED,
                    redeem_section=SECTION_REDEEMED,
                    is_family_offer=None,
                    **kwargs
                )
                if offer_to_display:
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

    @staticmethod
    def initialize_offers_array(offer_array, offer):

        offer_array['product_id'] = offer['product_id']
        offer_array['purchase_product_id'] = offer['purchase_product_id']
        offer_array['section_name'] = offer.get('product_name')
        offer_array['product_sku'] = offer['product_sku']
        offer_array['is_delivery_section'] = bool(offer['is_delivery'])
        offer_array['is_monthly_section'] = offer['is_monthly']
        offer_array['is_show_purchase_button'] = offer['is_show_purchase_button']
        offer_array['offers_to_display'] = []
        return offer_array

    def formulate_redeemable_product_offers(self, **kwargs):
        """
        Show product offers that are redeemable.
        """
        offer = kwargs['offer']
        offer_array = kwargs['offer_array']
        for _ in range(int(offer.get('quantity_redeemable', 0))):
            redeemability = offer['redeemability']

            if redeemability == Redemption.REUSABLE:
                redeemability = Redemption.REDEEMABLE

            offer_to_display = self.get_offer_to_display(
                redeemability=Redemption.REDEEMABLE,
                redeem_section=SECTION_REDEEMABLE,
                **kwargs
            )
            if offer_to_display:
                if offer['redeemability'] == Redemption.REDEEMABLE and not offer['allowed_onboarding']:
                    offer_to_display['is_pingable'] = offer['is_pingable']

                # If the Offer is redeemable and belongs to the Birthday SKU, change the validity date of
                # the offer to the last date of the current month.
                if (
                    kwargs['birthday_feature_enabled'] and
                    kwargs['has_birthday_month'] and
                    offer['product_sku'] in kwargs['birthday_skus'] and
                    redeemability == Redemption.REDEEMABLE and
                    kwargs['birthday_offers_validity']
                ):
                    offer_to_display['validity_date'] = offer['expiration_date']
                    if kwargs['birthday_offers_validity'] < offer['expiration_date']:
                        offer_to_display['validity_date'] = kwargs['birthday_offers_validity']

                if offer_to_display['is_pingable']:
                    kwargs['offer_flags']['is_any_offer_pingable'] = True

                if offer_array.get('offers_to_display'):
                    offer_array['offers_to_display'].append(offer_to_display)
                else:
                    offer_array['offers_to_display'] = [offer_to_display]

    def formulate_redeemed_product_offers(self, **kwargs):
        """
        Show products that have already been redeemed.
        """
        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        for _ in range(int(offer.get('quantity_redeemed', 0))):
            offer_to_display = self.get_offer_to_display(
                redeemability=Redemption.REDEEMED,
                redeem_section=SECTION_REDEEMED,
                **kwargs
            )
            if offer_to_display:
                offer_to_display['is_topup_offer_allowed'] = False
                # Offer Buy Back Allowed
                if offer.get('is_purchased', False):
                    offer_to_display['is_topup_offer_allowed'] = offer.get('top_up_offer_allowed', False)
                # if offer is purchased
                if kwargs['is_on_trial'] or offer.get('is_purchased', False):
                    if offer_array.get('offers_to_display'):
                        offer_array['offers_to_display'].append(offer_to_display)
                    else:
                        offer_array['offers_to_display'] = [offer_to_display]

    def formulate_pinged_product_offers(self, **kwargs):
        """
        Show product offers that have been pinged.
        """
        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        for _ in range(offer['shared_sent_count']):
            offer_to_display = self.get_offer_to_display(
                redeemability=Redemption.NOT_REDEEMABLE,
                redeem_section=SECTION_PINGED,
                **kwargs
            )
            if offer_to_display:
                offer_to_display['is_pinged'] = True
                if offer_array.get('offers_to_display'):
                    offer_array['offers_to_display'].append(offer_to_display)
                else:
                    offer_array['offers_to_display'] = [offer_to_display]

    def formulate_unredeemable_product_offers(self, **kwargs):
        """
        Show the product offers which are not redeemable.
        """
        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        for _ in range(int(offer.get('quantity_not_redeemable', 0))):
            offer_to_display = self.get_offer_to_display(
                redeemability=Redemption.NOT_REDEEMABLE,
                redeem_section=SECTION_PINGED,
                **kwargs
            )
            if offer_to_display:
                if offer_array.get('offers_to_display'):
                    offer_array['offers_to_display'].append(offer_to_display)
                else:
                    offer_array['offers_to_display'] = [offer_to_display]

    def formulate_product_offers(self, **kwargs):

        offer = kwargs['offer']
        offer_array = kwargs['offer_array']

        if offer_array['section_name'] == offer['product_name']:
            if not offer_array.get('offers_to_display'):
                self.initialize_offers_array(offer_array, offer)
            kwargs['is_family_offer'] = None
            self.formulate_redeemable_product_offers(**kwargs)
            self.formulate_redeemed_product_offers(**kwargs)
            self.formulate_pinged_product_offers(**kwargs)
            self.formulate_unredeemable_product_offers(**kwargs)

    @staticmethod
    def freeze_offers(offers_array, message_locale):
        """
        Freezes offers in response in case user's account has been frozen/blacklisted.
        """
        for offer_array in offers_array:
            for offer_to_display in offer_array['offers_to_display']:
                offer_to_display['sub_detail_label'] = TranslationManager.get_translation(
                    TranslationManager.user_account_frozen,
                    message_locale
                )
                offer_to_display['redeemability'] = Redemption.NOT_REDEEMABLE
                offer_to_display['is_pingable'] = False

    def formulate_offer_details_array(self, **kwargs):

        offer_flags = {
            'is_any_offer_pingable': kwargs['is_any_offer_pingable']
        }
        kwargs['offer_flags'] = offer_flags

        for offer in kwargs['offers']:
            kwargs['percentage_off'] = offer['voucher_type'] == Offer.OFFER_TYPE_VALUE_PERCENTAGE_OFF
            for offer_array in kwargs['offers_array']:
                self.formulate_ping_delivery_offers(
                    offer_array=offer_array,
                    offer=offer,
                    **kwargs
                )
                self.formulate_ping_non_delivery_offers(
                    offer_array=offer_array,
                    offer=offer,
                    **kwargs
                )
                self.formulate_personal_ping_delivery_offers(
                    offer_array=offer_array,
                    offer=offer,
                    **kwargs
                )
                self.formulate_personal_ping_non_delivery_offers(
                    offer_array=offer_array,
                    offer=offer,
                    **kwargs
                )
                self.formulate_product_offers(
                    offer_array=offer_array,
                    offer=offer,
                    **kwargs
                )

        is_any_offer_pingable = kwargs['offer_flags']['is_any_offer_pingable']

        # Remove sections where there is no offer available to redeem.
        filtered_offers = []
        for product_section in kwargs['offers_array']:
            if product_section['offers_to_display']:
                product_section['offers_to_display'] = multi_key_sort(
                    product_section['offers_to_display'],
                    ['sort_order', 'offer_sequence', 'offer_id']
                )
            filtered_offers.append(product_section)

        if kwargs['is_user_account_frozen']:
            self.freeze_offers(filtered_offers, kwargs['message_locale'])
            is_any_offer_pingable = False

        return filtered_offers, is_any_offer_pingable

    @staticmethod
    def get_birthday_offer_validity():
        """
        Returns date of validity in case of birthday offer.
        """
        offer_validity_date = datetime.datetime.now().date()
        offer_validity_date = offer_validity_date + datetime.timedelta(
            days=EntCustomerProfile.HAPPY_BIRTHDAY_END_RANGE_DAYS
        )
        offer_validity_date = datetime.datetime.strptime(
            offer_validity_date.strftime("%Y-%m-%dT12:00:00"),
            "%Y-%m-%dT%H:%M:%S"
        )
        return offer_validity_date
