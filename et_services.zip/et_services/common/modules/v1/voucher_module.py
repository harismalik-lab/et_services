from common.constants import VOUCHER_RESTRICTIONS, IMAGE_TYPE_VOUCHER_RESTRICTION, IMAGE_TYPE_VOUCHER_TYPE, \
    VOUCHER_TYPE_IMAGE_URL_PREFIX, VOUCHER_TYPE_IMAGE_URL_PREFIX_V7_V7, CATEGORY_NAME_TRAVEL, \
    CATEGORY_NAME_SERVICES, CATEGORY_NAME_RETAIL, CATEGORY_NAME_RESTAURANTS_AND_BARS, CATEGORY_NAME_LEISURE, \
    CATEGORY_NAME_BODY, OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE, VOUCHER_TYPE_IMAGE_URL_PREFIX_HS, \
    VOUCHER_RESTRICTION_IMAGE_URL_PREFIX, IMAGE_TYPE_PARTY_SIZE, PARTY_SIZE_IMAGE_URL_PREFIX
from common.models.wl_company import WlCompany
from common.utils.translation_manager import TranslationManager
from .category_module import CategoryModule


class VoucherModule(object):

    CATEGORY_IMAGE_PREFIX_MAPPING = {
        CATEGORY_NAME_BODY: "body",
        CATEGORY_NAME_LEISURE: "leisure",
        CATEGORY_NAME_RESTAURANTS_AND_BARS: "food",
        CATEGORY_NAME_RETAIL: "retail",
        CATEGORY_NAME_SERVICES: "services",
        CATEGORY_NAME_TRAVEL: "travel",
    }

    @classmethod
    def get_voucher_restriction_details(cls, voucher_restriction_id, offer_category, locale='en', url_update_v7=False):
        """
        Gets voucher restriction details.
        """
        _voucher_restriction_key = ''

        if VOUCHER_RESTRICTIONS.get(voucher_restriction_id):
            _voucher_restriction_key = getattr(TranslationManager, f'voucher_restriction_{voucher_restriction_id}', '')
            voucher_restriction_title = TranslationManager.get_translation(_voucher_restriction_key, locale)
            if voucher_restriction_title:
                from common.utils.api_utils import get_category_color_code
                category_color = get_category_color_code(offer_category)
                return {
                    'id': voucher_restriction_id,
                    'image': cls.get_image_url(
                        image_type=IMAGE_TYPE_VOUCHER_RESTRICTION,
                        category=offer_category,
                        voucher_type_id=0,
                        company='',
                        is_monthly=False,
                        replace_241_type_with_141=False,
                        voucher_restriction_id=voucher_restriction_id,
                        url_update_v7=url_update_v7
                    ),
                    'title': voucher_restriction_title,
                    'color': category_color
                }

    @classmethod
    def get_voucher_type_details(
            cls,
            voucher_type,
            offer_category,
            locale,
            replace_241_type_with_141,
            is_monthly,
            company,
            url_update_v7
    ):
        """
        Returns voucher type details.
        :rtype: dict
        """
        if company.lower() == WlCompany.COMPANY_CODE_HCS_Singapure:
            replace_241_type_with_141 = True
        voucher_types = {
            '1': 'Buy One Get One',
            '2': 'PERCENTAGE OFF',
            '3': 'GIFT',
            '4': 'PACKAGE',
            '6': 'SPEND THIS GET THIS'
        }
        if voucher_types.get(str(voucher_type)):
            if voucher_type == 1:
                if replace_241_type_with_141:
                    voucher_type_key = TranslationManager.voucher_type_141
                else:
                    voucher_type_key = TranslationManager.voucher_type_1
            else:
                voucher_type_key = getattr(TranslationManager, f'voucher_type_{voucher_type}', '')

            voucher_type_title = TranslationManager.get_translation(voucher_type_key, locale)
            if voucher_type_title:
                category_color = CategoryModule.get_category_color_code(offer_category)
                return {
                    'id': voucher_type,
                    'image': cls.get_image_url(
                        IMAGE_TYPE_VOUCHER_TYPE,
                        offer_category,
                        voucher_type,
                        replace_241_type_with_141,
                        '',
                        is_monthly,
                        company,
                        url_update_v7=url_update_v7
                    ),
                    'title': voucher_type_title,
                    'color': category_color
                }

    @classmethod
    def get_image_url(
            cls,
            image_type,
            category,
            voucher_type_id,
            replace_241_type_with_141,
            voucher_restriction_id,
            is_monthly,
            company,
            url_update_v7
    ):
        """
        Gets image url.
        :rtype: str
        """
        image_url = ""
        if category:
            voucher_type_img_url_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX
            _category = cls.CATEGORY_IMAGE_PREFIX_MAPPING.get(category)
            if url_update_v7:
                voucher_type_img_url_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX_V7_V7
            if _category:
                end_format = ""
                if voucher_type_id == OFFER_TYPE_VALUE_BUY_ONE_GET_ONE_FREE:
                    end_format = "_1_for_1"
                if image_type:
                    if image_type == IMAGE_TYPE_VOUCHER_TYPE:
                        if is_monthly:
                            if replace_241_type_with_141:
                                image_url = "{}{}_{}{}.png".format(
                                    voucher_type_img_url_prefix,
                                    "monthly",
                                    voucher_type_id,
                                    end_format
                                )
                            else:
                                image_url = "{}{}_{}.png".format(
                                    voucher_type_img_url_prefix,
                                    "monthly",
                                    voucher_type_id
                                )
                        else:
                            if (
                                company == WlCompany.COMPANY_CODE_ENTERTAINER_HSBC and
                                _category == 'services'
                            ):
                                voucher_image_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX_HS
                            else:
                                if (
                                    company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS and
                                    (
                                        _category == 'services' or
                                        _category == 'travel'
                                    )
                                ):
                                    voucher_image_prefix = VOUCHER_RESTRICTION_IMAGE_URL_PREFIX
                                else:
                                    voucher_image_prefix = VOUCHER_TYPE_IMAGE_URL_PREFIX

                            if replace_241_type_with_141:
                                image_url = "{}{}_{}{}.png".format(
                                    voucher_image_prefix,
                                    _category,
                                    voucher_type_id,
                                    end_format
                                )
                            else:
                                image_url = "{}{}_{}.png".format(
                                    voucher_image_prefix,
                                    _category,
                                    voucher_type_id
                                )

                    if image_type == IMAGE_TYPE_VOUCHER_RESTRICTION:
                        image_url_prefix = cls.get_image_url_prefix(company)
                        image_url = "{}{}_{}.png".format(
                            image_url_prefix,
                            _category,
                            voucher_restriction_id
                        )

                    if image_type == IMAGE_TYPE_PARTY_SIZE:
                        image_url_prefix = cls.get_image_url_prefix(company)
                        image_url = "{}{}{}.png".format(
                            image_url_prefix,
                            "party_size_",
                            _category
                        )

        return image_url

    @staticmethod
    def get_image_url_prefix(image_type):
        """
        Gets image url prefix.
        :rtype: str
        """
        if image_type == IMAGE_TYPE_VOUCHER_TYPE:
            return VOUCHER_TYPE_IMAGE_URL_PREFIX
        if image_type == IMAGE_TYPE_VOUCHER_RESTRICTION:
            return VOUCHER_RESTRICTION_IMAGE_URL_PREFIX
        if image_type == IMAGE_TYPE_PARTY_SIZE:
            return PARTY_SIZE_IMAGE_URL_PREFIX
