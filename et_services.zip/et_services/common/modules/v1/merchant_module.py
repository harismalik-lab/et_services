import json
from _md5 import md5


class MerchantModule(object):

    @staticmethod
    def process_merchant(merchant):
        """
        Process merchant after getting from db, sets image urls and encrypts merchant pin etc.
        """
        try:
            merchant['merchant_pin'] = md5(merchant.get('merchant_pin', '').encode()).hexdigest()
        except Exception:
            merchant['merchant_pin'] = md5('0000'.encode()).hexdigest()
        hero_urls = []
        hero_small_urls = []
        hero_urls_old = []
        hero_small_urls_old = []
        if merchant['p3_hero_image_retina']:
            hero_urls.append(merchant['p3_hero_image_retina'])
        if merchant['photo_url']:
            hero_urls.append(merchant['photo_url'])
        if merchant['p3_hero_image_non_retina']:
            hero_small_urls.append(merchant['p3_hero_image_non_retina'])
        if merchant['photo_small_url']:
            hero_small_urls.append(merchant['photo_small_url'])
        if merchant.get('hero_urls'):
            hero_urls_old = json.loads(merchant['hero_urls'])
        if merchant.get('hero_small_urls'):
            hero_small_urls_old = json.loads(merchant['hero_small_urls'])

        merchant['hero_urls'] = hero_urls + hero_urls_old
        merchant['hero_small_urls'] = hero_small_urls + hero_small_urls_old

        images_360 = {}
        if merchant['is_opted_in_for_360_image'] and merchant['p3_360_degree_image']:
            count = 1
            for hero_url in merchant['hero_urls']:
                if count > 1:
                    break
                images_360[hero_url] = merchant['p3_360_degree_image']
                count += 1
            hero_images_360 = images_360
        else:
            hero_images_360 = {}
        merchant['hero_images_360'] = hero_images_360
