from company_config_service.common.constants import SUPPORTED_LOCALES

LOG_SUB_FOLDERS = []
MESSAGE_KEYS = ('restaurants_and_bars', 'greetings')
ISO_CODE = 'iso_code'
PRODUCT_SKU = 'product_sku'
USER_GROUP = 'user_group'
IS_NEW = 'is_new'
IS_MEMBER = 'is_member'
IS_TRAVEL = 'is_travel'
IS_CHEERS = 'is_cheers'
IS_DELIVERY = 'is_delivery'
IS_MORE_SA = 'is_more_sa'

PRODUCT_MAPPING_SCHEMA = {
    USER_GROUP: {
        'type': int,
        'required': True
    },
    PRODUCT_SKU: {
        'type': str,
        'required': True
    },
    ISO_CODE: {
        'type': str,
        'required': True,
        'optional_composite_key': IS_TRAVEL
    },
    IS_CHEERS: {
        'type': bool,
        'required': False,
        'default': False
    },
    IS_NEW: {
        'type': bool,
        'required': False,
        'default': False
    },
    IS_MEMBER: {
        'type': bool,
        'required': False,
        'default': False
    },
    IS_TRAVEL: {
        'type': bool,
        'required': False,
        'default': False
    },
    IS_DELIVERY: {
        'type': bool,
        'required': False,
        'default': False
    },
    IS_MORE_SA: {
        'type': bool,
        'required': False,
        'default': False
    }
}
COMPANY_CONFIG_LIST = [
    {'key': 'is_captcha_verification', 'type': 'bool', 'default_value': False},
    {'key': 'is_s_p', 'type': 'bool', 'default_value': False},
    {'key': 'is_live_chat_enabled', 'type': 'bool', 'default_value': False},
    {'key': 'is_getaways_enable', 'type': 'bool', 'default_value': False},
    {'key': 'lookup_update_columns', 'type': 'text', 'default_value': 'first_name, last_name'},
    {'key': 'booking_enquiry_email', 'type': 'text', 'default_value': ''},
    {'key': 'wl_key_support_email', 'type': 'text', 'default_value': ''},
    {'key': 'login_type', 'type': 'option', 'options': ['uuid', 'email']},
    {'key': 'verify_bin_pattern', 'type': 'bool', 'default_value': False},
]

COMPANY_PRODUCTS_CONFIG = [
    {'key': PRODUCT_SKU, 'type': 'text', 'required': True},
    {'key': ISO_CODE, 'type': 'text', 'required': True},
    {'key': USER_GROUP, 'type': 'number', 'required': True},
    {'key': IS_TRAVEL, 'type': 'bool', 'required': False, 'default_value': False},
    {'key': IS_MORE_SA, 'type': 'bool', 'required': False, 'default_value': False},
    {'key': IS_MEMBER, 'type': 'bool', 'required': False, 'default_value': False},
    {'key': IS_DELIVERY, 'type': 'bool', 'required': False, 'default_value': False},
    {'key': IS_NEW, 'type': 'bool', 'required': False, 'default_value': False},
    {'key': IS_CHEERS, 'type': 'bool', 'required': False, 'default_value': False}
]

COMPANY_CREATION_CONFIG = [
    {'key': 'name', 'type': 'text', 'required': True},
    {'key': 'code', 'type': 'text', 'required': True},
    {'key': 'logo_url', 'type': 'text', 'required': False},
    {'key': 'description', 'type': 'text', 'required': False},
    {'key': 'api_url', 'type': 'text', 'required': False},
]

COMPANY_CREATION_CONFIG_META = {
    "primary_field": "code",
    "alias": "code",
    "display_keys": ["name", "code"]
}
COMPANY_TRANSLATION_CONFIG = [
    {'key': 'message_key', 'type': 'option', 'required': True, 'options': MESSAGE_KEYS},
    {'key': 'locale', 'type': 'option', 'required': True, 'options': SUPPORTED_LOCALES}
]

DEFAULT_COMPANY_RULES = (
    'booking_enquiry_email',
    'is_captcha_verification',
    'is_getaways_enable',
    'is_live_chat_enabled',
    'is_s_p',
    'login_type',
    'lookup_update_columns',
    'replace_241_type_with_141_locations',
    'verify_bin_pattern',
    'wl_key_support_email',
    'is_multiple_keys_allowed'
)
