"""
This module contains authentication logic
"""
import json
from base64 import b64decode

from flask import request
from flask_jwt_extended.exceptions import InvalidHeaderError, NoAuthorizationError
from flask_jwt_extended.view_decorators import ctx_stack, wraps
from jwt import InvalidAlgorithmError, decode
from jwt.exceptions import InvalidSignatureError
from werkzeug.exceptions import Forbidden, Unauthorized

from company_config_service.common.constants import (
    INVALID_JWT, JWT_HEADER_ERROR_MESSAGE, JWT_SIGNATURE_MISMATCH, MISSING_JWT_ERROR_MESSAGE
)
from company_config_service.common.models.business import Business
from company_config_service.common.utils.authentication import get_jw_token_identity, process_exception


def token_decorator(fn):
    @wraps(fn)
    def validator(self, *args, **kwargs):
        return jwt_token_required_wl(fn)(self, *args, **kwargs)
    return validator


def jwt_token_required_wl(fn):
    """
    If you decorate a vew with this, it will ensure that the requester has a
    valid JWT before calling the actual view. This does not check the freshness
    of the token.
    See also: fresh_jwt_required()
    :param fn: The view function to decorate
    """
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        if not hasattr(ctx_stack.top, 'jwt_identity'):
            jwt_data = decode_jwt_from_header()
            ctx_stack.top.jwt_identity = jwt_data
        data = get_jw_token_identity()
        if data and data.get('api_key'):
            return fn(self, *args, **kwargs)
        elif data and data.get('error_msg'):
            exception_to_be_raised = Unauthorized("Unauthorized")
            data = data.get('error_msg')
            self.status_code = 401
            self.code = 401
            self.send_response_flag = True
            self.process_request_exception(
                code=self.code,
                status_code=self.status_code,
                message=data,
                exception_raised=exception_to_be_raised
            )
            self.remove_logger_handlers()
            return self.send_response(data, self.status_code)
        # if token is inactive or wrong token
        data = INVALID_JWT
        self.status_code = 403
        self.code = 403
        self.send_response_flag = True
        exception_to_be_raised = Forbidden("You are not allowed to access this application")
        self.process_request_exception(
            code=self.code,
            status_code=self.status_code,
            message=data,
            exception_raised=exception_to_be_raised
        )
        self.remove_logger_handlers()
        return self.send_response(data, self.status_code)
    return wrapper


def get_verified_jwt_payload():
    jwt_bearer = request.environ.get('HTTP_AUTHORIZATION')
    if jwt_bearer:
        jwt_bearer = jwt_bearer.split(' ')[1]
        payload = decode(jwt_bearer, verify=False)
        header = b64decode(jwt_bearer.split('.')[0])
        jwt_algorithm = json.loads(header.decode()).get('alg')
        api_key = payload.get('api_key')
        if not api_key:
            raise Exception("Expected 'api_key' non provided.")
        business_info = Business.get_active_by_api_key(api_key)
        if business_info:
            secret_key = business_info.secret_key
            data = decode(jwt_bearer, secret_key, algorithms=[jwt_algorithm])
            data['name'] = business_info.name
            data['id'] = business_info.id
            data['is_active'] = business_info.is_active
            data['company_creation_limit'] = business_info.company_creation_limit
            return data
        raise InvalidSignatureError
    raise InvalidHeaderError


def decode_jwt_from_header():
    """
    Decodes JWT from authorization header and get identity
    :return: JWT identity or exception if raised
    """
    try:
        data = get_verified_jwt_payload()
    except InvalidHeaderError:
        data = {'error_msg': JWT_HEADER_ERROR_MESSAGE}
    except NoAuthorizationError:
        data = {'error_msg': MISSING_JWT_ERROR_MESSAGE}
    except (InvalidSignatureError, InvalidAlgorithmError):
        data = {'error_msg': JWT_SIGNATURE_MISMATCH}
    except Exception as exception_raised:
        error = process_exception(exception_raised)
        data = {'error_msg': error}
    return data
