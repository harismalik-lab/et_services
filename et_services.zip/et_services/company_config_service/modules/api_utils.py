"""
API Utils reside here
"""
from flask import g, request

from _md5 import md5
from company_config_service.common.models.location import Location
from company_config_service.common.utils.custom_request_fields_parser import custom_dict_parser
from company_config_service.modules.api_constants import PRODUCT_MAPPING_SCHEMA

cache = g.cache


def product_schema_validator(_):
    """
    Validates product_mappings
    """
    product_mappings = request.get_json()['product_mappings']
    for product_mapping in product_mappings:
        custom_dict_parser(product_mapping, PRODUCT_MAPPING_SCHEMA)
    return product_mappings


def generate_product_mapping_hash(location_id, product_sku, user_group):
    """
    Returns product mappings hash
    :rtype: str
    """
    return md5('{}{}{}'.format(location_id, product_sku, user_group).encode()).hexdigest()


@cache.memoize(timeout=1800)
def get_iso_codes_hash():
    """
    Returns iso and location ids hash map
    """
    iso_to_location_id_map = {}
    locations = Location.get_all_location_ids_and_iso_codes()
    for location in locations:
        iso_to_location_id_map[location.flag] = location.id
    return iso_to_location_id_map
