from company_config_service.app import create_app

app = create_app()['app']

if __name__ == "__main__":
    app.run()
