"""
This module contains routing for an app
"""
from company_config_service.app.api.v1.company_configs import CompanyConfigsAPI
from company_config_service.app.api.v1.company_messages_manager import CompanyMessagesManagerApi
from company_config_service.app.api.v1.company_product_configs import CompanyProductsConfigAPI
from company_config_service.app.api.v1.company_products_update import CompanyContentUpdateAPI
from company_config_service.app.api.v1.company_sepecific_translations import CompanySpecificTranslationConfigsApi
from company_config_service.app.api.v1.company_specific_configs import CompanySpecificConfigsAPI
from company_config_service.app.api.v1.company_translation_configs import CompanyTranslationConfigsApi
from company_config_service.app.api.v1.create_company import CreateCompanyAPI
from company_config_service.app.api.v1.create_company_configs import CreateCompanyConfigsAPI
from company_config_service.app.api.v1.get_companies import GetCompaniesAPI
from company_config_service.app.api.v1.get_company_products import GetCompanyProducts
from company_config_service.app.api.v1.update_company_rules import UpdateCompanyRulesAPI
from company_config_service.common.base_routing import BaseRouting


class CompanyConfigAPIV1(BaseRouting):
    api_version = '1'

    def set_routing_collection(self):
        self.routing_collection['create-company'] = {'view': CreateCompanyAPI, 'url': '/company'}

        self.routing_collection['company-product-api'] = {'view': CompanyContentUpdateAPI, 'url': '/company/products'}
        self.routing_collection['company-product-config-api'] = {'view': CompanyProductsConfigAPI,
                                                                 'url': '/company/products/configs'}  # noqa
        self.routing_collection['get-company-products-api'] = {'view': GetCompanyProducts,
                                                               'url': '/company/products/<string:company_code>'}  # noqa

        self.routing_collection['get-companies'] = {'view': GetCompaniesAPI, 'url': '/company'}

        self.routing_collection['company-translations'] = {
            'view': CompanyMessagesManagerApi, 'url': '/company/translations'
        }
        self.routing_collection['company-translation-configs'] = {
            'view': CompanyTranslationConfigsApi, 'url': '/company/translations/configs'
        }
        self.routing_collection['company-specific-translation-configs'] = {
            'view': CompanySpecificTranslationConfigsApi, 'url': '/company/translations/<string:company_code>'
        }
        self.routing_collection['company-configs'] = {'view': CompanyConfigsAPI, 'url': '/company/rules/configs'}
        self.routing_collection['update-company_rules'] = {
            'view': UpdateCompanyRulesAPI,
            'url': '/company/rules'
        }
        self.routing_collection['company-specific-configs'] = {'url': '/company/rules/<string:company_code>',
                                                               'view': CompanySpecificConfigsAPI}
        self.routing_collection['company_creation_config'] = {'url': '/company/configs',
                                                              'view': CreateCompanyConfigsAPI}
