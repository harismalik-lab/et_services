"""
Get API Configured products
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.models.wl_product import WlProduct
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.authentication import token_decorator


class GetCompanyProducts(BaseGetResource):
    request_parser = None
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/get_company_products_api.log',
        ),
        'name': 'get_company_products'
    }
    validators = [token_decorator]

    def initialize_local_variables(self):
        """
        Initializes local variables
        """
        self.business_data = get_jw_token_identity()

    def get_company(self, **kwargs):
        self.company_code = kwargs['company_code']
        company = WlCompany.get_by_code_and_business_id(self.company_code, self.business_data['id'])
        if not company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No company found against company code '{}'".format(self.company_code),
            )
            return self.send_response(self.response, self.status_code)

    def get_company_products(self):
        """
        Gets products bound with specified company
        """
        self.wl_products = []
        for product in WlProduct.get_active_by_company(self.company_code):
            self.wl_products.append(product._asdict())

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        data = {'products': self.wl_products}
        self.response = self.generate_response_dict(data=data)
        self.status_code = codes.OK
        return self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        self.initialize_local_variables()
        self.get_company(**kwargs)
        if self.send_response_flag:
            return
        self.get_company_products()
        self.generate_final_response()
