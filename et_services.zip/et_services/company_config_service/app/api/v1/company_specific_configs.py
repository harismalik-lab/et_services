"""
Company Specific Configs API
"""
from flask import current_app
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from common.constants import COMMA_BASED_API_CONFIG_KEYS
from common.utils.api_utils import convert_api_config_value_to_list, get_api_configurations
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.authentication import token_decorator


class CompanySpecificConfigsAPI(BaseGetResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_specific_configs_api.log',
        ),
        'name': 'company_specific_configs'
    }
    validators = [token_decorator]

    def initialize_local_variables(self):
        """
        Initializes local variables
        """
        self.business_data = get_jw_token_identity()

    def validate_company_owned_by_business(self):
        """
        Validates whether targeted company is owned by business
        """
        company = WlCompany.get_by_code_and_business_id(self.company, self.business_data['id'])
        if not company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No company found against company code '{}'".format(self.company),
            )
            return
        self.is_multiple_allowed = company.is_multiple_allowed

    def get_company_code(self, **kwargs):
        self.company = kwargs.get('company_code')

    def get_company_configs(self):
        """
        get list of companies
        """
        configs = get_api_configurations(company=self.company, environment=current_app.config['ENV'].lower())
        for key, value in configs.items():
            if COMMA_BASED_API_CONFIG_KEYS.__contains__(key):
                configs[key] = convert_api_config_value_to_list(value)
        configs['is_multiple_allowed'] = bool(self.is_multiple_allowed)
        self.configs = configs

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'configs': self.configs,
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Handles the api flow
        """
        self.initialize_local_variables()
        self.get_company_code(**kwargs)
        self.validate_company_owned_by_business()
        if self.send_response_flag:
            return
        self.get_company_configs()
        self.generate_final_response()
