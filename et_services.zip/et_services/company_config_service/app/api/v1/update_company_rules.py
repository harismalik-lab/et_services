"""
Company Creation API
"""
from flask import current_app, request
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BasePostResource
from company_config_service.common.models.api_configuration import ApiConfiguration
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.api_constants import DEFAULT_COMPANY_RULES
from company_config_service.modules.authentication import token_decorator


class UpdateCompanyRulesAPI(BasePostResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/update_company_rules.log',
        ),
        'name': 'update_company_rules'
    }
    validators = [token_decorator]

    def validate_request_json(self):
        """
        Validates if request has a valid json
        """
        if not request.json:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Missing required field 'company_code'"
            )
            return

    def populate_request_arguments(self):
        self.company_code = request.json.get('company_code', '')
        self.company_rules = request.json.get('api_configurations', [])

    def initialize_local_variables(self):
        """
        Initializes local variables
        """
        self.business_data = get_jw_token_identity()
        self.environment = current_app.config.get('ENV')
        self.wl_company = None
        self.invalid_rules = []
        self.valid_rules = []

    def validate_company(self):
        """
        Validates whether targeted company exists and is owned by business
        """
        if not self.company_code:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Missing required field 'company_code'"
            )
            return

        self.wl_company = WlCompany.get_active_by_code(self.company_code)
        if not self.wl_company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Company with code '{}' doesn't exists, please choose a different one.".format(
                    self.company_code
                )
            )
            return self.send_response(self.response, self.status_code)
        elif self.wl_company.business_id != self.business_data.get('id'):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid company code '{}'. Please choose a company that you have created.".format(
                    self.company_code
                )
            )
            return self.send_response(self.response, self.status_code)

    def validate_rules(self):
        """
        Validate rules given in json are valid
        """
        self.rules = {list(rule.keys())[0]: index for index, rule in enumerate(self.company_rules)}
        self.invalid_rules = list(self.rules.keys() - set(DEFAULT_COMPANY_RULES))
        if self.invalid_rules:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid company rule '{}'. Please choose a valid rules.".format(
                    self.invalid_rules[0]
                )
            )
            return self.send_response(self.response, self.status_code)

    def update_wl_company_rules(self):
        """
        Update rules related to wl company
        """
        if 'is_multiple_keys_allowed' in self.rules.keys():
            self.wl_company.is_multiple_allowed = self.company_rules[self.rules.get('is_multiple_keys_allowed')].get(
                'is_multiple_keys_allowed'
            )
            self.wl_company.update_record()
            self.valid_rules.append('is_multiple_keys_allowed')
            self.rules.pop('is_multiple_keys_allowed')

    def update_rules(self):
        """
        Update rules related to api configuration
        """
        existing_rules = ApiConfiguration.get_configuration_by_company(
            company=self.company_code,
            environment=self.environment
        )

        for rule in existing_rules:
            if rule.config_key in self.rules.keys():
                rule_value = self.company_rules[self.rules[rule.config_key]].get(rule.config_key)
                if isinstance(rule_value, list):
                    rule_value = ', '.join(rule_value)
                rule.config_value = rule_value
                self.valid_rules.append(rule.config_key)
                self.rules.pop(rule.config_key)
        if existing_rules:
            ApiConfiguration.bulk_update()

    def add_rules(self):
        """
        Add rules in api configuration
        """
        objects = []
        for rule_key, rule_index in self.rules.items():
            rule_value = self.company_rules[rule_index][rule_key]
            if isinstance(rule_value, list):
                rule_value = ', '.join(rule_value)
            objects.append(
                ApiConfiguration(
                    config_key=rule_key,
                    config_value=rule_value,
                    company=self.company_code,
                    environment=self.environment
                )
            )
            self.valid_rules.append(rule_key)

        if objects:
            ApiConfiguration.bulk_insert(objects)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'company_code': self.company_code,
            'rules_added_or_updated': self.valid_rules
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the api flow
        """
        self.validate_request_json()
        if self.send_response_flag:
            return
        self.populate_request_arguments()
        self.initialize_local_variables()
        self.validate_company()
        if self.send_response_flag:
            return
        self.validate_rules()
        if self.send_response_flag:
            return
        self.update_wl_company_rules()
        self.update_rules()
        self.add_rules()
        self.generate_final_response()
