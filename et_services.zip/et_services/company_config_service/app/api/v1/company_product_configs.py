"""
Company Products Config API
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.common.models.location import Location
from company_config_service.modules.api_constants import COMPANY_PRODUCTS_CONFIG
from company_config_service.modules.authentication import token_decorator


class CompanyProductsConfigAPI(BaseGetResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_products_configs_api.log',
        ),
        'name': 'company_products_configs'
    }
    validators = [token_decorator]

    def get_locations(self):
        """
        prepare location list containing objects of id, default names and iso code
        :return:
        """
        self.locations = [row._asdict() for row in Location.get_all_location_ids_default_names_and_iso_codes()]

    def prepare_final_response(self):
        """
        Prepares final response json
        """
        self.send_response_flag = True
        data = {
            'company_products_config': COMPANY_PRODUCTS_CONFIG,
            'locations': self.locations,
            'expects': 'list'
        }
        self.response = self.generate_response_dict(data=data)
        self.status_code = codes.OK

    def process_request(self, *args, **kwargs):
        self.get_locations()
        self.prepare_final_response()
