"""
Company Content update API
"""

from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.app.api.v1.validations.company_content_validator import company_content_parser
from company_config_service.common.base_resource import BasePostResource
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.models.wl_product import WlProduct
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.api_constants import (
    IS_CHEERS, IS_DELIVERY, IS_MEMBER, IS_MORE_SA, IS_NEW, IS_TRAVEL, ISO_CODE, PRODUCT_SKU, USER_GROUP
)
from company_config_service.modules.api_utils import generate_product_mapping_hash, get_iso_codes_hash
from company_config_service.modules.authentication import token_decorator


class CompanyContentUpdateAPI(BasePostResource):
    request_parser = company_content_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_products_update_api.log',
        ),
        'name': 'company_products'
    }
    validators = [token_decorator]

    def populate_request_arguments(self):
        self.product_mappings = self.request_args.get('product_mappings')
        self.company = self.request_args.get('company')

    def initialize_local_variables(self):
        """
        Initializes local variables
        """
        self.business_data = get_jw_token_identity()

    def validate_company_owned_by_business(self):
        """
        Validates whether targeted company is owned by business
        """
        company = WlCompany.get_by_code_and_business_id(self.company, self.business_data['id'])
        if not company:
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="No company found against company code '{}'".format(self.company),
            )
            return self.send_response(self.response, self.status_code)

    def get_location_ids_against_iso(self):
        """
        Gets location ids against provided iso codes
        """
        self.iso_to_location_id_map = get_iso_codes_hash()

    def extract_data_to_be_validated(self):
        """
        Extract mappings attributes which needs to be validated first
        """
        self.product_skus = []
        self.product_mapping_hash = {}
        for _index, mapping in enumerate(self.product_mappings):
            try:
                location_id = None
                if mapping.get(ISO_CODE):
                    mapping[ISO_CODE] = mapping[ISO_CODE].upper()
                    location_id = self.iso_to_location_id_map[mapping[ISO_CODE]]
                mapping[PRODUCT_SKU] = mapping[PRODUCT_SKU].upper()
                self.product_skus.append(mapping[PRODUCT_SKU])
                hash_key = generate_product_mapping_hash(location_id, mapping[PRODUCT_SKU], mapping[USER_GROUP])
                if self.product_mapping_hash.get(hash_key) is not None:
                    self.product_mappings[_index] = None
                self.product_mapping_hash[hash_key] = _index
            except KeyError:
                self.send_response_flag = True
                self.status_code = codes.UNPROCESSABLE_ENTITY
                self.response = self.generate_response_dict(
                    message="Unable to recognize iso code '{}'".format(mapping[ISO_CODE]),
                )
                return self.send_response(self.response, self.status_code)

    def get_already_bind_product_skus(self):
        """
        Gets product skus bind with provided company and provided locations
        """
        self.already_bind_products = []
        wl_products = WlProduct.get_active_by_company_and_skus(self.company, self.product_skus)
        for wl_product in wl_products:
            hash_key = generate_product_mapping_hash(
                wl_product.location_id,
                wl_product.product_sku,
                wl_product.user_group
            )
            if self.product_mapping_hash.get(hash_key) is not None:
                _index = self.product_mapping_hash[hash_key]
                self.product_mappings[_index] = None
                self.already_bind_products.append(self.product_mappings[_index])

    def create_product_binding(self):
        """
        Maps products skus against company
        """
        bindings = []
        for product_mapping in self.product_mappings:
            if product_mapping:
                temp_binding = WlProduct(
                    product_sku=product_mapping[PRODUCT_SKU],
                    wl_company=self.company,
                    location_id=self.iso_to_location_id_map[product_mapping[ISO_CODE]] if product_mapping.get(ISO_CODE) else None,  # noqa
                    user_group=product_mapping[USER_GROUP],
                    is_more_sa=product_mapping[IS_MORE_SA],
                    is_delivery=product_mapping[IS_DELIVERY],
                    is_cheers=product_mapping[IS_CHEERS],
                    ismember=product_mapping[IS_MEMBER],
                    isnew=product_mapping[IS_NEW],
                    istravel=product_mapping[IS_TRAVEL]
                )
                bindings.append(temp_binding)
        if bindings:
            WlProduct.bulk_insert(bindings)

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        self.response = self.generate_response_dict()
        self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Request Flow
        """
        self.initialize_local_variables()
        self.validate_company_owned_by_business()
        if self.send_response_flag:
            return
        self.get_location_ids_against_iso()
        self.extract_data_to_be_validated()
        if self.send_response_flag:
            return
        self.get_already_bind_product_skus()
        self.create_product_binding()
        self.generate_final_response()
