"""
Company Specific Translation Configs API
    - get `business_id` from jwt
    - get company from `**kwargs` -> `<company_code>` (url param)
    - validate company with `business_id`
    - If company validated:
        - get company specific active translations from db
        - convert orm objs to dict
    - generate response with data dict contains `company`, `company_translations` and return
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.common.models.company_messages import CompanyMessages
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.utils.authentication import get_jw_token_identity


class CompanySpecificTranslationConfigsApi(BaseGetResource):
    """
    @api {GET} /v1/company/translation/configs/<company_code> | get company company translation configs

    @apiVersion 1.0.0
    @apiName company/translation/configs/<company_code>
    @apiGroup CompanyConfigService
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_specific_translation_configs_api.log',
        ),
        'name': 'company_specific_translation_configs_api'
    }

    def initialize_local_variables(self):
        """
        declaring class variables
        """
        self.company_translations = []

    def get_business_id(self):
        """
        get business id from jwt payload
        """
        self.business_data = get_jw_token_identity()
        self.business_id = self.business_data['id']

    def validate_company(self, **kwargs):
        """
        check if company is valid with given business id
        """
        self.company_code = kwargs.get('company_code')
        if not WlCompany.get_by_code_and_business_id(self.company_code, self.business_id):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Company with given business id not found. Please enter valid company.",
            )
            return self.send_response(self.response, self.status_code)

    def get_company_translations(self):
        """
        - query database to get company specific records
        - if records found, convert into dict
        """
        self.company_translations_records = CompanyMessages.get_company_translations(self.company_code)
        for obj in self.company_translations_records:
            self.company_translations.append(obj._asdict())

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'company': self.company_code,
            'company_translations': self.company_translations,
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self, **kwargs):
        """
        Handles the api flow
        """
        self.initialize_local_variables()
        self.get_business_id()
        self.validate_company(**kwargs)
        if self.send_response_flag:
            return
        self.get_company_translations()
        self.generate_final_response()
