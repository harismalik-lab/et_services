"""
Company Configs API
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.modules.api_constants import COMPANY_CONFIG_LIST
from company_config_service.modules.authentication import token_decorator


class CompanyConfigsAPI(BaseGetResource):
    validators = [token_decorator]
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_configs_api.log',
        ),
        'name': 'company_configs'
    }

    def get_configs_list(self):
        """
        get list of companies
        """
        self.configs_list = COMPANY_CONFIG_LIST

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'configs': self.configs_list,
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the api flow
        """
        self.get_configs_list()
        self.generate_final_response()
