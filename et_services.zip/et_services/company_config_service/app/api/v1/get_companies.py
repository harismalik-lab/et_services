"""
Get Companies API
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.authentication import token_decorator


class GetCompaniesAPI(BaseGetResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/get_companies_api.log',
        ),
        'name': 'get_companies'
    }
    validators = [token_decorator]

    def initialize_local_variables(self):
        """
        Initializes local variables
        """
        self.business_data = get_jw_token_identity()

    def get_companies(self):
        """
        Fetches companies owned by a business
        """
        self.companies = []
        for company in WlCompany.get_active_companies_by_business_id(self.business_data['id']):
            self.companies.append(company._asdict())

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'companies': self.companies
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self, *args, **kwargs):
        """
        Request flow
        """
        self.initialize_local_variables()
        self.get_companies()
        self.generate_final_response()
