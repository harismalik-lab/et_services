"""
Create Company Configs API
"""
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BaseGetResource
from company_config_service.modules.api_constants import COMPANY_CREATION_CONFIG, COMPANY_CREATION_CONFIG_META


class CreateCompanyConfigsAPI(BaseGetResource):
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/create_company_configs_api.log',
        ),
        'name': 'create_company_configs'
    }

    def prepare_final_response(self):
        """
        Prepares final response json
        """
        self.send_response_flag = True
        data = {
            'configs': COMPANY_CREATION_CONFIG,
            'meta': COMPANY_CREATION_CONFIG_META
        }
        self.response = self.generate_response_dict(data=data)
        self.status_code = codes.OK

    def process_request(self):
        """
        Handles the api flow
        """
        self.prepare_final_response()
