"""
Company Creation API
"""
import secrets
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.app.api.v1.validations.create_company_validations import create_company_parser
from company_config_service.common.base_resource import BasePostResource
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.common.models.wl_company_api_configuration import WlCompanyApiConfiguration
from company_config_service.common.utils.authentication import get_jw_token_identity
from company_config_service.modules.authentication import token_decorator


class CreateCompanyAPI(BasePostResource):
    request_parser = create_company_parser
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/create_company_api.log',
        ),
        'name': 'create_company'
    }
    validators = [token_decorator]

    def populate_request_arguments(self):
        self.name = self.request_args.get('name')
        self.code = self.request_args.get('code')
        self.logo_url = self.request_args.get('logo_url')
        self.description = self.request_args.get('description')
        self.api_url = self.request_args.get('api_url')

    def initialize_local_variables(self):
        self.business_data = get_jw_token_identity()

    def validate_company_code(self):
        """
        Validates if company code does not already exist
        """
        if WlCompany.get_by_code(self.code):
            self.send_response_flag = True
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Invalid company code '{}'".format(self.code),
            )
            return self.send_response(self.response, self.status_code)

    def check_company_creation_limit(self):
        """
        Validates company creation limit by a business
        """
        owned_companies = WlCompany.get_number_of_companies_by_business_id(self.business_data['id'])
        if self.business_data['company_creation_limit'] <= owned_companies:
            self.send_response_flag = True,
            self.status_code = codes.UNPROCESSABLE_ENTITY
            self.response = self.generate_response_dict(
                message="Sorry! You have reached your company creation limit.".format(self.code),
            )
            return self.send_response(self.response, self.status_code)

    def setup_company(self):
        """
        Sets up company
        """
        self.company = WlCompany(
            name=self.name,
            code=self.code,
            description=self.description,
            logo=self.logo_url,
            business_id=self.business_data['id'],
            api_url=self.api_url
        )
        self.company.insert_record()
        self.company_api_config = WlCompanyApiConfiguration(
            company_code=self.company.code,
            api_token=secrets.token_hex(18),
            secret_key=secrets.token_urlsafe(16)
        )
        self.company_api_config.insert_record()

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {
            'company_code': self.company.code,
            'api_token': self.company_api_config.api_token,
            'secret_key': self.company_api_config.secret_key
        }
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the api flow
        """
        self.initialize_local_variables()
        self.validate_company_code()
        if self.send_response_flag:
            return
        self.check_company_creation_limit()
        if self.send_response_flag:
            return
        self.setup_company()
        self.generate_final_response()
