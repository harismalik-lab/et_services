"""
Company messages manager API
    - Get request.json as msgs_data
    - check if there is messages data.
        - get company from msgs_data
        - get set of msg_keys from msgs_data (from json)
        - get set of locales from msgs_data
            - return error response if invalid keys exist
        - validate message_keys and locales
            - return error response if invalid data
        - query database on the basis of company_code and msg_keys and get result
        - check if records need to be updated or to be inserted
            - maintain update/insert objs list
            - bulk insert or update records into database
            - generate response and return
"""
from flask import request
from requests import codes

from app_configurations.settings import ET_SERVICES_LOG_PATH
from company_config_service.common.base_resource import BasePostResource
from company_config_service.common.constants import SUPPORTED_LOCALES
from company_config_service.common.models.company_messages import CompanyMessages
from company_config_service.common.models.wl_company import WlCompany
from company_config_service.modules.api_constants import MESSAGE_KEYS
from company_config_service.modules.authentication import get_jw_token_identity, token_decorator


class CompanyMessagesManagerApi(BasePostResource):
    """
    @api {POST} /v1/company/translations | update/insert company messages

    @apiVersion 1.0.0
    @apiName company/translations
    @apiGroup CompanyConfigService
    """
    logger_info = {
        'filename': '{log_path}{file_path}'.format(
            log_path=ET_SERVICES_LOG_PATH,
            file_path='company_config_service/company_messages_manager_api.log',
        ),
        'name': 'company_messages_manager_api'
    }
    validators = [token_decorator]

    def populate_request_arguments(self):
        """
        populate from request data
        """
        self.msgs_data = request.get_json()

    def initialize_local_variables(self):
        """
        declaring class variables
        """
        self.msg_keys = set()
        self.obj_to_insert = []
        self.obj_to_be_updated = []

    def get_business_id(self):
        """
        get business id from jwt payload
        """
        self.business_data = get_jw_token_identity()
        self.business_id = self.business_data['id']

    def validate_company(self):
        """
        - check if there is messages data.
        - get company from msgs_data
        - check if company exists with corresponding business id
        """
        if not self.msgs_data:
            self.generate_error_response("Api expects a dict containing formatted data.")
            return self.send_response(self.response, self.status_code)
        try:
            self.company_code = self.msgs_data['company_code']
        except KeyError:
            self.generate_error_response("Missing required parameter 'company_code'.")
            return self.send_response(self.response, self.status_code)

        if not WlCompany.get_by_code_and_business_id(self.company_code, self.business_id):
            self.generate_error_response("Company with given business id not found. Please enter valid company.")
            return self.send_response(self.response, self.status_code)

    def process_request_data(self):
        """
        - get set of msg_keys from msgs_data (from json)
        - get set of locale_keys from msgs_data
        - validate message_keys and locales
            - return error response if invalid data
        - query database on the basis of company_code and msg_keys and get result
        - check if records need to be updated or tob be inserted
            - maintain update/insert objs list
            - bulk insert or update records into database
        """
        locale_keys = set()
        for record in self.msgs_data.get('translations'):
            self.msg_keys.add(record.get('message_key'))
            locale_keys.add(record.get('locale'))

        invalid_keys = self.msg_keys - set(MESSAGE_KEYS)
        invalid_locales = locale_keys - set(SUPPORTED_LOCALES)

        if invalid_keys:
            self.generate_error_response("'{}': invalid message keys.".format(invalid_keys))
            return self.send_response(self.response, self.status_code)
        if invalid_locales:
            self.generate_error_response("'{}': invalid locales.".format(invalid_locales))
            return self.send_response(self.response, self.status_code)

        self.translations = self.msgs_data.get('translations').copy()
        result = CompanyMessages.get_message_key_related_records(self.company_code, self.msg_keys)

        # update part
        for translation in self.msgs_data['translations']:
            if result:
                for obj in result:
                    if translation['message_key'] == obj.message_key and translation['locale'] == obj.locale:
                        obj.message_value = translation['message_value']
                        obj.is_active = 1
                        self.obj_to_be_updated.append(obj)
                        self.translations.remove(translation)

        # insert part
        for translation in self.translations:
            self.obj_to_insert.append(
                CompanyMessages(
                    company=self.company_code,
                    message_key= translation['message_key'],
                    message_value=translation['message_value'],
                    locale=translation['locale'],
                    is_active=1
                )
            )

        if self.obj_to_insert:
            CompanyMessages.bulk_upsert(self.obj_to_insert)
        else:
            CompanyMessages.bulk_upsert(self.obj_to_be_updated)

    def generate_error_response(self, message):
        """
        generate error response:
        - set flag as True
        - set status code
        - set message
        """
        self.send_response_flag = True
        self.status_code = codes.UNPROCESSABLE_ENTITY
        self.response = self.generate_response_dict(
            message=message,
        )

    def generate_final_response(self):
        """
        Generates final response
        """
        self.send_response_flag = True
        self.status_code = codes.OK
        data = {}
        self.response = self.generate_response_dict(data=data)
        self.send_response(self.response, self.status_code)

    def process_request(self):
        """
        Handles the api flow
        """
        self.populate_request_arguments()
        self.get_business_id()
        if self.send_response_flag:
            return
        self.validate_company()
        if self.send_response_flag:
            return
        self.initialize_local_variables()
        self.process_request_data()
        if self.send_response_flag:
            return
        self.generate_final_response()
