"""
This modules loads APIs for a specific service
"""
from flask import g

from company_config_service.app.routings.routings_v1 import CompanyConfigAPIV1

API_LOG_PATH = 'company_config_service/'


def api_urls():
    CompanyConfigAPIV1(app=g.app, name=CompanyConfigAPIV1.__name__).map_urls()
