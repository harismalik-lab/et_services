"""
This modules loads APIs for a specific service
"""
from flask import g

from config_service.app.routings.routings_v1 import ConfigAPIV1
from config_service.app.routings.routings_v2 import ConfigAPIV2

API_LOG_PATH = 'config_service/'


def api_urls():
    ConfigAPIV1(app=g.app, name=ConfigAPIV1.__name__).map_urls()
    ConfigAPIV2(app=g.app, name=ConfigAPIV2.__name__).map_urls()
