"""
This module contains routing for an app
"""

from config_service.app.api.v2.cheers_config.api import CheersConfigApiV2
from config_service.app.api.v2.configs.api import ConfigsApiV2
from config_service.app.api.v2.location_categories.api import LocationCategoriesApiV2
from config_service.app.api.v2.locations.api import LocationsApiV2
from config_service.app.routings.routings_v1 import ConfigAPIV1


class ConfigAPIV2(ConfigAPIV1):
    api_version = '2'

    def set_routing_collection(self):
        super().set_routing_collection()

        self.routing_collection['locations'] = {'view': LocationsApiV2, 'url': '/locations'}
        self.routing_collection['location_categories'] = {'view': LocationCategoriesApiV2,
                                                          'url': '/location/categories'}
        self.routing_collection['cheers_configs'] = {'view': CheersConfigApiV2, 'url': '/configs/cheers'}
        self.routing_collection['configs'] = {'view': ConfigsApiV2, 'url': '/configs'}
