"""
This module contains routing for an app
"""
from flask import current_app

from config_service.app.api.v1.app_tabs.api import AppTabsApi
from config_service.app.api.v1.configs.api import ConfigsApi
from config_service.app.api.v1.country.api import CountryApi
from config_service.app.api.v1.currencies.api import CurrenciesApi
from config_service.app.api.v1.filters.api import FiltersApi
from config_service.app.api.v1.location_categories.api import LocationCategoriesApi
from config_service.app.api.v1.locations.api import LocationsApi
from config_service.app.api.v1.travel_country.api import TravelCountryApi
from config_service.common.base_routing import BaseRouting


class ConfigAPIV1(BaseRouting):
    api_version = '1'
    base_url = current_app.config['CONFIG_SERVICE_AFFIX']

    def set_routing_collection(self):
        self.routing_collection['currencies'] = {'view': CurrenciesApi, 'url': '/currencies'}
        self.routing_collection['country'] = {'view': CountryApi, 'url': '/country'}
        self.routing_collection['travel_country'] = {'view': TravelCountryApi, 'url': '/travel/country'}
        self.routing_collection['locations'] = {'view': LocationsApi, 'url': '/locations'}
        self.routing_collection['filter'] = {'view': FiltersApi, 'url': '/filters'}
        self.routing_collection['location_categories'] = {'view': LocationCategoriesApi, 'url': '/location/categories'}
        self.routing_collection['app_tabs'] = {'view': AppTabsApi, 'url': '/app/tabs'}
        self.routing_collection['configs'] = {'view': ConfigsApi, 'url': '/configs'}
