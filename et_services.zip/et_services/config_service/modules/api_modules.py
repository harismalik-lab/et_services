"""
Contains API Specific Modules
"""

import datetime

from flask import g

from config_service.common import constants
from config_service.common.models.api_messages import APIMessages
from config_service.common.models.configuration_cheers import ConfigurationCheer
from config_service.common.models.home_screen_configurations import HomeScreenConfiguration
from config_service.common.models.wl_company import WlCompany
from config_service.common.models.wl_location_category import WlLocationCategory
from config_service.common.models.wl_user_group import WlUserGroup
from config_service.common.models.wl_validation import Wlvalidation
from config_service.common.utils.api_utils import category_title_to_lower, get_category_message_key
from config_service.modules.api_constants import ENTERTAINER

cache = g.cache


def get_api_categories(
        company,
        user_id,
        location_id,
        is_user_logged_in=False,
        purchasable_product_ids=[],
        purchased_product_ids=[],
        locale=constants.EN,
        is_user_purchased_any_affiliate_product=False
):
    """
    Gets the categories.
    :param is_user_purchased_any_affiliate_product:
    :param locale:
    :param purchased_product_ids:
    :param purchasable_product_ids:
    :param is_user_logged_in:
    :param location_id:
    :param user_id:
    :param company:
    :rtype: list
    """
    categories = []
    show_all_categories = False
    show_freemium_slider_icons = False
    categories_all = dict()

    if all([
        is_user_logged_in,
        is_user_purchased_any_affiliate_product
    ]):
        show_all_categories = True

    if show_all_categories:
        categories_all[constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS] = {
            "tile_id": 1,
            "category_id": 1,
            "is_free": False,
            "image": constants.IMAGE_RESTAURANTS_AND_BARS,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_RESTAURANTS_AND_BARS,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.RESTAURANTS_AND_BARS, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_RestaurantsandBars,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_RESTAURANTS_AND_BARS,
            "category_color": constants.COLOR_RESTAURANTS_AND_BARS,
            "map_pin_url": constants.MAP_PIN_RestaurantsandBars,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_RestaurantsandBars
        }
        categories_all[constants.CATEGORY_API_NAME_BODY] = {
            "tile_id": 2,
            "category_id": 2,
            "is_free": False,
            "image": constants.IMAGE_BODY,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_BODY,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.BODY, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Body,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_BODY,
            "category_color": constants.COLOR_BODY,
            "map_pin_url": constants.MAP_PIN_Body,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_Body
        }
        categories_all[constants.CATEGORY_API_NAME_LEISURE] = {
            "tile_id": 3,
            "category_id": 3,
            "is_free": False,
            "image": constants.IMAGE_LEISURE,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_LEISURE,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.LEISURE, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Leisure,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_LEISURE,
            "category_color": constants.COLOR_LEISURE,
            "map_pin_url": constants.MAP_PIN_Leisure,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_Leisure
        }
        categories_all[constants.CATEGORY_API_NAME_RETAIL] = {
            "tile_id": 7,
            "category_id": 7,
            "is_free": show_freemium_slider_icons,
            "image": constants.IMAGE_RETAIL,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_RETAIL,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.RETAIL, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Retail,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_RETAIL,
            "category_color": constants.COLOR_RETAIL,
            "map_pin_url": constants.MAP_PIN_Retail,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_Retail,
            "map_pin_selected_url": constants.MAP_PIN_SELECTED_RETAIL,
            "map_pin_selected_invalid_url": constants.MAP_PIN_SELECTED_INVALID_RETAIL
        }
        categories_all[constants.CATEGORY_API_NAME_SERVICES] = {
            "tile_id": 4,
            "category_id": 4,
            "is_free": False,
            "image": constants.IMAGE_SERVICES,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_SERVICES,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.SERVICES, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Services,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_SERVICES,
            "category_color": constants.COLOR_SERVICES,
            "map_pin_url": constants.MAP_PIN_Services,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_Services
        }
        categories_all[constants.CATEGORY_API_NAME_TRAVEL] = {
            "tile_id": 5,
            "category_id": 5,
            "is_free": False,
            "image": constants.IMAGE_TRAVEL,
            "banner_image": "",
            "api_name": constants.CATEGORY_API_NAME_TRAVEL,
            "display_name": HomeScreenConfiguration.get_category_label(
                category=constants.TRAVEL, locale=locale
            ),
            "analytics_category_name": constants.ANALYTICS_CATEGORY_CODE_Travel,
            "featured_merchant_icon_url": constants.FEATURED_MERCHANT_ICON_URL_TRAVEL,
            "category_color": constants.COLOR_TRAVEL,
            "map_pin_url": constants.MAP_PIN_Travel,
            "map_pin_invalid_url": constants.MAP_PIN_INVALID_Travel
        }

    user_groups = []
    if is_user_logged_in:
        user_groups = Wlvalidation.get_user_groups(company, user_id)
    if not user_groups:
        user_groups.append(WlUserGroup.DEFAULT_USER_GROUP)

    results = WlLocationCategory.get_location_categories(
        company, location_id, user_groups
    )

    categories_message_dict = get_categories_messages_dict(locale, company)

    for row in results:
        category = row._asdict()
        category['tile_id'] = 1
        api_name = category.get('api_name', '')
        category['banner_image'] = ''
        category["is_free"] = False
        category['title_color'] = constants.TITLE_COLOR
        constant_name = category.get('api_name', '').replace(' ', '')
        category['analytics_category_name'] = getattr(
            constants, 'ANALYTICS_CATEGORY_CODE_{}'.format(constant_name)
        )
        category['featured_merchant_icon_url'] = getattr(
            constants, 'FEATURED_MERCHANT_ICON_URL_{}'.format(constant_name)
        )
        category['category_color'] = category.get('color_code', '').replace("#", '')
        category_name = category_title_to_lower(api_name=api_name)
        if company == WlCompany.COMPANY_CODE_ENTERTAINER_GEMS:
            category['map_pin_url'] = constants.MAP_PIN_GENERIC_PIN_GEMS.format(category=category_name)
            category['map_pin_invalid_url'] = constants.Map_Pin_GENERIC_PIN_INVALID_GEMS.format(category=category_name)
        else:
            category['map_pin_url'] = getattr(constants, 'MAP_PIN_{}'.format(constant_name))
            category['map_pin_invalid_url'] = getattr(constants, 'MAP_PIN_INVALID_{}'.format(constant_name))
        try:
            del category['color_code']
        except KeyError:
            pass

        category_message_key = get_category_message_key(api_name)

        if categories_message_dict.get(category_message_key):
            category['display_name'] = categories_message_dict[category_message_key]
        else:
            category['display_name'] = HomeScreenConfiguration.get_category_label(
                category=api_name,
                locale=locale,
                company=company
            )
        try:
            del categories_all[api_name]
        except:
            pass

        categories.append(category)

    if show_all_categories:
        categories.extend(list(categories_all.values()))

    return categories


@cache.memoize(timeout=1800)
def get_categories_messages_dict(locale, company):
    messages_dict = dict()
    message_list = APIMessages.get_messages(locale, company)
    for message in message_list:
        messages_dict.update({message[0]: message[1]})
    return messages_dict


@cache.memoize(timeout=1800)
def get_cheers_configs(company, locale, location_id, _type):
    """
    Returns processed cheers configs
    :param company:
    :param locale:
    :param location_id:
    :param _type:
    :return:
    """
    current_date = datetime.datetime.now().strftime('%Y/%m/%d')
    cheers_configs = ConfigurationCheer.get_by_company_locale_and_type(
        company,
        location_id,
        locale,
        _type
    )
    # Default Configurations
    if not cheers_configs:
        cheers_configs = ConfigurationCheer.get_by_company_locale_and_type(
            ENTERTAINER,
            location_id,
            locale,
            _type
        )
    for _index, config in enumerate(cheers_configs):
        temp = config._asdict()
        temp['date_today'] = current_date
        cheers_configs[_index] = temp
    return cheers_configs
